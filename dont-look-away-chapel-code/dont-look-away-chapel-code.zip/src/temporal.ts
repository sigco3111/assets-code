import * as THREE from 'three';
import { Pass,FullScreenQuad } from 'three/addons/postprocessing/Pass.js';

// Temporal anti-aliasing. Each frame the camera shifts by a fraction of a pixel and blends with the frames before it,
// so a pixel smaller than a joint or a fold shows their average instead of flipping between them as you move.
// Nothing solid moves while it can be seen here, since the angels freeze when watched, so following the camera is enough.
const vertexShader=`varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}`;
const halton=(index:number,base:number)=>{let f=1,r=0;for(let i=index;i>0;i=Math.floor(i/base)){f/=base;r+=f*(i%base);}return r;};
export class TemporalPass extends Pass{
  private history=[0,1].map(()=>new THREE.WebGLRenderTarget(1,1,{type:THREE.HalfFloatType,minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,depthBuffer:false}));
  private resolve=new THREE.ShaderMaterial({depthTest:false,depthWrite:false,vertexShader,uniforms:{tColor:{value:null},tHistory:{value:null},tZ:{value:null},invViewProjection:{value:new THREE.Matrix4()},previous:{value:new THREE.Matrix4()},res:{value:new THREE.Vector2(1,1)},near:{value:.06},far:{value:65},fresh:{value:1}},fragmentShader:`#include <packing>
    varying vec2 vUv;uniform sampler2D tColor,tHistory,tZ;uniform mat4 invViewProjection,previous;uniform vec2 res;uniform float near,far,fresh;
    // Bright pixels are squeezed before blending, so one hot highlight can't dominate its neighbours and flash.
    vec3 squeeze(vec3 c){c=max(c,vec3(0.));return c/(1.+max(c.r,max(c.g,c.b)));}
    // Sharper than a plain filtered read, so the blending doesn't slowly soften the picture as you move.
    vec3 sharpHistory(vec2 uv){
      vec2 p=uv*res-.5,i=floor(p),f=p-i;
      vec2 w0=f*(-.5+f*(1.-.5*f)),w1=1.+f*f*(-2.5+1.5*f),w2=f*(.5+f*(2.-1.5*f)),w3=f*f*(-.5+.5*f);
      vec2 w12=w1+w2,t0=(i-.5)/res,t3=(i+2.5)/res,t12=(i+.5+w2/w12)/res;
      vec3 c=texture2D(tHistory,vec2(t12.x,t0.y)).rgb*w12.x*w0.y
        +texture2D(tHistory,vec2(t0.x,t12.y)).rgb*w0.x*w12.y
        +texture2D(tHistory,t12).rgb*w12.x*w12.y
        +texture2D(tHistory,vec2(t3.x,t12.y)).rgb*w3.x*w12.y
        +texture2D(tHistory,vec2(t12.x,t3.y)).rgb*w12.x*w3.y;
      float total=w12.x*w0.y+w0.x*w12.y+w12.x*w12.y+w3.x*w12.y+w12.x*w3.y;
      return max(c/total,vec3(0.));
    }
    void main(){
      vec2 px=1./res;vec3 current=squeeze(texture2D(tColor,vUv).rgb),m1=vec3(0.),m2=vec3(0.);float closest=1.;
      for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){
        vec2 o=vec2(float(x),float(y))*px;vec3 c=squeeze(texture2D(tColor,vUv+o).rgb);m1+=c;m2+=c*c;
        closest=min(closest,texture2D(tZ,vUv+o).r);
      }
      vec4 world=invViewProjection*vec4(vUv*2.-1.,closest*2.-1.,1.);world/=world.w;
      vec4 before=previous*world;vec2 uv=before.xy/before.w*.5+.5;
      // The torch is held in front of the camera, so it stays where it is on screen.
      if(perspectiveDepthToViewZ(closest,near,far)>-1.)uv=vUv;
      vec3 result=current;
      if(fresh<.5&&uv.x>0.&&uv.x<1.&&uv.y>0.&&uv.y<1.){
        // Keep the old value only as far as it could belong to what's here now, which is what stops ghost trails.
        m1/=9.;vec3 sigma=sqrt(max(m2/9.-m1*m1,vec3(0.)))*1.2+.002,history=sharpHistory(uv);
        vec3 offset=history-m1,scale=abs(offset/sigma);float over=max(scale.x,max(scale.y,scale.z));
        if(over>1.)history=m1+offset/over;
        float moved=length((uv-vUv)*res);
        result=mix(history,current,mix(.07,.2,clamp(moved/18.,0.,1.)));
      }
      gl_FragColor=vec4(result,1.);
    }`});
  private present=new THREE.ShaderMaterial({depthTest:false,depthWrite:false,vertexShader,uniforms:{tResolved:{value:null},res:{value:new THREE.Vector2(1,1)},sharpen:{value:.32}},fragmentShader:`
    varying vec2 vUv;uniform sampler2D tResolved;uniform vec2 res;uniform float sharpen;
    void main(){
      vec2 px=1./res;vec3 c=texture2D(tResolved,vUv).rgb;
      vec3 blur=(texture2D(tResolved,vUv+vec2(px.x,0.)).rgb+texture2D(tResolved,vUv-vec2(px.x,0.)).rgb+texture2D(tResolved,vUv+vec2(0.,px.y)).rgb+texture2D(tResolved,vUv-vec2(0.,px.y)).rgb)*.25;
      c=max(c+(c-blur)*sharpen,vec3(0.));
      gl_FragColor=vec4(c/max(1.-max(c.r,max(c.g,c.b)),.02),1.);
    }`});
  private quad=new FullScreenQuad();
  private width=1;private height=1;private frame=0;private fresh=true;
  private unjittered=new THREE.Matrix4();private previous=new THREE.Matrix4();private lastPosition=new THREE.Vector3();
  constructor(private camera:THREE.PerspectiveCamera,private depth:()=>THREE.Texture|null){super();}
  setSize(width:number,height:number){
    this.width=width;this.height=height;this.fresh=true;
    for(const t of this.history)t.setSize(width,height);
    this.resolve.uniforms.res.value.set(width,height);this.present.uniforms.res.value.set(width,height);
  }
  /** After a cut, nothing on screen can come from the frames before it. */
  restart(){this.fresh=true;}
  /** Call before rendering the scene. Pair with end(), since sight checks need the camera's true view. */
  begin(){
    if(!this.enabled)return;
    this.camera.updateMatrixWorld();this.unjittered.copy(this.camera.projectionMatrix);
    const i=this.frame++%16+1;
    this.camera.setViewOffset(this.width,this.height,halton(i,2)-.5,halton(i,3)-.5,this.width,this.height);
  }
  end(){if(this.enabled)this.camera.clearViewOffset();}
  render(renderer:THREE.WebGLRenderer,writeBuffer:THREE.WebGLRenderTarget,readBuffer:THREE.WebGLRenderTarget){
    const c=this.camera,r=this.resolve.uniforms,[target,old]=this.history;
    if(c.position.distanceTo(this.lastPosition)>1.5)this.fresh=true;this.lastPosition.copy(c.position);
    r.tColor.value=readBuffer.texture;r.tHistory.value=old.texture;r.tZ.value=this.depth()??readBuffer.depthTexture;
    r.near.value=c.near;r.far.value=c.far;r.fresh.value=this.fresh?1:0;r.previous.value.copy(this.previous);
    r.invViewProjection.value.copy(c.projectionMatrix).multiply(c.matrixWorldInverse).invert();
    this.quad.material=this.resolve;renderer.setRenderTarget(target);this.quad.render(renderer);
    this.present.uniforms.tResolved.value=target.texture;
    this.quad.material=this.present;renderer.setRenderTarget(this.renderToScreen?null:writeBuffer);this.quad.render(renderer);
    this.previous.copy(this.unjittered).multiply(c.matrixWorldInverse);
    this.history.reverse();this.fresh=false;
  }
}
