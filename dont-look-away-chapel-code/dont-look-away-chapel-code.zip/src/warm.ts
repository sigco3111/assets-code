import * as THREE from 'three';

// Lets the page answer between slow steps of loading. A hidden tab has no frames, so it doesn't wait for one.
export const nextFrame=()=>new Promise<void>(resolve=>{const late=setTimeout(resolve,100);requestAnimationFrame(()=>{clearTimeout(late);setTimeout(resolve);});});

// JavaScript finishing isn't the GPU finishing: wait for it without holding the page.
export async function settled(gl:WebGL2RenderingContext){
  const fence=gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE,0);gl.flush();
  do await nextFrame();while(fence&&gl.clientWaitSync(fence,0,0)===gl.TIMEOUT_EXPIRED);
  if(fence)gl.deleteSync(fence);
}

// A first draw prepares everything it touches, and all of it at once would hold the page for seconds.
// So textures go up one at a time and each mesh draws alone, with room to answer between them.
// `around` puts the scene in the state to warm, as the frame loop can change it between draws.
export async function warmScene(renderer:THREE.WebGLRenderer,scene:THREE.Scene,camera:THREE.Camera,around:(draw:()=>void)=>void=draw=>draw()){
  const gl=renderer.getContext() as WebGL2RenderingContext,target=new THREE.WebGLRenderTarget(4,4);
  let last=performance.now();
  const breathe=async()=>{if(performance.now()-last<30)return;await settled(gl);last=performance.now();};
  const meshes:THREE.Object3D[]=[],textures=new Set<THREE.Texture>();
  around(()=>scene.traverseVisible(object=>{
    const material=(object as THREE.Mesh).material;if(!material)return;
    meshes.push(object);
    for(const m of [material].flat())for(const value of Object.values(m))if((value as THREE.Texture)?.isTexture)textures.add(value as THREE.Texture);
  }));
  for(const texture of textures){renderer.initTexture(texture);await breathe();}
  for(const mesh of meshes){
    around(()=>{
      const culled=mesh.frustumCulled;
      for(const other of meshes)other.visible=other===mesh;
      mesh.frustumCulled=false;
      renderer.setRenderTarget(target);renderer.render(scene,camera);renderer.setRenderTarget(null);
      mesh.frustumCulled=culled;
      for(const other of meshes)other.visible=true;
    });
    await breathe();
  }
  target.dispose();
  await settled(gl);
}
