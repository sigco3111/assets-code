import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { Reflector } from 'three/addons/objects/Reflector.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { createPowerCabinet } from './power-cabinet';
import { candleStrength } from './horror';
import { ageStone,stoneNoise } from './stone';
import { blockGeometry,bookGeometry,candleGeometry,cornerGeometry,crossGeometry,flagstones,pierGeometry,pointedArc,ribStones,turnedGeometry,wallGeometry } from './stonework';

export type Obstacle = { x:number; z:number; w:number; d:number; h:number };
export type Station = { id:'power'|'key'|'gate'|'note'; position:THREE.Vector3; object:THREE.Group; label:string };
export const obstacles:Obstacle[]=[];
// Opaque inner volumes, separate from the generous navigation colliders.
export const sightBlockers:THREE.Box3[]=[];
export function insideFloor(x:number,z:number,r=0){
  return (Math.abs(x)<7.65-r && Math.abs(z)<15.6-r)||
    (x>7-r && x<13.6-r && z>-10.6+r && z<-3.4-r)||
    (x< -7+r && x> -13.6+r && z>3.4+r && z<10.6-r);
}
export function canStand(x:number,z:number,r=.25){
  if(!insideFloor(x,z,r))return false;
  return !obstacles.some(b=>Math.abs(x-b.x)<b.w/2+r&&Math.abs(z-b.z)<b.d/2+r);
}
export function segmentBlocked(a:THREE.Vector3,b:THREE.Vector3){
  const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z;
  for(const o of obstacles){
    let lo=0,hi=1;
    const p=[a.x,a.y,a.z],d=[dx,dy,dz],min=[o.x-o.w/2,0,o.z-o.d/2],max=[o.x+o.w/2,o.h,o.z+o.d/2];
    for(let k=0;k<3;k++){
      if(Math.abs(d[k])<1e-8){if(p[k]<min[k]||p[k]>max[k]){hi=-1;break;}}
      else{let t1=(min[k]-p[k])/d[k],t2=(max[k]-p[k])/d[k];if(t1>t2)[t1,t2]=[t2,t1];lo=Math.max(lo,t1);hi=Math.min(hi,t2);}
    }
    if(hi>=lo&&hi>.002&&lo<.98)return true;
  }
  return false;
}
export function random(seed=813){return ()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};}

export async function makeWorld(scene:THREE.Scene,onProgress:(label:string)=>void){
  sightBlockers.length=0;
  const rng=random(),loader=new THREE.TextureLoader();
  async function material(name:string,color:number,roughness:number,scale:number){
    const [map,normalMap,roughnessMap]=await Promise.all(['basecolor','normal','roughness'].map(type=>loader.loadAsync(`/assets/${name}-${type}.webp`).catch(()=>null)));
    for(const t of [map,normalMap,roughnessMap])if(t){t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(scale,scale);t.anisotropy=8;}
    if(map)map.colorSpace=THREE.SRGBColorSpace;
    return new THREE.MeshStandardMaterial({color,map,normalMap,roughnessMap,roughness,normalScale:new THREE.Vector2(.22,.22)});
  }
  onProgress('Dressing the chapel');
  const wood=await material('wood',0x6e5f4e,1,.4);
  const stone=new THREE.MeshStandardMaterial({color:0x99978b,roughness:.93}),floor=new THREE.MeshStandardMaterial({color:0x8e908c,roughness:.7});
  // Real stone in place of the painted blocks. Trim is cleaner than the walls, since damp and soot gather on broad faces.
  const stoneScan=async(name:string,color:boolean)=>{const t=await loader.loadAsync(`/assets/stone/${name}.jpg`);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=8;if(color)t.colorSpace=THREE.SRGBColorSpace;return t;};
  const [wallColor,wallNormal,wallRough,dressedColor,dressedNormal,dressedRough]=await Promise.all([stoneScan('wall-color',true),stoneScan('wall-normal',false),stoneScan('wall-roughness',false),stoneScan('dressed-color',true),stoneScan('dressed-normal',false),stoneScan('dressed-roughness',false)]);
  const noise=stoneNoise(),dressedMaps={color:dressedColor,normal:dressedNormal,roughness:dressedRough,noise},stoneMaps={color:wallColor,normal:wallNormal,roughness:wallRough,noise,render:{color:dressedColor,normal:dressedNormal,roughness:dressedRough}};
  const trim=stone.clone();trim.color.set(0xa09e92);ageStone(trim,dressedMaps,{tile:.7,relief:1,grime:.7});
  const darkStone=stone.clone();darkStone.color.set(0x646f71);ageStone(darkStone,dressedMaps,{tile:.7,relief:1});
  const metal=new THREE.MeshStandardMaterial({color:0x252a27,metalness:.8,roughness:.46});
  // Old iron and bronze: rough and pitted like everything else in here, not a smooth painted bar.
  const iron=ageStone(new THREE.MeshStandardMaterial({color:0x3f3c38,roughness:1}),dressedMaps,{tile:2.3,relief:.8,grime:0});
  const bronze=ageStone(new THREE.MeshStandardMaterial({color:0x6b5a3c,roughness:1}),dressedMaps,{tile:1.8,relief:.8,grime:0});
  const brass=new THREE.MeshStandardMaterial({color:0x80704d,metalness:.8,roughness:.48});
  const black=new THREE.MeshStandardMaterial({color:0x141918,roughness:1});
  // Wax glows a little from within, where the flame shines down through it.
  const waxGlow=document.createElement('canvas');waxGlow.width=4;waxGlow.height=64;{const t=waxGlow.getContext('2d')!,g=t.createLinearGradient(0,0,0,64);g.addColorStop(0,'#ffb060');g.addColorStop(.3,'#6a3a18');g.addColorStop(1,'#0c0603');t.fillStyle=g;t.fillRect(0,0,4,64);}
  const waxGlowTex=new THREE.CanvasTexture(waxGlow);waxGlowTex.colorSpace=THREE.SRGBColorSpace;
  const wax=new THREE.MeshStandardMaterial({color:0x6e6650,roughness:.8,emissive:0xffffff,emissiveMap:waxGlowTex,emissiveIntensity:.5});
  const ceiling=ageStone(new THREE.MeshStandardMaterial({color:0x2a3336,roughness:1}),dressedMaps,{tile:.4,relief:1,grime:0});
  ageStone(stone,stoneMaps,{tile:.42,relief:.95,wall:true});
  floor.vertexColors=true;ageStone(floor,dressedMaps,{tile:.72,relief:.8,grime:0,floor:true});
  const batches=new Map<THREE.Material,THREE.BufferGeometry[]>();
  const temp=new THREE.Object3D();
  function add(g:THREE.BufferGeometry,m:THREE.Material,x=0,y=0,z=0,rx=0,ry=0,rz=0){temp.position.set(x,y,z);temp.rotation.set(rx,ry,rz);temp.scale.set(1,1,1);temp.updateMatrix();g.applyMatrix4(temp.matrix);if(!batches.has(m))batches.set(m,[]);batches.get(m)!.push(g);}
  function box(w:number,h:number,d:number,x:number,y:number,z:number,m:THREE.Material=stone,solid=false,ry=0){
    let g:THREE.BufferGeometry;
    // Walls settle and blocks wear: only timber and fittings keep true edges.
    if(m===stone)g=wallGeometry(w,h,d,x,y,z,h>=3?.1:0);
    else if(m===trim||m===darkStone)g=blockGeometry(w,h,d);
    else{g=new THREE.BoxGeometry(w,h,d);const uv=g.attributes.uv,p=g.attributes.position,n=g.attributes.normal;
      for(let i=0;i<uv.count;i++){const nx=Math.abs(n.getX(i)),ny=Math.abs(n.getY(i));uv.setXY(i,nx>.5?p.getZ(i):p.getX(i),ny>.5?p.getZ(i):p.getY(i));}}
    add(g,m,x,y,z,0,ry);if(solid){
      obstacles.push({x,z,w,d,h:y+h/2});
      if(ry===0)sightBlockers.push(new THREE.Box3(new THREE.Vector3(x-w/2,y-h/2,z-d/2),new THREE.Vector3(x+w/2,y+h/2,z+d/2)).expandByScalar(-.005));
    }
  }
  function cylinder(r:number,rt:number,h:number,x:number,y:number,z:number,m=trim,segments=12){add(new THREE.CylinderGeometry(rt,r,h,segments),m,x,y,z);}
  function line(points:THREE.Vector3[],radius:number,m:THREE.Material=trim){add(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),Math.max(12,points.length*3),radius,6,false),m);}
  function archPoints(cx:number,z:number,w:number,spring:number,rise:number,axis='x'){
    const pts:THREE.Vector3[]=[];
    for(let i=0;i<=32;i++){const t=i/32,x=-w/2+w*t;const y=spring+rise*Math.sin(Math.PI*t)**.73;pts.push(axis==='x'?new THREE.Vector3(cx+x,y,z):new THREE.Vector3(cx,y,z+x));}return pts;
  }
  let ribSeed=1;
  function rib(points:THREE.Vector3[],width:number,depth=width){add(ribStones(new THREE.CatmullRomCurve3(points),width,ribSeed++,depth),trim);}
  // A wall carried over an opening on a pointed arch. `along` picks which way the wall runs.
  function archedWall(cu:number,fixed:number,half:number,spring:number,rise:number,top:number,thick:number,along:'x'|'z',wall=half,ribWidth=thick/2+.03){
    const arc=pointedArc(half,rise),shape=new THREE.Shape();
    shape.moveTo(-wall,spring);if(wall>half)shape.lineTo(-half,spring);
    for(const [u,v]of arc)shape.lineTo(u,spring+v);
    for(const [u,v]of [...arc].reverse())shape.lineTo(-u,spring+v);
    if(wall>half)shape.lineTo(wall,spring);shape.lineTo(wall,top);shape.lineTo(-wall,top);shape.closePath();
    const g=new THREE.ExtrudeGeometry(shape,{depth:thick,bevelEnabled:false});g.translate(0,0,-thick/2);
    if(along==='z')g.rotateY(Math.PI/2);g.computeVertexNormals();
    g.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(g.attributes.position.count*2),2));g.setIndex(Array.from({length:g.attributes.position.count},(_,i)=>i));
    add(g,stone,along==='z'?fixed:cu,0,along==='z'?cu:fixed);
    for(const s of [-1,1])rib(arc.map(([u,v])=>along==='z'?new THREE.Vector3(fixed,spring+v,cu+s*u):new THREE.Vector3(cu+s*u,spring+v,fixed)),ribWidth,.15);
  }
  // Stones along the foot of a wall, so it doesn't meet the floor in a ruled line.
  function footing(ax:number,az:number,bx:number,bz:number,nx:number,nz:number){
    const length=Math.hypot(bx-ax,bz-az);
    for(let t=0;t<length;){
      const l=Math.min(length-t,.5+rng()*.85),h=.16+rng()*.3,depth=.07+rng()*.15,mid=t+l/2,cx=ax+(bx-ax)*mid/length+nx*depth/2,cz=az+(bz-az)*mid/length+nz*depth/2;
      if(l>.2&&rng()>.12)nz===0?box(depth,h,l-.012,cx,h/2-.02,cz,trim):box(l-.012,h,depth,cx,h/2-.02,cz,trim);
      t+=l;
    }
  }
  function corner(x:number,z:number,h:number){add(cornerGeometry(.24,h),trim,x,h/2,z);}
  // Big arches are cut stone. Fine mouldings stay a single run.
  function arch(cx:number,z:number,w:number,spring:number,rise:number,axis='x',thickness=.12){const points=archPoints(cx,z,w,spring,rise,axis);if(thickness>=.1)rib(points,thickness);else line(points,thickness);}
  // Letters cut into stone: a dark cut with a little light along its lower lip.
  function engrave(lines:string[],w:number,h:number,x:number,y:number,z:number,rotation=0){
    const c=document.createElement('canvas');c.width=1024;c.height=Math.round(1024*h/w);const t=c.getContext('2d')!,size=Math.round(c.height/(lines.length+.7));t.textAlign='center';t.textBaseline='middle';t.font=`600 ${size}px Georgia`;
    for(const [dy,fill] of [[3,'rgba(255,238,205,.22)'],[0,'rgba(10,8,6,.9)']] as [number,string][]){t.fillStyle=fill;lines.forEach((l,i)=>t.fillText(l,512,c.height/2+(i-(lines.length-1)/2)*size*1.05+dy));}
    const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
    const cut=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:tex,transparent:true,roughness:1,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));cut.position.set(x,y,z);cut.rotation.y=rotation;scene.add(cut);
  }
  function plaque(text:string,w:number,h:number,x:number,y:number,z:number,rotation=0){
    const c=document.createElement('canvas');c.width=1024;c.height=512;const ctx=c.getContext('2d')!;
    ctx.fillStyle='#262d2c';ctx.fillRect(0,0,1024,512);ctx.strokeStyle='#a49774';ctx.lineWidth=3;ctx.strokeRect(25,25,974,462);ctx.textAlign='center';ctx.fillStyle='#b5ae98';ctx.font='42px Georgia';
    text.split('\n').forEach((l,i,a)=>ctx.fillText(l,512,256+(i-(a.length-1)/2)*65));
    const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
    const mesh=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:tex,roughness:.7,metalness:.2}));mesh.position.set(x,y,z);mesh.rotation.y=rotation;scene.add(mesh);return mesh;
  }
  // Continuous floor and stepped sanctuary.
  // The dark bed the paving lies in shows only down its joints.
  const bed=new THREE.MeshStandardMaterial({color:0x2c2822,roughness:1});
  // Far away a joint is thinner than a pixel, so it lifts towards the stone's tone and there's less contrast to flip between.
  bed.onBeforeCompile=shader=>{shader.vertexShader=`varying vec3 vBedWorld;\n${shader.vertexShader}`.replace('#include <project_vertex>','#include <project_vertex>\nvBedWorld=(modelMatrix*vec4(transformed,1.)).xyz;');shader.fragmentShader=`varying vec3 vBedWorld;\n${shader.fragmentShader}`.replace('#include <map_fragment>','#include <map_fragment>\ndiffuseColor.rgb*=mix(1.,3.2,smoothstep(5.,17.,length(cameraPosition-vBedWorld)));');};
  box(15.5,.25,31.5,0,-.17,0,bed);
  box(6,.25,7.3,10.6,-.17,-7,bed);box(6,.25,7.3,-10.6,-.17,7,bed);
  const paving=new THREE.Mesh(mergeGeometries([flagstones(-7.75,7.75,-15.75,15.75,31),flagstones(7.6,13.6,-10.6,-3.4,47),flagstones(-13.6,-7.6,3.4,10.6,59)]),floor);paving.receiveShadow=true;scene.add(paving);
  // Nave outer walls, leaving actual doorways to both rooms.
  for(const side of [-1,1]){
    const doorZ=side===1?-7:7;
    const spans:[number,number][]=[[-16,doorZ-1.5],[doorZ+1.5,16]];
    for(const [a,b]of spans)box(.5,10,b-a,side*7.9,5,(a+b)/2,stone,true);
    archedWall(doorZ,side*7.9,1.5,2.1,1.55,10,.5,'z',1.5,.42);
    for(const zz of [doorZ-1.6,doorZ+1.6])box(.3,2.1,.3,side*7.55,1.05,zz,trim);
    for(const [a,b]of [[-15.75,doorZ-1.78],[doorZ+1.78,15.75]])footing(side*7.65,a,side*7.65,b,-side,0);
    corner(side*7.55,-15.6,6.5);corner(side*7.55,15.6,6.5);
  }
  footing(-7.65,-15.7,7.65,-15.7,0,1);footing(-7.65,15.7,-1.85,15.7,0,-1);footing(1.85,15.7,7.65,15.7,0,-1);
  box(16,11,.6,0,5.5,-16,stone,true);box(6.5,10,.5,-4.9,5,16,stone,true);box(6.5,10,.5,4.9,5,16,stone,true);archedWall(0,16,1.65,2.4,1.7,10,.5,'x',1.65,.34);for(const x of [-1.8,1.8])box(.32,2.4,.3,x,1.2,15.64,trim);
  // Side rooms: coherent closed envelopes.
  for(const s of [-1,1]){
    const z=s===1?-7:7;
    box(.4,4.8,7.6,s*13.8,2.4,z,stone,true);
    box(6.2,4.8,.4,s*10.8,2.4,z-3.8,stone,true);box(6.2,4.8,.4,s*10.8,2.4,z+3.8,stone,true);
    box(6.2,.3,7.6,s*10.8,4.8,z,ceiling);
    footing(s*13.6,z-3.55,s*13.6,z+3.55,-s,0);footing(s*8.1,z-3.6,s*13.6,z-3.6,0,1);footing(s*8.1,z+3.6,s*13.6,z+3.6,0,-1);
    corner(s*13.5,z-3.5,4.8);corner(s*13.5,z+3.5,4.8);
  }
  // Piers carry a thick arcade and the wall above it. Slim shafts rise from each capital to carry the vault's ribs, so every rib lands on something.
  const bays=[-12,-6,0,6,12],vaultY=(x:number)=>5.92+4.3*Math.sin(Math.PI*(x+4.7)/9.4)**.73;
  for(const x of [-4.7,4.7])for(const z of bays){
    add(pierGeometry(x*7+z,3.25),trim,x,0,z);
    const inner=x-Math.sign(x)*.42;
    add(new THREE.CylinderGeometry(.085,.1,3.75,12),trim,inner,5.12,z);cylinder(.14,.1,.16,inner,3.34,z);cylinder(.12,.16,.16,inner,7,z);
    // The plinth's own footprint still blocks movement and sight.
    obstacles.push({x,z,w:1,d:1,h:.2});sightBlockers.push(new THREE.Box3(new THREE.Vector3(x-.495,.005,z-.495),new THREE.Vector3(x+.495,.195,z+.495)));
    obstacles.push({x,z,w:.85,d:.85,h:6.1});
    // This square stays inside the narrowest part of the round stone shaft.
    sightBlockers.push(new THREE.Box3(new THREE.Vector3(x-.2,.3,z-.2),new THREE.Vector3(x+.2,5.9,z+.2)));
    if(x<0)rib(Array.from({length:33},(_,i)=>{const px=-4.5+9*i/32;return new THREE.Vector3(px,vaultY(px),z);}),.17,.13);
    // Diagonal ribs follow the vault itself, from the shaft to the ridge.
    for(const s of [-1,1])rib(Array.from({length:17},(_,i)=>{const t=i/16,px=x*.96*(1-t);return new THREE.Vector3(px,vaultY(px),z+s*3*t);}),.09,.09);
  }
  for(const x of [-4.7,4.7])for(const z of [-15.75,15.75]){add(pierGeometry(x*11+z,3.25),trim,x,0,z);obstacles.push({x,z,w:1,d:1,h:.2});}
  for(const x of [-4.7,4.7])for(const [a,b]of [[-15.7,-12],[-12,-6],[-6,0],[0,6],[6,12],[12,15.7]]){
    const half=(b-a)/2;archedWall((a+b)/2,x,half-.38,3.25,2.7,7.1,.7,'z',half);
  }
  // Barrel vault, ridged cross sections, lateral aisle roofs.
  const positions:number[]=[],uvs:number[]=[],indices:number[]=[];
  for(let j=0;j<2;j++)for(let i=0;i<=48;i++){const t=i/48;positions.push(-4.7+9.4*t,5.95+4.3*Math.sin(Math.PI*t)**.73,-15.8+j*31.6);uvs.push(t*4,j*12);}
  for(let i=0;i<48;i++){indices.push(i,i+49,i+1,i+1,i+49,i+50);}
  const vault=new THREE.BufferGeometry();vault.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));vault.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));vault.setIndex(indices);vault.computeVertexNormals();ceiling.side=THREE.DoubleSide;add(vault,ceiling);
  for(const x of [-6.3,6.3])box(3.2,.2,32,x,6.5,0,ceiling);
  rib([new THREE.Vector3(0,10.18,-16),new THREE.Vector3(0,10.18,0),new THREE.Vector3(0,10.18,16)],.09);
  // Deep pointed window recesses and tracery.
  const paneCanvas=document.createElement('canvas');paneCanvas.width=256;paneCanvas.height=512;const pc=paneCanvas.getContext('2d')!;pc.fillStyle='#536b76';pc.fillRect(0,0,256,512);
  for(let row=-1;row<17;row++)for(let col=-1;col<7;col++){
    const x=col*48+(row%2)*24,y=row*36;pc.beginPath();pc.moveTo(x,y-36);pc.lineTo(x+24,y);pc.lineTo(x,y+36);pc.lineTo(x-24,y);pc.closePath();pc.fillStyle=['#556c78','#66797c','#465d69','#797d70'][Math.floor(rng()*4)];pc.fill();pc.strokeStyle='#1b292e';pc.lineWidth=2;pc.stroke();
  }
  for(let i=0;i<2500;i++){pc.fillStyle=`rgba(15,25,28,${rng()*.15})`;pc.fillRect(rng()*256,rng()*512,1+rng()*3,1+rng()*4);}
  // A century of dirt: soft smears over the glass, heaviest towards the bottom.
  for(let i=0;i<70;i++){const x=rng()*256,y=rng()**.6*512,r=14+rng()*46,g=pc.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(8,12,12,${.18+rng()*.4})`);g.addColorStop(1,'rgba(8,12,12,0)');pc.fillStyle=g;pc.fillRect(x-r,y-r,r*2,r*2);}
  const paneTex=new THREE.CanvasTexture(paneCanvas);paneTex.colorSpace=THREE.SRGBColorSpace;
  const windowMat=new THREE.MeshStandardMaterial({map:paneTex,emissiveMap:paneTex,emissive:0x8ca6bb,emissiveIntensity:.34,roughness:.35,metalness:.2,side:THREE.DoubleSide});
  for(const side of [-1,1])for(const z of [-12,-1,11]){
    box(.07,3.4,1.9,side*7.61,3.6,z,black);
    const shape=new THREE.Shape();shape.moveTo(-.8,-1.4);shape.lineTo(.8,-1.4);shape.lineTo(.8,1.1);shape.quadraticCurveTo(.7,1.8,0,2.4);shape.quadraticCurveTo(-.7,1.8,-.8,1.1);shape.closePath();const wg=new THREE.ShapeGeometry(shape,16);const wuv=wg.attributes.uv,wp=wg.attributes.position;for(let i=0;i<wuv.count;i++)wuv.setXY(i,(wp.getX(i)+.8)/1.6,(wp.getY(i)+1.4)/3.8);add(wg,windowMat,side*7.55,3.35,z,0,-side*Math.PI/2);
    box(.12,3.75,.07,side*7.47,3.82,z,trim);for(const offset of [-.82,.82])box(.12,2.75,.07,side*7.47,3.32,z+offset,trim);
    arch(side*7.45,z,1.8,4.45,1.3,'z',.11);
    box(.36,.2,2.2,side*7.5,1.95,z,trim);
    for(const y of [2.6,3.5,4.4])box(.026,.026,1.62,side*7.5,y,z,iron);
  }
  // Rose window: actual glass, leadwork, petal tracery and surrounding stone rings.
  const rose=new THREE.Group();rose.position.set(0,7.3,-15.64);scene.add(rose);
  const glassCanvas=document.createElement('canvas');glassCanvas.width=glassCanvas.height=1024;const ctx=glassCanvas.getContext('2d')!;
  ctx.fillStyle='#142b39';ctx.fillRect(0,0,1024,1024);
  const colors=['#405c6b','#9b7850','#708489','#5c697b','#9f8758','#3d5558'];
  for(let ring=0;ring<5;ring++)for(let i=0;i<36;i++){
    const a=i*Math.PI*2/36,r=ring*100;
    ctx.beginPath();ctx.arc(512,512,r+98,a,a+.168);ctx.arc(512,512,r+5,a+.168,a,true);ctx.closePath();ctx.fillStyle=colors[(i+ring*2)%colors.length];ctx.fill();ctx.strokeStyle='#172226';ctx.lineWidth=7;ctx.stroke();
  }
  for(let i=0;i<120;i++){const x=rng()*1024,y=rng()*1024,r=50+rng()*170,g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(6,9,10,${.12+rng()*.34})`);g.addColorStop(1,'rgba(6,9,10,0)');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2);}
  const glassTex=new THREE.CanvasTexture(glassCanvas);glassTex.colorSpace=THREE.SRGBColorSpace;
  const gm=new THREE.MeshStandardMaterial({map:glassTex,emissiveMap:glassTex,emissive:0xffffff,emissiveIntensity:1.25,roughness:.4,side:THREE.DoubleSide});
  rose.add(new THREE.Mesh(new THREE.CircleGeometry(2.15,80),gm));
  for(const r of [2.17,2.28,2.42,.52]){const t=new THREE.Mesh(new THREE.TorusGeometry(r,r===2.42?.1:.065,8,80),trim);t.position.z=.035;rose.add(t);}
  for(let i=0;i<12;i++){
    const a=i*Math.PI/6;const petal=new THREE.Mesh(new THREE.TorusGeometry(.57,.05,6,40),trim);petal.scale.set(.7,1.8,1);petal.position.set(Math.sin(a)*1.28,Math.cos(a)*1.28,.04);petal.rotation.z=-a;rose.add(petal);
    const spoke=new THREE.Mesh(new THREE.BoxGeometry(.045,1.65,.08),trim);spoke.position.set(Math.sin(a)*1.3,Math.cos(a)*1.3,.07);spoke.rotation.z=-a;rose.add(spoke);
  }
  // Altar, carved reredos, candles, devotional detail.
  box(4.4,.15,3.2,0,.065,-13.6,trim);box(3.7,.15,2.8,0,.2,-13.9,trim);
  box(2.9,1.05,1.1,0,.72,-14,trim,true);box(3.3,.18,1.4,0,1.33,-14,trim);box(3.02,.1,1.22,0,1.2,-14,trim);box(3.06,.14,1.26,0,.32,-14,trim);
  add(crossGeometry(2.3,1.15,.15,.09),bronze,0,3.55,-15.68);
  engrave(['IN SILENTIO','VIGILAMUS'],1.5,.375,0,.8,-13.446);
  // Pew rows. Open central aisle and side aisles are fully navigable.
  let pewModel:THREE.Group|null=null;
  try{pewModel=(await new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).loadAsync('/assets/pew-game.glb')).scene;}catch{/* Asset production preview uses the measured blockout. */}
  if(pewModel){
    pewModel.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(pewModel),size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3()),scale=2.8/size.x;
    const coords=[-1,1].flatMap(side=>[-7,-3.5,0,3.5,7].map(z=>({x:side*2.65,z})));
    pewModel.traverse(o=>{if(!(o as THREE.Mesh).isMesh)return;const m=o as THREE.Mesh,inst=new THREE.InstancedMesh(m.geometry,m.material,coords.length);
      coords.forEach(({x,z},i)=>{const matrix=new THREE.Matrix4().makeTranslation(x,0,z).multiply(new THREE.Matrix4().makeRotationY(Math.PI)).multiply(new THREE.Matrix4().makeScale(scale,scale,scale)).multiply(new THREE.Matrix4().makeTranslation(-center.x,-bounds.min.y,-center.z)).multiply(m.matrixWorld);inst.setMatrixAt(i,matrix);});inst.castShadow=true;inst.receiveShadow=true;scene.add(inst);
    });
  }
  for(const side of [-1,1])for(const z of [-7,-3.5,0,3.5,7]){
    const x=side*2.65;
    if(pewModel){
      obstacles.push({x,z,w:2.8,d:.95,h:1.3});continue;
    }
    box(2.8,.13,.6,x,.57,z,wood,true);box(2.8,.8,.14,x,.9,z+.34,wood);
    for(const xx of [x-1.38,x+1.38]){box(.15,.95,.8,xx,.5,z,wood);cylinder(.1,.1,.18,xx,1.06,z+.22,wood);box(.24,.11,.83,xx,1.02,z,wood);}
    for(const xx of [x-1,x+1])box(.13,.52,.42,xx,.26,z,wood);
    box(2.5,.12,.2,x,.17,z-.6,wood);
  }
  // Wrought iron entrance gate, animated as one group.
  const gate=new THREE.Group();gate.position.set(0,0,15.55);scene.add(gate);
  const meshBox=(w:number,h:number,d:number,x:number,y:number,z:number,m:THREE.Material,parent:THREE.Group)=>{const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;};
  // The bars follow the arch over them, rising to the middle.
  const gateArc=pointedArc(1.65,1.7);
  const gateHeight=(x:number)=>{const u=-Math.abs(x);for(let i=1;i<gateArc.length;i++)if(u<=gateArc[i][0]){const [a,b]=[gateArc[i-1],gateArc[i]],t=(u-a[0])/(b[0]-a[0]||1);return 2.4+a[1]+(b[1]-a[1])*t;}return 4.1;};
  for(let i=-7;i<=7;i++){const x=i*.2,h=gateHeight(x)-.32;meshBox(.035,h,.045,x,h/2,0,iron,gate);const tip=new THREE.Mesh(new THREE.ConeGeometry(.05,.17,4),iron);tip.position.set(x,h+.08,0);gate.add(tip);}
  for(const y of [.25,1.4,2.45])meshBox(3.02,.07,.065,0,y,0,iron,gate);
  box(2.1,.46,.05,0,5.05,15.7,trim);engrave(['SAINT ORISON','MDCCCLXXXIX'],1.7,.34,0,5.05,15.672,Math.PI);
  // Rooms: electrical switch cabinet and archive shelves.
  const cabinet=createPowerCabinet(dressedMaps);const power=cabinet.group;
  power.position.set(13.45,0,-7);power.rotation.y=-Math.PI/2;scene.add(power);
  const BOOK_TILES=8,spines=document.createElement('canvas');spines.width=1024;spines.height=512;{
    const t=spines.getContext('2d')!,tones=['#3a2118','#2a1c14','#46301c','#1f2a22','#2e1a1e','#3d3226','#23202a','#4a2a1a'],w=1024/BOOK_TILES;
    tones.forEach((tone,i)=>{
      const x=i*w;t.fillStyle=tone;t.fillRect(x,0,w,512);
      for(let k=0;k<420;k++){t.fillStyle=`rgba(${rng()>.6?'190,165,130':'0,0,0'},${rng()*.09})`;t.fillRect(x+rng()*w,rng()*512,1+rng()*7,1+rng()*18);}
      const shade=t.createLinearGradient(x,0,x+w,0);shade.addColorStop(0,'rgba(0,0,0,.55)');shade.addColorStop(.35,'rgba(0,0,0,0)');shade.addColorStop(.65,'rgba(0,0,0,0)');shade.addColorStop(1,'rgba(0,0,0,.55)');t.fillStyle=shade;t.fillRect(x,0,w,512);
      for(const b of [60,150,330,430]){t.fillStyle='rgba(0,0,0,.5)';t.fillRect(x,b+8,w,5);t.fillStyle='rgba(255,225,180,.12)';t.fillRect(x,b,w,8);}
      t.fillStyle=`rgba(170,135,80,${.14+rng()*.3})`;t.fillRect(x+w*.2,186,w*.6,3);t.fillRect(x+w*.2,262,w*.6,3);for(let k=0;k<4;k++)t.fillRect(x+w*.3,202+k*13,w*(.2+rng()*.3),3);
    });
  }
  const spineTex=new THREE.CanvasTexture(spines);spineTex.colorSpace=THREE.SRGBColorSpace;spineTex.anisotropy=8;
  const bookMaterial=new THREE.MeshStandardMaterial({map:spineTex,roughness:.82});
  for(const z of [4,10]){
    box(4.1,2.7,.45,-11,1.35,z,wood,true);
    for(const y of [.12,.8,1.5,2.2,2.8])box(4.3,.08,.6,-11,y,z-.08,wood);
    for(const shelf of [.16,.84,1.54])for(let x=-12.92;x<-9.2;){
      if(rng()<.07){x+=.12+rng()*.28;continue;}
      const w=.06+rng()*.07,h=.34+rng()*.27,d=.24+rng()*.1,lean=rng()<.09?(rng()-.5)*.26:0;
      add(bookGeometry(w,h,d,Math.floor(rng()*BOOK_TILES),BOOK_TILES),bookMaterial,x+w/2,shelf+h/2*Math.cos(lean)+Math.abs(Math.sin(lean))*w/2+.002,z-.355+d/2+rng()*.02,0,0,lean);
      x+=w+.002+(lean?.05:0);
    }
  }
  const key=new THREE.Group();key.position.set(-12.72,.955,6.9);key.rotation.y=.7;scene.add(key);
  box(1.2,.12,1.5,-12.7,.88,7,wood,true);for(const z of [6.4,7.6])box(.1,.85,.1,-12.7,.42,z,wood);
  // An old iron key: a looped bow, a collar, a round shank and a toothed bit.
  const bow=new THREE.Mesh(new THREE.TorusGeometry(.046,.01,8,18),iron);bow.rotation.x=-Math.PI/2;bow.scale.set(1,1.25,1);key.add(bow);
  const shank=new THREE.Mesh(new THREE.CylinderGeometry(.0085,.0085,.19,8),iron);shank.rotation.x=Math.PI/2;shank.position.z=.15;key.add(shank);
  for(const [zz,r] of [[.07,.016],[.084,.012]] as number[][]){const collar=new THREE.Mesh(new THREE.CylinderGeometry(r,r,.008,8),iron);collar.rotation.x=Math.PI/2;collar.position.z=zz;key.add(collar);}
  meshBox(.036,.007,.012,.024,0,.225,iron,key);meshBox(.024,.007,.01,.018,0,.208,iron,key);meshBox(.03,.007,.008,.021,0,.19,iron,key);
  // Keep this light outside the collectible: hiding a light's parent changes
  // the shader light count and recompiles the room at the moment of pickup.
  const keyGlow=new THREE.PointLight(0xdcc494,1.2,2,2);keyGlow.name='Gate key glow';keyGlow.position.copy(key.position).y+=.45;scene.add(keyGlow);
  const note=new THREE.Group();note.position.set(6.72,.963,10.6);scene.add(note);
  box(.9,.12,.8,6.8,.9,10.7,wood,true);box(.1,.9,.1,6.8,.45,10.7,wood);
  const paper=new THREE.Mesh(new THREE.PlaneGeometry(.38,.5),new THREE.MeshStandardMaterial({color:0xb6ae91,roughness:1}));paper.rotation.x=-Math.PI/2;paper.rotation.z=.16;note.add(paper);
  box(.05,.32,1.25,-7.585,4.3,7,trim);engrave(['THE ARCHIVE'],1.05,.2,-7.557,4.3,7,Math.PI/2);box(.05,.32,1.25,7.585,4.3,-7,trim);engrave(['SACRISTY'],.9,.2,7.557,4.3,-7,-Math.PI/2);
  // Wall tombs, inscriptions, reliefs, broken masonry and scattered leaves.
  for(const side of [-1,1])for(const bayZ of [-9,3,13]){
    if(side===-1&&bayZ===3)continue;
    // Keep the sacristy tomb clear of the jamb, including its projecting cap.
    // Its old end face was coplanar with the jamb and flickered in depth.
    const z=side===1&&bayZ===-9?-9.55:bayZ;
    box(.45,1.7,1.1,side*7.48,.85,z,darkStone);box(.55,.16,1.35,side*7.4,1.76,z,trim);
    add(crossGeometry(.7,.4,.06,.03),bronze,side*7.255,.95,z,0,-side*Math.PI/2);
  }
  // Fallen stone gathers against the walls in small heaps, under where it came from.
  const debris=ageStone(new THREE.MeshStandardMaterial({color:0xa09e92,roughness:1,flatShading:true}),dressedMaps,{tile:1.6,relief:.3,grime:0});
  for(let heap=0;heap<11;heap++){
    const side=rng()>.5?1:-1,hx=side*(6.7+rng()*.8),hz=-15+rng()*30;
    for(let i=0,n=5+Math.floor(rng()*9);i<n;i++){const size=(.03+rng()*rng()*.2),g=new THREE.DodecahedronGeometry(size,0);g.scale(1+rng()*.5,.5+rng()*.5,1);add(g,debris,hx+(rng()-.5)*.9,size*.3,hz+(rng()-.5)*1.3,rng(),rng()*6,rng());}
  }
  // Candles: shared flame geometry with animated shader; a few lights do the illumination.
  const flameMaterial=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide,uniforms:{time:{value:0},blackout:{value:0}},vertexShader:`varying vec2 vUv; varying float vZ; uniform float time; void main(){vUv=uv;vZ=position.z;vec3 p=position;p.x+=sin(time*8.+position.y*18.)*.009*uv.y;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,fragmentShader:`varying vec2 vUv; varying float vZ; uniform float blackout; void main(){vec2 p=(vUv-.5)*2.;float a=pow(max(0.,1.-length(vec2(p.x*1.8,p.y))),2.);vec3 c=mix(vec3(1.,.15,.01),vec3(1.,.85,.4),a);float threshold=.08+clamp((vZ+14.)/26.,0.,1.)*.68;float strength=1.-smoothstep(threshold,threshold+.16,blackout);gl_FragColor=vec4(c*2.,a*strength);}`});
  const fireGeometries:THREE.BufferGeometry[]=[];const candleLights:THREE.PointLight[]=[];const candleLocations:THREE.Vector3[]=[];
  function candle(x:number,y:number,z:number,height=.22){
    candleLocations.push(new THREE.Vector3(x,y+height+.035,z));
    add(candleGeometry(.036,height,x*13+z*7+height),wax,x,y,z);cylinder(.005,.004,.022,x,y+height+.006,z,black,6);
    const g=new THREE.PlaneGeometry(.13,.23);g.translate(x,y+height+.09,z);fireGeometries.push(g);const g2=g.clone();g2.translate(-x,-y-height-.09,-z);g2.rotateY(Math.PI/2);g2.translate(x,y+height+.09,z);fireGeometries.push(g2);
  }
  for(const x of [-6.1,6.1])for(const z of [-11,-4,4,11]){
    // The stem, tray and arms occupy real floor space for players and pursuers.
    obstacles.push({x,z,w:.5,d:.4,h:2.35});
    // A wrought iron stand: spread foot, turned collars up the stem, a dished pan with old wax in it.
    add(turnedGeometry([[.001,0],[.2,0],[.2,.025],[.13,.05],[.06,.1],[.042,.18],[.03,.3],[.05,.34],[.05,.37],[.026,.41],[.024,1.05],[.042,1.09],[.042,1.12],[.024,1.16],[.024,1.74],[.05,1.78],[.2,1.81],[.215,1.84],[.19,1.83],[.001,1.82]]),iron,x,0,z);
    for(let i=-1;i<=1;i++){candle(x+i*.19,1.83,z,.18+(1-Math.abs(i))*.1);if(i)line([new THREE.Vector3(x,1.4,z),new THREE.Vector3(x+i*.1,1.47,z),new THREE.Vector3(x+i*.19,1.6,z),new THREE.Vector3(x+i*.19,1.81,z)],.012,iron);}
    const l=new THREE.PointLight(0xffa862,6,7.5,1.6);l.position.set(x,2.75,z);scene.add(l);candleLights.push(l);
  }
  for(const x of [-1.15,-.8,.8,1.15])candle(x,1.43,-14,.23+rng()*.2);
  const altarLight=new THREE.PointLight(0xffb672,8,9,1.6);altarLight.position.set(0,2.7,-13.2);scene.add(altarLight);candleLights.push(altarLight);
  // The sacristy candle sits in a wall-mounted iron sconce and drip tray.
  box(.14,.3,.05,12,1.3,-10.565,iron);
  for(const y of [1.2,1.4])add(new THREE.SphereGeometry(.014,6,5),iron,12,y,-10.535);
  line([new THREE.Vector3(12,1.22,-10.54),new THREE.Vector3(12,1.17,-10.4),new THREE.Vector3(12,1.34,-10.27)],.014,iron);
  add(turnedGeometry([[.001,0],[.05,0],[.11,.03],[.12,.05],[.1,.042],[.04,.03],[.001,.028]]),iron,12,1.34,-10.27);
  for(const [x,y,z] of [[12,1.415,-10.27],[-12.32,.94,7.42],[7.02,.96,10.92]]){candle(x,y+.012,z,.32);add(turnedGeometry([[.001,0],[.075,0],[.085,.012],[.05,.016],[.001,.014]]),iron,x,y,z);const l=new THREE.PointLight(0xffb06a,6,8,1.45);l.position.set(x,y+.85,x===12?z+.7:z);scene.add(l);candleLights.push(l);}
  const fire=new THREE.Mesh(mergeGeometries(fireGeometries),flameMaterial);scene.add(fire);
  const smokeGeometry=new THREE.BufferGeometry();smokeGeometry.setAttribute('position',new THREE.Float32BufferAttribute(candleLocations.flatMap(p=>p.toArray()),3));
  const extinguished=new Float32Array(candleLocations.length).fill(1e6);smokeGeometry.setAttribute('extinguished',new THREE.BufferAttribute(extinguished,1));
  const smokeMaterial=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{time:{value:0},strength:{value:1}},vertexShader:`attribute float extinguished; uniform float time; varying float vAge; void main(){vAge=time-extinguished;vec3 p=position;float age=max(0.,vAge);p.y+=age*.13;p.x+=sin(age*2.3+position.z)*age*.035;vec4 mv=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*mv;gl_PointSize=clamp((38.+age*24.)/-mv.z,1.,60.);}`,fragmentShader:`uniform float strength;varying float vAge;void main(){if(vAge<0.||vAge>5.)discard;vec2 p=(gl_PointCoord-.5)*2.;float shape=pow(max(0.,1.-dot(p,p)),2.);gl_FragColor=vec4(.38,.42,.43,shape*.16*strength*exp(-vAge*.8)*smoothstep(0.,.15,vAge));}`});
  const smoke=new THREE.Points(smokeGeometry,smokeMaterial);smoke.frustumCulled=false;scene.add(smoke);
  // Hanging sanctuary banners and iron chandeliers break up the repeated bays.
  const fabric=new THREE.MeshStandardMaterial({color:0x35282a,roughness:1,side:THREE.DoubleSide});
  for(const side of [-1,1]){
    const g=new THREE.PlaneGeometry(1.0,3.6,20,30),p=g.attributes.position;
    for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i);p.setZ(i,Math.sin(x*22)*.055+Math.sin(y*2+x)*.035);if(y< -1.65)p.setY(i,y+rng()*.22);}
    g.computeVertexNormals();add(g,fabric,side*3.5,4.8,-15.45);
    line([new THREE.Vector3(side*3.5-.65,6.65,-15.35),new THREE.Vector3(side*3.5+.65,6.65,-15.35)],.026,brass);
    box(.025,1.0,.04,side*3.5,5.2,-15.32,brass);box(.38,.025,.04,side*3.5,5.4,-15.31,brass);
  }
  for(const z of [-3,9]){
    add(new THREE.TorusGeometry(1.1,.035,7,48),metal,0,5.7,z,Math.PI/2);
    for(let i=0;i<6;i++){const a=i*Math.PI/3,x=Math.cos(a)*1.1,zz=z+Math.sin(a)*1.1;line([new THREE.Vector3(x,5.7,zz),new THREE.Vector3(0,7.2,z),new THREE.Vector3(0,9.6,z)],.012,metal);cylinder(.065,.065,.16,x,5.75,zz,brass);}
  }
  // Dust, rain glimpsed through the high windows, and soft shafts of moonlight.
  const dustPositions=new Float32Array(600*3);for(let i=0;i<600;i++){dustPositions[i*3]=(rng()-.5)*15;dustPositions[i*3+1]=rng()*8;dustPositions[i*3+2]=(rng()-.5)*30;}
  const dg=new THREE.BufferGeometry();dg.setAttribute('position',new THREE.BufferAttribute(dustPositions,3));
  const dust=new THREE.Points(dg,new THREE.PointsMaterial({color:0x8c9ca1,size:.011,transparent:true,opacity:.14,depthWrite:false}));scene.add(dust);
  const beamMaterial=new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,uniforms:{time:{value:0},strength:{value:1}},vertexShader:`varying vec2 vUv;varying vec3 vWorld;void main(){vUv=uv;vWorld=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`varying vec2 vUv; varying vec3 vWorld; uniform float time;uniform float strength;void main(){float edge=pow(sin(vUv.x*3.14159),2.);float vertical=sin(vUv.y*3.14159);float dust=.92+.08*sin(vWorld.x*.9+vWorld.y*.7+time*.14);gl_FragColor=vec4(.29,.43,.52,edge*vertical*dust*.032*strength);}`});
  const moonShafts:THREE.SpotLight[]=[];
  for(const z of [-11,-1,10]){
    const g=new THREE.PlaneGeometry(1.8,10);const beam=new THREE.Mesh(g,beamMaterial);beam.position.set(3.1,3.9,z);beam.rotation.z=-.8;scene.add(beam);
    const l=new THREE.SpotLight(0x8fb4d6,42,22,.22,.9,1.8);l.position.set(7.4,5.1,z);l.target.position.set(-2,.1,z-1.5);scene.add(l,l.target);moonShafts.push(l);
  }
  const moon=new THREE.SpotLight(0xa4bfdd,150,30,.43,.9,1.6);moon.position.set(0,8,-14.8);moon.target.position.set(0,0,-5);moon.castShadow=true;moon.shadow.mapSize.set(1024,1024);moon.shadow.radius=3;moon.shadow.bias=-.0004;moon.shadow.normalBias=.025;scene.add(moon,moon.target);
  moon.shadow.autoUpdate=false;moon.shadow.needsUpdate=true;
  const ambient=new THREE.HemisphereLight(0x6f86a0,0x1c1c16,.38);scene.add(ambient);
  const angelRim=new THREE.SpotLight(0x86aace,60,15,.6,.95,1.8);angelRim.position.set(2,6,-4);angelRim.target.position.set(0,1.4,-9);scene.add(angelRim,angelRim.target);
  const emergencyLights:THREE.PointLight[]=[];
  const bulbMaterial=new THREE.MeshStandardMaterial({color:0xaeb8ad,emissive:0xc2d6c4,emissiveIntensity:0,roughness:.35});
  for(const [wall,z]of [[7.6,-5.05],[-7.6,8.95]]){
    const s=Math.sign(wall),arm=wall-s*.2;
    box(.05,.26,.14,wall,3.05,z,iron);
    line([new THREE.Vector3(wall,3.13,z),new THREE.Vector3(wall-s*.14,3.16,z),new THREE.Vector3(arm,3.09,z)],.009,iron);
    add(turnedGeometry([[.001,.05],[.03,.05],[.058,.015],[.06,0],[.052,.008],[.001,.03]]),iron,arm,3.02,z);
    add(new THREE.SphereGeometry(.043,12,9),bulbMaterial,arm,2.98,z);
    for(const y of [2.96,3])add(new THREE.TorusGeometry(y===3?.05:.053,.0035,5,14),iron,arm,y-.012,z,Math.PI/2);
    for(let i=0;i<4;i++){const a=i*Math.PI/2+.4,c=Math.cos(a)*.052,d=Math.sin(a)*.052;line([new THREE.Vector3(arm+c,3.02,z+d),new THREE.Vector3(arm+c*1.05,2.97,z+d*1.05),new THREE.Vector3(arm+c*.25,2.92,z+d*.25)],.003,iron);}
    const light=new THREE.PointLight(0xc4d8c9,0,7,2);light.position.set(arm-s*.08,2.98,z);scene.add(light);emergencyLights.push(light);
  }
  // Lightly reflective damp floor. Reflection is deliberately restrained, not polished marble.
  const reflection=new Reflector(new THREE.PlaneGeometry(15.4,31.4),{textureWidth:512,textureHeight:512,color:0x7d8a8c,clipBias:.003,multisample:0});
  reflection.rotation.x=-Math.PI/2;reflection.position.y=.006;
  // Only the floor's damp patches reflect, the same ones the paving's stone shows.
  const rm=reflection.material as THREE.ShaderMaterial;rm.transparent=true;rm.depthWrite=false;rm.uniforms.tStoneNoise={value:noise};
  rm.vertexShader=rm.vertexShader.replace('void main() {','varying vec3 vWP;void main() {vWP=(modelMatrix*vec4(position,1.)).xyz;');
  rm.fragmentShader=rm.fragmentShader.replace('void main() {','varying vec3 vWP;uniform sampler2D tStoneNoise;void main() {').replace('gl_FragColor = vec4( blendOverlay( base.rgb, color ), 1.0 );',`float wet=smoothstep(.54,.76,texture2D(tStoneNoise,vWP.xz*.085).r*.75+texture2D(tStoneNoise,vWP.xz*.33).r*.25);gl_FragColor=vec4(min(base.rgb,vec3(1.2))*.8,wet*.2);`);
  scene.add(reflection);
  // Merge static detail by material to keep draw calls under control.
  for(const [m,geoms]of batches){const geometry=mergeGeometries(geoms);if(!geometry)continue;const mesh=new THREE.Mesh(geometry,m);
    // Big flat surfaces shading themselves from a moving torch make bands that sweep across them from a distance. The room is closed, so they've nothing to shade anyway.
    mesh.castShadow=m!==stone&&m!==ceiling&&m!==bed;mesh.receiveShadow=true;scene.add(mesh);geoms.forEach(g=>g.dispose());}
  const stations:Station[]=[{id:'power',position:new THREE.Vector3(12.8,1.4,-7),object:power,label:'HOLD TO RESTORE POWER'},{id:'key',position:new THREE.Vector3(-12.7,1.0,7),object:key,label:'TAKE THE GATE KEY'},{id:'gate',position:new THREE.Vector3(0,1.5,15.2),object:gate,label:'UNLOCK THE GATE'},{id:'note',position:new THREE.Vector3(6.8,1,10.7),object:note,label:'READ THE KEEPER’S NOTE'}];
  for(const group of [rose,gate]){
    const groups=new Map<THREE.Material,THREE.BufferGeometry[]>();
    for(const o of [...group.children]){const m=o as THREE.Mesh;if(!m.isMesh||Array.isArray(m.material))continue;m.updateMatrix();if(!groups.has(m.material))groups.set(m.material,[]);groups.get(m.material)!.push(m.geometry.clone().applyMatrix4(m.matrix));group.remove(m);m.geometry.dispose();}
    for(const [mat,parts]of groups){const merged=new THREE.Mesh(mergeGeometries(parts),mat);merged.castShadow=true;merged.receiveShadow=true;group.add(merged);parts.forEach(g=>g.dispose());}
  }
  const background=scene.background instanceof THREE.Color?scene.background.clone():null,fog=scene.fog?.color.clone();
  let emergencyLevel=0,lastTime=0,isPitchBlack=false;
  return {stations,reflection,moon,ambient,candleLights,emergencyLights,get isPitchBlack(){return isPitchBlack;},update(time:number,powered:boolean,blackout=0){
    flameMaterial.uniforms.time.value=time;flameMaterial.uniforms.blackout.value=blackout;beamMaterial.uniforms.time.value=time;smokeMaterial.uniforms.time.value=time;
    candleLights.forEach((l,i)=>l.intensity=candleStrength(l.position.z,blackout)*(i===8?8:i>8?6:6)*(1+Math.sin(time*5+i*7)*.06+Math.sin(time*11+i)*.025));
    let smokeChanged=false;candleLocations.forEach((p,i)=>{
      if(blackout===0&&extinguished[i]!==1e6){extinguished[i]=1e6;smokeChanged=true;}
      else if(blackout>0&&extinguished[i]===1e6&&candleStrength(p.z,blackout)<.08){extinguished[i]=time;smokeChanged=true;}
    });if(smokeChanged)smokeGeometry.attributes.extinguished.needsUpdate=true;
    const darkness=THREE.MathUtils.smoothstep(blackout,0,.8);
    if(time<lastTime)emergencyLevel=powered?1:0;
    // A tripped supply cuts the entrance fixtures and their emissive bulbs together.
    emergencyLevel=powered?THREE.MathUtils.damp(emergencyLevel,1,2.5,Math.min(.05,Math.max(0,time-lastTime))):0;lastTime=time;
    ambient.intensity=.38*(1-darkness)+emergencyLevel*.025;
    moon.intensity=150*(1-darkness);angelRim.intensity=60*(1-darkness);
    moonShafts.forEach(l=>l.intensity=42*(1-darkness));
    wax.emissiveIntensity=.5*(1-darkness);windowMat.emissiveIntensity=.42*(1-darkness);gm.emissiveIntensity=1.25*(1-darkness);
    beamMaterial.uniforms.strength.value=1-darkness;
    smokeMaterial.uniforms.strength.value=1-darkness;
    dust.material.opacity=.14*(1-darkness);keyGlow.intensity=key.visible?1.2*(1-darkness):0;
    scene.environmentIntensity=.05*(1-darkness);
    if(background&&scene.background instanceof THREE.Color)scene.background.copy(background).multiplyScalar(1-darkness);
    if(fog&&scene.fog)scene.fog.color.copy(fog).multiplyScalar(1-darkness);
    emergencyLights.forEach(l=>l.intensity=emergencyLevel*7);bulbMaterial.emissiveIntensity=emergencyLevel*2.2;
    // Only declare darkness after the last candle and every silhouette source
    // are gone. The player torch is handled separately by the observation check.
    isPitchBlack=blackout===1&&!powered&&emergencyLevel===0;
    dust.rotation.y=Math.sin(time*.025)*.02;dust.position.y=Math.sin(time*.06)*.08;
    cabinet.setPowered(powered);
  }};
}
