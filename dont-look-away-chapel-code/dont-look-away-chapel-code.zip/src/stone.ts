import * as THREE from 'three';

// Old stone, mapped by where it is in the world, so plain boxes and cylinders share scanned courses with no stretching.
// The ageing follows where water and smoke really go: grime rising from the floor, damp running down under the windows,
// soot above the candles. After Realistic Procedural Dungeons' stone.
export type StoneMaps={color:THREE.Texture;normal:THREE.Texture;roughness:THREE.Texture;noise:THREE.Texture;render?:{color:THREE.Texture;normal:THREE.Texture;roughness:THREE.Texture}};
type StoneOptions={tile?:number;relief?:number;grime?:number;wall?:boolean;floor?:boolean};

const WINDOW_Z=[-12,-1,11],CANDLE_Z=[-11,-4,4,11];
const list=(values:number[])=>values.map(v=>v.toFixed(1)).join(',');

/** A soft tiling noise for everything that shouldn't repeat with the stone. */
export function stoneNoise(size=256){
  const data=new Uint8Array(size*size);
  const lattice=new Float32Array(256*256);let seed=91;
  for(let i=0;i<lattice.length;i++){seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;lattice[i]=((t^t>>>14)>>>0)/4294967296;}
  const value=(x:number,y:number,period:number)=>{
    const ix=Math.floor(x),iy=Math.floor(y),fx=x-ix,fy=y-iy,ux=fx*fx*(3-2*fx),uy=fy*fy*(3-2*fy);
    const at=(a:number,b:number)=>lattice[(((a%period)+period)%period)*256+((b%period)+period)%period];
    return at(ix,iy)*(1-ux)*(1-uy)+at(ix+1,iy)*ux*(1-uy)+at(ix,iy+1)*(1-ux)*uy+at(ix+1,iy+1)*ux*uy;
  };
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    let sum=0,amp=.5,period=4,total=0;
    for(let o=0;o<6;o++){sum+=amp*value(x/size*period,y/size*period,period);total+=amp;amp*=.5;period*=2;}
    data[y*size+x]=Math.round(THREE.MathUtils.clamp((sum/total-.5)*1.7+.5,0,1)*255);
  }
  const texture=new THREE.DataTexture(data,size,size,THREE.RedFormat);
  texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;texture.generateMipmaps=true;texture.needsUpdate=true;
  return texture;
}

export function ageStone(material:THREE.MeshStandardMaterial,maps:StoneMaps,{tile=.5,relief=1,grime=1,wall=false,floor=false}:StoneOptions={}){
  material.map=null;material.normalMap=null;material.roughnessMap=null;material.metalness=0;
  const key=`stone|${tile}|${relief}|${grime}|${wall}|${floor}`;
  material.customProgramCacheKey=()=>key;
  material.onBeforeCompile=shader=>{
    Object.assign(shader.uniforms,{tStoneColor:{value:maps.color},tStoneNormal:{value:maps.normal},tStoneRough:{value:maps.roughness},tStoneNoise:{value:maps.noise},tRenderColor:{value:maps.render?.color??null},tRenderNormal:{value:maps.render?.normal??null},tRenderRough:{value:maps.render?.roughness??null}});
    shader.vertexShader=`${floor?'attribute float aStone;varying float vStone;':''}varying vec3 vWP;varying vec3 vWN;\n${shader.vertexShader}`.replace('#include <project_vertex>',`#include <project_vertex>
      vWP=(modelMatrix*vec4(transformed,1.)).xyz;vWN=normalize(mat3(modelMatrix)*objectNormal);${floor?'vStone=aStone;':''}`);
    shader.fragmentShader=`${floor?'varying float vStone;':''}varying vec3 vWP;varying vec3 vWN;uniform sampler2D tStoneColor,tStoneNormal,tStoneRough,tStoneNoise,tRenderColor,tRenderNormal,tRenderRough;
      vec3 stoneN;float stoneR;\n${shader.fragmentShader}`
      .replace('#include <map_fragment>',`
      vec3 wn0=normalize(vWN);if(!gl_FrontFacing)wn0=-wn0;
      vec3 tw=pow(abs(wn0),vec3(5.));tw/=tw.x+tw.y+tw.z;
      vec2 uvX=vWP.zy*${tile.toFixed(3)},uvY=vWP.xz*${tile.toFixed(3)}${floor?'+vStone*vec2(5.3,3.1)':''},uvZ=vWP.xy*${tile.toFixed(3)};
      vec3 sAlbedo=texture2D(tStoneColor,uvX).rgb*tw.x+texture2D(tStoneColor,uvY).rgb*tw.y+texture2D(tStoneColor,uvZ).rgb*tw.z;
      vec3 nX=texture2D(tStoneNormal,uvX).xyz*2.-1.,nY=texture2D(tStoneNormal,uvY).xyz*2.-1.,nZ=texture2D(tStoneNormal,uvZ).xyz*2.-1.;
      stoneN=normalize(wn0+${relief.toFixed(2)}*(vec3(0.,nX.y,nX.x)*tw.x+vec3(nY.x,0.,nY.y)*tw.y+vec3(nZ.x,nZ.y,0.)*tw.z));
      stoneR=texture2D(tStoneRough,uvX).r*tw.x+texture2D(tStoneRough,uvY).r*tw.y+texture2D(tStoneRough,uvZ).r*tw.z;
      float sAlong=vWP.x*tw.z+vWP.z*tw.x+vWP.x*tw.y;
      float sBroad=texture2D(tStoneNoise,vec2(sAlong,vWP.y)*.045+vWP.xz*.013).r;
      float sMid=texture2D(tStoneNoise,vec2(sAlong,vWP.y)*.19+.31).r;
      float sStreak=texture2D(tStoneNoise,vec2(sAlong*.31,vWP.y*.04)+.57).r*.62+sMid*.38;
      // Each area of wall weathered on its own, so the courses never read as a repeat.
      ${wall?`
      // Old lime render over the blocks. It fills the joints first, so what breaks through is the blocks' faces,
      // in whole regions of bare stonework and surviving render, with a dark lip where it has come away.
      vec2 pX=uvX*1.34+.37,pY=uvY*1.34+.37,pZ=uvZ*1.34+.37;
      vec3 sRender=texture2D(tRenderColor,pX).rgb*tw.x+texture2D(tRenderColor,pY).rgb*tw.y+texture2D(tRenderColor,pZ).rgb*tw.z;
      float sFace=dot(sAlbedo,vec3(.3,.6,.1));
      float sCover=smoothstep(0.,.2,sBroad*.8+sMid*.2-.4-sFace*.2+(vWP.y-1.2)*.012);
      sAlbedo=mix(vec3(dot(sAlbedo,vec3(.33))),sAlbedo,.8)*.72+.05;
      float sLip=smoothstep(0.,.5,sCover)*(1.-smoothstep(.5,1.,sCover));
      sAlbedo=mix(sAlbedo,sRender*.92,sCover)*(1.-.32*sLip);
      vec3 rX=texture2D(tRenderNormal,pX).xyz*2.-1.,rY=texture2D(tRenderNormal,pY).xyz*2.-1.,rZ=texture2D(tRenderNormal,pZ).xyz*2.-1.;
      stoneN=normalize(mix(stoneN,normalize(wn0+.8*(vec3(0.,rX.y,rX.x)*tw.x+vec3(rY.x,0.,rY.y)*tw.y+vec3(rZ.x,rZ.y,0.)*tw.z)),sCover));
      stoneR=mix(stoneR,texture2D(tRenderRough,pX).r*tw.x+texture2D(tRenderRough,pY).r*tw.y+texture2D(tRenderRough,pZ).r*tw.z,sCover);`:''}
      sAlbedo*=mix(.62,1.18,smoothstep(.25,.75,sBroad));
      // Damp runs in long streaks from above, and it's darker where it stands.
      float sDamp=smoothstep(.42,.72,sStreak);
      sAlbedo*=mix(1.04,.62,sDamp*${(.7*grime).toFixed(2)});
      // Grime climbs from the floor, unevenly.
      float sRise=smoothstep(0.,1.9,vWP.y+(sMid-.5)*1.5);
      sAlbedo*=mix(${(1-.74*grime).toFixed(2)},1.,sRise);
      float sWet=(1.-sRise)*.6;
      ${wall?`
      // Water comes in under the windows, staining the wall dark and faintly green below each sill.
      float sWall=smoothstep(7.,7.4,abs(vWP.x))*(1.-smoothstep(8.,8.2,abs(vWP.x)));float sStain=0.,sSoot=0.;
      for(int i=0;i<3;i++){float dz=vWP.z-float[3](${list(WINDOW_Z)})[i]+(sMid-.5)*.8;sStain=max(sStain,exp(-dz*dz*.85)*(1.-smoothstep(.2,2.2,vWP.y)));}
      for(int i=0;i<4;i++){float dz=vWP.z-float[4](${list(CANDLE_Z)})[i]+(sMid-.5)*.7;sSoot=max(sSoot,exp(-dz*dz*(1.5-vWP.y*.17))*smoothstep(1.9,2.7,vWP.y)*(1.-smoothstep(3.2,6.2,vWP.y)));}
      sStain*=sWall;sSoot*=sWall;
      sAlbedo=mix(sAlbedo,sAlbedo*vec3(.42,.5,.42),sStain*.9);
      sAlbedo*=1.-sSoot*.68;sWet=max(sWet,sStain*.8);`:''}
      ${floor?`
      // Standing damp in patches, darker and catching the light, and a path worn paler down the middle.
      sWet=smoothstep(.54,.76,texture2D(tStoneNoise,vWP.xz*.085).r*.75+texture2D(tStoneNoise,vWP.xz*.33).r*.25);
      sAlbedo*=mix(1.14,.84,smoothstep(.5,2.4,abs(vWP.x)))*mix(1.,.6,sWet)*mix(.34,1.08,smoothstep(.3,.72,sBroad*.65+sMid*.35));
      // Dirt gathers where nothing walks: round the foot of each pier and along the walls.
      float sPier=length(vec2(abs(abs(vWP.x)-4.7),mod(vWP.z+3.,6.)-3.));
      float sEdge=abs(vWP.x)<7.7?min(7.65-abs(vWP.x),15.7-abs(vWP.z)):1.5;
      sAlbedo*=mix(.45,1.,smoothstep(.45,1.5,sPier+(sMid-.5)*.8))*mix(.4,1.,smoothstep(0.,1.15,max(sEdge,0.)+(sMid-.5)*.8));
      // Water fills the stone's pits, so damp patches read smooth and don't glitter.
      stoneN=normalize(mix(stoneN,wn0,sWet*.8));`:''}
      // Neutral stone: its colour comes from what's lighting it.
      float sLum=dot(sAlbedo,vec3(.3,.6,.1));sAlbedo=mix(vec3(sLum),sAlbedo,.42)*1.5;
      stoneR=mix(stoneR,stoneR*${floor?'.3':'.62'},${floor?'sWet':'sDamp*.5+sWet*.5'});
      // Fine relief smaller than a pixel only sparkles as you move: fade it with distance, and roughen wherever the normal changes faster than the screen can show.
      stoneN=normalize(mix(stoneN,wn0,smoothstep(2.5,14.,length(cameraPosition-vWP))*.9));
      stoneR=max(stoneR,min(1.,length(fwidth(stoneN))*3.));
      diffuseColor.rgb*=sAlbedo;`)
      .replace('#include <roughnessmap_fragment>',`#include <roughnessmap_fragment>
      roughnessFactor=clamp(roughnessFactor*stoneR*1.15,.46,1.);`)
      .replace('#include <normal_fragment_maps>',`normal=normalize((viewMatrix*vec4(stoneN,0.)).xyz);`)
      // The floor sees little of the room's soft light, so it only shows where something is really lighting it.
      .replace('#include <lights_fragment_end>',`#include <lights_fragment_end>
      ${floor?'reflectedLight.indirectDiffuse*=.42;':''}
      // Old stone barely shines. Each flat stone would otherwise flash on and off as you walk, facing a low moon.
      reflectedLight.directSpecular*=${floor?'.1':'.4'};`);
  };
  material.needsUpdate=true;
  return material;
}
