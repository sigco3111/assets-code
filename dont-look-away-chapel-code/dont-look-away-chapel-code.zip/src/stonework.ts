import * as THREE from 'three';

// Cut stone instead of plain tubes and cylinders. After Realistic Procedural Dungeons' piers and ribs.
const hash=(a:number,b:number)=>{const s=Math.sin(a*127.1+b*311.7)*43758.5453;return s-Math.floor(s);};
function finish(g:THREE.BufferGeometry){
  // Stone is mapped by world position, but everything sharing a batch must carry the same attributes.
  g.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(g.attributes.position.count*2),2));
  if(!g.index)g.setIndex(Array.from({length:g.attributes.position.count},(_,i)=>i));
  return g;
}

/** A pier from the floor up: square plinth, moulded base, a shaft of drums, a capital carved with leaves, and a square abacus at `spring`. */
export function pierGeometry(seed:number,spring:number,R=.36){
  const rings:{y:number;r:number;square:number;carve:number}[]=[];
  const ring=(y:number,r:number,square=0,carve=0)=>rings.push({y,r,square,carve});
  const top=spring-.66;
  ring(-.05,.62,1);ring(.02,.56,1);ring(.14,.51,.95);ring(.2,.49,.9);ring(.23,.45,1);ring(.27,.45,.6);ring(.29,R+.08,0);ring(.34,R+.1,0);ring(.38,R+.05,0);ring(.42,R+.02,0);
  let y=.44,drum=0;
  while(y<top-.05){
    const next=Math.min(top,y+.36+hash(drum,seed)*.16),r=R+(hash(drum*2.1,seed)-.5)*.014;
    ring(y+.006,r-.016);ring(y+.016,r);ring(next-.016,r);ring(next-.006,r-.016);
    y=next;drum++;
  }
  ring(top,R+.03);ring(top+.03,R+.03);ring(top+.05,R-.01);
  for(let i=0;i<=9;i++){const t=i/9;ring(top+.06+t*.42,R+t*t*.11,t*.4,Math.sin(t*Math.PI)**.6);}
  ring(spring-.16,.47,1);ring(spring-.08,.52,1);ring(spring-.03,.52,1);ring(spring,.44,1);ring(spring+.16,.01);
  const SEG=40,positions:number[]=[],index:number[]=[];
  rings.forEach((q,i)=>{
    for(let s=0;s<SEG;s++){
      const a=s/SEG*Math.PI*2,c=Math.cos(a),n=Math.sin(a),sq=1/(Math.abs(c)**7+Math.abs(n)**7)**(1/7);
      let r=q.r*(1+(sq-1)*q.square);
      // Leaves: eight lobes with a rib down each, curling out towards the top.
      if(q.carve)r+=q.carve*(.075*Math.abs(Math.cos(a*4))**.5-.03+.022*Math.exp(-(((a*4)%Math.PI-Math.PI/2)**2)*18)+(hash(s,i)-.5)*.014);
      // Chips and wear round the drums, none of them on the plinth.
      else r+=(hash(s*.31,i*.17)-.5)*(q.y>.42?.01:.03);
      positions.push(c*r,q.y,n*r);
    }
  });
  for(let i=0;i<rings.length-1;i++)for(let s=0;s<SEG;s++){const a=i*SEG+s,b=i*SEG+(s+1)%SEG,c=a+SEG,e=b+SEG;index.push(a,c,b,b,c,e);}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setIndex(index);g.computeVertexNormals();
  return finish(g);
}

/** A rib as a row of separate cut stones along a curve, each a little different, with a dark gap between them. `depth` is its thickness across the curve. */
export function ribStones(curve:THREE.Curve<THREE.Vector3>,width:number,seed:number,depth=width){
  const out:number[]=[],count=Math.max(3,Math.round(curve.getLength()/.46)),P=new THREE.Vector3(),T=new THREE.Vector3(),S=new THREE.Vector3(),N=new THREE.Vector3();
  const section=(t:number,w:number,d:number)=>{
    curve.getPointAt(t,P);curve.getTangentAt(t,T);
    S.set(-T.z,0,T.x);if(S.lengthSq()<1e-6)S.set(1,0,0);S.normalize();
    N.crossVectors(S,T).normalize();if(N.y>0)N.negate();
    return [[-w,-d],[-w,d*.55],[-w*.62,d],[w*.62,d],[w,d*.55],[w,-d],[w*.62,-d*1.1],[-w*.62,-d*1.1]].map(([s,n])=>new THREE.Vector3().copy(P).addScaledVector(S,s).addScaledVector(N,n));
  };
  const tri=(p:THREE.Vector3,q:THREE.Vector3,r:THREE.Vector3)=>out.push(p.x,p.y,p.z,q.x,q.y,q.z,r.x,r.y,r.z);
  for(let i=0;i<count;i++){
    const w=width*(.93+hash(i,seed)*.14),d=depth*(.9+hash(i*1.7,seed)*.26);
    const a=section((i+.025)/count,w,d),b=section((i+.975)/count,w,d),n=a.length;
    for(let k=0;k<n;k++){const j=(k+1)%n;tri(a[k],b[k],a[j]);tri(a[j],b[k],b[j]);}
    for(let k=1;k<n-1;k++){tri(a[0],a[k],a[k+1]);tri(b[0],b[k+1],b[k]);}
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(out,3));g.computeVertexNormals();
  return finish(g);
}

/** Paving laid stone by stone over a rectangle: uneven courses, worn edges, each stone its own shade, a few sunk or tipped. */
export function flagstones(x0:number,x1:number,z0:number,z1:number,seed:number){
  const positions:number[]=[],colors:number[]=[],stones:number[]=[];let s=seed>>>0;
  const rnd=()=>{s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};
  const lay=(cx:number,cz:number,hx:number,hz:number)=>{
    const sunk=rnd()<.09,top=sunk?-.012-rnd()*.012:-rnd()*.004,tx=(rnd()-.5)*(sunk?.05:.012),tz=(rnd()-.5)*(sunk?.05:.012),tone=.62+rnd()*.52,id=rnd(),yaw=(rnd()-.5)*Math.min(.03,.03/Math.max(hx,hz)),cos=Math.cos(yaw),sin=Math.sin(yaw);
    const outline:[number,number,number][]=[];const r=.02+rnd()*rnd()*.1;
    for(const [sx,sz,from]of [[1,1,0],[-1,1,1],[-1,-1,2],[1,-1,3]])for(let k=0;k<3;k++){
      const a=(from+(k+.5)/3)*Math.PI/2,lx=sx*(hx-r)+Math.cos(a)*r,lz=sz*(hz-r)+Math.sin(a)*r;
      outline.push([lx*(1-rnd()*.028),lz*(1-rnd()*.028),rnd()]);
    }
    const bevel=.007+rnd()*.009,ring=(inset:number,y:number,shade:number,tip:boolean)=>outline.map(([lx,lz])=>{
      const px=lx*Math.max(.2,(hx-inset)/hx),pz=lz*Math.max(.2,(hz-inset)/hz);
      return {p:[cx+px*cos-pz*sin,y+(tip?tx*px+tz*pz:0),cz+px*sin+pz*cos],shade};
    });
    const foot=ring(0,-.03,.42,false),shoulder=ring(0,top-bevel,.8,true),face=ring(bevel,top,1,true),centre={p:[cx,top,cz],shade:1};
    const push=(v:{p:number[];shade:number})=>{positions.push(...v.p);const c=tone*v.shade;colors.push(c,c,c);stones.push(id);};
    const n=outline.length;
    for(let i=0;i<n;i++){const j=(i+1)%n;
      for(const [a,b]of [[foot,shoulder],[shoulder,face]]){push(a[i]);push(b[i]);push(a[j]);push(a[j]);push(b[i]);push(b[j]);}
      push(face[i]);push(centre);push(face[j]);
    }
  };
  // Stones of many sizes, not courses: each block of floor is split at random until its pieces are stone sized.
  const split=(a:number,b:number,c:number,d:number)=>{
    const w=b-a,h=d-c,limit=.68+rnd()*.8;
    if(Math.max(w,h)<limit||Math.min(w,h)<.5){const gap=.016+rnd()*rnd()*.02;lay((a+b)/2,(c+d)/2,w/2-gap,h/2-gap);return;}
    if(w>h*(.75+rnd()*.5)){const m=a+w*(.36+rnd()*.28);split(a,m,c,d);split(m,b,c,d);}
    else{const m=c+h*(.36+rnd()*.28);split(a,b,c,m);split(a,b,m,d);}
  };
  for(let x=x0;x<x1;){
    const strip=Math.min(x1-x,2.5+rnd()*1.7);let z=z0-rnd()*1.2;
    while(z<z1){const row=1.7+rnd()*1.4,a=Math.max(z,z0),b=Math.min(z+row,z1);if(b-a>.1)split(x,x+strip,a,b);z+=row;}
    x+=strip;
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setAttribute('aStone',new THREE.Float32BufferAttribute(stones,1));g.computeVertexNormals();
  return g;
}

// Stays open-free however it's nudged: the same point always moves the same way.
const nudge=(g:THREE.BufferGeometry,amount:number)=>{
  const p=g.attributes.position;
  for(let i=0;i<p.count;i++){
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i),kx=Math.round(x*400),ky=Math.round(y*400),kz=Math.round(z*400);
    p.setXYZ(i,x+(hash(kx+ky*.3,kz)-.5)*amount,y+(hash(ky+kz*.3,kx)-.5)*amount,z+(hash(kz+kx*.3,ky)-.5)*amount);
  }
};

/** A cut block: worn edges and corners that aren't quite true. */
export function blockGeometry(w:number,h:number,d:number){
  const b=Math.min(.02,Math.min(w,h,d)*.2),shape=new THREE.Shape();
  shape.moveTo(-w/2+b,-d/2+b);shape.lineTo(w/2-b,-d/2+b);shape.lineTo(w/2-b,d/2-b);shape.lineTo(-w/2+b,d/2-b);shape.closePath();
  const g=new THREE.ExtrudeGeometry(shape,{depth:h-2*b,bevelEnabled:true,bevelSize:b,bevelThickness:b,bevelSegments:1});
  g.rotateX(-Math.PI/2);g.translate(0,-(h-2*b)/2,0);
  nudge(g,Math.min(.014,Math.min(w,h,d)*.1));g.computeVertexNormals();
  return finish(g);
}

/** A wall that isn't a plane: long shallow bulges where it has settled, and a foot that flares into the floor. Never thinner than its box, so what it hides stays hidden. */
export function wallGeometry(w:number,h:number,d:number,x:number,y:number,z:number,flare:number){
  const step=.42,g=new THREE.BoxGeometry(w,h,d,Math.max(1,Math.ceil(w/step)),Math.max(1,Math.ceil(h/step)),Math.max(1,Math.ceil(d/step))),p=g.attributes.position;
  for(let i=0;i<p.count;i++){
    const v=Math.max(0,(p.getY(i)+h/2)/h),ly=h*v**(flare?1.7:1)-h/2,wy=y+ly,wx=x+p.getX(i),wz=z+p.getZ(i),along=wx+wz;
    const bulge=(.5+.5*Math.sin(along*.83+wy*.31+1.3)*Math.sin(along*.29-wy*.47+.6))*.045+(.5+.5*Math.sin(along*2.3-wy*1.7))*.012;
    const foot=Math.max(0,1-Math.max(0,wy)/.9);
    const out=bulge+flare*foot*foot*(.75+.5*Math.sin(along*1.9));
    let px=p.getX(i),pz=p.getZ(i);
    if(Math.abs(px)>w/2-1e-4)px+=Math.sign(px)*out;
    if(Math.abs(pz)>d/2-1e-4)pz+=Math.sign(pz)*out;
    p.setXYZ(i,px,ly,pz);
  }
  g.computeVertexNormals();
  return finish(g);
}

/** A rough stone post for where two walls meet, so the corner isn't a clean line. */
export function cornerGeometry(radius:number,height:number){
  const g=new THREE.CylinderGeometry(radius*.9,radius,height,10,Math.max(2,Math.round(height/.5)),true);
  const p=g.attributes.position;
  for(let i=0;i<p.count;i++){const a=Math.atan2(p.getZ(i),p.getX(i)),band=Math.round(p.getY(i)*2),n=1+(hash(Math.round(a*6)+band,band*1.7)-.5)*.16;p.setX(i,p.getX(i)*n);p.setZ(i,p.getZ(i)*n);}
  g.computeVertexNormals();
  return finish(g);
}

/** A cross with arms that flare slightly, worn at the edges. Faces +z. */
export function crossGeometry(height:number,span:number,thick:number,depth:number){
  const t=thick/2,f=t*1.5,top=height/2,arm=span/2,c=height*.2,shape=new THREE.Shape();
  shape.moveTo(-t,-top);shape.lineTo(t,-top);shape.lineTo(t*.8,c-t);shape.lineTo(arm-.02,c-f);shape.lineTo(arm,c+f);shape.lineTo(t*.8,c+t);shape.lineTo(f,top);shape.lineTo(-f,top);shape.lineTo(-t*.8,c+t);shape.lineTo(-arm,c+f);shape.lineTo(-arm+.02,c-f);shape.lineTo(-t*.8,c-t);shape.closePath();
  const b=Math.min(.012,thick*.14),g=new THREE.ExtrudeGeometry(shape,{depth:depth-2*b,bevelEnabled:true,bevelSize:b,bevelThickness:b,bevelSegments:1});
  nudge(g,b*.5);g.computeVertexNormals();
  return finish(g);
}

/** A book standing on a shelf with its spine facing -z, the spine rounded, its picture one of `tiles` across a shared sheet. */
export function bookGeometry(w:number,h:number,d:number,tile:number,tiles:number){
  const g=new THREE.BoxGeometry(w,h,d,4,1,1),p=g.attributes.position,uv=g.attributes.uv;
  for(let i=0;i<p.count;i++){
    if(p.getZ(i)<-d/2+1e-4){const t=p.getX(i)/(w/2);p.setZ(i,p.getZ(i)-(1-t*t)*Math.min(.016,w*.16));}
    uv.setX(i,(tile+.02+uv.getX(i)*.96)/tiles);
  }
  g.computeVertexNormals();
  return g;
}

/** One side of a pointed arch from its spring to its point, as (across, up) pairs. */
export function pointedArc(half:number,rise:number,steps=14){
  const cx=(rise*rise-half*half)/(2*half),radius=cx+half,end=Math.atan2(rise,-cx),out:[number,number][]=[];
  for(let i=0;i<=steps;i++){const a=Math.PI+(end-Math.PI)*i/steps;out.push([cx+Math.cos(a)*radius,Math.sin(a)*-radius*(a>Math.PI?1:-1)]);}
  return out;
}

/** A candle burned part way down: uneven, its top dished round the wick, wax run down its side and pooled at its foot. Faces of its v run foot to top. */
export function candleGeometry(radius:number,height:number,seed:number){
  const SEG=14,RINGS=9,positions:number[]=[],uvs:number[]=[],index:number[]=[];
  const lobes=[0,1,2].map(i=>({at:hash(i,seed)*Math.PI*2,size:.14+hash(i*2.3,seed)*.28,reach:.35+hash(i*3.7,seed)*.6}));
  const profile=(t:number):[number,number]=>{
    if(t<.12)return [radius*(1.9-t/.12*.9),height*t*.25];
    if(t>.92)return [radius*(1-(t-.92)/.08*.75),height*(1-(t-.92)/.08*.05)];
    return [radius*(1+(hash(Math.round(t*8),seed)-.5)*.1),height*(.03+(t-.12)/.8*.97)];
  };
  for(let r=0;r<=RINGS;r++){
    const t=r/RINGS,[rad,y]=profile(t);
    for(let s=0;s<=SEG;s++){
      const a=s/SEG*Math.PI*2;let out=rad;
      for(const l of lobes){const d=Math.atan2(Math.sin(a-l.at),Math.cos(a-l.at));if(t>1-l.reach&&t<.95)out+=Math.exp(-(d*d)/(l.size*l.size))*radius*.26;}
      positions.push(Math.cos(a)*out,y,Math.sin(a)*out);uvs.push(s/SEG,t);
    }
  }
  for(let r=0;r<RINGS;r++)for(let s=0;s<SEG;s++){const a=r*(SEG+1)+s,b=a+1,c=a+SEG+1,e=c+1;index.push(a,c,b,b,c,e);}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));g.setIndex(index);g.computeVertexNormals();
  return g;
}

/** A turned shape round the y axis from (radius, height) points, slightly out of true like anything hand made. */
export function turnedGeometry(points:number[][]){
  const g=new THREE.LatheGeometry(points.map(([r,y])=>new THREE.Vector2(r,y)),14);
  const p=g.attributes.position;
  for(let i=0;i<p.count;i++){const a=Math.round(Math.atan2(p.getZ(i),p.getX(i))*3),n=1+(hash(a,Math.round(p.getY(i)*40))-.5)*.05;p.setX(i,p.getX(i)*n);p.setZ(i,p.getZ(i)*n);}
  g.computeVertexNormals();
  return g;
}
