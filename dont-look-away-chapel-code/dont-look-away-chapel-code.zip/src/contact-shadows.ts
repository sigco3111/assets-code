import * as THREE from 'three';
import { Pass,FullScreenQuad } from 'three/addons/postprocessing/Pass.js';

// Darkens creases: where nearby surfaces stand in front of this one. From
// Realistic Procedural Dungeons. Worked out at half size, then softened.
const vertexShader=`varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}`;
export class ContactShadowPass extends Pass{
  private target=new THREE.WebGLRenderTarget(1,1,{minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,depthBuffer:false});
  private occlusion=new THREE.ShaderMaterial({depthTest:false,depthWrite:false,vertexShader,uniforms:{tZ:{value:null},near:{value:.06},far:{value:65},lens:{value:1},res:{value:new THREE.Vector2(1,1)}},fragmentShader:`#include <packing>
    varying vec2 vUv;uniform sampler2D tZ;uniform float near,far,lens;uniform vec2 res;
    float sceneZ(vec2 uv){return perspectiveDepthToViewZ(texture2D(tZ,uv).r,near,far);}
    void main(){
      float z=sceneZ(vUv);
      if(z<-45.){gl_FragColor=vec4(1.);return;}
      // This surface's plane. One over depth runs straight across the screen on a flat surface, so a sample
      // only counts if it stands in front of that, which keeps a floor seen at an angle from shadowing itself.
      vec2 px=2./res;float iz=1./z;
      float xa=1./sceneZ(vUv+vec2(px.x,0.))-iz,xb=iz-1./sceneZ(vUv-vec2(px.x,0.));
      float ya=1./sceneZ(vUv+vec2(0.,px.y))-iz,yb=iz-1./sceneZ(vUv-vec2(0.,px.y));
      vec2 slope=vec2(abs(xa)<abs(xb)?xa:xb,abs(ya)<abs(yb)?ya:yb)/px;
      float occ=0.;
      vec2 scale=vec2(res.y/res.x,1.)*min(.16,lens*.3/-z);
      for(int i=0;i<16;i++){
        float a=float(i)*2.399963,r=sqrt((float(i)+.5)/16.);
        vec2 o=vec2(cos(a),sin(a))*scale*r;
        float d=sceneZ(vUv+o)-1./(iz+dot(slope,o));
        occ+=smoothstep(.07,.22,d)*(1.-smoothstep(.55,1.1,d));
      }
      gl_FragColor=vec4(vec3(1.-min(1.,occ/16.*2.1)*.72),1.);
    }`});
  private composite=new THREE.ShaderMaterial({depthTest:false,depthWrite:false,vertexShader,uniforms:{tColor:{value:null},tAO:{value:null},res:{value:new THREE.Vector2(1,1)}},fragmentShader:`
    varying vec2 vUv;uniform sampler2D tColor,tAO;uniform vec2 res;
    void main(){
      vec4 color=texture2D(tColor,vUv);vec2 px=2./res;float s=0.;
      for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++)s+=texture2D(tAO,vUv+vec2(float(x),float(y))*px).r;
      // Flames and anything burning bright keep their light.
      color.rgb*=mix(s/9.,1.,smoothstep(.8,2.,dot(color.rgb,vec3(.3,.6,.1))));
      gl_FragColor=color;
    }`});
  private quad=new FullScreenQuad();
  /** The scene's depth, for passes after this one. */
  depth:THREE.Texture|null=null;
  constructor(private camera:THREE.PerspectiveCamera){super();}
  setSize(width:number,height:number){
    this.target.setSize(Math.max(1,width>>1),Math.max(1,height>>1));
    this.occlusion.uniforms.res.value.set(width,height);this.composite.uniforms.res.value.set(width,height);
  }
  render(renderer:THREE.WebGLRenderer,writeBuffer:THREE.WebGLRenderTarget,readBuffer:THREE.WebGLRenderTarget){
    const o=this.occlusion.uniforms;this.depth=readBuffer.depthTexture;
    o.tZ.value=readBuffer.depthTexture;o.near.value=this.camera.near;o.far.value=this.camera.far;o.lens.value=this.camera.projectionMatrix.elements[5];
    this.quad.material=this.occlusion;renderer.setRenderTarget(this.target);this.quad.render(renderer);
    this.composite.uniforms.tColor.value=readBuffer.texture;this.composite.uniforms.tAO.value=this.target.texture;
    this.quad.material=this.composite;renderer.setRenderTarget(this.renderToScreen?null:writeBuffer);this.quad.render(renderer);
  }
}
