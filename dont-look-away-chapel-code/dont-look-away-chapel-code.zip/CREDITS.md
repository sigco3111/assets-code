# Credits

Don't Look Away by Blendi Bylygbashi. Code is MIT: see [LICENSE](LICENSE).

## Code

- [three.js](https://github.com/mrdoob/three.js), MIT.
- The stone shader, piers, ribs, paving and contact shadows are adapted from [Realistic Procedural Dungeons](https://git.patch.gg/blendi/realistic-procedural-dungeons), MIT, which builds on Dungeons (a block on Patch, MIT) and [Dungeon Forge](https://github.com/majidmanzarpour/threejs-procedural-dungeon) by Majid Manzarpour, MIT. Licence texts are in [licenses/](licenses/).

## Textures (CC0 1.0)

From [Poly Haven](https://polyhaven.com):

- "Medieval Blocks 05" and "Medieval Wall 01" by Rob Tuytel: `public/assets/stone/`.
- "Worn Planks" by Dimitrios Savva: `public/assets/wood-*.webp`.

## Models and generated pictures

The angels (`public/assets/angel-*.glb`) and the pew (`public/assets/pew-game.glb`) began as images made with Nano Banana, turned into 3D with Meshy, and were then compressed and placed in the game. `public/social-preview.jpg` and the pictures in `docs/media/` are captures of the game.

Copyright in AI output is unsettled and may not exist in some countries. To the extent we hold any rights in these files, we dedicate them under [CC0 1.0](licenses/CC0-1.0.txt). We make no promise that they are free of other people's rights.

## Fonts (SIL Open Font License 1.1)

Cormorant Garamond and Manrope: licence texts are in `public/fonts/`. The bundled files stay under that licence.

## Sound

The sound effects in `public/assets/*.mp3` were generated with ElevenLabs Sound Effects for this game. They are included so the game runs, and are not covered by this repository's open licences. If you want to reuse them on their own, check ElevenLabs' terms first. The heartbeat and some other sounds are synthesised in code, which is under the MIT licence.
