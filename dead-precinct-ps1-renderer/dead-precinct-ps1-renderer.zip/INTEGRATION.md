# INTEGRATION — ps1-renderer.js

Extracted sections of a single-file game; reuse as reference or with light adaptation.

Globals the code expects:
- `const W=320,H=240` and `gl` = `canvas.getContext('webgl',{antialias:false})`.
- `hx` = 2D context of an overlay canvas (only needed for `grain()`/vignette).
- `rnd` = `Math.random` (grain only).

Frame flow (mirrors the original):
1. Build geometry into the shared buffer with `box(M, ...)` / `quad(...)` /
   `mesh(...)` (mesh lives with the character code, not in this pack).
   `vtx/quad` append to `V`; reset `vn=0` per scene build.
2. Call `draw3(eye,target,l1,c1,l2,c2,amb,fog,fogColor,fov,bgTexture?,bgBrightness,bgTint)`.
   With `bgTexture` null it draws the buffered geometry straight; with a texture it
   draws the pre-rendered background first (mode `md=1`), then writes scene depth
   with the color mask off, then draws characters so they occlude correctly.
3. Overlay: draw the 3D canvas to the 2D canvas, then `grain()`, vignette `VG`,
   and the `#scan` CSS layer (snippet at the bottom of the file).

The BG loader maps room keys ("0_0".."5_1") to image URLs; the example paths match
the `dead-precinct-backgrounds` pack (assets-2d-pixel).
