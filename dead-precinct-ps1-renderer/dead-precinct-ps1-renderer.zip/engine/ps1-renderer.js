// Dead Precinct PS1 스타일 WebGL 렌더러 (참고용 원본 발췌)
// 출처: https://github.com/Bao5ye/dead-precinct (commit 3292dc6, MIT, Copyright (c) 2026 Bao5ye)
// 외부 라이브러리 없는 WebGL1 단일 패스 렌더러. 320x240 렌더 타깃.
// 특징: 버텍스 스냅(지터), 어파인 텍스처 매핑, 버텍스별 2점 조명+거리 감쇠, 안개,
//       15비트 디더링, 절차적 표면 머티리얼(t=3..8: 벽돌/타일/판자/콘크리트/금속/천),
//       프리렌더 배경 깊이 합성(md=1 모드: 배경을 깊이 버퍼 뒤에 그림), CRT 그레인·비네트.
// 구성: [1] GL 초기화+셰이더 [2] 프리렌더 배경 텍스처 로더 [3] vtx/quad/box 지오메트리
//       [4] 4x4 행렬·투영·뷰 [5] draw3(조명/안개/배경 합성 드로) [6] 그레인·비네트·스캔라인.
// 의존: W=320,H=240, gl(캔버스 webgl 컨텍스트). 캐릭터 메시는 mesh()가 같은 V 버퍼에 쌓음(본 팩 미포함).
/* ---------- GL: PS1 스타일 셰이더(버텍스 떨림/버텍스별 라이팅/안개/15비트 디더링) ---------- */
function sh(t,s){const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);return o}
const pr=gl.createProgram();
gl.attachShader(pr,sh(gl.VERTEX_SHADER,`attribute vec3 p,c,n;attribute float t;attribute vec2 uv;varying vec3 va;uniform mat4 vp;uniform vec2 fog;uniform float md;
varying vec3 vc,vw,vN;varying float vf,vt;
void main(){vec4 q=vp*vec4(p,1.);if(md>.5)q=vec4(p.xy,0.,1.);else if(t<.5||t>9.5){float w=max(abs(q.w),.001);q.xy=floor(q.xy/w*vec2(160.,120.)+.5)/vec2(160.,120.)*w;}
gl_Position=q;va=vec3(uv*q.w,q.w);vc=c;vt=t;vN=n;vw=p;vf=clamp((q.w-fog.x)/(fog.y-fog.x),0.,1.);}`));
gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,`precision highp float;varying vec3 vc,vw,vN,va;varying float vf,vt;uniform sampler2D atl;uniform vec3 fc,l1,c1,l2,c2,amb;uniform vec4 rs;uniform float md,bgk;uniform vec3 bgt;uniform sampler2D bg;
float H(vec2 v){return fract(sin(dot(v,vec2(12.9898,78.233)))*43758.5453);}
float VN(vec2 v){vec2 i=floor(v),f=fract(v);f=f*f*(3.-2.*f);return mix(mix(H(i),H(i+vec2(1.,0.)),f.x),mix(H(i+vec2(0.,1.)),H(i+vec2(1.,1.)),f.x),f.y);}
void main(){if(md>.5){gl_FragColor=vec4(texture2D(bg,gl_FragCoord.xy/vec2(320.,240.)).rgb*bgk*bgt,1.);return;}vec3 col=vc,N=normalize(vN);int m=int(vt+.5);
if(m!=2){if(m==10)col=texture2D(atl,va.xy/va.z).rgb*vc;else if(m>0){vec3 q=vw-N*.01;vec2 uv=abs(N.y)>.5?q.xz:abs(N.x)>.5?q.zy:q.xy;uv=floor(uv*32.)/32.;float h=H(uv*32.),k=1.;
 if(m==3){vec2 b=uv*vec2(2.5,5.);b.x+=.5*mod(floor(b.y),2.);vec2 f=fract(b);k=(f.x<.08||f.y<.14)?.5:.75+.3*H(floor(b))+.1*h;}
 else if(m==4){vec2 f=fract(uv*2.);k=(f.x<.07||f.y<.07)?.55:(mod(floor(uv.x*2.)+floor(uv.y*2.),2.)<.5?1.:.72)*(.92+.12*h);}
 else if(m==5){float r=floor(uv.y*6.);k=fract(uv.y*6.)<.17?.55:.8+.25*H(vec2(r,floor(uv.x*.8+H(vec2(r,1.))*3.)))-.12*H(vec2(floor(uv.x*32.),r));}
 else if(m==6){k=.78+.2*h+.2*VN(uv*3.);}
 else if(m==7){vec2 f=fract(uv*vec2(2.,1.));k=(f.x<.04||f.y<.03)?.5:(f.x<.1||f.y<.06)?1.15:.9+.1*h;}
 else if(m==8){k=uv.y<.9?(fract(uv.x*2.)<.07?.4:.55+.08*h):uv.y<1.?1.15:.9+.12*h;}
 else k=.85+.25*h;
 k*=.7+.45*VN(uv*.9+7.);
 if(abs(N.y)<.5)k*=.5+.5*smoothstep(0.,.7,q.y);
 else if(N.y>.5&&q.y<.2){float d=min(min(q.x-rs.x,rs.z-q.x),min(q.z-rs.y,rs.w-q.z));k*=.5+.5*smoothstep(0.,.8,d);}
 col*=k;}
 vec3 L=l1-vw;float d=max(length(L),.01);vec3 lt=amb*(1.+.5*max(N.y,0.))+c1*(max(dot(N,L/d),0.)*.8+.2)/(1.+.12*d*d);
 L=l2-vw;d=max(length(L),.01);lt+=c2*(max(dot(N,L/d),0.)*.8+.2)/(1.+.12*d*d);col*=lt;}
col=mix(col,fc,vf);vec2 f=mod(floor(gl_FragCoord.xy),2.);float d=f.x<.5?(f.y<.5?0.:.75):(f.y<.5?.5:.25);
gl_FragColor=vec4(floor(col*31.+d)/31.,1.);}`));
gl.linkProgram(pr);gl.useProgram(pr);
const u={};['vp','l1','c1','l2','c2','amb','fog','fc','rs','md','bgk','bgt'].forEach(n=>u[n]=gl.getUniformLocation(pr,n));
gl.bindBuffer(gl.ARRAY_BUFFER,gl.createBuffer());
[['p',3,0],['c',3,12],['n',3,24],['t',1,36],['uv',2,40]].forEach(a=>{const l=gl.getAttribLocation(pr,a[0]);gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,a[1],gl.FLOAT,false,48,a[2])});
gl.enable(gl.DEPTH_TEST);
// [2] 프리렌더 배경 텍스처 로더 — 원본은 base64 데이터 URI 내장, 여기서는 외부 PNG 경로 예시
const BG={"0_0":"bg/street-a.png","0_1":"bg/street-b.png","1_0":"bg/hall-a.png","1_1":"bg/hall-b.png","2_0":"bg/office.png","3_0":"bg/corridor-a.png","3_1":"bg/corridor-b.png","4_0":"bg/armory.png","5_0":"bg/garage-a.png","5_1":"bg/garage-b.png"},BT={};
if(BG)for(const k in BG){const im=new Image();im.onload=()=>{const t=gl.createTexture();gl.bindTexture(3553,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,1);gl.texImage2D(3553,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,im);
 gl.texParameteri(3553,10240,9728);gl.texParameteri(3553,10241,9728);gl.texParameteri(3553,10242,33071);gl.texParameteri(3553,10243,33071);BT[k]=t};im.src=BG[k]}
let RS=[-99,-99,99,99],REC=null;const V=new Float32Array(1500000);let vn=0,vs=0;

// [3] 지오메트리 적재 파이프라인 (vtx/quad/box)
const Q1=[0,0],Q0=[Q1,Q1,Q1,Q1];function vtx(a,c,n,t,q=Q1){const i=vn*12;V[i+10]=q[0];V[i+11]=q[1];V[i]=a[0];V[i+1]=a[1];V[i+2]=a[2];V[i+3]=c[0];V[i+4]=c[1];V[i+5]=c[2];V[i+6]=n[0];V[i+7]=n[1];V[i+8]=n[2];V[i+9]=t;vn++}
function quad(a,b,c,d,n,col,t,q=Q0){vtx(a,col,n,t,q[0]);vtx(b,col,n,t,q[1]);vtx(c,col,n,t,q[2]);vtx(a,col,n,t,q[0]);vtx(c,col,n,t,q[2]);vtx(d,col,n,t,q[3])}
const FC=[[0,2,6,4,-1,0,0],[1,3,7,5,1,0,0],[0,1,5,4,0,-1,0],[2,3,7,6,0,1,0],[0,1,3,2,0,0,-1],[4,5,7,6,0,0,1]],cs=[];for(let i=0;i<8;i++)cs.push([0,0,0]);
function box(M,cx,cy,cz,sx,sy,sz,col,t=0,k=1,tx){if(REC)REC.push([cx,cy,cz,sx,sy,sz,col,t,k]);
 for(let i=0;i<8;i++){const s=i&2?k:1,x=cx+(i&1?sx:-sx)/2*s,y=cy+(i&2?sy:-sy)/2,z=cz+(i&4?sz:-sz)/2*s,c=cs[i];c[0]=M[0]*x+M[4]*y+M[8]*z+M[12];c[1]=M[1]*x+M[5]*y+M[9]*z+M[13];c[2]=M[2]*x+M[6]*y+M[10]*z+M[14]}
 FC.forEach((f,fi)=>quad(cs[f[0]],cs[f[1]],cs[f[2]],cs[f[3]],[M[0]*f[4]+M[4]*f[5]+M[8]*f[6],M[1]*f[4]+M[5]*f[5]+M[9]*f[6],M[2]*f[4]+M[6]*f[5]+M[10]*f[6]],col,t,tx&&UVF(tx,fi)))}
// [4] 4x4 행렬 · 투영 · 뷰
const I0=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
function mul(a,b){const o=new Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o}
const X=(...m)=>m.reduce(mul),T=(x,y,z)=>[1,0,0,0,0,1,0,0,0,0,1,0,x,y,z,1],SC=s=>[s,0,0,0,0,s,0,0,0,0,s,0,0,0,0,1];
const RY=a=>{const c=Math.cos(a),s=Math.sin(a);return[c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1]},RX=a=>{const c=Math.cos(a),s=Math.sin(a);return[1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1]};
function persp(f,a,n,r){const t=1/Math.tan(f/2);return[t/a,0,0,0,0,t,0,0,0,0,(r+n)/(n-r),-1,0,0,2*r*n/(n-r),0]}
function look(e,c){let z=[e[0]-c[0],e[1]-c[1],e[2]-c[2]],l=Math.hypot(z[0],z[1],z[2]);z=z.map(v=>v/l);let x=[z[2],0,-z[0]];l=Math.hypot(x[0],x[2]);x=x.map(v=>v/l);
 const y=[z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0]],d=v=>-(v[0]*e[0]+v[1]*e[1]+v[2]*e[2]);
 return[x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,d(x),d(y),d(z),1]}
// [5] draw3: 씬 드로 + 프리렌더 배경 깊이 합성
function draw3(eye,tg,l1,c1,l2,c2,amb,fog,fc,fov=1,tex,bgk=1,bgt=[1,1,1]){gl.viewport(0,0,W,H);gl.clearColor(fc[0],fc[1],fc[2],1);gl.clear(16640);
 gl.uniformMatrix4fv(u.vp,false,new Float32Array(mul(persp(fov,W/H,.1,60),look(eye,tg))));
 gl.uniform3fv(u.l1,l1);gl.uniform3fv(u.c1,c1);gl.uniform3fv(u.l2,l2);gl.uniform3fv(u.c2,c2);gl.uniform3fv(u.amb,amb);gl.uniform2fv(u.fog,fog);gl.uniform3fv(u.fc,fc);gl.uniform4fv(u.rs,RS);gl.uniform1f(u.md,0);
 if(!tex){gl.bufferData(gl.ARRAY_BUFFER,V.subarray(0,vn*12),gl.DYNAMIC_DRAW);gl.drawArrays(4,0,vn);return}
 const vd=vn,z=[0,0,0];for(const q of[[-1,-1],[1,-1],[1,1],[-1,-1],[1,1],[-1,1]])vtx([q[0],q[1],0],z,z,0);
 gl.bufferData(gl.ARRAY_BUFFER,V.subarray(0,vn*12),gl.DYNAMIC_DRAW);gl.bindTexture(3553,tex);gl.uniform1f(u.bgk,bgk);gl.uniform3fv(u.bgt,bgt);gl.uniform1f(u.md,1);gl.disable(gl.DEPTH_TEST);gl.drawArrays(4,vd,6);
 gl.enable(gl.DEPTH_TEST);gl.uniform1f(u.md,0);gl.colorMask(false,false,false,false);gl.drawArrays(4,0,vs);gl.colorMask(true,true,true,true);gl.drawArrays(4,vs,vd-vs)}

// [6] CRT 그레인 · 비네트 · 스캔라인 (2D 오버레이 캔버스 + CSS)
const VG=document.createElement('canvas');VG.width=W;VG.height=H;{const x=VG.getContext('2d'),g=x.createRadialGradient(160,120,50,160,120,210);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.85)');x.fillStyle=g;x.fillRect(0,0,W,H)}
function grain(){for(let i=0;i<260;i++){hx.fillStyle=rnd()<.5?'rgba(255,255,255,.07)':'rgba(0,0,0,.14)';hx.fillRect(rnd()*W|0,rnd()*H|0,1,1)}}
// CSS: #scan{position:absolute;inset:0;pointer-events:none;background:repeating-linear-gradient(0deg,rgba(0,0,0,.2) 0 1px,transparent 1px 3px);box-shadow:inset 0 0 70px #000}
