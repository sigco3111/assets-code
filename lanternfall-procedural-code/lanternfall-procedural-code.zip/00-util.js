'use strict';
/* LANTERNFALL - util */
const LF = window.LF = {};
const PI = Math.PI, TAU = PI * 2;
const clamp = (x, a, b) => x < a ? a : x > b ? b : x;
const sat = x => x < 0 ? 0 : x > 1 ? 1 : x;
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = (a, b, x) => { x = sat((x - a) / (b - a)); return x * x * (3 - 2 * x); };
const QS = new URLSearchParams(location.search);
const qnum = (k, d) => QS.has(k) && QS.get(k) !== '' && !isNaN(+QS.get(k)) ? +QS.get(k) : d;

function mulberry(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6D2B79F5) >>> 0; let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hash1(n) { n = Math.sin(n * 127.1 + 311.7) * 43758.5453; return n - Math.floor(n); }
function hash2(x, y) { const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return n - Math.floor(n); }
function hash3(x, y, z) { const n = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453; return n - Math.floor(n); }
function vnoise2(x, y) {
  const ix = Math.floor(x), iy = Math.floor(y); let fx = x - ix, fy = y - iy;
  fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
  return lerp(lerp(hash2(ix, iy), hash2(ix + 1, iy), fx), lerp(hash2(ix, iy + 1), hash2(ix + 1, iy + 1), fx), fy);
}
function vnoise3(x, y, z) {
  const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z); let fx = x - ix, fy = y - iy, fz = z - iz;
  fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy); fz = fz * fz * (3 - 2 * fz);
  const a = lerp(lerp(hash3(ix, iy, iz), hash3(ix + 1, iy, iz), fx), lerp(hash3(ix, iy + 1, iz), hash3(ix + 1, iy + 1, iz), fx), fy);
  const b = lerp(lerp(hash3(ix, iy, iz + 1), hash3(ix + 1, iy, iz + 1), fx), lerp(hash3(ix, iy + 1, iz + 1), hash3(ix + 1, iy + 1, iz + 1), fx), fy);
  return lerp(a, b, fz);
}
function fbm3(x, y, z, o) { let s = 0, a = 0.5; for (let i = 0; i < (o || 3); i++) { s += a * vnoise3(x, y, z); x *= 2.03; y *= 2.03; z *= 2.03; a *= 0.5; } return s; }
// sRGB hex -> linear rgb triple
function C(hex) {
  const f = v => { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  return [f((hex >> 16) & 255), f((hex >> 8) & 255), f(hex & 255)];
}
const mixC = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
// the road: identical in GLSL (world.js)
const WORLD_L = 4096, KW = n => TAU * n / WORLD_L;
function pathZ(x) { return 2.4 * Math.sin(x * KW(20)) + 1.3 * Math.sin(x * KW(9) + 1.7); }
function pathDZ(x) { return 2.4 * KW(20) * Math.cos(x * KW(20)) + 1.3 * KW(9) * Math.cos(x * KW(9) + 1.7); }
function terrH(x, z) {
  const d = Math.abs(z - pathZ(x)), k = smooth(6.5, 20, d), far = smooth(30, 150, d);
  const h1 = 1.6 * Math.sin(x * KW(13) + z * 0.071 + 1.3) + 1.2 * Math.sin(x * KW(31) - z * 0.113 + 4.1) + 0.5 * Math.sin(x * KW(67) + z * 0.31) + 0.35 * Math.sin(-x * KW(113) + z * 0.47 + 2.0);
  const h2 = far * far * (14 + 9 * Math.sin(x * KW(5) + z * 0.011) + 6 * Math.sin(x * KW(11) - z * 0.023 + 1.0));
  return k * h1 * 0.6 + h2;
}
const ease = {
  io: t => t * t * (3 - 2 * t),
  in: t => t * t * t,
  out: t => 1 - Math.pow(1 - t, 3),
  lin: t => t,
  snap: t => 1 - Math.pow(1 - t, 5)
};
function angDiff(a, b) { let d = (b - a) % TAU; if (d > PI) d -= TAU; if (d < -PI) d += TAU; return d; }
function fmt(n) {
  n = Math.floor(n);
  if (n < 10000) return '' + n;
  if (n < 1e6) return (n / 1e3).toFixed(n < 1e5 ? 1 : 0) + 'k';
  if (n < 1e9) return (n / 1e6).toFixed(n < 1e8 ? 2 : 1) + 'M';
  return (n / 1e9).toFixed(2) + 'B';
}
