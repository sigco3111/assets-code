/* LANTERNFALL - the gloam: monsters and bosses */
LF.MONSTERS = {};
function bipedRig(j) {
  // j: joint table {hips:[x,y,z], spine, chest, neck, head, sh:[x,y], el:[x,y], wr:[x,y], hp:[x,y], kn:[x,y], an:[x,y]}
  const s = j.sh, e = j.el, w = j.wr, h = j.hp, k = j.kn, a = j.an, c = j.chest;
  return makeRig([
    ['root', null, 0, 0, 0], ['hips', 'root'].concat(j.hips), ['spine', 'hips'].concat(j.spine), ['chest', 'spine'].concat(c), ['neck', 'chest'].concat(j.neck), ['head', 'neck'].concat(j.head),
    ['lUp', 'chest', s[0], s[1], s[2] || 0], ['lFore', 'lUp', e[0], e[1], e[2] || 0], ['lHand', 'lFore', w[0], w[1], w[2] || 0],
    ['rUp', 'chest', -s[0], s[1], s[2] || 0], ['rFore', 'rUp', -e[0], e[1], e[2] || 0], ['rHand', 'rFore', -w[0], w[1], w[2] || 0],
    ['lThigh', 'hips', h[0], h[1], 0], ['lShin', 'lThigh', k[0], k[1], 0], ['lFoot', 'lShin', a[0], a[1], 0],
    ['rThigh', 'hips', -h[0], h[1], 0], ['rShin', 'rThigh', -k[0], k[1], 0], ['rFoot', 'rShin', -a[0], a[1], 0],
    ['cloakA', 'chest', 0, c[1] + 0.18, -0.1], ['cloakB', 'cloakA', 0, c[1] - 0.18, -0.15], ['cloakC', 'cloakB', 0, c[1] - 0.54, -0.17],
    ['wR', 'rHand', -w[0], w[1] - 0.05, 0], ['wL', 'lHand', w[0], w[1] - 0.05, 0], ['str', 'wL', w[0], w[1], 0], ['arw', 'str', w[0], w[1], 0],
    ['lan', 'wL', w[0], w[1], 0, 1], ['back', 'chest', 0, c[1], -0.12], ['lanB', 'back', 0, c[1], -0.12, 1]
  ]);
}
// limb hanging in bind: three joints, five radii (top, mid-upper, joint, mid-lower, end)
function limb3(g, p1, p2, p3, r, bA, bB, opt) {
  opt = opt || {}; const rings = [], add = (p, q, t, rad) => rings.push({ y: lerp(p[1], q[1], t), x: lerp(p[0], q[0], t), z: lerp(p[2] || 0, q[2] || 0, t), rx: rad, rz: rad * (opt.kz || 1) });
  add(p3, p2, 0, r[4]); add(p3, p2, 0.5, r[3]); add(p2, p1, 0, r[2]); add(p2, p1, 0.5, r[1]); add(p2, p1, 1, r[0]);
  g.bone(jb(bA, bB, p2[1], opt.range || 0.06));
  return g.loft(rings, { seg: opt.seg || 10, sub: 3, cap0: true, cap1: true, wr: opt.wr, wra: opt.wra || 3, wry: opt.wry || 14 });
}
function rockAt(g, c, s, seed, col) {
  const r = mulberry(seed), ox = r() * 40, oy = r() * 40, sh = col || (0.055 + r() * 0.06);
  g.mat(typeof sh === 'number' ? [sh, sh, sh * 0.98] : sh, 0.93, 0, T_STONE, 0.6);
  g.tr(c[0], c[1], c[2], (r() - 0.5) * 0.5, r() * TAU, (r() - 0.5) * 0.5);
  g.surf(11, 7, (u, v) => { const a = u * TAU, b = (v - 0.5) * PI, cb = Math.cos(b), x = Math.cos(a) * cb, y = Math.sin(b), z = Math.sin(a) * cb; const d = 0.7 + 0.5 * fbm3(x * 1.1 + ox, y * 1.1 + oy, z * 1.1, 2) + 0.2 * Math.round(vnoise3(x * 1.7 + oy, y * 1.7, z * 1.7 + ox) * 2); const e = 0.7; return [_spow(x, e) * d * s[0], _spow(y, e) * d * s[1], _spow(z, e) * d * s[2]]; }, { closeU: true });
  g.pop();
}
const M_GLOW = C(0xbfffd0);

/* ---------- PEATWIGHT ---------- */
(function () {
  const J = { hips: [0, 0.9, 0], spine: [0, 1.03, 0], chest: [0, 1.22, 0.0], neck: [0, 1.45, 0.02], head: [0, 1.5, 0.05], sh: [0.25, 1.38], el: [0.29, 0.98], wr: [0.31, 0.6], hp: [0.115, 0.86], kn: [0.125, 0.47], an: [0.13, 0.09] };
  function build(opt) {
    const rig = bipedRig(J), g = new Geo(rig), peat = C(0x1d1711), peat2 = C(0x2b2218), root = C(0x40311f);
    g.mat(peat, 0.97, 0, T_PEAT, 1.2); g.bone(chainY([['chest', 9], ['spine', 1.2], ['hips', 1.02]], 0.07));
    g.loft([{ y: 0.78, rx: 0.17, rz: 0.13, rb: 0.14 }, { y: 0.92, rx: 0.2, rz: 0.15, rb: 0.16 }, { y: 1.08, rx: 0.18, rz: 0.16, rb: 0.17 }, { y: 1.25, rx: 0.24, rz: 0.17, rb: 0.24 }, { y: 1.4, rx: 0.27, rz: 0.15, rb: 0.27 }, { y: 1.5, rx: 0.2, rz: 0.11, rb: 0.2 }, { y: 1.56, rx: 0.08, rz: 0.06, rb: 0.1 }], { seg: 16, sub: 3, cap0: true, cap1: true, wr: 0.22, wra: 3, wry: 9 });
    // head: a sunken lump with two pale pits
    g.bone('head'); g.mat(peat2, 0.97, 0, T_PEAT, 0.4);
    g.tr(0, 1.56, 0.1, 0.35, 0, 0); g.loft([{ y: -0.12, rx: 0.07, rz: 0.08 }, { y: -0.04, rx: 0.105, rz: 0.12, rb: 0.11 }, { y: 0.06, rx: 0.11, rz: 0.12, rb: 0.12 }, { y: 0.14, rx: 0.07, rz: 0.08 }, { y: 0.17, rx: 0.01, rz: 0.01 }], { seg: 12, sub: 3, cap0: true, cap1: true, wr: 0.2, wra: 3, wry: 20 });
    g.mat(M_GLOW, 0.4, 0, T_GLOW, 0.9); for (const s of [-1, 1]) { g.tr(s * 0.042, 0.035, 0.106); g.sphere(0.014, 0.01, 0.01, 6, 4); g.pop(); }
    g.mat([0.004, 0.004, 0.004], 1, 0, T_PEAT, 0); g.tr(0, -0.05, 0.1); g.sphere(0.04, 0.022, 0.03, 8, 5); g.pop();
    g.pop();
    for (const s of [1, -1]) {
      const U = s > 0 ? 'lUp' : 'rUp', F = s > 0 ? 'lFore' : 'rFore', Hn = s > 0 ? 'lHand' : 'rHand', Tn = s > 0 ? 'lThigh' : 'rThigh', S = s > 0 ? 'lShin' : 'rShin', Ft = s > 0 ? 'lFoot' : 'rFoot';
      g.mat(peat, 0.97, 0, T_PEAT, 0.8); limb3(g, [s * 0.25, 1.42, 0], [s * 0.29, 0.98, 0], [s * 0.31, 0.6, 0], [0.1, 0.075, 0.06, 0.075, 0.055], U, F, { wr: 0.25 });
      g.mat(peat, 0.97, 0, T_PEAT, 2.0); limb3(g, [s * 0.115, 0.92, 0], [s * 0.125, 0.47, 0], [s * 0.13, 0.06, 0], [0.12, 0.1, 0.075, 0.085, 0.09], Tn, S, { wr: 0.22 });
      g.bone(Ft); g.tr(s * 0.13, 0.05, 0.06); g.surf(9, 6, (u, v) => { const a = u * TAU, b = (v - 0.5) * PI, cb = Math.cos(b); return [Math.cos(a) * cb * 0.1, Math.max(-0.04, Math.sin(b) * 0.07), Math.sin(a) * cb * 0.17]; }, { closeU: true }); g.pop();
      // root claws
      g.bone(Hn); g.mat(root, 0.9, 0, T_PEAT, 0.5);
      g.tr(s * 0.31, 0.57, 0); g.sphere(0.065, 0.07, 0.07, 8, 6); g.pop();
      for (let i = 0; i < 4; i++) { const a = (i - 1.5) * 0.5; g.tube([[s * 0.31 + Math.sin(a) * 0.04, 0.55, 0.02], [s * 0.31 + Math.sin(a) * 0.09, 0.44, 0.05 + Math.cos(a) * 0.03], [s * 0.31 + Math.sin(a) * 0.11, 0.3, 0.11 + i * 0.01], [s * 0.31 + Math.sin(a) * 0.09, 0.22, 0.17]], t => 0.02 * (1 - t * 0.85), { seg: 5, sub: 3 }); }
      // roots winding the arm
      g.bone(jb(U, F, 0.98, 0.06)); const pts = []; for (let i = 0; i <= 14; i++) { const t = i / 14, y = lerp(1.4, 0.64, t), a = t * 9 + s; pts.push([s * lerp(0.25, 0.31, t) + Math.cos(a) * 0.085, y, Math.sin(a) * 0.085]); } g.tube(pts, 0.014, { seg: 5, sub: 2 });
      // rags of rotted rope/cloth off the forearm
      g.mat(C(0x2a251c), 0.97, 0, T_CLOTH, 0.5); g.bone(F);
      g.surf(4, 4, (u, v) => [s * 0.3 + (u - 0.5) * 0.12, 0.95 - v * (0.3 + 0.1 * Math.sin(u * 9)), -0.07 - v * 0.05 + 0.02 * Math.sin(u * 5 + v * 4)], { thick: 0.004 });
    }
    // roots across the back and a rope round the waist
    g.mat(root, 0.9, 0, T_PEAT, 0.5); g.bone(chainY([['chest', 9], ['spine', 1.2], ['hips', 1.02]], 0.07));
    for (let k = 0; k < 4; k++) { const pts = [], ph = k * 1.7; for (let i = 0; i <= 12; i++) { const t = i / 12, y = lerp(0.85, 1.5, t), a = ph + t * 4.2; pts.push([Math.cos(a) * (0.2 + 0.05 * Math.sin(t * 3 + k)), y, Math.sin(a) * (0.18 + 0.05 * t)]); } g.tube(pts, t => 0.018 - 0.008 * t, { seg: 5, sub: 2 }); }
    g.mat(COL.rope, 0.95, 0, T_CLOTH, 1.5); g.lathe([[0.2, 0.96], [0.215, 0.98], [0.2, 1.0]], 12); g.tube([[0.1, 0.98, 0.16], [0.13, 0.8, 0.19], [0.11, 0.62, 0.17]], 0.014, { seg: 5, sub: 2 });
    const fig = new Figure(g, rig); fig.fx = { tip: [rig.names.rHand, -0.33, 0.3, 0.1], head: [rig.names.head, 0, 1.6, 0.12] }; return fig;
  }
  const carry = { spine: [0.38, 0, 0], chest: [0.3, 0, 0], neck: [-0.25, 0, 0], head: [-0.3, 0, 0], lUp: [-0.35, 0, 0.12], rUp: [-0.3, 0, -0.12], lFore: [-0.3, 0, 0], rFore: [-0.35, 0, 0], lThigh: [-0.2, 0.15, 0.06], rThigh: [-0.2, -0.15, -0.06], lShin: [0.35, 0, 0], rShin: [0.35, 0, 0], lFoot: [-0.15, 0, 0], rFoot: [-0.15, 0, 0] };
  const clips = { attack: mkClip(0.5, [
    { t: 0.32, e: 'out', b: { spine: [0.0, 0, 0], chest: [-0.2, -0.3, 0], rUp: [-2.7, 0, -0.5], rFore: [-0.9, 0, 0], lUp: [-1.0, 0, 0.5], lFore: [-0.8, 0, 0] }, root: [0, 0.02, -0.06] },
    { t: 0.5, e: 'in', b: { spine: [0.6, 0, 0], chest: [0.5, 0.4, 0], rUp: [-0.9, 0, 0.3], rFore: [-0.2, 0, 0], lUp: [-0.2, 0, 0.5] }, root: [0, -0.1, 0.25] },
    { t: 0.72, b: {}, root: [0, -0.1, 0.25] }], carry) };
  LF.MONSTERS.peatwight = { build, style: { carry, clips, strideAmp: 0.75, stride: 1.05, gait: { bounce: 1.4, sway: 2.0, lean: 0.6 } }, scale: 1.04, death: 'burn', disCol: [1, 0.45, 0.1], hpY: 1.85, radius: 0.42 };
})();

/* ---------- THORNLING ---------- */
(function () {
  const J = { hips: [0, 0.82, 0], spine: [0, 0.95, 0], chest: [0, 1.1, 0.0], neck: [0, 1.3, 0.02], head: [0, 1.36, 0.04], sh: [0.17, 1.26], el: [0.24, 0.92], wr: [0.27, 0.56], hp: [0.09, 0.8], kn: [0.12, 0.45], an: [0.12, 0.07] };
  function build(opt) {
    const rig = bipedRig(J), g = new Geo(rig), briar = C(0x33261a), briar2 = C(0x4a3a24), thorn = C(0x6a5a40);
    const twist = (p1, p2, p3, bA, bB, r0, n) => {
      g.bone(jb(bA, bB, p2[1], 0.05));
      for (let k = 0; k < n; k++) { const pts = [], ph = k / n * TAU; for (let i = 0; i <= 10; i++) { const t = i / 10, P1 = t < 0.5 ? p1 : p2, P2 = t < 0.5 ? p2 : p3, u = t < 0.5 ? t * 2 : t * 2 - 1, a = ph + t * 7, rr = r0 * (1 - t * 0.4); pts.push([lerp(P1[0], P2[0], u) + Math.cos(a) * rr, lerp(P1[1], P2[1], u), lerp(P1[2] || 0, P2[2] || 0, u) + Math.sin(a) * rr]); } g.mat(k % 2 ? briar2 : briar, 0.92, 0, T_PEAT, 0.8); g.tube(pts, t => 0.02 * (1 - t * 0.45), { seg: 5, sub: 2 }); }
      // thorns
      g.mat(thorn, 0.8, 0, T_BONE, 0.2); const r = mulberry(Math.floor(p1[1] * 100 + p1[0] * 37 + 9));
      for (let i = 0; i < 7; i++) { const t = r(), P1 = t < 0.5 ? p1 : p2, P2 = t < 0.5 ? p2 : p3, u = t < 0.5 ? t * 2 : t * 2 - 1, a = r() * TAU, bx = lerp(P1[0], P2[0], u), by = lerp(P1[1], P2[1], u), bz = lerp(P1[2] || 0, P2[2] || 0, u); g.tube([[bx + Math.cos(a) * 0.03, by, bz + Math.sin(a) * 0.03], [bx + Math.cos(a) * 0.1, by + 0.03, bz + Math.sin(a) * 0.1]], t2 => 0.011 * (1 - t2), { seg: 4, sub: 1 }); }
    };
    for (const s of [1, -1]) {
      twist([s * 0.17, 1.28, 0], [s * 0.24, 0.92, 0], [s * 0.27, 0.5, 0.02], s > 0 ? 'lUp' : 'rUp', s > 0 ? 'lFore' : 'rFore', 0.03, 3);
      twist([s * 0.09, 0.84, 0], [s * 0.12, 0.45, 0.02], [s * 0.12, 0.03, 0], s > 0 ? 'lThigh' : 'rThigh', s > 0 ? 'lShin' : 'rShin', 0.035, 3);
      g.bone(s > 0 ? 'lHand' : 'rHand'); g.mat(thorn, 0.8, 0, T_BONE, 0.2);
      for (let i = 0; i < 3; i++) { const a = (i - 1) * 0.6; g.tube([[s * 0.27, 0.52, 0.02], [s * 0.27 + Math.sin(a) * 0.07, 0.4, 0.06], [s * 0.27 + Math.sin(a) * 0.09, 0.26, 0.14]], t => 0.016 * (1 - t * 0.9), { seg: 4, sub: 2 }); }
      g.bone(s > 0 ? 'lFoot' : 'rFoot'); g.mat(briar, 0.92, 0, T_PEAT, 1.5);
      for (let i = 0; i < 3; i++) { const a = (i - 1) * 0.7; g.tube([[s * 0.12, 0.08, 0], [s * 0.12 + Math.sin(a) * 0.08, 0.03, 0.1], [s * 0.12 + Math.sin(a) * 0.12, 0.01, 0.2]], t => 0.022 * (1 - t * 0.7), { seg: 4, sub: 2 }); }
    }
    // body: a cage of briar hoops round a dark core
    g.bone(chainY([['chest', 9], ['spine', 1.08], ['hips', 0.93]], 0.06)); g.mat([0.006, 0.008, 0.005], 1, 0, T_PEAT, 0);
    g.loft([{ y: 0.76, rx: 0.08, rz: 0.07 }, { y: 0.95, rx: 0.1, rz: 0.09 }, { y: 1.15, rx: 0.13, rz: 0.11 }, { y: 1.3, rx: 0.1, rz: 0.09 }, { y: 1.36, rx: 0.04, rz: 0.04 }], { seg: 10, sub: 3, cap0: true, cap1: true, wr: 0.15 });
    for (let k = 0; k < 7; k++) { const pts = [], y0 = 0.78 + k * 0.085, tilt = (k % 2 ? 1 : -1) * 0.07; for (let i = 0; i <= 14; i++) { const a = i / 14 * TAU, rr = 0.1 + 0.06 * Math.sin((y0 - 0.74) / 0.62 * PI); pts.push([Math.cos(a) * (rr + 0.04), y0 + Math.sin(a + k) * tilt, Math.sin(a) * (rr + 0.02)]); } g.mat(k % 2 ? briar2 : briar, 0.92, 0, T_PEAT, 0.6); g.tube(pts, 0.017, { seg: 5, sub: 1, cap: false }); }
    g.mat(thorn, 0.8, 0, T_BONE, 0.2); const r = mulberry(77); for (let i = 0; i < 16; i++) { const a = r() * TAU, y = 0.8 + r() * 0.5, rr = 0.15; g.tube([[Math.cos(a) * rr, y, Math.sin(a) * rr * 0.9], [Math.cos(a) * (rr + 0.1), y + 0.04, Math.sin(a) * (rr + 0.1)]], t => 0.012 * (1 - t), { seg: 4, sub: 1 }); }
    // seed-husk head, split, with a faint glow inside
    g.bone('head'); g.tr(0, 1.44, 0.06, 0.5, 0, 0);
    g.mat(C(0x3d2f1c), 0.85, 0, T_WOOD, 0.3);
    for (const sg of [-1, 1]) g.surf(8, 8, (u, v) => { const a = (u - 0.5) * 2.6 * sg + (sg > 0 ? 0 : PI), b = (v - 0.5) * PI, cb = Math.cos(b); return [Math.sin(a) * cb * 0.085 + sg * 0.012, Math.sin(b) * 0.2 - 0.02, Math.cos(a) * cb * 0.1]; }, { thick: 0.008 });
    g.mat(M_GLOW, 0.4, 0, T_GLOW, 0.7); g.sphere(0.045, 0.14, 0.05, 6, 6);
    g.mat(thorn, 0.8, 0, T_BONE, 0.2); for (let i = 0; i < 4; i++) g.tube([[(i - 1.5) * 0.03, 0.15, -0.02], [(i - 1.5) * 0.06, 0.3 + (i % 2) * 0.06, -0.08]], t => 0.012 * (1 - t), { seg: 4, sub: 1 });
    g.pop();
    const fig = new Figure(g, rig); fig.fx = { tip: [rig.names.rHand, -0.3, 0.3, 0.12], head: [rig.names.head, 0, 1.45, 0.1] }; return fig;
  }
  const carry = { spine: [0.5, 0, 0], chest: [0.35, 0, 0], neck: [-0.4, 0, 0], head: [-0.3, 0, 0], lUp: [-0.7, 0, 0.5], rUp: [-0.7, 0, -0.5], lFore: [-0.9, 0, 0], rFore: [-0.9, 0, 0], lThigh: [-0.6, 0.2, 0.15], rThigh: [-0.6, -0.2, -0.15], lShin: [1.0, 0, 0], rShin: [1.0, 0, 0], lFoot: [-0.4, 0, 0], rFoot: [-0.4, 0, 0] };
  const clips = { attack: mkClip(0.45, [
    { t: 0.28, e: 'out', b: { spine: [0.2, 0, 0], chest: [0.0, -0.4, 0], rUp: [-2.4, 0, -0.7], rFore: [-1.2, 0, 0], lUp: [-2.2, 0, 0.7], lFore: [-1.2, 0, 0] }, root: [0, 0.08, -0.1] },
    { t: 0.45, e: 'in', b: { spine: [0.8, 0, 0], chest: [0.5, 0.3, 0], rUp: [-1.1, 0, 0.4], rFore: [-0.3, 0, 0], lUp: [-1.0, 0, -0.3], lFore: [-0.3, 0, 0] }, root: [0, -0.05, 0.4] },
    { t: 0.7, b: {}, root: [0, -0.05, 0.3] }], carry) };
  LF.MONSTERS.thornling = { build, style: { carry, clips, strideAmp: 1.1, stride: 0.6, gait: { bounce: 1.8, sway: 1.5, lift: 1.6 } }, scale: 0.62, death: 'burst', disCol: [0.6, 1, 0.5], hpY: 1.05, radius: 0.28 };
})();

/* ---------- RUSTBOUND (and THE BARROW KING) ---------- */
(function () {
  const P = { sh: 0.215, hp: 0.1 };
  function build(opt) {
    opt = opt || {}; const king = !!opt.king, rig = humanRig(P), g = new Geo(rig), H = HW;
    const rust = C(0x3d3e42), dark = C(0x2c2826), gl = (x0, y0, x1, y1, r, bone) => { g.bone(bone); g.mat(M_GLOW, 0.4, 0, T_GLOW, 0.16); g.tube([[x0, y0, 0], [x1, y1, 0]], r * 0.7, { seg: 5, sub: 1 }); };
    const pm = (gr) => g.mat(rust, 0.52, 0.9, T_PLATE, gr === undefined ? 1.2 : 0.75 + gr * 0.22);
    // the pale light that holds it up, glimpsed in the gaps
    gl(0, 0.95, 0, 1.5, 0.05, HW.TW);
    g.mat([0.004, 0.005, 0.004], 1, 0, T_PEAT, 0); for (const s of [1, -1]) { g.bone(jb(s > 0 ? 'lUp' : 'rUp', s > 0 ? 'lFore' : 'rFore', 1.14, 0.05)); g.tube([[s * P.sh, 1.44, 0], [s * (P.sh + 0.02), 1.14, 0], [s * (P.sh + 0.03), 0.9, 0]], 0.03, { seg: 6, sub: 2 }); g.bone(jb(s > 0 ? 'lThigh' : 'rThigh', s > 0 ? 'lShin' : 'rShin', 0.5, 0.05)); g.tube([[s * P.hp, 0.94, 0], [s * P.hp, 0.5, 0], [s * P.hp, 0.12, 0]], 0.04, { seg: 6, sub: 2 }); }
    // cuirass, fauld, tassets
    pm(2.0); H.torso(g, { grow: 0.03, y0: 1.06, y1: 1.47, k: 1.04, kz: 1.12, thick: 0.006, bone: 'chest', wr: 0.012 });
    g.bone('hips'); for (let i = 0; i < 3; i++) { const y = 1.05 - i * 0.075, gr = 0.036 + i * 0.012; g.loft([{ y: y - 0.085, rx: 0.172 + gr + 0.012, rz: 0.11 + gr + 0.012, rb: 0.12 + gr + 0.012, sq: 2.3 }, { y, rx: 0.165 + gr, rz: 0.105 + gr, rb: 0.115 + gr, sq: 2.3 }], { seg: 16, sub: 1, thick: 0.005 }); }
    for (const s of [1, -1]) {
      const U = s > 0 ? 'lUp' : 'rUp', F = s > 0 ? 'lFore' : 'rFore', Tn = s > 0 ? 'lThigh' : 'rThigh', S = s > 0 ? 'lShin' : 'rShin';
      pm(1.8); H.spaulder(g, P, s, { s: king ? 1.5 : 1.2, col: rust });
      pm(1.8); H.arm(g, P, s, { y0: 1.19, y1: 1.36, grow: 0.02, k: 1.1, thick: 0.005, bone: U, cap1: false });
      H.arm(g, P, s, { y0: 0.92, y1: 1.1, grow: 0.018, k: 1.1, thick: 0.005, bone: F, cap1: false }); H.couter(g, P, s, { col: rust });
      pm(1.5); H.fist(g, P, s);
      g.bone(H.skirtW(1.0)); g.surf(5, 4, (u, v) => { const a = (u - 0.5) * 1.5; return [s * (0.105 + Math.sin(a) * 0.01) + Math.sin(a) * 0.09, 0.86 - v * 0.2, 0.135 * Math.cos(a) + 0.01]; }, { thick: 0.005 });
      pm(2.2); H.leg(g, P, s, { y0: 0.57, y1: 0.86, grow: 0.018, thick: 0.005, bone: Tn }); H.leg(g, P, s, { y0: 0.14, y1: 0.44, grow: 0.016, thick: 0.005, bone: S }); H.poleyn(g, P, s, { col: rust });
      pm(2.6); H.boot(g, P, s, { top: 0.2 });
    }
    // helm: a sallet with a long tail, a brow lip and a visor; the slit between them is dark
    g.bone('head'); pm(1.4);
    g.loft([{ y: 1.7, rx: 0.107, rz: 0.128, rb: 0.15 }, { y: 1.715, rx: 0.109, rz: 0.142, rb: 0.146 }, { y: 1.74, rx: 0.106, rz: 0.124, rb: 0.135 }, { y: 1.795, rx: 0.088, rz: 0.104, rb: 0.112 }, { y: 1.835, rx: 0.052, rz: 0.062, rb: 0.066 }, { y: 1.85, rx: 0.004, rz: 0.006, rb: 0.006 }], { seg: 18, sub: 3, thick: 0.005 });
    g.loft([{ y: 1.585, rx: 0.1, rz: 0.03, rb: 0.168 }, { y: 1.64, rx: 0.106, rz: 0.06, rb: 0.156 }, { y: 1.7, rx: 0.107, rz: 0.1, rb: 0.15 }], { seg: 14, sub: 2, arc: [PI + 0.5, TAU - 0.5], thick: 0.005 });
    g.loft([{ y: 1.52, rx: 0.086, rz: 0.118, rb: 0.07 }, { y: 1.58, rx: 0.098, rz: 0.138, rb: 0.09 }, { y: 1.64, rx: 0.104, rz: 0.146, rb: 0.1 }, { y: 1.682, rx: 0.106, rz: 0.142, rb: 0.1 }], { seg: 14, sub: 2, arc: [-0.5, PI + 0.5], thick: 0.005, wr: 0.02 });
    g.loft([{ y: 1.745, rx: 0.006, rz: 0.126, rb: 0.137 }, { y: 1.83, rx: 0.006, rz: 0.066, rb: 0.07 }, { y: 1.86, rx: 0.004, rz: 0.01, rb: 0.01 }], { seg: 6, sub: 2, cap1: true });
    g.mat([0.002, 0.003, 0.002], 1, 0, T_PEAT, 0); g.loft([{ y: 1.56, rx: 0.09, rz: 0.11, rb: 0.1 }, { y: 1.7, rx: 0.098, rz: 0.118, rb: 0.12 }, { y: 1.76, rx: 0.09, rz: 0.11, rb: 0.11 }], { seg: 12, sub: 1 });
    g.mat(M_GLOW, 0.4, 0, T_GLOW, 0.9); for (const s of [-1, 1]) { g.tr(s * 0.036, 1.692, 0.118); g.sphere(0.017, 0.008, 0.01, 6, 4); g.pop(); }
    g.bone(chainY([['neck', 9], ['chest', 1.5]], 0.03)); pm(1.8); g.loft([{ y: 1.47, rx: 0.15, rz: 0.12, rb: 0.12 }, { y: 1.52, rx: 0.1, rz: 0.1, rb: 0.1 }, { y: 1.56, rx: 0.095, rz: 0.1, rb: 0.098 }], { seg: 14, sub: 2, thick: 0.005 });
    // rags of a surcoat
    const rag = king ? C(0x3a1418) : C(0x2e2620);
    g.mat(rag, 0.97, 0, T_CLOTH, 2.0); H.skirt(g, { y0: 1.0, y1: king ? 0.42 : 0.52, grow: 0.07, flare: 0.05, arc: [PI / 2 - 0.5, PI / 2 + 0.6], seg: 8, thick: 0.004, wave: 0.07, folds: 11 });
    H.skirt(g, { y0: 1.0, y1: 0.46, grow: 0.07, flare: 0.06, arc: [-PI / 2 - 0.7, -PI / 2 + 0.4], seg: 8, thick: 0.004, wave: 0.07, folds: 9 });
    H.belt(g, { grow: 0.075, w: 0.03, y: 1.0 });
    let sw;
    if (king) {
      // crown of iron spikes, a great tattered cloak, a great blade
      g.bone('head'); g.mat(COL.brass, 0.5, 0.9, T_PLATE, 1.2); g.lathe([[0.112, 1.745], [0.118, 1.76], [0.116, 1.79], [0.11, 1.79]], 16);
      for (let i = 0; i < 9; i++) { const a = i / 9 * TAU; g.tube([[Math.cos(a) * 0.114, 1.785, Math.sin(a) * 0.126], [Math.cos(a) * 0.125, 1.9 + (i % 2) * 0.05, Math.sin(a) * 0.137]], t => 0.012 * (1 - t * 0.9), { seg: 4, sub: 1 }); }
      H.cloak(g, P, { hem: 0.2, wrap: 0.35, col: C(0x2a0f12), flare: 0.16, fold: 0.11, clasp: false }); H.furMantle(g, P, { col: C(0x2a2622), back: 0.2 });
      sw = H.sword(g, P, -1, { len: 1.3, w: 0.045, grip: 0.3, guard: 0.16, col: C(0x6a6058) });
    } else sw = H.sword(g, P, -1, { len: 0.92, w: 0.04, grip: 0.12, guard: 0.11, col: C(0x6a6058) });
    const fig = new Figure(g, rig); fig.fx = { tip: [rig.names.wR, sw.tip[0], sw.tip[1], sw.tip[2]], base: [rig.names.wR, sw.base[0], sw.base[1], sw.base[2]], head: [rig.names.head, 0, 1.7, 0.1] }; return fig;
  }
  const carry = stance({ spine: [0.12, 0, 0], chest: [0.08, 0, 0], neck: [0.15, 0, 0], rUp: [0.1, 0, -0.14], rFore: [-0.2, 0, 0], rHand: [0.9, 0, 0], lUp: [0.05, 0, 0.14], lFore: [-0.35, 0, 0] });
  const ready = rdy({ rUp: [0.3, 0, -0.4], rFore: [-1.3, 0, 0], rHand: [-0.1, 0, 0], lUp: [-0.5, 0, 0.3], lFore: [-0.9, 0, 0] });
  const atk = mkClip(0.5, [
    { t: 0.34, e: 'out', b: { hips: [0.0, -0.8, 0], chest: [-0.15, -0.35, 0], rUp: [-2.4, 0, -0.7], rFore: [-1.4, 0, 0], rHand: [-0.5, 0, 0], lUp: [-0.8, 0, 0.5] }, root: [0, 0, -0.05] },
    { t: 0.5, e: 'in', b: { hips: [0.14, 0.05, 0], chest: [0.35, 0.5, 0], rUp: [-1.1, 0, 0.5], rFore: [-0.2, 0, 0], rHand: [0.6, 0, 0], lUp: [0.1, 0, 0.4], lThigh: [-0.85, 0, 0.08], lShin: [0.75, 0, 0] }, root: [0, -0.08, 0.3] },
    { t: 0.7, e: 'out', b: { chest: [0.4, 0.7, 0], rUp: [-0.3, 0, 0.6], rHand: [0.8, 0, 0] }, root: [0, -0.08, 0.3] }], ready);
  const sweep = mkClip(0.6, [
    { t: 0.42, e: 'out', b: { hips: [0.05, -1.05, 0], spine: [0.05, -0.3, 0], chest: [0.0, -0.55, 0], rUp: [-1.4, 0, -1.2], rFore: [-0.7, 0, 0], rHand: [0.1, 0.4, 0], lUp: [-1.4, 0, -0.4], lFore: [-1.1, 0, 0] }, root: [0, -0.08, -0.1] },
    { t: 0.6, e: 'in', b: { hips: [0.1, 0.4, 0], spine: [0.1, 0.3, 0], chest: [0.15, 0.7, 0], rUp: [-1.35, 0, 0.5], rFore: [-0.2, 0, 0], rHand: [0.2, -0.2, 0], lUp: [-1.2, 0, -0.9], lThigh: [-0.8, 0, 0.1], lShin: [0.75, 0, 0] }, root: [0, -0.12, 0.3] },
    { t: 0.8, b: { chest: [0.15, 1.0, 0] }, root: [0, -0.12, 0.3] }], ready);
  LF.MONSTERS.rustbound = { build, style: { carry, ready, readyRoot: -0.04, clips: { attack: atk }, strideAmp: 0.8, swingR: 0.2, gait: { bounce: 0.7, sway: 1.6, lean: 1.2 } }, scale: 1.1, death: 'shatter', disCol: [0.7, 1, 0.75], hpY: 2.1, radius: 0.42 };
  LF.MONSTERS.barrowking = { build: o => build(Object.assign({ king: true }, o || {})), style: { carry, ready, readyRoot: -0.04, clips: { attack: atk, special: sweep }, strideAmp: 0.75, swingR: 0.2 }, scale: 1.95, death: 'shatter', disCol: [0.7, 1, 0.75], hpY: 3.9, radius: 0.85, boss: true };
})();

/* ---------- CAIRNBACK (and OLD MOSSJAW) ---------- */
(function () {
  const J = { hips: [0, 0.78, 0], spine: [0, 0.94, 0], chest: [0, 1.14, 0.0], neck: [0, 1.38, 0.08], head: [0, 1.4, 0.14], sh: [0.34, 1.3], el: [0.42, 0.86], wr: [0.45, 0.44], hp: [0.17, 0.74], kn: [0.19, 0.42], an: [0.19, 0.09] };
  function build(opt) {
    opt = opt || {}; const boss = !!opt.boss, rig = bipedRig(J), g = new Geo(rig), turf = C(0x26301a), root = C(0x3c2f20);
    let sd = 100; const rk = (bone, c, s) => { g.bone(bone); rockAt(g, c, s, sd++); };
    rk('hips', [0, 0.8, 0], [0.3, 0.2, 0.24]); rk('spine', [0.06, 0.98, 0.03], [0.26, 0.16, 0.22]); rk('spine', [-0.1, 1.0, -0.05], [0.2, 0.14, 0.2]);
    rk('chest', [0, 1.2, 0.02], [0.44, 0.24, 0.3]); rk('chest', [0.16, 1.33, -0.08], [0.24, 0.18, 0.24]); rk('chest', [-0.18, 1.35, -0.06], [0.26, 0.17, 0.22]);
    rk('head', [0, 1.44, 0.2], [0.15, 0.12, 0.16]);
    g.bone('head'); g.mat(M_GLOW, 0.4, 0, T_GLOW, 1.0); for (const s of [-1, 1]) { g.tr(s * 0.06, 1.46, 0.33); g.sphere(0.028, 0.02, 0.016, 6, 4); g.pop(); }
    if (boss) { g.bone('head'); rockAt(g, [0, 1.3, 0.26], [0.19, 0.07, 0.15], 177); }
    for (const s of [1, -1]) {
      const U = s > 0 ? 'lUp' : 'rUp', F = s > 0 ? 'lFore' : 'rFore', Hn = s > 0 ? 'lHand' : 'rHand', Tn = s > 0 ? 'lThigh' : 'rThigh', S = s > 0 ? 'lShin' : 'rShin', Ft = s > 0 ? 'lFoot' : 'rFoot';
      rk('chest', [s * 0.36, 1.34, 0], [0.19, 0.17, 0.19]);
      rk(U, [s * 0.39, 1.08, 0], [0.13, 0.2, 0.14]); rk(F, [s * 0.44, 0.66, 0.01], [0.15, 0.22, 0.16]); rk(Hn, [s * 0.46, 0.36, 0.03], [0.17, 0.15, 0.18]);
      rk(Tn, [s * 0.18, 0.58, 0], [0.15, 0.17, 0.16]); rk(S, [s * 0.19, 0.27, 0], [0.13, 0.17, 0.14]); rk(Ft, [s * 0.2, 0.07, 0.07], [0.15, 0.08, 0.22]);
      // roots lacing the joints
      g.mat(root, 0.92, 0, T_PEAT, 0.6);
      g.bone(jb(U, F, 0.86, 0.1)); for (let k = 0; k < 3; k++) { const a = k * 2.1; g.tube([[s * 0.4 + Math.cos(a) * 0.1, 1.05, Math.sin(a) * 0.1], [s * 0.42 + Math.cos(a + 1) * 0.11, 0.86, Math.sin(a + 1) * 0.11], [s * 0.44 + Math.cos(a + 2) * 0.12, 0.68, Math.sin(a + 2) * 0.12]], 0.02, { seg: 5, sub: 3 }); }
      g.bone(jb(Tn, S, 0.42, 0.08)); for (let k = 0; k < 3; k++) { const a = k * 2.1 + 1; g.tube([[s * 0.18 + Math.cos(a) * 0.12, 0.56, Math.sin(a) * 0.12], [s * 0.19 + Math.cos(a + 1) * 0.11, 0.42, Math.sin(a + 1) * 0.11], [s * 0.19 + Math.cos(a + 2) * 0.11, 0.3, Math.sin(a + 2) * 0.11]], 0.02, { seg: 5, sub: 3 }); }
      g.bone((x, y, z) => ['chest', U, smooth(1.3, 1.05, y)]); for (let k = 0; k < 3; k++) { const a = k * 2.1 + 2; g.tube([[s * 0.3 + Math.cos(a) * 0.08, 1.34, Math.sin(a) * 0.12], [s * 0.37 + Math.cos(a + 1) * 0.1, 1.22, Math.sin(a + 1) * 0.12], [s * 0.39 + Math.cos(a + 2) * 0.1, 1.08, Math.sin(a + 2) * 0.12]], 0.022, { seg: 5, sub: 3 }); }
    }
    g.bone(chainY([['chest', 9], ['spine', 1.1], ['hips', 0.9]], 0.08)); g.mat(root, 0.92, 0, T_PEAT, 0.6);
    for (let k = 0; k < 5; k++) { const pts = [], ph = k * 1.3; for (let i = 0; i <= 10; i++) { const t = i / 10, a = ph + t * 3.4; pts.push([Math.cos(a) * (0.27 + 0.1 * t), lerp(0.74, 1.36, t), Math.sin(a) * (0.23 + 0.05 * t)]); } g.tube(pts, t => 0.026 - 0.01 * t, { seg: 5, sub: 2 }); }
    // turf on the back with moor grass
    g.bone('chest'); g.mat(turf, 0.97, 0, T_PEAT, 0.3);
    g.tr(0, 1.42, -0.1); g.surf(12, 6, (u, v) => { const a = u * TAU, b = v * PI * 0.5; return [Math.cos(a) * Math.cos(b) * 0.4 * (1 + 0.12 * Math.sin(a * 3)), Math.sin(b) * 0.2, Math.sin(a) * Math.cos(b) * 0.27]; }, { closeU: true }); g.pop();
    g.mat(C(0x6e6238), 0.85, 0, T_CLOTH, 0); const r = mulberry(31);
    for (let i = 0; i < (boss ? 60 : 44); i++) { const a = r() * TAU, d = Math.sqrt(r()) * 0.34, bx = Math.cos(a) * d, bz = -0.1 + Math.sin(a) * d * 0.65, by = 1.42 + 0.19 * Math.cos(d / 0.36 * PI / 2), h = 0.1 + r() * 0.2, lx = (r() - 0.5) * 0.22, lz = -0.06 - r() * 0.16; g.surf(1, 3, (u, v) => [bx + (u - 0.5) * 0.02 * (1 - v * 0.9) + lx * v * v, by + h * v * (1 - 0.3 * v), bz + lz * v * v]); }
    if (boss) { // a dead tree rooted in its back
      g.mat(C(0x2a221b), 0.95, 0, T_PEAT, 0);
      const br = (p, d, len, rad, depth) => { const pts = [p.slice()]; let q = p.slice(), dir = d.slice(); for (let i = 0; i < 4; i++) { dir[0] += (r() - 0.5) * 0.5; dir[1] += (r() - 0.3) * 0.3; dir[2] += -0.15 + (r() - 0.5) * 0.5; const l = Math.hypot(dir[0], dir[1], dir[2]); dir = dir.map(v => v / l); q = [q[0] + dir[0] * len / 4, q[1] + dir[1] * len / 4, q[2] + dir[2] * len / 4]; pts.push(q); } g.tube(pts, t => rad * (1 - t * 0.6), { seg: 6, sub: 2 }); if (depth > 0) for (let k = 0; k < 2; k++) { const at = pts[2 + k]; const nd = [dir[0] + (r() - 0.5) * 1.5, dir[1] + (r() - 0.2) * 0.8, dir[2] + (r() - 0.5) * 1.5], l = Math.hypot(nd[0], nd[1], nd[2]); br(at, nd.map(v => v / l), len * 0.62, rad * 0.55, depth - 1); } };
      br([0.05, 1.5, -0.14], [0.1, 1, -0.1], 0.95, 0.07, 3);
    }
    const fig = new Figure(g, rig); fig.fx = { tip: [rig.names.rHand, -0.46, 0.3, 0.1], tipL: [rig.names.lHand, 0.46, 0.3, 0.1], head: [rig.names.head, 0, 1.46, 0.3] }; return fig;
  }
  const carry = { spine: [0.3, 0, 0], chest: [0.22, 0, 0], neck: [-0.3, 0, 0], head: [-0.2, 0, 0], lUp: [-0.2, 0, 0.16], rUp: [-0.2, 0, -0.16], lFore: [-0.25, 0, 0], rFore: [-0.25, 0, 0], lThigh: [-0.15, 0.15, 0.1], rThigh: [-0.15, -0.15, -0.1], lShin: [0.3, 0, 0], rShin: [0.3, 0, 0], lFoot: [-0.15, 0, 0], rFoot: [-0.15, 0, 0] };
  const smash = (hit) => mkClip(hit, [
    { t: hit * 0.66, e: 'out', b: { spine: [-0.1, 0, 0], chest: [-0.25, 0, 0], rUp: [-2.8, 0, -0.35], rFore: [-0.6, 0, 0], lUp: [-2.8, 0, 0.35], lFore: [-0.6, 0, 0], head: [-0.5, 0, 0] }, root: [0, 0.06, -0.08] },
    { t: hit, e: 'in', b: { spine: [0.65, 0, 0], chest: [0.5, 0, 0], rUp: [-0.95, 0, 0.1], rFore: [-0.2, 0, 0], lUp: [-0.95, 0, -0.1], lFore: [-0.2, 0, 0], lShin: [0.7, 0, 0], rShin: [0.7, 0, 0], lThigh: [-0.6, 0.15, 0.1], rThigh: [-0.6, -0.15, -0.1], head: [-0.4, 0, 0] }, root: [0, -0.16, 0.22] },
    { t: Math.min(0.95, hit + 0.22), b: {}, root: [0, -0.16, 0.22] }], carry);
  LF.MONSTERS.cairnback = { build, style: { carry, clips: { attack: smash(0.52) }, strideAmp: 0.62, stride: 1.25, gait: { bounce: 1.6, sway: 2.4, lean: 0.5 } }, scale: 1.5, death: 'shatter', disCol: [0.8, 0.9, 0.7], hpY: 2.7, radius: 0.75 };
  LF.MONSTERS.mossjaw = { build: o => build(Object.assign({ boss: true }, o || {})), style: { carry, clips: { attack: smash(0.5), special: smash(0.62) }, strideAmp: 0.6, stride: 1.25, gait: { bounce: 1.6, sway: 2.4, lean: 0.5 } }, scale: 2.35, death: 'shatter', disCol: [0.8, 0.9, 0.7], hpY: 4.3, radius: 1.15, boss: true };
})();

/* ---------- GLOAMHOUND (and THE HOLLOW STAG): four legs ---------- */
class QuadAnim {
  constructor(fig, style) { this.f = fig; this.st = style; this.ph = Math.random() * TAU; this.t = Math.random() * 9; this.moveW = 0; this.act = null; this.actT = 0; this.stag = 0; this.stagDir = 1; this.down = false; const n = fig.rig.names; this.ix = {}; for (const k in n) this.ix[k] = n[k] * 3; }
  play(name, windup, recover) { const c = this.st.clips[name]; if (!c) return; this.act = c; this.actT = 0; this.actW = windup; this.actR = recover; }
  update(dt, speed, combat, forceT) {
    const f = this.f, E = f.euler, Tr = f.trans, ix = this.ix, st = this.st; E.fill(0); Tr.fill(0); this.t += dt; const t = this.t;
    const mv = Math.min(1.5, Math.abs(speed) / 3); this.moveW = lerp(this.moveW, mv > 0.03 ? 1 : 0, 1 - Math.exp(-dt * 9)); const w = this.moveW;
    this.ph += speed * dt / (st.stride || 0.8) * PI;
    const ph = this.ph, lope = Math.min(1, mv);
    // prowl / idle
    E[ix.hlU] += 0.28; E[ix.hrU] += 0.28; E[ix.hlL] -= 0.42; E[ix.hrL] -= 0.42; E[ix.hlP] += 0.14; E[ix.hrP] += 0.14; E[ix.flU] -= 0.12; E[ix.frU] -= 0.12; E[ix.flL] += 0.2; E[ix.frL] += 0.2; E[ix.flP] -= 0.08; E[ix.frP] -= 0.08; E[ix.spine] += 0.06; Tr[ix.hips + 1] -= 0.035;
    E[ix.neck] += 0.5 + 0.05 * Math.sin(t * 1.3) - 0.3 * w * lope; E[ix.head] += -0.1 + 0.06 * Math.sin(t * 0.7) + (combat ? -0.15 : 0); E[ix.head + 1] += 0.2 * Math.sin(t * 0.45) * (1 - w);
    E[ix.tail1] += -0.5 + 0.1 * Math.sin(t * 1.7); E[ix.tail1 + 1] += 0.3 * Math.sin(t * 2.1 + 1) ; E[ix.tail2 + 1] += 0.4 * Math.sin(t * 2.1); E[ix.tail2] += 0.2;
    E[ix.chest] += 0.035 * Math.sin(t * 2.2); Tr[ix.hips + 1] += (combat ? -0.06 : 0) + 0.012 * Math.sin(t * 2.2); E[ix.jaw] += 0.18 + 0.12 * Math.sin(t * 3.1); E[ix.head + 2] += 0.12 * Math.sin(t * 0.9) * (1 - w); E[ix.spine + 1] += 0.08 * Math.sin(t * 0.6) * (1 - w);
    if (w > 0.002) {
      const leg = (U, L, Pw, p, fore) => {
        const s = Math.sin(p), c = Math.cos(p), A = 0.72 * (0.6 + 0.4 * lope), sw = Math.max(0, c);
        E[ix[U]] += (-A * s + (fore ? 0.05 : -0.05)) * w; E[ix[L]] += (fore ? -1 : 1) * (0.25 + 0.9 * Math.pow(sw, 1.5)) * w * (fore ? 0.9 : 1); E[ix[Pw]] += ((fore ? 1 : -1) * 0.6 * Math.pow(sw, 1.5) + A * s * 0.5) * w;
      };
      const g2 = 0.5 * PI * lope; // trot toward gallop: pairs drift
      leg('flU', 'flL', 'flP', ph, true); leg('frU', 'frL', 'frP', ph + PI - g2 * 0.5, true); leg('hlU', 'hlL', 'hlP', ph + PI + g2, false); leg('hrU', 'hrL', 'hrP', ph + g2 * 0.5, false);
      Tr[ix.hips + 1] += (0.06 * Math.sin(ph * 2) - 0.02) * w; E[ix.spine] += 0.2 * Math.sin(ph * 2 + 0.5) * w * lope; E[ix.hips] += -0.18 * Math.sin(ph * 2) * w * lope; E[ix.chest] += 0.14 * Math.sin(ph * 2 + 1.2) * w * lope; E[ix.hips + 1] += 0.12 * Math.sin(ph) * w; E[ix.chest + 1] -= 0.1 * Math.sin(ph) * w; E[ix.neck] -= 0.12 * Math.sin(ph * 2 + 0.8) * w; E[ix.tail1] += 0.25 * w * lope; E[ix.jaw] += 0.25 * w; E[ix.chest + 2] += 0.05 * Math.sin(ph) * w; E[ix.hips + 2] -= 0.05 * Math.sin(ph) * w;
      E[ix.head] += 0.06 * Math.sin(ph * 2 + 1) * w;
    }
    if (this.act || forceT !== undefined) {
      const c = this.act; let u;
      if (forceT !== undefined) u = forceT; else { this.actT += dt; u = this.actT < this.actW ? this.actT / this.actW * c.hit : c.hit + (this.actT - this.actW) / this.actR * (1 - c.hit); }
      this.actU = u;
      if (c) { if (u >= 1) this.act = null; else { const k = Math.min(1, u / 0.07) * Math.min(1, (1 - u) / 0.16); for (const n of c.names) { sampTrack(c.tr[n], u, _tv); const i = ix[n]; E[i] = lerp(E[i], _tv[0], k); E[i + 1] = lerp(E[i + 1], _tv[1], k); E[i + 2] = lerp(E[i + 2], _tv[2], k); } sampTrack(c.root, u, _tv); Tr[ix.root] += _tv[0] * k; Tr[ix.hips + 1] += _tv[1] * k; Tr[ix.root + 2] += _tv[2] * k; } }
    }
    if (this.stag > 0) { this.stag = Math.max(0, this.stag - dt * 2.8); const k = Math.sin(Math.min(1, this.stag) * PI); E[ix.spine] -= 0.15 * k; E[ix.neck] -= 0.4 * k; E[ix.head + 2] += 0.3 * k * this.stagDir; Tr[ix.root + 2] -= 0.15 * k; E[ix.flU] -= 0.3 * k; E[ix.frU] -= 0.3 * k; }
    f.solve(); f.skin();
  }
}
(function () {
  function rigQ(o) {
    const lg = o.leg || 1, nk = o.neck || 1, hy = 0.34 + 0.28 * lg, ky = 0.07 + 0.27 * lg;
    return makeRig([
      ['root', null, 0, 0, 0], ['hips', 'root', 0, hy, -0.38], ['spine', 'hips', 0, hy + 0.03, -0.05], ['chest', 'spine', 0, hy + 0.02, 0.34], ['neck', 'chest', 0, hy + 0.09, 0.5], ['head', 'neck', 0, hy + 0.09 + 0.14 * nk, 0.5 + 0.2 * nk], ['jaw', 'head', 0, hy + 0.05 + 0.14 * nk, 0.53 + 0.2 * nk],
      ['tail1', 'hips', 0, hy + 0.03, -0.5], ['tail2', 'tail1', 0, hy - 0.04, -0.78],
      ['flU', 'chest', 0.1, hy - 0.04, 0.4], ['flL', 'flU', 0.1, ky, 0.4], ['flP', 'flL', 0.1, 0.07, 0.42], ['frU', 'chest', -0.1, hy - 0.04, 0.4], ['frL', 'frU', -0.1, ky, 0.4], ['frP', 'frL', -0.1, 0.07, 0.42],
      ['hlU', 'hips', 0.11, hy - 0.03, -0.38], ['hlL', 'hlU', 0.11, ky + 0.03, -0.5], ['hlP', 'hlL', 0.11, 0.08, -0.46], ['hrU', 'hips', -0.11, hy - 0.03, -0.38], ['hrL', 'hrU', -0.11, ky + 0.03, -0.5], ['hrP', 'hrL', -0.11, 0.08, -0.46]
    ]);
  }
  function build(opt) {
    opt = opt || {}; const stag = !!opt.stag, o = stag ? { leg: 1.35, neck: 1.5 } : {}, rig = rigQ(o), g = new Geo(rig), H = k => { const i = rig.names[k] * 3; return [rig.head[i], rig.head[i + 1], rig.head[i + 2]]; };
    const bark = C(0x2b2219), pale = C(0x8f8a72), moss = C(0x2a3a1c), hy = H('hips')[1];
    // body: deep chest, tucked belly, arched back
    g.mat(bark, 0.95, 0, T_PEAT, 0.5);
    g.bone((x, y, z) => z > 0.12 ? ['chest', 'spine', 1 - smooth(0.12, 0.3, z)] : ['spine', 'hips', 1 - smooth(-0.3, -0.1, z)]);
    g.tr(0, hy + 0.0, 0, PI / 2, 0, 0);
    g.loft([{ y: -0.54, rx: 0.04, rz: 0.05, rb: 0.05, z: 0.04 }, { y: -0.44, rx: 0.1, rz: 0.13, rb: 0.1, z: 0.02 }, { y: -0.3, rx: 0.105, rz: 0.12, rb: 0.12 }, { y: -0.12, rx: 0.075, rz: 0.065, rb: 0.13, z: -0.02 }, { y: 0.06, rx: 0.085, rz: 0.1, rb: 0.13, z: -0.03 }, { y: 0.24, rx: 0.125, rz: 0.2, rb: 0.15, z: -0.01 }, { y: 0.4, rx: 0.13, rz: 0.2, rb: 0.18, z: 0.0 }, { y: 0.52, rx: 0.085, rz: 0.12, rb: 0.13, z: 0.01 }, { y: 0.58, rx: 0.04, rz: 0.06, rb: 0.06 }], { seg: 14, sub: 3, cap0: true, cap1: true, wr: 0.14, wra: 3, wry: 9 });
    g.pop();
    // pale ribs standing proud of the chest
    g.mat(pale, 0.7, 0, T_BONE, 0.5);
    for (let i = 0; i < 6; i++) { const z = 0.1 + i * 0.066, rr = 0.128 + 0.018 * Math.sin(i / 5 * PI), pts = []; for (let k = 0; k <= 10; k++) { const a = PI + 0.25 + k / 10 * (PI - 0.5); pts.push([Math.cos(a) * rr, hy - 0.05 + Math.sin(a) * rr * 1.45, z + 0.05 * Math.sin(a)]); } g.tube(pts, t => 0.007 + 0.006 * Math.sin(t * PI), { seg: 5, sub: 1 }); }
    // spine thorns and moss
    g.mat(C(0x5e5038), 0.8, 0, T_BONE, 0.3);
    for (let i = 0; i < 11; i++) { const z = -0.42 + i * 0.09, h = 0.07 + 0.07 * Math.sin(i / 10 * PI) + (i % 2) * 0.02; g.tube([[0, hy + 0.1 + 0.03 * Math.sin(i / 10 * PI), z], [0, hy + 0.1 + h, z - 0.05]], t => 0.014 * (1 - t), { seg: 4, sub: 1 }); }
    g.mat(moss, 0.97, 0, T_PEAT, 0); g.bone('chest');
    g.tr(0.06, hy + 0.13, 0.3); g.sphere(0.11, 0.05, 0.13, 8, 5); g.pop(); g.tr(-0.07, hy + 0.11, 0.14); g.sphere(0.08, 0.04, 0.1, 8, 5); g.pop();
    // neck + head
    g.mat(bark, 0.95, 0, T_PEAT, 0.3); g.bone((x, y, z) => ['chest', 'neck', smooth(0.44, 0.56, z)]);
    const nb = H('neck'), hd = H('head'); g.tube([[0, nb[1] - 0.05, nb[2] - 0.1], [0, nb[1] + 0.02, nb[2] + 0.02], [0, hd[1], hd[2]]], t => 0.085 - 0.03 * t, { seg: 8, sub: 3 });
    g.bone('head'); g.mat(pale, 0.7, 0, T_BONE, 0.3);
    g.tr(hd[0], hd[1], hd[2], PI / 2 + 0.25, 0, 0);
    g.loft([{ y: -0.06, rx: 0.06, rz: 0.05, rb: 0.06 }, { y: 0.02, rx: 0.075, rz: 0.055, rb: 0.07 }, { y: 0.12, rx: 0.055, rz: 0.04, rb: 0.05 }, { y: 0.24, rx: 0.036, rz: 0.03, rb: 0.032 }, { y: 0.31, rx: 0.02, rz: 0.02, rb: 0.016 }], { seg: 10, sub: 3, cap0: true, cap1: true, wr: 0.08 });
    g.mat(M_GLOW, 0.4, 0, T_GLOW, 1.0); for (const s of [-1, 1]) { g.tr(s * 0.058, 0.07, -0.03); g.sphere(0.014, 0.018, 0.012, 6, 4); g.pop(); }
    g.mat(bark, 0.9, 0, T_PEAT, 0); for (const s of [-1, 1]) g.tube([[s * 0.05, -0.02, -0.05], [s * 0.09, -0.1, -0.12], [s * 0.07, -0.2, -0.16]], t => 0.016 * (1 - t * 0.9), { seg: 4, sub: 2 });
    g.pop();
    g.bone('jaw'); g.mat(pale, 0.7, 0, T_BONE, 0.3); g.tr(hd[0], hd[1] - 0.045, hd[2] + 0.02, PI / 2 + 0.42, 0, 0);
    g.loft([{ y: 0.0, rx: 0.05, rz: 0.018 }, { y: 0.14, rx: 0.034, rz: 0.014 }, { y: 0.26, rx: 0.016, rz: 0.01 }], { seg: 8, sub: 2, cap0: true, cap1: true });
    g.mat(C(0xb8b29a), 0.5, 0, T_BONE, 0); for (let i = 0; i < 5; i++) for (const s of [-1, 1]) g.tube([[s * (0.036 - i * 0.004), 0.08 + i * 0.04, -0.012], [s * (0.036 - i * 0.004), 0.085 + i * 0.04, -0.045]], t => 0.006 * (1 - t), { seg: 3, sub: 1 });
    g.pop();
    if (stag) { // antlers of bleached wood
      g.bone('head'); g.mat(pale, 0.75, 0, T_BONE, 0.2);
      for (const s of [-1, 1]) {
        const b0 = [hd[0] + s * 0.05, hd[1] + 0.05, hd[2] - 0.04], beam = [b0, [b0[0] + s * 0.16, b0[1] + 0.2, b0[2] - 0.1], [b0[0] + s * 0.3, b0[1] + 0.42, b0[2] - 0.12], [b0[0] + s * 0.34, b0[1] + 0.66, b0[2] - 0.02], [b0[0] + s * 0.28, b0[1] + 0.84, b0[2] + 0.1]];
        g.tube(beam, t => 0.026 * (1 - t * 0.7), { seg: 6, sub: 3 });
        const tine = (p, d, l) => g.tube([p, [p[0] + d[0] * l * 0.5, p[1] + d[1] * l * 0.5 + 0.03, p[2] + d[2] * l * 0.5], [p[0] + d[0] * l, p[1] + d[1] * l + 0.1, p[2] + d[2] * l]], t => 0.017 * (1 - t * 0.85), { seg: 5, sub: 2 });
        tine(beam[1], [s * 0.1, 0.5, 0.8], 0.28); tine(beam[2], [s * 0.5, 0.5, 0.6], 0.3); tine(beam[3], [s * 0.2, 0.6, -0.7], 0.26); tine(beam[2], [-s * 0.3, 0.8, -0.3], 0.2);
      }
    }
    // legs
    const legq = (U, L, Pw, fore) => {
      const a = H(U), b = H(L), c = H(Pw);
      g.mat(bark, 0.95, 0, T_PEAT, 1.2); g.bone(jb(U, L, b[1], 0.05));
      g.tube([[a[0] * 0.9, a[1] + 0.08, a[2]], [a[0], (a[1] + b[1]) / 2 + 0.02, a[2] + (fore ? 0.035 : 0.05)], b, [b[0], (b[1] + c[1]) / 2, (b[2] + c[2]) / 2 + (fore ? -0.015 : -0.03)], c], t => (fore ? 0.062 : 0.085) * Math.pow(1 - t, 0.75) + 0.022, { seg: 8, sub: 3, flatten: 0.8 });
      g.mat(pale, 0.7, 0, T_BONE, 0.8); g.tr(b[0], b[1], b[2]); g.sphere(0.036, 0.04, 0.04, 6, 5); g.pop();
      g.bone(Pw); g.mat(bark, 0.95, 0, T_PEAT, 2); g.tr(c[0], 0.04, c[2] + 0.03); g.sphere(0.045, 0.04, 0.07, 7, 5); g.pop();
      g.mat(pale, 0.6, 0, T_BONE, 0.5); for (let i = 0; i < 3; i++) g.tube([[c[0] + (i - 1) * 0.025, 0.035, c[2] + 0.08], [c[0] + (i - 1) * 0.03, 0.01, c[2] + 0.14]], t => 0.011 * (1 - t), { seg: 3, sub: 1 });
    };
    legq('flU', 'flL', 'flP', true); legq('frU', 'frL', 'frP', true); legq('hlU', 'hlL', 'hlP', false); legq('hrU', 'hrL', 'hrP', false);
    // tail: a twisted root
    g.mat(bark, 0.95, 0, T_PEAT, 0.6); g.bone((x, y, z) => ['tail1', 'tail2', smooth(-0.62, -0.8, z)]);
    const t1 = H('tail1'), t2 = H('tail2'); g.tube([[0, t1[1], t1[2] + 0.06], [0, t1[1] - 0.02, t1[2] - 0.14], t2, [0, t2[1] - 0.1, t2[2] - 0.24]], t => 0.034 * (1 - t * 0.85), { seg: 6, sub: 3 });
    const fig = new Figure(g, rig); fig.fx = { tip: [rig.names.head, hd[0], hd[1] - 0.1, hd[2] + 0.3], head: [rig.names.head, hd[0], hd[1], hd[2] + 0.1] }; return fig;
  }
  const bite = mkClip(0.5, [
    { t: 0.3, e: 'out', b: { hips: [-0.15, 0, 0], spine: [0.1, 0, 0], neck: [0.5, 0, 0], head: [-0.3, 0, 0], jaw: [0.5, 0, 0], hlU: [-0.3, 0, 0], hrU: [-0.3, 0, 0], hlL: [0.5, 0, 0], hrL: [0.5, 0, 0], flU: [0.2, 0, 0], frU: [0.2, 0, 0] }, root: [0, -0.1, -0.2] },
    { t: 0.5, e: 'in', b: { hips: [0.12, 0, 0], spine: [-0.1, 0, 0], neck: [-0.35, 0, 0], head: [0.25, 0, 0], jaw: [0.05, 0, 0], hlU: [0.6, 0, 0], hrU: [0.6, 0, 0], hlL: [0.1, 0, 0], hrL: [0.1, 0, 0], flU: [-0.7, 0, 0], frU: [-0.7, 0, 0], flL: [-0.3, 0, 0], frL: [-0.3, 0, 0] }, root: [0, 0.08, 0.55] },
    { t: 0.75, b: {}, root: [0, 0, 0.35] }], {});
  const charge = mkClip(0.7, [
    { t: 0.45, e: 'out', b: { neck: [0.9, 0, 0], head: [0.5, 0, 0], hips: [-0.1, 0, 0], flU: [0.3, 0, 0], frU: [-0.6, 0, 0], frL: [-0.9, 0, 0] }, root: [0, -0.08, -0.25] },
    { t: 0.56, e: 'io', b: { frU: [0.2, 0, 0], frL: [-0.2, 0, 0] }, root: [0, -0.08, -0.25] },
    { t: 0.7, e: 'in', b: { neck: [0.7, 0, 0], head: [0.2, 0, 0], hips: [0.1, 0, 0], flU: [-0.6, 0, 0], frU: [-0.6, 0, 0], hlU: [0.6, 0, 0], hrU: [0.6, 0, 0] }, root: [0, 0, 0.3] },
    { t: 0.88, b: { neck: [-0.2, 0, 0] }, root: [0, 0, 0.2] }], {});
  LF.MONSTERS.gloamhound = { build, animClass: QuadAnim, style: { clips: { attack: bite }, stride: 0.85 }, scale: 1.12, death: 'shatter', disCol: [0.7, 1, 0.7], hpY: 1.15, radius: 0.4 };
  LF.MONSTERS.hollowstag = { build: o => build(Object.assign({ stag: true }, o || {})), animClass: QuadAnim, style: { clips: { attack: bite, special: charge }, stride: 0.9 }, scale: 2.2, death: 'shatter', disCol: [0.7, 1, 0.7], hpY: 3.6, radius: 1.0, boss: true };
})();

/* ---------- GLOAMWISP ---------- */
class WispAnim {
  constructor(fig, style) { this.f = fig; this.st = style; this.t = Math.random() * 9; this.act = null; this.actT = 0; this.stag = 0; this.stagDir = 1; this.lag = [0, 0, 0, 0, 0, 0]; this.flare = 0; const n = fig.rig.names; this.ix = {}; for (const k in n) this.ix[k] = n[k] * 3; }
  play(name, windup, recover) { this.act = { hit: 0.5 }; this.actT = 0; this.actW = windup; this.actR = recover; }
  update(dt, speed, combat, forceT) {
    const f = this.f, E = f.euler, Tr = f.trans, ix = this.ix; E.fill(0); Tr.fill(0); this.t += dt; const t = this.t;
    let u = -1; if (this.act) { this.actT += dt; u = this.actT < this.actW ? this.actT / this.actW * 0.5 : 0.5 + (this.actT - this.actW) / this.actR * 0.5; if (u >= 1) { this.act = null; u = -1; } }
    if (forceT !== undefined) u = forceT; this.actU = u;
    const rise = u >= 0 ? Math.sin(Math.min(1, u / 0.5) * PI / 2) * (u < 0.5 ? 1 : Math.max(0, 1 - (u - 0.5) * 3)) : 0;
    this.flare = rise;
    Tr[ix.root + 1] = 0.22 + 0.07 * Math.sin(t * 1.4) + 0.03 * Math.sin(t * 2.9) + rise * 0.15;
    E[ix.core + 2] = 0.06 * Math.sin(t * 0.9); E[ix.core] = 0.08 * Math.sin(t * 1.1 + 1) - rise * 0.25;
    const L = this.lag, tg = clamp(speed * 0.14, -0.6, 0.6) + 0.06 * Math.sin(t * 1.7);
    L[1] += ((tg - L[0]) * 30 - L[1] * 5) * dt; L[0] += L[1] * dt; L[3] += ((L[0] * 0.8 + 0.05 * Math.sin(t * 2.3) - L[2]) * 24 - L[3] * 4) * dt; L[2] += L[3] * dt; L[5] += ((L[2] * 0.8 + 0.07 * Math.sin(t * 3.1) - L[4]) * 20 - L[5] * 3.5) * dt; L[4] += L[5] * dt;
    E[ix.sh1] = L[0]; E[ix.sh2] = L[2]; E[ix.sh3] = L[4]; E[ix.sh1 + 2] = 0.05 * Math.sin(t * 1.2); E[ix.sh2 + 2] = 0.07 * Math.sin(t * 1.5 + 1); E[ix.sh3 + 2] = 0.1 * Math.sin(t * 1.9 + 2);
    E[ix.armL + 2] = 0.25 + 0.1 * Math.sin(t * 1.3) + rise * 1.1; E[ix.armR + 2] = -0.25 - 0.1 * Math.sin(t * 1.5 + 1) - rise * 1.1; E[ix.armL] = -0.2 - rise * 0.9; E[ix.armR] = -0.2 - rise * 0.9;
    E[ix.armL2 + 2] = 0.2 * Math.sin(t * 1.9) - rise * 0.5; E[ix.armR2 + 2] = 0.2 * Math.sin(t * 2.1) + rise * 0.5;
    if (this.stag > 0) { this.stag = Math.max(0, this.stag - dt * 2.5); const k = Math.sin(Math.min(1, this.stag) * PI); E[ix.core] -= 0.5 * k; Tr[ix.root + 2] -= 0.2 * k; E[ix.sh1] += 0.5 * k; }
    f.u.uGlow.value = 1 + 0.25 * Math.sin(t * 7) + rise * 3;
    f.solve(); f.skin();
  }
}
(function () {
  function build() {
    const rig = makeRig([['root', null, 0, 0, 0], ['core', 'root', 0, 1.5, 0], ['sh1', 'core', 0, 1.34, 0], ['sh2', 'sh1', 0, 1.02, 0], ['sh3', 'sh2', 0, 0.7, 0], ['armL', 'core', 0.16, 1.44, 0], ['armL2', 'armL', 0.3, 1.14, 0], ['armR', 'core', -0.16, 1.44, 0], ['armR2', 'armR', -0.3, 1.14, 0]]);
    const g = new Geo(rig), sh = C(0x15181a), sh2 = C(0x23292c);
    // pale flame
    g.bone('core'); g.mat(C(0xd6ffe0), 0.4, 0, T_GLOW, 2.0); g.tr(0, 1.54, -0.01, 0, 0, 0, 0.72); g.surf(10, 8, (u, v) => { const a = u * TAU, b = (v - 0.5) * PI, cb = Math.cos(b), up = Math.max(0, Math.sin(b)); return [Math.cos(a) * cb * 0.085 * (1 - up * 0.5), Math.sin(b) * (0.1 + up * 0.09), Math.sin(a) * cb * 0.085 * (1 - up * 0.5)]; }, { closeU: true }); g.pop();
    g.mat(C(0x9fffc0), 0.4, 0, T_GLOW, 0.25); g.bone((x, y, z) => y > 1.3 ? ['core', 'sh1', 1 - smooth(1.3, 1.4, y)] : ['sh1', 'sh2', 1 - smooth(0.98, 1.3, y)]); g.loft([{ y: 0.95, rx: 0.015 }, { y: 1.15, rx: 0.05 }, { y: 1.4, rx: 0.06 }], { seg: 6, sub: 2 });
    // cowl: a deep hood with an oval mouth
    g.mat(sh, 0.97, 0, T_CLOTH, 0.2); g.bone('core');
    g.surf(26, 14, (u, v) => { const y = lerp(1.32, 1.82, v), q = (y - 1.55) / 0.15, op = Math.abs(q) < 1 ? 0.62 * Math.sqrt(1 - q * q) : 0, a = lerp(PI / 2 + op, PI / 2 - op + TAU, u), e = Math.abs(u - 0.5) * 2, fr = smooth(0.6, 1, e) * (op > 0.02 ? 1 : 0.3);
      const tt = clamp((y - 1.66) / 0.16, 0, 1), dome = Math.sqrt(Math.max(0, 1 - tt * tt)), low = smooth(1.5, 1.32, y); const rx = 0.125 * dome + 0.05 * low + 0.004, rz = (0.15 + fr * 0.07) * dome + 0.03 * low, rb = (0.15 + 0.07 * smooth(1.5, 1.72, y)) * (0.3 + 0.7 * dome) + 0.05 * low; const s = Math.sin(a);
      return [Math.cos(a) * rx * (1 + 0.05 * Math.sin(a * 7 + y * 20)), y - 0.03 * tt * tt * Math.max(0, -s), (s >= 0 ? rz : rb) * s]; }, { thick: 0.008 });
    // shroud: layered rags, each hanging from the shoulders and fraying to a point
    g.bone((x, y, z) => { if (y > 1.2) return ['core', 'sh1', 1 - smooth(1.2, 1.42, y)]; if (y > 0.86) return ['sh1', 'sh2', 1 - smooth(0.86, 1.2, y)]; return ['sh2', 'sh3', 1 - smooth(0.5, 0.86, y)]; });
    for (let layer = 0; layer < 2; layer++) for (let k = 0; k < 9; k++) {
      const a0 = k / 9 * TAU + 0.2 + layer * 0.35, a1 = a0 + TAU / 9 * 1.5, len = (layer ? 0.55 : 0.85) + 0.55 * hash1(k * 7.3 + layer * 3.1), r0 = layer ? 0.135 : 0.115;
      g.mat(mixC(sh, sh2, hash1(k * 3.3 + layer)), 0.97, 0, T_CLOTH, 0.4);
      g.surf(5, 9, (u, v) => { const f = v, tip = 1 - 0.85 * smooth(0.45, 1, f) * Math.abs(u - 0.5) * 2, a = lerp((a0 + a1) / 2, lerp(a0, a1, u), tip), y = 1.44 - v * len, r = r0 + (layer ? 0.2 : 0.14) * Math.pow(f, 0.7) + 0.03 * Math.sin(a * 5 + k) * f; return [Math.cos(a) * r, y - 0.06 * smooth(0.6, 1, f) * Math.abs(Math.sin(u * 7 + k)), Math.sin(a) * r * 0.92]; }, { thick: 0.003 });
    }
    // two thin trailing rags where arms might be
    for (const s of [1, -1]) {
      const A = s > 0 ? 'armL' : 'armR', B = s > 0 ? 'armL2' : 'armR2'; g.mat(sh2, 0.97, 0, T_CLOTH, 0.3); g.bone(jb(A, B, 1.14, 0.1));
      g.surf(3, 8, (u, v) => { const y = 1.44 - v * 0.8, w = 0.05 * (1 - v * 0.85); return [s * (0.15 + v * 0.17) + (u - 0.5) * w, y, -0.02 + (u - 0.5) * w * 0.6 + 0.02 * Math.sin(v * 9)]; }, { thick: 0.003 });
    }
    const fig = new Figure(g, rig); fig.fx = { tip: [rig.names.core, 0, 1.52, 0.15], head: [rig.names.core, 0, 1.52, 0] }; return fig;
  }
  LF.MONSTERS.gloamwisp = { build, animClass: WispAnim, style: { clips: { attack: { hit: 0.5 } } }, scale: 1.0, death: 'gutter', disCol: [0.6, 1, 0.75], hpY: 2.2, radius: 0.35, float: true };
})();
LF.MON_ORDER = ['thornling', 'peatwight', 'gloamhound', 'gloamwisp', 'rustbound', 'cairnback', 'barrowking', 'mossjaw', 'hollowstag'];
