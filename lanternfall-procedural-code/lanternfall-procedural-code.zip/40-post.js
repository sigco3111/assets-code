/* LANTERNFALL - render pipeline: HDR scene -> AO + fog/in-scatter -> bloom -> DOF + tonemap + grade */
LF.gfx = (function () {
  const G = {}; let renderer, rtScene, rtA, rtB = [], quad, qscene, qcam, mFog, mDown, mFinal, W = 2, H = 2;
  const FS_V = 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0., 1.); }';
  const NL = 4;
  G.lights = []; for (let i = 0; i < NL; i++) G.lights.push({ pos: new THREE.Vector3(), col: new THREE.Color(0, 0, 0) });
  G.params = { exposure: 0.62, focus: 18, aperture: 1.0, bloom: 0.5, ao: 1.0, vignette: 1.0, fogMul: 1.0, flash: 0, sat: 1.0, contrast: qnum('contrast', 0.6), color: qnum('color', 1) };
  G.init = function (canvas) {
    renderer = G.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, stencil: false, powerPreference: 'high-performance' });
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; renderer.toneMapping = THREE.NoToneMapping; renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
    renderer.setClearColor(0x000000, 1); renderer.info.autoReset = true;
    qscene = new THREE.Scene(); qcam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), null); quad.frustumCulled = false; qscene.add(quad);
    const lp = [], lc = []; for (let i = 0; i < NL; i++) { lp.push(new THREE.Vector3()); lc.push(new THREE.Vector3()); }
    mFog = new THREE.ShaderMaterial({ depthTest: false, depthWrite: false, vertexShader: FS_V,
      uniforms: { tC: { value: null }, tD: { value: null }, uInvProj: { value: new THREE.Matrix4() }, uCamW: { value: new THREE.Matrix4() }, uNF: { value: new THREE.Vector2(0.5, 600) }, uRes: { value: new THREE.Vector2() },
        uFog: { value: new THREE.Color() }, uDens: { value: 0.016 }, uLP: { value: lp }, uLC: { value: lc }, uAO: { value: 1 }, uTime: { value: 0 }, uMoon: { value: new THREE.Vector3() }, uMoonI: { value: 1 } },
      fragmentShader: `precision highp float; precision highp sampler2D; varying vec2 vUv; uniform sampler2D tC, tD; uniform mat4 uInvProj, uCamW; uniform vec2 uNF, uRes; uniform vec3 uFog, uMoon; uniform float uDens, uAO, uTime, uMoonI;
uniform vec3 uLP[${NL}]; uniform vec3 uLC[${NL}];
float lin(float d){ return uNF.x*uNF.y / (uNF.y - d*(uNF.y-uNF.x)); }
float ign(vec2 p){ return fract(52.9829189*fract(dot(p, vec2(.06711056,.00583715)))); }
void main(){
  vec3 col = texture2D(tC, vUv).rgb; float d = texture2D(tD, vUv).x; float z = lin(d);
  vec4 vp = uInvProj * vec4(vUv*2.-1., 1., 1.); vec3 vdir = normalize(vp.xyz/vp.w); vec3 wdir = normalize((uCamW * vec4(vdir,0.)).xyz); vec3 ro = uCamW[3].xyz;
  float dist = z / max(-vdir.z, 1e-4); bool isSky = d >= .99999;
  // ambient occlusion: opposite pairs cancel on slopes
  float ao = 1.;
  if (!isSky && uAO > 0.) {
    float rad = clamp(.42 / z, .003, .06); float ang = ign(gl_FragCoord.xy + fract(uTime)*0.) * 6.2832; float occ = 0.;
    for (int i = 0; i < 8; i++) {
      float a = ang + float(i)*2.39996; float r = rad * (.3 + .7*sqrt((float(i)+.5)/8.));
      vec2 o = vec2(cos(a), sin(a)) * r * vec2(uRes.y/uRes.x, 1.);
      float z1 = lin(texture2D(tD, vUv + o).x), z2 = lin(texture2D(tD, vUv - o).x);
      float d1 = z - z1, d2 = z - z2; float rng = .55;
      float d1c = clamp(d1, -rng, rng), d2c = clamp(d2, -rng, rng);
      float keep = 1. - smoothstep(rng*.8, rng*1.6, max(abs(d1), abs(d2)) - min(abs(d1), abs(d2)));
      occ += clamp((d1c + d2c) / .2, 0., 1.) * max(keep, step(max(abs(d1),abs(d2)), rng));
    }
    ao = 1. - uAO * clamp(occ / 8. * 1.5, 0., .85);
    float lum = dot(col, vec3(.3,.5,.2)); ao = mix(ao, 1., clamp(lum*.35, 0., .6));
  }
  col *= ao;
  // fog: exponential with height falloff
  float T = isSky ? 420. : dist;
  float hb = .11; float dy = wdir.y; float k = abs(dy) < 1e-3 ? T : (1.-exp(-hb*dy*T))/(hb*dy);
  float od = uDens * exp(-hb*max(ro.y,0.)) * k * 1.9 + uDens * T * .22;
  float fa = 1. - exp(-od);
  vec3 fogc = uFog * (1. + uMoonI * 1.2 * pow(max(dot(wdir, uMoon), 0.), 5.));
  if (isSky) fa *= smoothstep(.34, -.02, dy);
  col = mix(col, fogc, fa);
  // point-light in-scatter (closed form), capped to the surface
  float Tm = min(T, 90.);
  for (int i = 0; i < ${NL}; i++) {
    vec3 q = ro - uLP[i]; float b = dot(wdir, q), c = dot(q, q); float s = 1. / sqrt(max(c - b*b, 1e-3));
    float I = s * (atan((Tm + b)*s) - atan(b*s));
    col += uLC[i] * I * uDens;
  }
  gl_FragColor = vec4(max(col, vec3(0.)), z);
}` });
    mDown = new THREE.ShaderMaterial({ depthTest: false, depthWrite: false, vertexShader: FS_V, uniforms: { tC: { value: null }, uTx: { value: new THREE.Vector2() }, uThr: { value: 0 } },
      fragmentShader: `precision highp float; precision highp sampler2D; varying vec2 vUv; uniform sampler2D tC; uniform vec2 uTx; uniform float uThr;
vec3 pre(vec3 c){ if (uThr <= 0.) return c; float l = max(c.r, max(c.g, c.b)); float k = max(l - uThr, 0.); return c * (k / max(l, 1e-4)) ; }
void main(){ vec3 c = pre(texture2D(tC, vUv).rgb)*.25;
  c += pre(texture2D(tC, vUv + uTx*vec2(1.,1.)).rgb)*.1875; c += pre(texture2D(tC, vUv + uTx*vec2(-1.,1.)).rgb)*.1875;
  c += pre(texture2D(tC, vUv + uTx*vec2(1.,-1.)).rgb)*.1875; c += pre(texture2D(tC, vUv + uTx*vec2(-1.,-1.)).rgb)*.1875;
  gl_FragColor = vec4(min(c, vec3(24.)), 1.); }` });
    mFinal = new THREE.ShaderMaterial({ depthTest: false, depthWrite: false, vertexShader: FS_V,
      uniforms: { tC: { value: null }, tB1: { value: null }, tB2: { value: null }, tB3: { value: null }, tB4: { value: null }, uRes: { value: new THREE.Vector2() }, uTime: { value: 0 },
        uExp: { value: 1 }, uFocus: { value: 18 }, uAp: { value: 1 }, uBloom: { value: 0.5 }, uVig: { value: 1 }, uFlash: { value: 0 }, uSat: { value: 1 }, uCon: { value: 0 }, uCol: { value: 0 } },
      fragmentShader: `precision highp float; precision highp sampler2D; varying vec2 vUv; uniform sampler2D tC, tB1, tB2, tB3, tB4; uniform vec2 uRes; uniform float uTime, uExp, uFocus, uAp, uBloom, uVig, uFlash, uSat, uCon, uCol;
float coc(float z){ float c = (z - uFocus) / z; c = c > 0. ? max(c - .1, 0.) * 9. : max(-c - .22, 0.) * 5.; return min(c * uAp, 7.); }
float h(vec2 p){ vec3 p3=fract(vec3(p.xyx)*.1031); p3+=dot(p3,p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }
vec3 agx(vec3 c){
  const mat3 mi = mat3(.842479062253094,.0423282422610123,.0423756549057051,.0784335999999992,.878468636469772,.0784336,.0792237451477643,.0791661274605434,.879142973793104);
  const mat3 mo = mat3(1.19687900512017,-.0528968517574562,-.0529716355144438,-.0980208811401368,1.15190312990417,-.0980434501171241,-.0990297440797205,-.0989611768448433,1.15107367264116);
  c = mi * c; c = clamp((log2(max(c, 1e-10)) + 12.47393) / 16.5, 0., 1.);
  vec3 c2 = c*c, c4 = c2*c2;
  c = 15.5*c4*c2 - 40.14*c4*c + 31.96*c4 - 6.868*c2*c + .4298*c2 + .1191*c - .00232;
  c = mo * c; return c; }
void main(){
  vec4 cz = texture2D(tC, vUv); vec3 col = cz.rgb; float z = cz.a; float cc = coc(z);
  if (uAp > 0.) {
    float acc = 1.; vec2 px = 1./uRes; float rmax = 7.*uAp; float a0 = h(gl_FragCoord.xy)*6.2832;
    for (int i = 0; i < 22; i++) {
      float fi = float(i)+.5; float r = sqrt(fi/22.) * rmax; float a = a0 + fi*2.39996;
      vec2 uv = vUv + vec2(cos(a), sin(a)) * r * px;
      vec4 s = texture2D(tC, uv); float sc = coc(s.a);
      if (s.a > z) sc = min(sc, cc*2.);
      float m = smoothstep(r-.5, r+.5, sc);
      col += mix(col/acc, s.rgb, m); acc += 1.;
    }
    col /= acc;
  }
  vec3 bl = texture2D(tB1, vUv).rgb*.34 + texture2D(tB2, vUv).rgb*.3 + texture2D(tB3, vUv).rgb*.22 + texture2D(tB4, vUv).rgb*.14;
  col += bl * uBloom;
  col *= uExp;
  vec2 q = vUv - .5; float vg = 1. - dot(q,q) * 1.25 * uVig; col *= clamp(vg, 0., 1.) * mix(1., vg, .5);
  col += uFlash * vec3(1., .82, .55);
  col = agx(col);
  // look: a touch more contrast, cold shadows, warm highs
  float l = dot(col, vec3(.2126,.7152,.0722));
  col = mix(vec3(l), col, 1.22 * uSat);
  col = pow(max(col, 0.), vec3(1.32));
  col += vec3(-.004, .0, .003) * (1.-smoothstep(0., .35, l));
  col = pow(max(col, 0.), vec3(1./2.2));
  // colour: vibrance weighted to muted mid-tones, and a warm/cool split (cool teal-blue shadows, warm lantern lights)
  { float l2 = dot(col, vec3(.2126,.7152,.0722)), mx = max(col.r, max(col.g, col.b)), mn = min(col.r, min(col.g, col.b)), st = mx - mn;
    float mid = smoothstep(.03,.2,l2) * (1.-smoothstep(.6,.95,l2));
    float hr = (col.g - mn) / max(col.r - mn, 1e-4); float ob = (col.r >= col.g && col.g >= col.b) ? smoothstep(.2,.45,hr) * (1.-smoothstep(.8,1.,hr)) : 0.;
    col = mix(vec3(l2), col, 1. + uCol * .8 * (1.-.6*ob) * mid * (1.-smoothstep(.12,.55,st)));
    float warm = smoothstep(-.04,.12, col.r - col.b);
    col += uCol * vec3(-.022,.006,.034) * (1.-warm) * smoothstep(.0,.05,l2) * (1.-smoothstep(.1,.45,l2));
    col += uCol * vec3(.011,.006,-.008) * warm * smoothstep(.2,.7,l2);
    col = clamp(col, 0., 1.); }
  // a small S-curve: deeper blacks and a little more snap, highlights kept
  { col = min(col * (1. + .22*uCon), 1.); vec3 sc = col*col*(3.-2.*col); col = mix(col, sc, uCon); col = max(col - .17*uCon, 0.) / (1. - .17*uCon); }
  float g = h(gl_FragCoord.xy + fract(uTime*7.13)*913.) - .5; col += g * mix(.035, .012, smoothstep(0., .5, l));
  gl_FragColor = vec4(col, 1.);
}` });
    canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); G.lost = true; const el = document.getElementById('lost'); if (el) el.style.display = 'flex'; }, false);
    G.resize();
    return renderer;
  };
  function mk(w, h, depth) {
    const o = { type: THREE.HalfFloatType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: !!depth, stencilBuffer: false, generateMipmaps: false };
    if (depth) { o.samples = G.msaa; o.depthTexture = new THREE.DepthTexture(w, h); o.depthTexture.type = THREE.UnsignedIntType; o.depthTexture.minFilter = o.depthTexture.magFilter = THREE.NearestFilter; }
    return new THREE.WebGLRenderTarget(w, h, o);
  }
  G.msaa = qnum('msaa', 4);
  G.resize = function () {
    const cw = Math.max(2, window.innerWidth), ch = Math.max(2, window.innerHeight), dpr = window.devicePixelRatio || 1;
    let s = dpr; const cap = 2.1e6; if (cw * ch * s * s > cap) s = Math.sqrt(cap / (cw * ch));
    W = Math.max(2, Math.round(cw * s)); H = Math.max(2, Math.round(ch * s)); G.W = W; G.H = H; G.cw = cw; G.ch = ch;
    renderer.setPixelRatio(1); renderer.setSize(W, H, false); renderer.domElement.style.width = cw + 'px'; renderer.domElement.style.height = ch + 'px';
    if (rtScene) { rtScene.depthTexture.dispose(); rtScene.dispose(); rtA.dispose(); rtB.forEach(r => r.dispose()); }
    rtScene = mk(W, H, true); rtA = mk(W, H, false); rtB = [];
    let w = W, h = H; for (let i = 0; i < 4; i++) { w = Math.max(2, w >> 1); h = Math.max(2, h >> 1); rtB.push(mk(w, h, false)); }
  };
  const inv = new THREE.Matrix4();
  G.render = function (scene, camera, time) {
    if (G.lost) return;
    const p = G.params;
    renderer.setRenderTarget(rtScene); renderer.clear(); renderer.render(scene, camera);
    // fog + ao
    const u = mFog.uniforms; u.tC.value = rtScene.texture; u.tD.value = rtScene.depthTexture; u.uInvProj.value.copy(camera.projectionMatrixInverse); u.uCamW.value.copy(camera.matrixWorld);
    u.uNF.value.set(camera.near, camera.far); u.uRes.value.set(W, H); u.uFog.value.copy(LF.world.cur.fog); u.uDens.value = LF.world.cur.dens * p.fogMul; u.uAO.value = p.ao; u.uTime.value = time;
    u.uMoon.value.copy(LF.world.MOON_DIR); u.uMoonI.value = LF.world.cur.moon;
    for (let i = 0; i < NL; i++) { u.uLP.value[i].copy(G.lights[i].pos); u.uLC.value[i].set(G.lights[i].col.r, G.lights[i].col.g, G.lights[i].col.b); }
    quad.material = mFog; renderer.setRenderTarget(rtA); renderer.render(qscene, qcam);
    // bloom chain
    let src = rtA; quad.material = mDown;
    for (let i = 0; i < 4; i++) { mDown.uniforms.tC.value = src.texture; mDown.uniforms.uTx.value.set(1 / src.width, 1 / src.height); mDown.uniforms.uThr.value = i === 0 ? 1.05 : 0; renderer.setRenderTarget(rtB[i]); renderer.render(qscene, qcam); src = rtB[i]; }
    const f = mFinal.uniforms; f.tC.value = rtA.texture; f.tB1.value = rtB[0].texture; f.tB2.value = rtB[1].texture; f.tB3.value = rtB[2].texture; f.tB4.value = rtB[3].texture; f.uRes.value.set(W, H); f.uTime.value = time;
    f.uExp.value = p.exposure; f.uFocus.value = p.focus; f.uAp.value = p.aperture; f.uBloom.value = p.bloom; f.uVig.value = p.vignette; f.uFlash.value = p.flash; f.uSat.value = p.sat; f.uCon.value = p.contrast; f.uCol.value = p.color;
    quad.material = mFinal; renderer.setRenderTarget(null); renderer.render(qscene, qcam);
  };
  return G;
})();
