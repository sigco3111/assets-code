/* LANTERNFALL - humanoid rig + wardrobe (layered gear built from lofts, skinned on the CPU) */
function humanRig(o) {
  o = o || {}; const sh = o.sh || 0.2, hp = o.hp || 0.095;
  return makeRig([
    ['root', null, 0, 0, 0], ['hips', 'root', 0, 0.98, 0], ['spine', 'hips', 0, 1.12, 0], ['chest', 'spine', 0, 1.28, 0], ['neck', 'chest', 0, 1.5, 0], ['head', 'neck', 0, 1.585, 0.01],
    ['lUp', 'chest', sh, 1.435, 0], ['lFore', 'lUp', sh + 0.02, 1.14, 0], ['lHand', 'lFore', sh + 0.03, 0.885, 0],
    ['rUp', 'chest', -sh, 1.435, 0], ['rFore', 'rUp', -sh - 0.02, 1.14, 0], ['rHand', 'rFore', -sh - 0.03, 0.885, 0],
    ['lThigh', 'hips', hp, 0.93, 0], ['lShin', 'lThigh', hp + 0.005, 0.5, 0], ['lFoot', 'lShin', hp + 0.005, 0.085, 0],
    ['rThigh', 'hips', -hp, 0.93, 0], ['rShin', 'rThigh', -hp - 0.005, 0.5, 0], ['rFoot', 'rShin', -hp - 0.005, 0.085, 0],
    ['cloakA', 'chest', 0, 1.46, -0.1], ['cloakB', 'cloakA', 0, 1.1, -0.15], ['cloakC', 'cloakB', 0, 0.74, -0.17],
    ['wR', 'rHand', -sh - 0.03, 0.835, 0], ['wL', 'lHand', sh + 0.03, 0.835, 0],
    ['str', 'wL', sh + 0.03, 0.835, 0], ['arw', 'str', sh + 0.03, 0.835, 0], ['lan', 'wL'].concat(o.lan || [sh + 0.03, 0.835, 0], [1]), ['back', 'chest', 0, 1.3, -0.12], ['lanB', 'back'].concat(o.lanB || [-0.14, 2.43, 0.07], [1])
  ]);
}
const COL = {
  mail: C(0x70757a), plate: C(0x8b8f93), iron: C(0x34353a), brass: C(0x8a6a34),
  linen: C(0x857a60), buff: C(0x6e6148), murrey: C(0x4a1e22), bone: C(0x6e6857), wool: C(0x222a27), woolBrown: C(0x3c3026), woolGrey: C(0x44474a), black: C(0x1a1a1c),
  leather: C(0x40291a), leatherDk: C(0x271b13), leatherTan: C(0x6a4a2c), waxed: C(0x25221c),
  skin: C(0x6e5040), skinDk: C(0x3a2a22), hair: C(0x2a2018), hairGrey: C(0x6a665e), fur: C(0x4c3b2c), furGrey: C(0x5a5650), wood: C(0x5e4a32), woodDk: C(0x3a2c1e), rope: C(0x6a5c40)
};
const HW = (function () {
  const H = {};
  const TP = [[0.90, 0.168, 0.105, 0.115, 2.3], [0.98, 0.172, 0.11, 0.12, 2.3], [1.045, 0.152, 0.103, 0.102, 2.2], [1.1, 0.153, 0.105, 0.1, 2.2], [1.17, 0.162, 0.112, 0.1, 2.2], [1.27, 0.182, 0.125, 0.11, 2.3], [1.37, 0.198, 0.122, 0.112, 2.4], [1.44, 0.19, 0.105, 0.105, 2.5], [1.49, 0.11, 0.075, 0.085, 2.2], [1.525, 0.062, 0.06, 0.066, 2.0]];
  const AP = [[1.5, 0.03, -0.015], [1.475, 0.058, 0], [1.43, 0.066, 0.004], [1.34, 0.058, 0.008], [1.22, 0.05, 0.016], [1.14, 0.047, 0.02], [1.07, 0.049, 0.023], [0.99, 0.042, 0.027], [0.905, 0.034, 0.03]];
  const LP = [[0.99, 0.086, 0.095, 0.1, 0], [0.9, 0.09, 0.097, 0.1, 0], [0.76, 0.08, 0.088, 0.088, 0.002], [0.62, 0.066, 0.07, 0.068, 0.004], [0.5, 0.056, 0.06, 0.056, 0.005], [0.43, 0.052, 0.05, 0.06, 0.005], [0.34, 0.054, 0.046, 0.07, 0.005], [0.22, 0.044, 0.04, 0.05, 0.005], [0.1, 0.038, 0.04, 0.042, 0.005]];
  AP.reverse(); LP.reverse(); // all tables ascending in y
  function samp(Tb, y) {
    if (y <= Tb[0][0]) return Tb[0]; const n = Tb.length; if (y >= Tb[n - 1][0]) return Tb[n - 1];
    for (let i = 0; i < n - 1; i++) { const a = Tb[i], b = Tb[i + 1]; if (y <= b[0]) { const t = (y - a[0]) / (b[0] - a[0]); return a.map((v, k) => lerp(v, b[k], t)); } }
    return Tb[n - 1];
  }
  function span(Tb, y0, y1) { // table rows clipped to [y0,y1], ascending y
    const out = [samp(Tb, y0)];
    for (const r of Tb) if (r[0] > y0 + 0.012 && r[0] < y1 - 0.012) out.push(r); out.push(samp(Tb, y1)); out[0] = out[0].slice(); out[0][0] = y0; const l = out[out.length - 1] = out[out.length - 1].slice(); l[0] = y1; return out;
  }
  const BL = y => smooth(1.04, 1.1, y) * smooth(1.3, 1.13, y);
  H.TW = chainY([['neck', 9], ['chest', 1.5], ['spine', 1.27], ['hips', 1.1]], 0.05);
  // torso shell. o: grow, y0, y1, k (width), kz (depth), belly, arc, thick, seg
  H.torso = function (g, o) {
    o = o || {}; const gr = o.grow || 0, k = o.k || 1, kz = o.kz || k, rows = span(TP, o.y0 === undefined ? 0.9 : o.y0, o.y1 === undefined ? 1.525 : o.y1);
    g.bone(o.bone || H.TW);
    return g.loft(rows.map(r => ({ y: r[0], rx: r[1] * k + gr, rx: r[1] * k + gr + (o.blouse || 0) * BL(r[0]), rz: r[2] * kz + gr + (o.belly || 0) * smooth(0.28, 0, Math.abs(r[0] - 1.1)) + (o.blouse || 0) * BL(r[0]) * 1.2, rb: r[3] * kz + gr + (o.blouse || 0) * BL(r[0]), sq: r[4] })), { seg: o.seg || 18, sub: 3, arc: o.arc, thick: o.thick, cap0: o.cap0, cap1: o.cap1, wr: o.wr, wra: o.wra, wry: o.wry });
  };
  H.arm = function (g, P, side, o) {
    o = o || {}; const gr = o.grow || 0, k = o.k || 1, rows = span(AP, o.y0 === undefined ? 0.905 : o.y0, o.y1 === undefined ? 1.5 : o.y1), U = side > 0 ? 'lUp' : 'rUp', F = side > 0 ? 'lFore' : 'rFore';
    g.bone(o.bone || jb(U, F, 1.14, 0.05));
    return g.loft(rows.map(r => ({ y: r[0], rx: r[1] * k + gr, x: side * (P.sh + r[2]) })), { seg: o.seg || 10, sub: 3, thick: o.thick, cap0: o.cap0, cap1: o.cap1 === undefined ? (o.y1 === undefined) : o.cap1, wr: o.wr, wra: o.wra || 2, wry: o.wry || 55 });
  };
  H.leg = function (g, P, side, o) {
    o = o || {}; const gr = o.grow || 0, k = o.k || 1, rows = span(LP, o.y0 === undefined ? 0.1 : o.y0, o.y1 === undefined ? 0.99 : o.y1), Tn = side > 0 ? 'lThigh' : 'rThigh', S = side > 0 ? 'lShin' : 'rShin';
    g.bone(o.bone || jb(Tn, S, 0.5, 0.055));
    return g.loft(rows.map(r => ({ y: r[0], rx: r[1] * k + gr, rz: r[2] * k + gr, rb: r[3] * k + gr, x: side * (P.hp + r[4]) })), { seg: o.seg || 12, sub: 3, arc: o.arc, thick: o.thick, cap0: o.cap0, cap1: o.cap1, wr: o.wr, wra: o.wra || 2, wry: o.wry || 45 });
  };
  H.boot = function (g, P, side, o) {
    o = o || {}; const x = side * (P.hp + 0.005), S = side > 0 ? 'lShin' : 'rShin', F = side > 0 ? 'lFoot' : 'rFoot', top = o.top || 0.37;
    g.bone(jb(S, F, 0.1, 0.035));
    H.leg(g, P, side, { y0: 0.07, y1: top, grow: 0.009, bone: jb(S, F, 0.1, 0.035) });
    // folded cuff
    g.bone(S); const c = samp(LP, top);
    g.loft([{ y: top - 0.05, rx: c[1] + 0.011, rz: c[2] + 0.011, rb: c[3] + 0.012, x }, { y: top - 0.02, rx: c[1] + 0.015, rz: c[2] + 0.015, rb: c[3] + 0.016, x }, { y: top + 0.01, rx: c[1] + 0.013, rz: c[2] + 0.013, rb: c[3] + 0.014, x }, { y: top + 0.01, rx: c[1] + 0.005, rz: c[2] + 0.005, rb: c[3] + 0.005, x }], { seg: 12, sub: 2 });
    // foot: lofted along +Z with a flat sole and a heel
    g.bone(F);
    g.tr(x, 0.056, 0.012, PI / 2, 0, 0);
    g.loft([{ y: -0.088, rx: 0.026, rz: 0.03, rb: 0.03, sq: 2.6 }, { y: -0.06, rx: 0.042, rz: 0.05, rb: 0.05, sq: 2.6 }, { y: -0.01, rx: 0.047, rz: 0.052, rb: 0.062, sq: 2.6 }, { y: 0.05, rx: 0.047, rz: 0.05, rb: 0.05, sq: 2.5 }, { y: 0.11, rx: 0.05, rz: 0.046, rb: 0.03, sq: 2.4 }, { y: 0.165, rx: 0.044, rz: 0.04, rb: 0.016, sq: 2.3 }, { y: 0.2, rx: 0.032, rz: 0.034, rb: 0.004, sq: 2.2 }, { y: 0.222, rx: 0.014, rz: 0.026, rb: -0.006, sq: 2.2 }], { seg: 12, sub: 3, cap0: true, cap1: true, wr: 0.06, wra: 2, wry: 30 });
    g.pop();
    const m = g.m; g.mat(COL.leatherDk, 0.9, 0, T_LEATHER, 1.6);
    g.tr(x, 0.015, 0.012, PI / 2, 0, 0);
    g.loft([{ y: -0.092, rx: 0.036, rz: 0.015, sq: 3 }, { y: -0.06, rx: 0.045, rz: 0.015, sq: 3 }, { y: -0.012, rx: 0.046, rz: 0.015, sq: 3 }, { y: -0.008, rx: 0.044, rz: 0.006, rb: 0.015, sq: 3 }, { y: 0.11, rx: 0.052, rz: 0.006, rb: 0.012, sq: 3 }, { y: 0.19, rx: 0.04, rz: 0.004, rb: 0.01, sq: 3 }, { y: 0.226, rx: 0.016, rz: 0.002, rb: 0.008, sq: 3 }], { seg: 10, sub: 2, cap0: true, cap1: true });
    g.m = m; g.pop();
  };
  H.fist = function (g, P, side, o) {
    const x = side * (P.sh + 0.03), Hn = side > 0 ? 'lHand' : 'rHand';
    g.bone(Hn);
    g.loft([{ y: 0.782, rx: 0.026, rz: 0.036, rb: 0.026, x, z: 0.006, sq: 2.6 }, { y: 0.8, rx: 0.037, rz: 0.05, rb: 0.036, x, z: 0.008, sq: 3 }, { y: 0.835, rx: 0.04, rz: 0.05, rb: 0.04, x, z: 0.006, sq: 3 }, { y: 0.868, rx: 0.036, rz: 0.04, rb: 0.036, x, z: 0.002, sq: 2.6 }, { y: 0.89, rx: 0.03, rz: 0.03, rb: 0.03, x, sq: 2.2 }], { seg: 10, sub: 2, cap0: true, cap1: true });
    for (let k = 0; k < 4; k++) { g.tr(x - side * 0.027 + side * k * 0.018, 0.812 + 0.004 * Math.sin(k * 1.3), 0.05); g.sphere(0.0095, 0.02, 0.012, 5, 4); g.pop(); }
    g.tr(x - side * 0.03, 0.845, 0.034, 0.5, 0, 0); g.sphere(0.014, 0.03, 0.016, 6, 5); g.pop();
    g.bone(jb(side > 0 ? 'lFore' : 'rFore', Hn, 0.885, 0.02));
    g.tr(x, 0, 0); g.lathe([[0.036, 0.935], [0.038, 0.9], [0.04, 0.875], [0.03, 0.858]], 9); g.pop();
    return g;
  };
  // skirt weights: sides follow the thighs, centre hangs from the hips
  H.skirtW = function (yTop) {
    return (x, y, z) => {
      const t = smooth(yTop, yTop - 0.24, y), lf = smooth(0.015, 0.075, Math.abs(x)), L = x > 0;
      if (y < 0.52 && lf > 0.97) return [L ? 'lThigh' : 'rThigh', L ? 'lShin' : 'rShin', smooth(0.52, 0.26, y) * 0.7];
      return ['hips', L ? 'lThigh' : 'rThigh', t * lf];
    };
  };
  // skirt from waist to hem. o: y0 (top), y1 (hem), r0:[rx,rz], r1:[rx,rz], flare, arc, thick, wave
  H.skirt = function (g, o) {
    const y0 = o.y0, y1 = o.y1, n = 5, rings = [], a = samp(TP, Math.max(0.9, y0));
    for (let i = 0; i <= n; i++) { const t = i / n, y = lerp(y1, y0, t), f = 1 - t; rings.push({ y, rx: a[1] + (o.grow || 0) + (o.flare || 0.05) * f, rz: a[2] + (o.grow || 0) + (o.flare || 0.05) * f * 0.9, rb: a[3] + (o.grow || 0) + (o.flare || 0.05) * f * 1.1, sq: 2.3 }); }
    g.bone(H.skirtW(o.wTop || y0));
    const wave = o.wave || 0;
    if (!wave) return g.loft(rings, { seg: o.seg || 20, sub: 2, arc: o.arc, thick: o.thick === undefined ? 0.008 : o.thick });
    // hem with soft folds
    const seg = o.seg || 28, arc = o.arc, a0 = arc ? arc[0] : 0, a1 = arc ? arc[1] : TAU, ax = a[1] + (o.grow || 0), az = a[2] + (o.grow || 0), ab = a[3] + (o.grow || 0), fl = o.flare || 0.05;
    return g.surf(seg, 8, (u, v) => {
      const y = lerp(y1, y0, v), f = 1 - v, an = a0 + (a1 - a0) * u, c = Math.cos(an), s = Math.sin(an), fold = 1 + wave * f * Math.sin(an * (o.folds || 9) + 1.3) + wave * 0.5 * f * Math.sin(an * 17 + 4);
      return [(ax + fl * f) * c * fold, y, (s >= 0 ? az + fl * f * 0.9 : ab + fl * f * 1.1) * s * fold];
    }, { closeU: !arc, thick: o.thick === undefined ? 0.008 : o.thick });
  };
  H.belt = function (g, o) {
    o = o || {}; const y = o.y || 1.045, a = samp(TP, y), gr = o.grow || 0.03, w = o.w || 0.026;
    g.bone('hips'); g.mat(o.col || COL.leatherDk, 0.62, 0, T_LEATHER, 0.5);
    g.loft([{ y: y - w, rx: a[1] + gr, rz: a[2] + gr, rb: a[3] + gr, sq: 2.2 }, { y: y - w, rx: a[1] + gr + 0.007, rz: a[2] + gr + 0.007, rb: a[3] + gr + 0.007, sq: 2.2 }, { y: y + w, rx: a[1] + gr + 0.007, rz: a[2] + gr + 0.007, rb: a[3] + gr + 0.007, sq: 2.2 }, { y: y + w, rx: a[1] + gr, rz: a[2] + gr, rb: a[3] + gr, sq: 2.2 }], { seg: 18, sub: 1 });
    // buckle + strap end
    g.mat(COL.brass, 0.45, 0.9, T_PLATE, 0.3);
    g.tr(0.015, y - 0.03, a[2] + gr + 0.006, 0, 0, 0); g.loft([{ y: 0, rx: 0.03, rz: 0.006, sq: 6 }, { y: 0.06, rx: 0.03, rz: 0.006, sq: 6 }], { seg: 8, sub: 1, cap0: true, cap1: true }); g.pop();
    g.mat(o.col || COL.leatherDk, 0.62, 0, T_LEATHER, 0.5);
    g.bone(H.skirtW(y)); g.tr(-0.03, y - 0.19, a[2] + gr + 0.012, 0.06, 0, 0.05); g.loft([{ y: 0, rx: 0.012, rz: 0.003, sq: 5 }, { y: 0.19, rx: 0.018, rz: 0.004, sq: 5 }], { seg: 8, sub: 1, cap0: true }); g.pop();
  };
  H.pouch = function (g, x, y, z, s, col) {
    g.bone('hips'); g.mat(col || COL.leather, 0.7, 0, T_LEATHER, 0.6);
    g.tr(x, y, z, 0, Math.atan2(x, z), 0, s || 1);
    g.loft([{ y: -0.1, rx: 0.045, rz: 0.03, sq: 3 }, { y: -0.06, rx: 0.055, rz: 0.04, sq: 3 }, { y: 0, rx: 0.05, rz: 0.034, sq: 3 }], { seg: 10, sub: 2, cap0: true, cap1: true });
    g.surf(6, 3, (u, v) => [(u - 0.5) * 0.1, 0.004 - v * 0.07, 0.036 + Math.sin(v * 2.2) * 0.012], { thick: 0.005 });
    g.pop();
  };
  // head with a restrained face. o: beard (0..1 length), skin, hair
  H.head = function (g, o) {
    o = o || {}; const sk = o.skin || COL.skin;
    g.bone(jb('head', 'neck', 1.56, 0.02)); g.mat(sk, 0.62, 0, T_SKIN, 0.25);
    g.lathe([[0.05, 1.47], [0.049, 1.53], [0.052, 1.585]], 10);
    g.bone('head');
    g.loft([{ y: 1.548, rx: 0.038, rz: 0.058, rb: 0.04, z: 0.012 }, { y: 1.575, rx: 0.057, rz: 0.082, rb: 0.066, z: 0.008 }, { y: 1.62, rx: 0.07, rz: 0.093, rb: 0.084, z: 0.004 }, { y: 1.675, rx: 0.076, rz: 0.097, rb: 0.094 }, { y: 1.72, rx: 0.078, rz: 0.1, rb: 0.1 }, { y: 1.765, rx: 0.071, rz: 0.09, rb: 0.096 }, { y: 1.795, rx: 0.046, rz: 0.06, rb: 0.066 }, { y: 1.806, rx: 0.012, rz: 0.016, rb: 0.016 }], { seg: 16, sub: 3, cap0: true, cap1: true });
    // nose, brow, cheek planes
    g.loft([{ y: 1.648, rx: 0.017, rz: 0.03, rb: 0.01, z: 0.092 }, { y: 1.668, rx: 0.014, rz: 0.03, rb: 0.01, z: 0.092 }, { y: 1.7, rx: 0.01, rz: 0.016, rb: 0.01, z: 0.09 }, { y: 1.722, rx: 0.011, rz: 0.012, rb: 0.01, z: 0.09 }], { seg: 8, sub: 2, cap0: true });
    g.tr(0, 1.722, 0.086); g.sphere(0.062, 0.012, 0.022, 10, 5); g.pop();
    g.mat(mixC(sk, [0, 0, 0], 0.78), 0.5, 0, T_SKIN, 0);
    for (const s of [-1, 1]) { g.tr(s * 0.031, 1.699, 0.086); g.sphere(0.016, 0.008, 0.012, 8, 5); g.pop(); }
    g.tr(0, 1.612, 0.089); g.sphere(0.022, 0.004, 0.008, 8, 4); g.pop();
    if (o.beard) {
      const b = o.beard; g.mat(o.hair || COL.hair, 0.95, 0, T_FUR, 0.3);
      g.loft([{ y: 1.555 - b * 0.09, rx: 0.02, rz: 0.03, rb: 0.0, z: 0.05 }, { y: 1.565 - b * 0.04, rx: 0.052, rz: 0.062, rb: 0.01, z: 0.036 }, { y: 1.6, rx: 0.075, rz: 0.1, rb: 0.03, z: 0.004 }, { y: 1.64, rx: 0.079, rz: 0.1, rb: 0.03, z: 0.002 }, { y: 1.665, rx: 0.079, rz: 0.086, rb: 0.03 }], { seg: 14, sub: 3, arc: [-0.25, PI + 0.25], cap0: true });
      g.tr(0, 1.632, 0.094); g.sphere(0.034, 0.011, 0.014, 8, 4); g.pop(); // moustache
    }
    if (o.hairCap) { g.mat(o.hair || COL.hair, 0.95, 0, T_FUR, 0.2); g.loft([{ y: 1.6, rx: 0.074, rz: 0.03, rb: 0.092, z: -0.006 }, { y: 1.68, rx: 0.082, rz: 0.07, rb: 0.102 }, { y: 1.74, rx: 0.082, rz: 0.098, rb: 0.105 }, { y: 1.79, rx: 0.06, rz: 0.075, rb: 0.08 }, { y: 1.813, rx: 0.01, rz: 0.012, rb: 0.012 }], { seg: 14, sub: 3, cap1: true }); }
  };
  // mail coif: hood + mantle over the shoulders
  H.coif = function (g, P, o) {
    o = o || {}; g.mat(o.col || COL.mail, 0.5, 0.85, T_MAIL, 0.3);
    g.bone(chainY([['head', 9], ['neck', 1.585], ['chest', 1.5]], 0.035));
    const win = o.window === undefined ? 0.6 : o.window, a0 = PI / 2 + win, a1 = PI / 2 - win + TAU, lip = o.lip || 1.684;
    // crown, open at the face
    g.loft([{ y: lip, rx: 0.089, rz: 0.108, rb: 0.104 }, { y: 1.74, rx: 0.088, rz: 0.106, rb: 0.108 }, { y: 1.79, rx: 0.066, rz: 0.08, rb: 0.086 }, { y: 1.816, rx: 0.02, rz: 0.03, rb: 0.03 }], { seg: 16, sub: 3, arc: [a0, a1], thick: 0.006 });
    // ventail and mantle: closed below the eyes, draping over the shoulders
    g.loft([{ y: 1.418, rx: P.sh + 0.02, rz: 0.145, rb: 0.136, sq: 2.5 }, { y: 1.455, rx: P.sh - 0.02, rz: 0.13, rb: 0.126, sq: 2.4 }, { y: 1.5, rx: 0.118, rz: 0.1, rb: 0.104 }, { y: 1.55, rx: 0.084, rz: 0.092, rb: 0.088 }, { y: 1.61, rx: 0.086, rz: 0.108, rb: 0.096 }, { y: lip, rx: 0.089, rz: 0.11, rb: 0.104 }], { seg: 18, sub: 3, thick: 0.007, wr: 0.05, wra: 4, wry: 40 });
  };
  H.kettle = function (g, o) {
    o = o || {}; g.bone('head'); g.mat(o.col || COL.plate, 0.44, 1, T_PLATE, 0.5);
    g.tr(0, 1.748, 0.0, -0.03, 0, 0);
    g.loft([{ y: -0.052, rx: 0.16, rz: 0.168, rb: 0.166 }, { y: -0.038, rx: 0.158, rz: 0.165, rb: 0.164 }, { y: 0.0, rx: 0.098, rz: 0.114, rb: 0.114 }, { y: 0.04, rx: 0.094, rz: 0.11, rb: 0.112 }, { y: 0.075, rx: 0.074, rz: 0.088, rb: 0.09 }, { y: 0.094, rx: 0.036, rz: 0.044, rb: 0.046 }, { y: 0.1, rx: 0.004, rz: 0.006, rb: 0.006 }], { seg: 20, sub: 1, thick: 0.004 });
    // raised comb + rivets
    g.loft([{ y: 0.0, rx: 0.006, rz: 0.116, rb: 0.116 }, { y: 0.07, rx: 0.006, rz: 0.094, rb: 0.096 }, { y: 0.106, rx: 0.005, rz: 0.03, rb: 0.03 }], { seg: 8, sub: 2, cap1: true });
    g.mat(COL.iron, 0.5, 1, T_PLATE, 0.3);
    for (let i = 0; i < 10; i++) { const a = i / 10 * TAU + 0.3; g.tr(Math.cos(a) * 0.1, 0.012, Math.sin(a) * 0.116); g.sphere(0.006, 0.005, 0.006, 5, 3); g.pop(); }
    g.pop();
  };
  // shoulder plate: 2 lames. side +1 left
  H.spaulder = function (g, P, side, o) {
    o = o || {}; const U = side > 0 ? 'lUp' : 'rUp', x = side * P.sh, s = o.s || 1;
    g.mat(o.col || COL.plate, 0.46, 1, T_PLATE, 0.5);
    const shell = (y, r, ry, drop, w) => g.surf(8, 5, (u, v) => {
      const a = (u - 0.5) * 2.5, b = v * 1.25; const cx = Math.sin(b), cy = Math.cos(b);
      return [x + side * (cx * r * Math.cos(a) * 0.86 + 0.012), y + cy * ry - drop * v, Math.sin(a) * cx * r * 1.12];
    }, { thick: 0.005, flip: side < 0 });
    g.bone(() => ['chest', U, 0.45]); shell(1.428, 0.082 * s, 0.07 * s, 0.0);
    g.bone(() => ['chest', U, 0.8]); shell(1.39, 0.08 * s, 0.04 * s, 0.05);
    g.bone(U); shell(1.345, 0.074 * s, 0.03 * s, 0.05);
  };
  H.couter = function (g, P, side, o) {
    const U = side > 0 ? 'lUp' : 'rUp', F = side > 0 ? 'lFore' : 'rFore', x = side * (P.sh + 0.02);
    g.mat((o && o.col) || COL.plate, 0.46, 1, T_PLATE, 0.5); g.bone(() => [U, F, 0.5]);
    g.tr(x, 1.14, -0.012); g.surf(8, 5, (u, v) => { const a = u * TAU, b = v * 1.5; return [Math.cos(a) * Math.sin(b) * 0.06, Math.sin(a) * Math.sin(b) * 0.066, -Math.cos(b) * 0.062]; }, { closeU: true, thick: 0.004 }); g.pop();
  };
  H.vambrace = function (g, P, side, o) {
    o = o || {}; const F = side > 0 ? 'lFore' : 'rFore';
    g.mat(o.col || COL.plate, o.rough || 0.46, o.metal === undefined ? 1 : o.metal, o.ty === undefined ? T_PLATE : o.ty, 0.5);
    H.arm(g, P, side, { y0: 0.93, y1: 1.09, grow: 0.012, bone: F, thick: 0.004, cap1: false });
  };
  H.poleyn = function (g, P, side, o) {
    const Tn = side > 0 ? 'lThigh' : 'rThigh', S = side > 0 ? 'lShin' : 'rShin', x = side * (P.hp + 0.005);
    g.mat((o && o.col) || COL.plate, 0.46, 1, T_PLATE, 0.9); g.bone(() => [Tn, S, 0.5]);
    g.tr(x, 0.5, 0.01); g.surf(8, 5, (u, v) => { const a = u * TAU, b = v * 1.45; return [Math.cos(a) * Math.sin(b) * 0.06, Math.sin(a) * Math.sin(b) * 0.07, Math.cos(b) * 0.066]; }, { closeU: true, thick: 0.004 }); g.pop();
    g.bone(Tn); H.leg(g, P, side, { y0: 0.56, y1: 0.8, grow: 0.012, arc: [0.25, PI - 0.25], thick: 0.004 });
  };
  H.greave = function (g, P, side, o) {
    const S = side > 0 ? 'lShin' : 'rShin';
    g.mat((o && o.col) || COL.plate, 0.46, 1, T_PLATE, 1.2); H.leg(g, P, side, { y0: 0.17, y1: 0.45, grow: 0.012, arc: [-0.3, PI + 0.3], thick: 0.004, bone: S });
  };
  // cloak hanging from the shoulders. o: len (hem y), w0, w1, col, wrap (how far it comes round the front), folds
  H.cloak = function (g, P, o) {
    o = o || {}; const hem = o.hem === undefined ? 0.42 : o.hem, top = 1.5, wrap = o.wrap === undefined ? 0.5 : o.wrap;
    g.mat(o.col || COL.wool, 0.95, 0, T_CLOTH, 1.5);
    g.bone((x, y, z) => { if (y > 1.36) return ['chest', 'cloakA', 1 - smooth(1.36, 1.5, y)]; if (y > 1.02) return ['cloakA', 'cloakB', 1 - smooth(1.02, 1.36, y)]; return ['cloakB', 'cloakC', 1 - smooth(0.66, 1.02, y)]; });
    const a0 = -PI / 2 - (PI / 2 + wrap), a1 = -PI / 2 + (PI / 2 + wrap);
    g.surf(38, 16, (u, v) => {
      const y = lerp(top, hem, Math.pow(v, 0.9)), f = v, a = lerp(a0, a1, u), back = Math.max(0, -Math.sin(a));
      const rx = lerp(0.13, P.sh + 0.075, smooth(0, 0.14, f)) + f * (o.flare || 0.1), rz = lerp(0.1, 0.165, smooth(0, 0.14, f)) + f * (o.flare || 0.1) * 0.9;
      const nz = vnoise2(a * 2.1 + 3.3, 0.5), fold = 1 + (o.fold || 0.085) * smooth(0.1, 0.75, f) * (Math.sin(a * 9 + 0.7 + nz * 5) * (0.5 + nz) + 0.5 * Math.sin(a * 19 + 2)) + 0.04 * (vnoise2(a * 3, y * 6) - 0.5);
      const drop = (1 - back) * 0.03 * f, rag = smooth(0.8, 1, f) * (0.05 * vnoise2(a * 6 + 1, 2.2) + 0.035 * vnoise2(a * 17, 5.1));
      return [Math.cos(a) * rx * fold, y + drop + rag + Math.sin(a * 7) * 0.012 * f, Math.sin(a) * rz * fold - 0.012 - 0.05 * f * back];
    }, { thick: 0.007 });
    // clasp
    if (o.clasp !== false) { g.bone('chest'); g.mat(COL.brass, 0.45, 0.9, T_PLATE, 0.2); g.tr(0, 1.462, 0.108); g.sphere(0.02, 0.02, 0.008, 8, 5); g.pop(); }
  };
  // cloth hood: a closed cowl with an oval, shadowed face opening, and a short mantle
  H.hood = function (g, P, o) {
    o = o || {}; g.mat(o.col || COL.wool, 0.95, 0, T_CLOTH, 0.6);
    g.bone(chainY([['head', 9], ['neck', 1.6], ['chest', 1.51]], 0.04));
    const op0 = o.open || 0.7, yc = 1.672, hy = 0.118, pk = o.peak || 0.05;
    g.surf(30, 16, (u, v) => {
      const y = lerp(1.5, 1.855, v), q = (y - yc) / hy, op = Math.abs(q) < 1 ? op0 * Math.sqrt(1 - q * q) : 0;
      const a = lerp(PI / 2 + op, PI / 2 - op + TAU, u), e = Math.abs(u - 0.5) * 2, fr = smooth(0.62, 1, e) * (op > 0.02 ? 1 : 0.4);
      const tt = clamp((y - 1.73) / 0.125, 0, 1), dome = Math.sqrt(Math.max(0, 1 - tt * tt)), low = smooth(1.6, 1.5, y);
      const rx = (0.106 + 0.012 * Math.sin(clamp((y - 1.5) / 0.25, 0, 1) * PI)) * dome + 0.012 * low + 0.004, rz = (0.118 + fr * 0.04) * dome + 0.004 + 0.01 * low, rb = (0.122 + pk * smooth(1.62, 1.76, y)) * (0.25 + 0.75 * dome) + 0.012 * low;
      const s = Math.sin(a), c = Math.cos(a), wr = 1 + 0.03 * Math.sin(a * 7 + y * 30) + 0.02 * Math.sin(a * 13);
      return [c * rx * wr, y + fr * 0.012 * (1 - v) - 0.012 * tt * tt * Math.max(0, -s), (s >= 0 ? rz : rb) * s * wr + 0.008];
    }, { thick: 0.01 });
    g.bone(chainY([['neck', 9], ['chest', 1.5]], 0.04));
    g.surf(26, 6, (u, v) => { const a = u * TAU, y = lerp(1.54, 1.35, v), f = smooth(0, 1, v), rx = lerp(0.1, P.sh + 0.09, Math.pow(f, 0.7)), rz = lerp(0.1, 0.172, Math.pow(f, 0.7)), w = 1 + 0.04 * f * Math.sin(a * 9 + 1) + 0.025 * f * Math.sin(a * 17); return [Math.cos(a) * rx * w, y + 0.014 * Math.sin(a * 5) * f - 0.02 * f * Math.max(0, Math.sin(a)), Math.sin(a) * rz * w]; }, { closeU: true, thick: 0.009 });
  };
  /* ----- carried things ----- */
  // sword in a hand; blade along +Z (bind), edge down. o: len, w, grip, guard, pommel, side(-1 right)
  H.sword = function (g, P, side, o) {
    o = o || {}; const x = side * (P.sh + 0.03), y = 0.835, len = o.len || 0.8, w = o.w || 0.026, gl = o.grip || 0.1, B = side > 0 ? 'wL' : 'wR';
    g.bone(B);
    g.tr(x, y, 0, PI / 2, 0, 0); // local +Y -> world +Z
    g.mat(COL.leatherDk, 0.7, 0, T_LEATHER, 0.2); g.lathe([[0.013, -gl * 0.62], [0.016, -gl * 0.3], [0.015, 0], [0.013, gl * 0.4]], 8);
    g.mat(COL.iron, 0.42, 1, T_PLATE, 0.2); g.tr(0, -gl * 0.62 - 0.018, 0); g.sphere(0.024, 0.02, 0.024, 8, 6); g.pop();
    // guard (along world Y => local Z after the rotation)
    g.loft([{ y: gl * 0.4, rx: 0.012, rz: (o.guard || 0.1), sq: 3 }, { y: gl * 0.4 + 0.016, rx: 0.011, rz: (o.guard || 0.1) * 0.96, sq: 3 }], { seg: 8, sub: 1, cap0: true, cap1: true });
    // blade: diamond section, flats face +-X, edges along local Z
    g.mat(o.col || C(0xa9adb2), 0.3, 1, T_PLATE, 0.25);
    const y0 = gl * 0.4 + 0.016; g.loft([{ y: y0, rx: 0.0045, rz: w, sq: 1 }, { y: y0 + len * 0.6, rx: 0.004, rz: w * 0.82, sq: 1 }, { y: y0 + len * 0.9, rx: 0.003, rz: w * 0.55, sq: 1 }, { y: y0 + len, rx: 0.0005, rz: 0.002, sq: 1 }], { seg: 4, sub: 1, flat: true });
    g.pop();
    return { tip: [x, y, gl * 0.4 + 0.016 + len], base: [x, y, 0.06] };
  };
  // heater shield strapped to the left forearm; face +X (side), top toward +Z (bind)
  H.shield = function (g, P, side, o) {
    o = o || {}; const F = side > 0 ? 'lFore' : 'rFore', x0 = side * (P.sh + 0.105), yc = 1.02, hw = o.hw || 0.3, hh = o.h || 0.86;
    g.bone(F);
    const prof = t => t < 0.3 ? 1 : Math.pow(Math.cos((t - 0.3) / 0.7 * PI / 2), 0.72);
    const cA = o.colA || COL.murrey, cB = o.colB || COL.bone;
    const face = (ins, mat) => g.surf(12, 12, (u, v) => {
      const s = (u - 0.5) * 2, w = hw * prof(v) * (1 - ins), yy = s * w, zz = hh * 0.42 - v * hh * (1 - ins * 0.3) - ins * 0.02;
      return [x0 + side * (0.07 - yy * yy * 0.75 - ins * 0.2), yc + yy, zz];
    }, { thick: ins ? 0.004 : 0.016, flip: side < 0 });
    g.mat(COL.woodDk, 0.8, 0, T_WOOD, 0.5); face(0);
    // painted face: per pale, two surfaces just proud of the board
    const half = (s0, s1, col) => { g.mat(col, 0.72, 0, T_CLOTH, 0.9); g.surf(6, 12, (u, v) => { const s = lerp(s0, s1, u), w = hw * prof(v) * 0.965, yy = s * w, zz = hh * 0.42 - 0.012 - v * hh * 0.972; return [x0 + side * (0.073 - yy * yy * 0.75), yc + yy, zz]; }, { flip: side < 0 }); };
    half(-1, 0, cA); half(0, 1, cB);
    // rim and boss rivets
    g.mat(COL.iron, 0.5, 1, T_PLATE, 0.6);
    const N = 26; for (let i = 0; i < N; i++) { const t = i / N; const v = t < 0.5 ? t * 2 : (1 - t) * 2, sgn = t < 0.5 ? 1 : -1, w = hw * prof(v) * 0.93, yy = sgn * w, zz = hh * 0.42 - 0.02 - v * hh * 0.95; g.tr(x0 + side * (0.076 - yy * yy * 0.75), yc + yy, zz); g.sphere(0.008, 0.008, 0.008, 5, 3); g.pop(); }
    // enarmes (straps) on the back
    g.mat(COL.leather, 0.7, 0, T_LEATHER, 0.3);
    g.tr(side * (P.sh + 0.035), 1.07, 0); g.lathe([[0.062, -0.014], [0.064, 0], [0.062, 0.014]], 8, { thick: 0.004 }); g.pop();
    g.tr(side * (P.sh + 0.04), 0.94, 0); g.lathe([[0.056, -0.014], [0.058, 0], [0.056, 0.014]], 8, { thick: 0.004 }); g.pop();
  };
  H.scabbard = function (g, P, side, o) {
    o = o || {}; g.bone(H.skirtW(1.02)); const x = side * 0.19;
    g.tr(x, 1.0, 0.02, -1.15 + PI, 0, side * 0.12);
    g.mat(COL.leatherDk, 0.66, 0, T_LEATHER, 0.8); g.loft([{ y: 0, rx: 0.012, rz: 0.03, sq: 2.6 }, { y: 0.6, rx: 0.01, rz: 0.024, sq: 2.6 }, { y: 0.74, rx: 0.006, rz: 0.012, sq: 2.6 }], { seg: 8, sub: 1, cap1: true });
    g.mat(COL.iron, 0.5, 1, T_PLATE, 0.5); g.loft([{ y: -0.005, rx: 0.014, rz: 0.033, sq: 2.6 }, { y: 0.05, rx: 0.014, rz: 0.032, sq: 2.6 }], { seg: 8, sub: 1, cap0: true }); g.loft([{ y: 0.66, rx: 0.011, rz: 0.02, sq: 2.6 }, { y: 0.76, rx: 0.006, rz: 0.01, sq: 2.6 }], { seg: 8, sub: 1, cap1: true });
    g.pop();
  };
  // hanging lantern (around origin, hangs along -Y). bone must be an abs bone
  H.lanternBody = function (g, bone, x, y, z, s) {
    g.bone(bone); g.tr(x, y, z, 0, 0, 0, s || 1);
    g.mat(COL.iron, 0.55, 0.9, T_PLATE, 0.2);
    g.tube([[0, 0, 0], [0, -0.07, 0]], 0.006, { seg: 4, sub: 1 }); g.tr(0, -0.045, 0, PI / 2, 0, 0); g.lathe([[0.02, -0.004], [0.024, 0], [0.02, 0.004]], 8, { thick: 0.004 }); g.pop();
    g.lathe([[0.0, -0.07], [0.02, -0.075], [0.035, -0.1], [0.085, -0.14], [0.09, -0.155], [0.07, -0.155]], 8);
    g.lathe([[0.07, -0.365], [0.085, -0.365], [0.085, -0.385], [0.05, -0.39], [0.02, -0.41], [0.0, -0.415]], 8);
    for (let i = 0; i < 4; i++) { const a = i / 4 * TAU + PI / 4; g.tube([[Math.cos(a) * 0.076, -0.155, Math.sin(a) * 0.076], [Math.cos(a) * 0.076, -0.365, Math.sin(a) * 0.076]], 0.007, { seg: 4, sub: 1 }); }
    for (const yy of [-0.2, -0.32]) g.lathe([[0.078, yy - 0.004], [0.082, yy], [0.078, yy + 0.004]], 8);
    g.mat(C(0xffb055), 0.4, 0, T_GLOW, 1.0);
    g.lathe([[0.0, -0.165], [0.064, -0.165], [0.064, -0.36], [0.0, -0.36]], 8);
    g.pop();
  };
  // rolled cloth around the neck and shoulders (a hood thrown back, a gathered cloak)
  H.cowl = function (g, P, o) {
    o = o || {}; g.mat(o.col || COL.wool, 0.95, 0, T_CLOTH, 0.5); g.bone(chainY([['neck', 9], ['chest', 1.52]], 0.04));
    const r = o.r || 0.034, y = o.y || 1.485, N = 20, pts = [];
    for (let i = 0; i <= N; i++) { const a = i / N * TAU + PI / 2, c = Math.cos(a), s = Math.sin(a); pts.push([c * (0.118 + (o.wide || 0)), y + (s > 0 ? -0.035 * s : -0.012 * s) + 0.008 * Math.sin(a * 5), s * (s > 0 ? 0.112 : 0.118) - 0.004]); }
    g.tube(pts, t => r * (0.8 + 0.3 * Math.sin(t * 23) * Math.sin(t * 7)), { seg: 8, sub: 1, cap: false });
    if (o.hood) { // hood hanging down the back
      g.surf(8, 5, (u, v) => { const a = (u - 0.5) * 2.2, yy = lerp(1.5, 1.27, v), w = 0.1 * (1 - v * 0.75); return [Math.sin(a) * w, yy, -0.12 - Math.cos(a) * w * 0.7 - 0.05 * Math.sin(v * PI)]; }, { thick: 0.012 });
    }
  };
  // a strap around the torso (baldric / guige / bandolier): from shoulder over chest to opposite hip and round the back
  H.strap = function (g, o) {
    o = o || {}; const s = o.side || 1, w = o.w || 0.017, gr = o.grow || 0.04; g.bone(H.TW); g.mat(o.col || COL.leather, 0.66, 0, T_LEATHER, 0.5);
    const N = 22, pts = [];
    for (let i = 0; i <= N; i++) { const t = i / N, a = t * TAU, yy = 1.25 + 0.2 * Math.cos(a), r = samp(TP, yy), c = Math.cos(a), sn = Math.sin(a + PI / 2 * 0); pts.push([s * c * (r[1] * 0.92 + gr * 0.6) * (0.55 + 0.45 * Math.abs(c)), yy, Math.sin(a) * ((Math.sin(a) > 0 ? r[2] : r[3]) + gr)]); }
    g.tube(pts, w, { seg: 6, sub: 1, cap: false, flatten: 0.35 });
  };
  return H;
})();
const BASE_STANCE = { hips: [0.02, 0.06, 0.04], spine: [0.05, -0.03, -0.03], chest: [0.03, -0.04, -0.025], neck: [0.12, 0, 0], head: [-0.08, 0.1, 0.02],
  lThigh: [-0.17, 0.3, 0.075], lShin: [0.27, 0, 0], lFoot: [-0.1, 0, -0.05], rThigh: [0.05, -0.22, -0.07], rShin: [0.05, 0, 0], rFoot: [-0.08, 0, 0.05],
  lUp: [0.07, 0, 0.16], rUp: [0.05, 0, -0.17], lFore: [-0.4, 0.2, 0], rFore: [-0.36, -0.2, 0] };
function stance(over) { const o = {}; for (const k in BASE_STANCE) o[k] = BASE_STANCE[k].slice(); for (const k in over) o[k] = over[k]; return o; }
