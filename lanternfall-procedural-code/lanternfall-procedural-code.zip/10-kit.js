/* LANTERNFALL - kit: procedural mesh builder with skin weights, surface material, CPU-skinned Figure */
const T_SKIN = 0, T_CLOTH = 1, T_QUILT = 2, T_MAIL = 3, T_LEATHER = 4, T_PLATE = 5, T_FUR = 6, T_WOOD = 7, T_STONE = 8, T_PEAT = 9, T_GLOW = 10, T_BONE = 11;

function makeRig(defs) {
  const n = defs.length, rig = { n, names: {}, parent: new Int8Array(n), head: new Float32Array(n * 3), abs: new Uint8Array(n) };
  defs.forEach((d, i) => {
    rig.names[d[0]] = i; rig.parent[i] = d[1] == null ? -1 : rig.names[d[1]];
    rig.head[i * 3] = d[2]; rig.head[i * 3 + 1] = d[3]; rig.head[i * 3 + 2] = d[4]; if (d[5]) rig.abs[i] = 1;
  });
  return rig;
}

const _spow = (v, e) => v < 0 ? -Math.pow(-v, e) : Math.pow(v, e);
function catmull(a, b, c, d, t) { const t2 = t * t, t3 = t2 * t; return 0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3); }

class Geo {
  constructor(rig) {
    this.rig = rig || null;
    this.P = []; this.N = []; this.Cc = []; this.UV = []; this.M = []; this.BA = []; this.BB = []; this.W = []; this.I = [];
    this.m = { c: [0.5, 0.5, 0.5], r: 0.8, me: 0, ty: 0, g: 1 };
    this.bn = 0; this.xf = new THREE.Matrix4(); this.stack = []; this._v = new THREE.Vector3();
  }
  mat(c, r, me, ty, g) { this.m = { c, r, me: me || 0, ty: ty || 0, g: g === undefined ? 1 : g }; return this; }
  bone(b) { this.bn = b; return this; }
  bi(b) { return typeof b === 'number' ? b : this.rig.names[b]; }
  push(m) { this.stack.push(this.xf.clone()); this.xf.multiply(m); return this; }
  tr(x, y, z, rx, ry, rz, sx, sy, sz) {
    const m = new THREE.Matrix4().compose(new THREE.Vector3(x || 0, y || 0, z || 0),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(rx || 0, ry || 0, rz || 0, 'YXZ')),
      new THREE.Vector3(sx === undefined ? 1 : sx, sy === undefined ? (sx === undefined ? 1 : sx) : sy, sz === undefined ? (sx === undefined ? 1 : sx) : sz));
    return this.push(m);
  }
  pop() { this.xf = this.stack.pop(); return this; }
  _emit(x, y, z, nx, ny, nz, u, v) {
    const i = this.P.length / 3, m = this.m;
    this.P.push(x, y, z); this.N.push(nx, ny, nz); this.Cc.push(m.c[0], m.c[1], m.c[2]); this.UV.push(u, v); this.M.push(m.r, m.me, m.ty, m.g);
    if (this.rig) {
      let b = this.bn;
      if (typeof b === 'function') { const r = b(x, y, z); this.BA.push(this.bi(r[0])); this.BB.push(this.bi(r[1])); this.W.push(sat(r[2])); }
      else { const k = this.bi(b); this.BA.push(k); this.BB.push(k); this.W.push(0); }
    }
    return i;
  }
  // parametric surface. fn(u,v) -> [x,y,z] in local space. opt: closeU, flip, flat, uv:[uLen,vLen], cap0, cap1, thick
  surf(nu, nv, fn, opt) {
    opt = opt || {};
    const cu = !!opt.closeU, W = nu + 1, H = nv + 1, G = new Float32Array(W * H * 3), v3 = this._v;
    let cx = 0, cy = 0, cz = 0;
    for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
      const p = fn((cu && i === nu) ? 0 : i / nu, j / nv); v3.set(p[0], p[1], p[2]).applyMatrix4(this.xf);
      const k = (j * W + i) * 3; G[k] = v3.x; G[k + 1] = v3.y; G[k + 2] = v3.z; cx += v3.x; cy += v3.y; cz += v3.z;
    }
    cx /= W * H; cy /= W * H; cz /= W * H;
    const det = this.xf.determinant() < 0; const flip = (!!opt.flip) !== det;
    // uv lengths
    let uL = opt.uv ? opt.uv[0] : 0, vL = opt.uv ? opt.uv[1] : 0;
    if (!opt.uv) {
      const jm = H >> 1, im = W >> 1;
      for (let i = 0; i < nu; i++) { const a = (jm * W + i) * 3, b = a + 3; uL += Math.hypot(G[b] - G[a], G[b + 1] - G[a + 1], G[b + 2] - G[a + 2]); }
      for (let j = 0; j < nv; j++) { const a = (j * W + im) * 3, b = a + W * 3; vL += Math.hypot(G[b] - G[a], G[b + 1] - G[a + 1], G[b + 2] - G[a + 2]); }
    }
    const NN = new Float32Array(W * H * 3);
    for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
      let i0 = i - 1, i1 = i + 1; if (cu) { if (i0 < 0) i0 = nu - 1; if (i1 > nu) i1 = 1; } else { if (i0 < 0) i0 = 0; if (i1 > nu) i1 = nu; }
      const j0 = Math.max(0, j - 1), j1 = Math.min(nv, j + 1);
      const a = (j * W + i0) * 3, b = (j * W + i1) * 3, c = (j0 * W + i) * 3, d = (j1 * W + i) * 3;
      const ux = G[b] - G[a], uy = G[b + 1] - G[a + 1], uz = G[b + 2] - G[a + 2], vx = G[d] - G[c], vy = G[d + 1] - G[c + 1], vz = G[d + 2] - G[c + 2];
      let nx = vy * uz - vz * uy, ny = vz * ux - vx * uz, nz = vx * uy - vy * ux, l = Math.hypot(nx, ny, nz);
      const k = (j * W + i) * 3;
      if (l < 1e-9) { nx = G[k] - cx; ny = G[k + 1] - cy; nz = G[k + 2] - cz; l = Math.hypot(nx, ny, nz) || 1; if (flip) l = -l; }
      if (flip) l = -l; NN[k] = nx / l; NN[k + 1] = ny / l; NN[k + 2] = nz / l;
    }
    const th = opt.thick || 0;
    const emitGrid = (off, inv) => {
      const base = this.P.length / 3;
      for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
        const k = (j * W + i) * 3, s = inv ? -1 : 1;
        this._emit(G[k] - NN[k] * off, G[k + 1] - NN[k + 1] * off, G[k + 2] - NN[k + 2] * off, NN[k] * s, NN[k + 1] * s, NN[k + 2] * s, i / nu * uL, j / nv * vL);
      }
      const f = flip !== inv;
      for (let j = 0; j < nv; j++) for (let i = 0; i < nu; i++) {
        const a = base + j * W + i, b = a + W, c = a + 1, d = b + 1;
        if (f) this.I.push(a, c, b, c, d, b); else this.I.push(a, b, c, c, b, d);
      }
      return base;
    };
    if (opt.flat) {
      for (let j = 0; j < nv; j++) for (let i = 0; i < nu; i++) {
        const ia = (j * W + i) * 3, ib = ia + W * 3, ic = ia + 3, id = ib + 3;
        const ux = G[ic] - G[ia], uy = G[ic + 1] - G[ia + 1], uz = G[ic + 2] - G[ia + 2], vx = G[ib] - G[ia], vy = G[ib + 1] - G[ia + 1], vz = G[ib + 2] - G[ia + 2];
        let nx = vy * uz - vz * uy, ny = vz * ux - vx * uz, nz = vx * uy - vy * ux, l = Math.hypot(nx, ny, nz);
        if (l < 1e-12) { // degenerate (triangle): use other corner
          const wx = G[id] - G[ib], wy = G[id + 1] - G[ib + 1], wz = G[id + 2] - G[ib + 2];
          nx = vy * wz - vz * wy; ny = vz * wx - vx * wz; nz = vx * wy - vy * wx; l = Math.hypot(nx, ny, nz) || 1;
        }
        if (flip) l = -l; nx /= l; ny /= l; nz /= l;
        const a = this._emit(G[ia], G[ia + 1], G[ia + 2], nx, ny, nz, i / nu * uL, j / nv * vL), b = this._emit(G[ib], G[ib + 1], G[ib + 2], nx, ny, nz, i / nu * uL, (j + 1) / nv * vL),
          c = this._emit(G[ic], G[ic + 1], G[ic + 2], nx, ny, nz, (i + 1) / nu * uL, j / nv * vL), d = this._emit(G[id], G[id + 1], G[id + 2], nx, ny, nz, (i + 1) / nu * uL, (j + 1) / nv * vL);
        if (flip) this.I.push(a, c, b, c, d, b); else this.I.push(a, b, c, c, b, d);
      }
    } else {
      emitGrid(0, false);
      if (th) {
        emitGrid(th, true);
        // rims
        const rim = (idx, nrm) => { // idx: list of grid indices along edge, nrm(k)->neighbor interior index
          const base = this.P.length / 3, n = idx.length;
          for (let q = 0; q < n; q++) {
            const k = idx[q] * 3, m = nrm(q) * 3; let nx = G[k] - G[m], ny = G[k + 1] - G[m + 1], nz = G[k + 2] - G[m + 2]; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
            this._emit(G[k], G[k + 1], G[k + 2], nx, ny, nz, q / n * uL, 0);
            this._emit(G[k] - NN[k] * th, G[k + 1] - NN[k + 1] * th, G[k + 2] - NN[k + 2] * th, nx, ny, nz, q / n * uL, th);
          }
          for (let q = 0; q < n - 1; q++) { const a = base + q * 2; this.I.push(a, a + 1, a + 2, a + 2, a + 1, a + 3, a, a + 2, a + 1, a + 2, a + 3, a + 1); }
        };
        const r0 = [], r1 = [], c0 = [], c1 = [];
        for (let i = 0; i < W; i++) { r0.push(i); r1.push(nv * W + i); }
        for (let j = 0; j < H; j++) { c0.push(j * W); c1.push(j * W + nu); }
        if (!opt.cap0) rim(r0, q => W + q); if (!opt.cap1) rim(r1, q => (nv - 1) * W + q);
        if (!cu) { rim(c0, q => q * W + 1); rim(c1, q => q * W + nu - 1); }
      }
    }
    if (cu && (opt.cap0 || opt.cap1)) {
      const cap = (j, up) => {
        let ax = 0, ay = 0, az = 0; for (let i = 0; i < nu; i++) { const k = (j * W + i) * 3; ax += G[k]; ay += G[k + 1]; az += G[k + 2]; } ax /= nu; ay /= nu; az /= nu;
        let nx = 0, ny = 0, nz = 0; // newell
        for (let i = 0; i < nu; i++) { const k = (j * W + i) * 3, m = (j * W + (i + 1) % nu) * 3; nx += (G[k + 1] - G[m + 1]) * (G[k + 2] + G[m + 2]); ny += (G[k + 2] - G[m + 2]) * (G[k] + G[m]); nz += (G[k] - G[m]) * (G[k + 1] + G[m + 1]); }
        let l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
        // orient: away from the neighbouring ring
        const jn = j === 0 ? 1 : nv - 1, kk = (jn * W) * 3, k0 = (j * W) * 3; const dx = G[k0] - G[kk], dy = G[k0 + 1] - G[kk + 1], dz = G[k0 + 2] - G[kk + 2];
        let s = 1; if (nx * dx + ny * dy + nz * dz < 0) { nx = -nx; ny = -ny; nz = -nz; s = -1; }
        const c = this._emit(ax, ay, az, nx, ny, nz, 0, 0), b0 = this.P.length / 3;
        for (let i = 0; i < nu; i++) { const k = (j * W + i) * 3; this._emit(G[k], G[k + 1], G[k + 2], nx, ny, nz, G[k] - ax, G[k + 2] - az); }
        for (let i = 0; i < nu; i++) { const a = b0 + i, b = b0 + (i + 1) % nu; if (s > 0) this.I.push(c, a, b); else this.I.push(c, b, a); }
      };
      if (opt.cap0) cap(0); if (opt.cap1) cap(nv);
    }
    return this;
  }
  // rings: [{y,rx,rz,rb,x,z,sq}] ; opt: seg, sub, arc:[a0,a1] (radians, 0=+X, PI/2=+Z), cap0, cap1, thick, flat, uv
  loft(rings, opt) {
    opt = opt || {}; const seg = opt.seg || 12, sub = opt.sub || 3, nr = rings.length;
    const R = rings.map(r => [r.y, r.rx, r.rz === undefined ? r.rx : r.rz, r.rb === undefined ? (r.rz === undefined ? r.rx : r.rz) : r.rb, r.x || 0, r.z || 0, r.sq || 2]);
    const nv = (nr - 1) * sub, arc = opt.arc, a0 = arc ? arc[0] : 0, a1 = arc ? arc[1] : TAU;
    const o = Object.assign({}, opt, { closeU: !arc });
    const tmp = new Array(7), wr = opt.wr || 0, wra = opt.wra || 3, wry = opt.wry || 30, wo = (this.P.length % 977) * 0.37;
    return this.surf(seg, nv, (u, v) => {
      let f = v * (nr - 1), i = Math.min(nr - 2, Math.floor(f)); f -= i;
      const A = R[Math.max(0, i - 1)], B = R[i], Cq = R[i + 1], D = R[Math.min(nr - 1, i + 2)];
      for (let k = 0; k < 7; k++) tmp[k] = sub === 1 ? lerp(B[k], Cq[k], f) : catmull(A[k], B[k], Cq[k], D[k], f);
      const a = a0 + (a1 - a0) * u, c = Math.cos(a), s = Math.sin(a), e = 2 / Math.max(0.5, tmp[6]);
      let k = 1; if (wr) { const ww = arc ? a : (u > 0.5 ? TAU - a : a); k = 1 + wr * (vnoise2(ww * wra + wo, tmp[0] * wry + wo) + 0.5 * vnoise2(ww * wra * 2.3 + wo, tmp[0] * wry * 2.1) - 0.75) * 1.4; }
      return [tmp[4] + Math.max(0, tmp[1]) * k * _spow(c, e), tmp[0], tmp[5] + Math.max(0, s >= 0 ? tmp[2] : tmp[3]) * k * _spow(s, e)];
    }, o);
  }
  lathe(prof, seg, opt) { return this.loft(prof.map(p => ({ y: p[1], rx: p[0] })), Object.assign({ seg: seg || 12, sub: 1 }, opt || {})); }
  sphere(r, sy, sz, nu, nv) {
    sy = sy === undefined ? r : sy; sz = sz === undefined ? r : sz;
    return this.surf(nu || 12, nv || 8, (u, v) => { const a = u * TAU, b = (v - 0.5) * PI, cb = Math.cos(b); return [r * Math.cos(a) * cb, sy * Math.sin(b), sz * Math.sin(a) * cb]; }, { closeU: true });
  }
  box(w, h, d, sq) { return this.loft([{ y: 0, rx: w / 2, rz: d / 2, sq: sq || 16 }, { y: h, rx: w / 2, rz: d / 2, sq: sq || 16 }], { seg: 8, sub: 1, cap0: true, cap1: true }); }
  // sweep a round (or flat) section along a path. rad: number | fn(t)
  tube(pts, rad, opt) {
    opt = opt || {}; const seg = opt.seg || 7, sub = opt.sub || 3, n = pts.length, nv = opt.sub === 1 ? n - 1 : (n - 1) * sub;
    const P = [], rf = typeof rad === 'function' ? rad : () => rad, flat = opt.flatten || 1;
    for (let j = 0; j <= nv; j++) {
      let f = j / nv * (n - 1), i = Math.min(n - 2, Math.floor(f)); f -= i;
      const A = pts[Math.max(0, i - 1)], B = pts[i], Cq = pts[i + 1], D = pts[Math.min(n - 1, i + 2)];
      P.push(new THREE.Vector3(catmull(A[0], B[0], Cq[0], D[0], f), catmull(A[1], B[1], Cq[1], D[1], f), catmull(A[2], B[2], Cq[2], D[2], f)));
    }
    const T = P.map((p, j) => new THREE.Vector3().subVectors(P[Math.min(nv, j + 1)], P[Math.max(0, j - 1)]).normalize());
    const U = [], V = []; let u0 = new THREE.Vector3(1, 0, 0); if (Math.abs(T[0].x) > 0.9) u0.set(0, 0, 1);
    if (opt.up) u0.set(opt.up[0], opt.up[1], opt.up[2]);
    u0.addScaledVector(T[0], -u0.dot(T[0])).normalize();
    for (let j = 0; j <= nv; j++) { if (j > 0) { u0 = u0.clone().addScaledVector(T[j], -u0.dot(T[j])).normalize(); } U.push(u0.clone()); V.push(new THREE.Vector3().crossVectors(T[j], u0)); }
    return this.surf(seg, nv, (u, v) => {
      const j = Math.round(v * nv), a = u * TAU, r = rf(j / nv), c = Math.cos(a) * r, s = Math.sin(a) * r * flat, p = P[j], uu = U[j], vv = V[j];
      return [p.x + uu.x * c + vv.x * s, p.y + uu.y * c + vv.y * s, p.z + uu.z * c + vv.z * s];
    }, { closeU: true, cap0: opt.cap !== false, cap1: opt.cap !== false, flat: opt.flat });
  }
  // typed arrays
  finish() {
    return { P: new Float32Array(this.P), N: new Float32Array(this.N), C: new Float32Array(this.Cc), UV: new Float32Array(this.UV), M: new Float32Array(this.M),
      BA: new Uint8Array(this.BA), BB: new Uint8Array(this.BB), W: new Float32Array(this.W), I: this.P.length / 3 > 65535 ? new Uint32Array(this.I) : new Uint16Array(this.I) };
  }
  toGeometry() {
    const d = this.finish(), g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(d.P, 3)); g.setAttribute('normal', new THREE.BufferAttribute(d.N, 3));
    g.setAttribute('color', new THREE.BufferAttribute(d.C, 3)); g.setAttribute('aUv', new THREE.BufferAttribute(d.UV, 2));
    g.setAttribute('aMat', new THREE.BufferAttribute(d.M, 4)); g.setAttribute('aRest', new THREE.BufferAttribute(d.P.slice(), 3));
    g.setIndex(new THREE.BufferAttribute(d.I, 1)); g.computeBoundingSphere(); g.computeBoundingBox();
    return g;
  }
}
// weight helpers (bind pose: limbs hang along -Y)
const jb = (a, b, y0, range) => (x, y, z) => [a, b, 1 - smooth(y0 - range, y0 + range, y)];
function chainY(list, range) { // [[name,yTop],...] from top to bottom; each bone owns below its y until next
  return (x, y, z) => {
    for (let i = 0; i < list.length - 1; i++) { const yb = list[i + 1][1]; if (y > yb - range) return [list[i][0], list[i + 1][0], 1 - smooth(yb - range, yb + range, y)]; }
    const l = list[list.length - 1][0]; return [l, l, 0];
  };
}

/* ---------- surface material (all hand-built geometry) ---------- */
const SURF_VPARS = `
attribute vec4 aMat; attribute vec3 aRest; attribute vec2 aUv;
varying vec4 vMat; varying vec3 vRest; varying vec2 vUvS;
`;
const SURF_FPARS = `
uniform float uDissolve; uniform float uDisH; uniform vec3 uDisCol; uniform vec3 uFlash; uniform float uDim; uniform float uGlow;
varying vec4 vMat; varying vec3 vRest; varying vec2 vUvS;
float lfRough, lfMetal, lfH; vec3 lfEmis;
float h12(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float h13(vec3 p3){ p3 = fract(p3 * .1031); p3 += dot(p3, p3.zyx + 31.32); return fract((p3.x + p3.y) * p3.z); }
float n2(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(h12(i),h12(i+vec2(1.,0.)),f.x),mix(h12(i+vec2(0.,1.)),h12(i+vec2(1.,1.)),f.x),f.y); }
float n3(vec3 p){ vec3 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(mix(h13(i),h13(i+vec3(1.,0.,0.)),f.x),mix(h13(i+vec3(0.,1.,0.)),h13(i+vec3(1.,1.,0.)),f.x),f.y),
             mix(mix(h13(i+vec3(0.,0.,1.)),h13(i+vec3(1.,0.,1.)),f.x),mix(h13(i+vec3(0.,1.,1.)),h13(i+vec3(1.,1.,1.)),f.x),f.y),f.z); }
float fb3(vec3 p){ return .5*n3(p)+.25*n3(p*2.03+7.1)+.125*n3(p*4.1+3.3); }
`;
const SURF_FMAIN = `
{
  float ty = vMat.z; vec3 col = diffuseColor.rgb; float rough = vMat.x, metal = vMat.y, h = 0.; vec3 em = vec3(0.);
  vec2 uv = vUvS; vec3 rp = vRest;
  float px = max(fwidth(uv.x), fwidth(uv.y));
  float big = fb3(rp*9.), fine = n3(rp*70.);
  float dz = (rp.y/uDisH)*.72 + n3(rp*17.)*.28;
  if (uDissolve > 0.) { float th = uDissolve*1.06; if (dz < th) discard; em += uDisCol * smoothstep(.07, 0., dz-th) * 7.; }
  float mudK = 1.;
  if (ty < .5) { col *= .82 + .36*big; h = fine*.0006; }
  else if (ty < 1.5) {
    float f = smoothstep(.0016,.0006,px); float w = sin(uv.x*1570.)*sin(uv.y*1570.);
    float fold = n3(rp*vec3(26.,5.,26.));
    h = w*.0004*f + big*.002 + fold*.006; col *= (.72 + .42*big) * (1. + .14*w*f) * (.8+.4*fold);
  } else if (ty < 2.5) {
    float q = abs(sin(uv.x*98. + 1.5*n3(rp*vec3(3.,9.,3.)))); float pil = pow(q,.7); h = pil*.0034 + fine*.0006 + n3(rp*vec3(30.,6.,30.))*.004;
    col *= (.78+.22*pil) * (.74+.44*big); col *= 1. - .3*smoothstep(.12,.0,q);
    float st = smoothstep(.75,1., sin(uv.y*900.)) * smoothstep(.2,.05,q); col *= 1.+.6*st;
  } else if (ty < 3.5) {
    float f = smoothstep(.0036,.0012,px);
    vec2 g = uv*349.; float row = floor(g.y/3.14159); g.x += mod(row,2.)*1.5708;
    float r = abs(sin(g.x))*abs(sin(g.y));
    h = r*.0024*f; col *= mix(.72, .3+1.0*r, f) * (.75+.5*big);
    float gl = step(.9, h13(floor(rp*240.))); rough = mix(rough, .22, gl*.7);
    float rust = smoothstep(.5,.75, fb3(rp*13.+1.7)); col = mix(col, vec3(.07,.036,.02), rust*.5); metal *= 1.-rust*.5;
  } else if (ty < 4.5) {
    float cr = abs(n3(rp*vec3(60.,24.,60.))-.5)*2.; cr = smoothstep(.0,.22,cr); float fold = n3(rp*vec3(18.,7.,18.));
    h = fine*.0008 + cr*.0007 + fold*.004; col *= (.72+.4*big)*(.9+.1*cr)*(.85+.3*fold); rough -= .12*fine;
  } else if (ty < 5.5) {
    float sc = n3(rp*vec3(34.,260.,34.)), dent = n3(rp*27.);
    h = dent*.0028 + sc*.0004;
    float rust = smoothstep(.46,.66, fb3(rp*17.+3.) + (vMat.w-1.)*.2 + vMat.w*.12*(1.-smoothstep(.2,1.3,rp.y)));
    col *= .74+.42*sc; rough += (sc-.5)*.3 + (dent-.5)*.2;
    col = mix(col, vec3(.085,.042,.022)*(.5+.9*fine), rust*.88); metal *= 1.-rust*.85; rough = mix(rough, .93, rust);
    mudK = .7;
  } else if (ty < 6.5) {
    float ff = smoothstep(.004,.0012,px); float s = mix(.5, n3(rp*vec3(210.,26.,210.)), ff), s2 = n3(rp*vec3(64.,11.,64.)+9.), s3 = n3(rp*19.);
    h = s*.003*ff+s2*.006+s3*.012; col *= (.36 + .5*s2 + .4*s*s) * (.55+.9*s3);
  } else if (ty < 7.5) {
    float gr = n2(vec2(uv.x*260., uv.y*9.)), g2 = n2(vec2(uv.x*60., uv.y*3.)+4.);
    h = gr*.0016; col *= .6+.34*gr+.26*g2;
  } else if (ty < 8.5) {
    float s = fb3(rp*5.), s2 = fb3(rp*23.+5.), s3 = n3(rp*90.);
    h = s*.03 + s2*.01 + s3*.0015; col *= .42+.6*s2+.25*s;
    float lich = smoothstep(.5,.6, fb3(rp*3.7+11.)); col = mix(col, vec3(.035,.05,.025), lich*.7);
    float l2 = smoothstep(.64,.7, fb3(rp*8.1+31.)); col = mix(col, vec3(.2,.2,.17), l2*.4);
    mudK = .4;
  } else if (ty < 9.5) {
    float rd = abs(n2(vec2(uv.x*80., uv.y*13.))-.5)*2., s2 = fb3(rp*14.);
    h = rd*.008 + s2*.008; col *= .45+.5*rd+.4*s2;
  } else if (ty < 10.5) {
    em += col * vMat.w * uGlow; col *= .05; mudK = 0.;
  } else {
    float gr = n2(vec2(uv.x*150., uv.y*18.)); h = gr*.001; col *= .7+.3*big+.12*gr;
    float st = smoothstep(.5,.7,fb3(rp*11.)); col = mix(col, col*vec3(.5,.42,.3), st*.7);
  }
  if (mudK > 0. && ty < 9.5) {
    float mud = vMat.w * mudK * (1.-smoothstep(.02,.62, rp.y + (big-.45)*.5));
    col = mix(col, vec3(.04,.032,.024)*(.7+.6*fine), mud*.8); rough = mix(rough,.95,mud); metal *= 1.-mud*.9;
  }
  diffuseColor.rgb = col * uDim; lfRough = clamp(rough,.05,1.); lfMetal = clamp(metal,0.,1.); lfH = h; lfEmis = em + uFlash;
}
`;
const SURF_FNORMAL = `
{
  vec3 dp1 = dFdx(-vViewPosition), dp2 = dFdy(-vViewPosition); float dhx = dFdx(lfH), dhy = dFdy(lfH);
  vec3 r1 = cross(dp2, normal), r2 = cross(normal, dp1); float det = dot(dp1, r1);
  if (abs(det) > 1e-12) { vec3 gr = sign(det) * (dhx*r1 + dhy*r2); normal = normalize(abs(det)*normal - clamp(gr, -abs(det)*2.5, abs(det)*2.5)); }
}
`;
function makeSurfMat(opt) {
  const m = new THREE.MeshStandardMaterial(Object.assign({ vertexColors: true, side: THREE.DoubleSide, roughness: 1, metalness: 0, envMapIntensity: 1 }, opt || {}));
  m.userData.u = { uDissolve: { value: 0 }, uDisH: { value: 1.9 }, uDisCol: { value: new THREE.Color(1, 0.45, 0.1) }, uFlash: { value: new THREE.Color(0, 0, 0) }, uDim: { value: 1 }, uGlow: { value: 1 } };
  m.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, m.userData.u);
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\n' + SURF_VPARS)
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvMat=aMat; vRest=aRest; vUvS=aUv;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\n' + SURF_FPARS)
      .replace('#include <color_fragment>', '#include <color_fragment>\n' + SURF_FMAIN)
      .replace('#include <roughnessmap_fragment>', 'float roughnessFactor = lfRough;')
      .replace('#include <metalnessmap_fragment>', 'float metalnessFactor = lfMetal;')
      .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\n' + SURF_FNORMAL)
      .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\ntotalEmissiveRadiance += lfEmis;');
  };
  m.customProgramCacheKey = () => 'lfsurf';
  return m;
}

/* ---------- CPU-skinned figure ---------- */
class Figure {
  constructor(geo, rig) {
    const d = geo.d || geo.finish(); this.rig = rig; this.d = d; this.nv = d.P.length / 3; const nb = rig.n; this.nb = nb;
    this.euler = new Float32Array(nb * 3); this.trans = new Float32Array(nb * 3);
    this.R = new Float32Array(nb * 9); this.Wp = new Float32Array(nb * 3); this.O = new Float32Array(nb * 3);
    this.absR = new Float32Array(nb * 9); for (let i = 0; i < nb; i++) { this.absR[i * 9] = this.absR[i * 9 + 4] = this.absR[i * 9 + 8] = 1; }
    this.free = null; this.hideB = new Uint8Array(nb);
    const g = this.geom = new THREE.BufferGeometry();
    this.pos = new THREE.BufferAttribute(new Float32Array(d.P), 3); this.pos.setUsage(THREE.DynamicDrawUsage);
    this.nrm = new THREE.BufferAttribute(new Float32Array(d.N), 3); this.nrm.setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('position', this.pos); g.setAttribute('normal', this.nrm);
    g.setAttribute('color', new THREE.BufferAttribute(d.C, 3)); g.setAttribute('aUv', new THREE.BufferAttribute(d.UV, 2));
    g.setAttribute('aMat', new THREE.BufferAttribute(d.M, 4)); g.setAttribute('aRest', new THREE.BufferAttribute(d.P, 3));
    g.setIndex(new THREE.BufferAttribute(d.I, 1));
    let maxY = 0, maxR = 0; for (let i = 0; i < this.nv; i++) { maxY = Math.max(maxY, d.P[i * 3 + 1]); maxR = Math.max(maxR, Math.hypot(d.P[i * 3], d.P[i * 3 + 2])); }
    this.height = maxY; g.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, maxY * 0.5, 0), Math.max(maxY, maxR) * 1.6 + 1.0);
    this.mat = makeSurfMat(); this.u = this.mat.userData.u; this.u.uDisH.value = maxY;
    this.mesh = new THREE.Mesh(g, this.mat); this.mesh.castShadow = true; this.mesh.receiveShadow = true;
    this.solve(); this.skin();
  }
  bi(n) { return this.rig.names[n]; }
  set(name, x, y, z) { const i = this.rig.names[name] * 3; this.euler[i] = x; this.euler[i + 1] = y; this.euler[i + 2] = z; }
  solve() {
    const rig = this.rig, nb = this.nb, E = this.euler, Tt = this.trans, R = this.R, Wp = this.Wp, O = this.O, H = rig.head, par = rig.parent;
    for (let i = 0; i < nb; i++) {
      const e = i * 3, r = i * 9, p = par[i];
      if (this.free && this.free[i]) { const f = this.free[i]; for (let k = 0; k < 9; k++) R[r + k] = f.R[k]; Wp[e] = f.p[0]; Wp[e + 1] = f.p[1]; Wp[e + 2] = f.p[2]; }
      else {
        const cx = Math.cos(E[e]), sx = Math.sin(E[e]), cy = Math.cos(E[e + 1]), sy = Math.sin(E[e + 1]), cz = Math.cos(E[e + 2]), sz = Math.sin(E[e + 2]);
        const l0 = cz * cy, l1 = -sz, l2 = cz * sy, l3 = cx * sz * cy + sx * sy, l4 = cx * cz, l5 = cx * sz * sy - sx * cy, l6 = sx * sz * cy - cx * sy, l7 = sx * cz, l8 = sx * sz * sy + cx * cy;
        if (p < 0) { R[r] = l0; R[r + 1] = l1; R[r + 2] = l2; R[r + 3] = l3; R[r + 4] = l4; R[r + 5] = l5; R[r + 6] = l6; R[r + 7] = l7; R[r + 8] = l8; Wp[e] = H[e] + Tt[e]; Wp[e + 1] = H[e + 1] + Tt[e + 1]; Wp[e + 2] = H[e + 2] + Tt[e + 2]; }
        else {
          const q = p * 9, pe = p * 3, a0 = R[q], a1 = R[q + 1], a2 = R[q + 2], a3 = R[q + 3], a4 = R[q + 4], a5 = R[q + 5], a6 = R[q + 6], a7 = R[q + 7], a8 = R[q + 8];
          const dx = H[e] - H[pe] + Tt[e], dy = H[e + 1] - H[pe + 1] + Tt[e + 1], dz = H[e + 2] - H[pe + 2] + Tt[e + 2];
          Wp[e] = Wp[pe] + a0 * dx + a1 * dy + a2 * dz; Wp[e + 1] = Wp[pe + 1] + a3 * dx + a4 * dy + a5 * dz; Wp[e + 2] = Wp[pe + 2] + a6 * dx + a7 * dy + a8 * dz;
          if (rig.abs[i]) { const A = this.absR; for (let k = 0; k < 9; k++) R[r + k] = A[r + k]; }
          else {
            R[r] = a0 * l0 + a1 * l3 + a2 * l6; R[r + 1] = a0 * l1 + a1 * l4 + a2 * l7; R[r + 2] = a0 * l2 + a1 * l5 + a2 * l8;
            R[r + 3] = a3 * l0 + a4 * l3 + a5 * l6; R[r + 4] = a3 * l1 + a4 * l4 + a5 * l7; R[r + 5] = a3 * l2 + a4 * l5 + a5 * l8;
            R[r + 6] = a6 * l0 + a7 * l3 + a8 * l6; R[r + 7] = a6 * l1 + a7 * l4 + a8 * l7; R[r + 8] = a6 * l2 + a7 * l5 + a8 * l8;
          }
        }
      }
      if (this.hideB[i]) { for (let k = 0; k < 9; k++) R[r + k] = 0; }
      const hx = H[e], hy = H[e + 1], hz = H[e + 2];
      O[e] = Wp[e] - (R[r] * hx + R[r + 1] * hy + R[r + 2] * hz); O[e + 1] = Wp[e + 1] - (R[r + 3] * hx + R[r + 4] * hy + R[r + 5] * hz); O[e + 2] = Wp[e + 2] - (R[r + 6] * hx + R[r + 7] * hy + R[r + 8] * hz);
    }
  }
  skin() {
    const d = this.d, P = d.P, N = d.N, BA = d.BA, BB = d.BB, W = d.W, R = this.R, O = this.O, op = this.pos.array, on = this.nrm.array, nv = this.nv;
    for (let i = 0; i < nv; i++) {
      const k = i * 3, x = P[k], y = P[k + 1], z = P[k + 2], nx = N[k], ny = N[k + 1], nz = N[k + 2];
      let a = BA[i] * 9, o = BA[i] * 3;
      let px = R[a] * x + R[a + 1] * y + R[a + 2] * z + O[o], py = R[a + 3] * x + R[a + 4] * y + R[a + 5] * z + O[o + 1], pz = R[a + 6] * x + R[a + 7] * y + R[a + 8] * z + O[o + 2];
      let qx = R[a] * nx + R[a + 1] * ny + R[a + 2] * nz, qy = R[a + 3] * nx + R[a + 4] * ny + R[a + 5] * nz, qz = R[a + 6] * nx + R[a + 7] * ny + R[a + 8] * nz;
      const w = W[i];
      if (w > 0) {
        a = BB[i] * 9; o = BB[i] * 3; const u = 1 - w;
        px = px * u + (R[a] * x + R[a + 1] * y + R[a + 2] * z + O[o]) * w; py = py * u + (R[a + 3] * x + R[a + 4] * y + R[a + 5] * z + O[o + 1]) * w; pz = pz * u + (R[a + 6] * x + R[a + 7] * y + R[a + 8] * z + O[o + 2]) * w;
        qx = qx * u + (R[a] * nx + R[a + 1] * ny + R[a + 2] * nz) * w; qy = qy * u + (R[a + 3] * nx + R[a + 4] * ny + R[a + 5] * nz) * w; qz = qz * u + (R[a + 6] * nx + R[a + 7] * ny + R[a + 8] * nz) * w;
      }
      op[k] = px; op[k + 1] = py; op[k + 2] = pz; on[k] = qx; on[k + 1] = qy; on[k + 2] = qz;
    }
    this.pos.needsUpdate = true; this.nrm.needsUpdate = true;
  }
  // model-space position of a rest-space point rigidly attached to a bone
  bonePoint(b, x, y, z, out) {
    const a = b * 9, o = b * 3, R = this.R, O = this.O;
    out.set(R[a] * x + R[a + 1] * y + R[a + 2] * z + O[o], R[a + 3] * x + R[a + 4] * y + R[a + 5] * z + O[o + 1], R[a + 6] * x + R[a + 7] * y + R[a + 8] * z + O[o + 2]);
    return out;
  }
  worldPoint(b, x, y, z, out) { this.bonePoint(b, x, y, z, out); return out.applyMatrix4(this.mesh.matrixWorld); }
  // break the figure apart: every bone becomes a free rigid body (model space)
  shatter(rng, power, dirx, dirz) {
    this.free = [];
    for (let i = 0; i < this.nb; i++) {
      const r = i * 9, e = i * 3; const ax = rng() - 0.5, ay = rng() - 0.5, az = rng() - 0.5, al = Math.hypot(ax, ay, az) || 1;
      this.free.push({ R: Array.from(this.R.subarray(r, r + 9)), p: [this.Wp[e], this.Wp[e + 1], this.Wp[e + 2]],
        v: [(rng() - 0.5) * power + (dirx || 0) * power * 0.6, rng() * power * 0.9 + 0.4, (rng() - 0.5) * power + (dirz || 0) * power * 0.6],
        ax: [ax / al, ay / al, az / al], w: (rng() * 4 + 1.5) * (power > 1.5 ? 1 : 0.6), rest: false, fl: 0.06 + rng() * 0.1 });
    }
  }
  stepFree(dt) {
    if (!this.free) return;
    for (const f of this.free) {
      if (f.rest) continue;
      f.v[1] -= 12 * dt; f.p[0] += f.v[0] * dt; f.p[1] += f.v[1] * dt; f.p[2] += f.v[2] * dt;
      if (f.p[1] < f.fl) { f.p[1] = f.fl; if (Math.abs(f.v[1]) < 1.2) { f.rest = true; continue; } f.v[1] *= -0.28; f.v[0] *= 0.55; f.v[2] *= 0.55; f.w *= 0.5; }
      const a = f.w * dt, c = Math.cos(a), s = Math.sin(a), t = 1 - c, x = f.ax[0], y = f.ax[1], z = f.ax[2], R = f.R;
      const m0 = t * x * x + c, m1 = t * x * y - s * z, m2 = t * x * z + s * y, m3 = t * x * y + s * z, m4 = t * y * y + c, m5 = t * y * z - s * x, m6 = t * x * z - s * y, m7 = t * y * z + s * x, m8 = t * z * z + c;
      const n = [m0 * R[0] + m1 * R[3] + m2 * R[6], m0 * R[1] + m1 * R[4] + m2 * R[7], m0 * R[2] + m1 * R[5] + m2 * R[8], m3 * R[0] + m4 * R[3] + m5 * R[6], m3 * R[1] + m4 * R[4] + m5 * R[7], m3 * R[2] + m4 * R[5] + m5 * R[8], m6 * R[0] + m7 * R[3] + m8 * R[6], m6 * R[1] + m7 * R[4] + m8 * R[7], m6 * R[2] + m7 * R[5] + m8 * R[8]];
      f.R = n;
    }
  }
  dispose() { this.geom.dispose(); this.mat.dispose(); }
            }
