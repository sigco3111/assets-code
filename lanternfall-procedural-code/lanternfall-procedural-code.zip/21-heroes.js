/* LANTERNFALL - the six heroes: models + animation styles */
LF.HEROES = {};
const DOWN_POSE = { hips: [0.35, 0, 0], spine: [0.3, 0, 0], chest: [0.28, 0, 0], neck: [0.3, 0, 0], head: [0.35, 0, 0.1], lThigh: [-1.5, 0, 0.1], lShin: [1.65, 0, 0], lFoot: [-0.2, 0, 0], rThigh: [-0.1, 0, -0.1], rShin: [1.75, 0, 0], rFoot: [0.9, 0, 0],
  lUp: [-0.5, 0, 0.15], lFore: [-0.7, 0, 0], rUp: [-0.2, 0, -0.2], rFore: [-0.5, 0, 0] };
// lantern on a hooked pole strapped to the back (for whoever carries the party light)
function lanternBack(g, P) {
  g.bone('back'); g.mat(COL.wood, 0.85, 0, T_WOOD, 0.8);
  g.tube([[-0.12, 0.95, -0.17], [-0.13, 1.6, -0.2], [-0.14, 2.35, -0.22]], 0.017, { seg: 6, sub: 2 });
  g.mat(COL.iron, 0.55, 0.9, T_PLATE, 0.3);
  g.tube([[-0.14, 2.3, -0.22], [-0.14, 2.46, -0.2], [-0.14, 2.54, -0.08], [-0.14, 2.5, 0.04], [-0.14, 2.43, 0.07]], 0.009, { seg: 5, sub: 4 });
  g.mat(COL.leather, 0.7, 0, T_LEATHER, 0.4); g.bone('chest');
  g.tube([[-0.13, 1.47, -0.14], [0.02, 1.36, 0.135], [0.17, 1.12, 0.1], [0.12, 1.04, -0.13], [-0.13, 1.47, -0.14]], 0.012, { seg: 5, sub: 4, flatten: 0.4 });
  HW.lanternBody(g, 'lanB', -0.14, 2.43, 0.07, 1);
}
function finishHero(g, rig, P, opt, fx) {
  if (opt && opt.lantern && !fx.lan) { lanternBack(g, P); fx.lan = ['lanB', -0.14, 2.43 - 0.26, 0.07]; }
  const fig = new Figure(g, rig); fig.P = P; fig.fx = {};
  for (const k in fx) fig.fx[k] = [rig.names[fx[k][0]], fx[k][1], fx[k][2], fx[k][3]];
  return fig;
}
const RB = { hips: [0.06, -0.5, 0], spine: [0.08, -0.08, 0], chest: [0.06, 0, 0], head: [0, 0.55, 0], lThigh: [-0.48, 0.1, 0.08], lShin: [0.5, 0, 0], lFoot: [0, 0, 0], rThigh: [0.2, -0.3, -0.1], rShin: [0.3, 0, 0], rFoot: [-0.4, 0, 0] };
function rdy(over) { const o = {}; for (const k in RB) o[k] = RB[k]; for (const k in over) o[k] = over[k]; return o; }

/* ---------- WARDEN: kettle helm, mail, tabard, heater shield, arming sword ---------- */
(function () {
  const P = { sh: 0.205, hp: 0.097 };
  function build(opt) {
    const rig = humanRig(P), g = new Geo(rig), H = HW;
    for (const s of [1, -1]) {
      g.mat(COL.woolBrown, 0.95, 0, T_CLOTH, 1.6); H.leg(g, P, s, { y0: 0.3, y1: 0.99, k: 1.06, wr: 0.05 });
      g.mat(COL.leather, 0.74, 0, T_LEATHER, 1.8); H.boot(g, P, s, { top: 0.36 });
      H.poleyn(g, P, s); H.greave(g, P, s);
    }
    g.mat(COL.buff, 0.95, 0, T_QUILT, 1.3); H.skirt(g, { y0: 1.04, y1: 0.6, grow: 0.012, flare: 0.06, thick: 0.012 });
    g.mat(COL.mail, 0.5, 0.85, T_MAIL, 0.8); H.torso(g, { grow: 0.014, y0: 0.99, y1: 1.5, wr: 0.02 }); H.skirt(g, { y0: 1.03, y1: 0.67, grow: 0.022, flare: 0.05, thick: 0.007, wave: 0.025, folds: 7 });
    for (const s of [1, -1]) {
      g.mat(COL.mail, 0.5, 0.85, T_MAIL, 0.5); H.arm(g, P, s, { y0: 1.1, y1: 1.5, grow: 0.016, k: 1.14, wr: 0.05 });
      g.mat(COL.buff, 0.95, 0, T_QUILT, 0.6); H.arm(g, P, s, { y0: 0.9, y1: 1.13, grow: 0.01, k: 1.12, cap1: false });
      H.vambrace(g, P, s); H.couter(g, P, s); H.spaulder(g, P, s, { s: 1.12 });
      g.mat(COL.leatherDk, 0.7, 0, T_LEATHER, 0.5); H.fist(g, P, s);
    }
    const half = (a0, a1, col) => { g.mat(col, 0.95, 0, T_CLOTH, 1.2); H.torso(g, { grow: 0.027, y0: 1.0, y1: 1.47, arc: [a0, a1], seg: 10, thick: 0.004, wr: 0.03, wra: 5, wry: 16, blouse: 0.014 }); };
    half(-PI / 2, PI / 2, COL.murrey); half(PI / 2, PI * 1.5, COL.bone);
    const panel = (a0, a1, col) => { g.mat(col, 0.95, 0, T_CLOTH, 1.7); H.skirt(g, { y0: 1.04, y1: 0.64, grow: 0.03, flare: 0.058, arc: [a0, a1], seg: 8, thick: 0.005, wave: 0.035, folds: 8 }); };
    panel(PI / 2 - 0.95, PI / 2, COL.murrey); panel(PI / 2, PI / 2 + 0.95, COL.bone); panel(-PI / 2, -PI / 2 + 0.95, COL.murrey); panel(-PI / 2 - 0.95, -PI / 2, COL.bone);
    H.belt(g, { grow: 0.036 }); H.pouch(g, -0.16, 1.0, -0.1, 1); H.pouch(g, -0.2, 1.0, 0.03, 0.8, COL.leatherTan); H.scabbard(g, P, 1);
    H.strap(g, { side: -1, grow: 0.034 });
    H.head(g, {}); H.coif(g, P); H.kettle(g);
    H.cloak(g, P, { hem: 0.56, wrap: 0.22, col: COL.wool, flare: 0.07 }); H.cowl(g, P, { col: COL.wool, r: 0.03, y: 1.475, wide: 0.03 });
    const sw = H.sword(g, P, -1, { len: 0.82 }); H.shield(g, P, 1);
    return finishHero(g, rig, P, opt, { tip: ['wR', sw.tip[0], sw.tip[1], sw.tip[2]], base: ['wR', sw.base[0], sw.base[1], sw.base[2]], off: ['lFore', P.sh + 0.2, 1.02, 0] });
  }
  const carry = stance({ lUp: [-0.18, 0, 0.16], lFore: [-0.95, 0.25, 0], rUp: [0.1, 0, -0.12], rFore: [-0.32, 0, 0], rHand: [0.5, 0, 0] });
  const ready = rdy({ hips: [0.06, -0.55, 0], head: [0, 0.6, 0], lUp: [-0.75, 0, 0.3], lFore: [-1.2, 0.3, 0], rUp: [0.45, 0, -0.35], rFore: [-1.5, 0, 0], rHand: [-0.2, 0, 0] });
  const clips = {
    attack: mkClip(0.42, [
      { t: 0.28, e: 'out', b: { hips: [0.0, -0.8, 0], chest: [-0.12, -0.3, 0], rUp: [-2.3, 0, -0.7], rFore: [-1.5, 0, 0], rHand: [-0.5, 0, 0], lUp: [-0.5, 0, 0.5], lFore: [-1.0, 0.3, 0] }, root: [0, -0.02, -0.05] },
      { t: 0.42, e: 'in', b: { hips: [0.12, 0.05, 0], chest: [0.3, 0.5, 0], rUp: [-1.15, 0, 0.5], rFore: [-0.2, 0, 0], rHand: [0.55, 0, 0], lUp: [-0.2, 0, 0.5], lFore: [-1.3, 0.3, 0], lThigh: [-0.85, 0, 0.08], lShin: [0.75, 0, 0], rThigh: [0.4, 0, -0.1], rShin: [0.25, 0, 0] }, root: [0, -0.07, 0.3] },
      { t: 0.6, e: 'out', b: { hips: [0.14, 0.2, 0], chest: [0.36, 0.7, 0], rUp: [-0.35, 0, 0.6], rFore: [-0.35, 0, 0], rHand: [0.7, 0, 0] }, root: [0, -0.08, 0.32] }], ready),
    bash: mkClip(0.45, [
      { t: 0.25, e: 'out', b: { hips: [0.15, -0.3, 0], chest: [0.12, -0.2, 0], lUp: [0.1, 0, 0.35], lFore: [-1.7, 0.3, 0] }, root: [0, -0.1, -0.08] },
      { t: 0.45, e: 'in', b: { hips: [0.2, -0.75, 0], chest: [0.2, -0.25, 0], lUp: [-1.25, 0, 0.1], lFore: [-0.7, 0.3, 0], lThigh: [-0.95, 0, 0.08], lShin: [0.8, 0, 0], rThigh: [0.5, 0, -0.1], rShin: [0.2, 0, 0] }, root: [0, -0.1, 0.45] },
      { t: 0.65, b: { hips: [0.2, -0.7, 0] }, root: [0, -0.1, 0.42] }], ready),
    guard: mkClip(0.3, [
      { t: 0.3, e: 'out', b: { hips: [0.18, -0.7, 0], chest: [0.12, -0.1, 0], lUp: [-1.0, 0, 0.2], lFore: [-1.35, 0.3, 0], rUp: [0.6, 0, -0.5], rFore: [-1.2, 0, 0], lThigh: [-0.7, 0, 0.1], lShin: [0.85, 0, 0], rThigh: [0.3, 0, -0.14], rShin: [0.5, 0, 0] }, root: [0, -0.14, 0] },
      { t: 0.85, b: {}, root: [0, -0.14, 0] }], ready)
  };
  LF.HEROES.warden = { build, style: { carry, ready, readyRoot: -0.05, clips, swingL: 0.15, swingR: 0.6, strideAmp: 0.92, stride: 0.96, gait: { bounce: 0.8, sway: 1.5, lean: 1.3, lift: 0.9 }, downPose: DOWN_POSE } };
})();

/* ---------- REAVER: broad, fur mantle, mail, odd plate, greatsword ---------- */
(function () {
  const P = { sh: 0.228, hp: 0.102 };
  function build(opt) {
    const rig = humanRig(P), g = new Geo(rig), H = HW;
    for (const s of [1, -1]) {
      g.mat(C(0x2c2620), 0.95, 0, T_CLOTH, 1.7); H.leg(g, P, s, { y0: 0.3, y1: 0.99, k: 1.14, wr: 0.06 });
      g.mat(COL.leatherDk, 0.76, 0, T_LEATHER, 2.0); H.boot(g, P, s, { top: 0.42 });
    }
    H.poleyn(g, P, -1, { col: COL.iron }); H.greave(g, P, 1, { col: COL.iron });
    g.mat(C(0x4d4332), 0.95, 0, T_QUILT, 1.4); H.skirt(g, { y0: 1.04, y1: 0.66, grow: 0.018, flare: 0.06, thick: 0.012 });
    g.mat(COL.mail, 0.52, 0.85, T_MAIL, 1.0); H.torso(g, { grow: 0.016, y0: 0.99, y1: 1.5, k: 1.1, kz: 1.12, wr: 0.02 }); H.skirt(g, { y0: 1.03, y1: 0.74, grow: 0.03, flare: 0.045, thick: 0.007, wave: 0.03, folds: 6 });
    for (const s of [1, -1]) {
      g.mat(COL.mail, 0.52, 0.85, T_MAIL, 0.6); H.arm(g, P, s, { y0: 1.12, y1: 1.5, grow: 0.018, k: 1.32, wr: 0.05 });
      g.mat(C(0x4d4332), 0.95, 0, T_QUILT, 0.6); H.arm(g, P, s, { y0: 0.9, y1: 1.15, grow: 0.01, k: 1.26, cap1: false });
      H.vambrace(g, P, s, s > 0 ? {} : { col: COL.leatherDk, metal: 0, ty: T_LEATHER, rough: 0.7 });
      g.mat(COL.leatherDk, 0.7, 0, T_LEATHER, 0.5); H.fist(g, P, s);
    }
    H.spaulder(g, P, 1, { s: 1.42, col: COL.plate }); H.couter(g, P, 1); H.spaulder(g, P, -1, { s: 1.08, col: COL.iron });
    // leather jerkin panel + crossed straps + two belts
    g.mat(COL.leatherDk, 0.72, 0, T_LEATHER, 1.0); H.torso(g, { grow: 0.03, y0: 1.02, y1: 1.4, k: 1.1, kz: 1.12, arc: [PI / 2 - 1.2, PI / 2 + 1.2], seg: 10, thick: 0.006, wr: 0.03 });
    H.strap(g, { side: 1, grow: 0.05, w: 0.02 }); H.strap(g, { side: -1, grow: 0.052, w: 0.02 });
    H.belt(g, { grow: 0.046, w: 0.036 }); H.belt(g, { grow: 0.052, w: 0.02, y: 0.995, col: COL.leather });
    H.pouch(g, 0.18, 0.99, -0.08, 1.1); H.pouch(g, -0.19, 1.0, 0.02, 0.9, COL.leatherTan);
    // hide skirt at the back
    g.mat(COL.fur, 1, 0, T_FUR, 1.3); H.skirt(g, { y0: 1.04, y1: 0.6, grow: 0.04, flare: 0.07, arc: [-PI / 2 - 1.3, -PI / 2 + 1.3], seg: 12, thick: 0.014, wave: 0.05, folds: 5 });
    H.head(g, { beard: 1.0, hair: COL.hair, hairCap: true }); H.skullcap(g); H.furMantle(g, P, { back: 0.34 });
    const sw = H.sword(g, P, -1, { len: 1.24, w: 0.034, grip: 0.3, guard: 0.14 });
    return finishHero(g, rig, P, opt, { tip: ['wR', sw.tip[0], sw.tip[1], sw.tip[2]], base: ['wR', sw.base[0], sw.base[1], sw.base[2]] });
  }
  const carry = stance({ rUp: [-0.38, 0, -0.2], rFore: [-2.1, 0, 0], rHand: [0.3, 0, 0], lUp: [0.05, 0, 0.14], lFore: [-0.3, 0, 0], spine: [0.07, 0, 0] });
  const ready = rdy({ rUp: [-0.15, 0, -0.32], rFore: [-1.5, 0, 0], rHand: [-0.45, 0, 0], lUp: [-0.7, 0, -0.5], lFore: [-1.45, 0, 0], chest: [0.1, 0.1, 0] });
  const clips = {
    attack: mkClip(0.45, [
      { t: 0.3, e: 'out', b: { hips: [0.0, -0.75, 0], chest: [-0.1, -0.45, 0], rUp: [-1.5, 0, -0.75], rFore: [-1.9, 0, 0], rHand: [-0.5, 0, 0], lUp: [-1.7, 0, -0.35], lFore: [-1.7, 0, 0] }, root: [0, 0, -0.06] },
      { t: 0.45, e: 'in', b: { hips: [0.14, 0.1, 0], chest: [0.36, 0.6, 0], rUp: [-1.0, 0, 0.5], rFore: [-0.3, 0, 0], rHand: [0.6, 0, 0], lUp: [-1.0, 0, -0.9], lFore: [-0.6, 0, 0], lThigh: [-0.9, 0, 0.08], lShin: [0.8, 0, 0], rThigh: [0.45, 0, -0.1], rShin: [0.25, 0, 0] }, root: [0, -0.09, 0.36] },
      { t: 0.66, e: 'out', b: { chest: [0.42, 0.8, 0], rUp: [-0.4, 0, 0.6], rHand: [0.8, 0, 0], lUp: [-0.5, 0, -0.9] }, root: [0, -0.1, 0.38] }], ready),
    cleave: mkClip(0.5, [
      { t: 0.32, e: 'out', b: { hips: [0.05, -1.0, 0], spine: [0.05, -0.3, 0], chest: [0.0, -0.5, 0], rUp: [-1.3, 0, -1.1], rFore: [-0.9, 0, 0], rHand: [0.1, 0.4, 0], lUp: [-1.5, 0, -0.5], lFore: [-1.2, 0, 0] }, root: [0, -0.06, -0.08] },
      { t: 0.5, e: 'in', b: { hips: [0.1, 0.3, 0], spine: [0.1, 0.3, 0], chest: [0.15, 0.6, 0], rUp: [-1.35, 0, 0.35], rFore: [-0.25, 0, 0], rHand: [0.2, -0.2, 0], lUp: [-1.3, 0, -0.9], lFore: [-0.5, 0, 0], lThigh: [-0.8, 0, 0.1], lShin: [0.75, 0, 0], rThigh: [0.4, 0, -0.12], rShin: [0.3, 0, 0] }, root: [0, -0.1, 0.3] },
      { t: 0.7, e: 'out', b: { hips: [0.1, 0.6, 0], chest: [0.15, 0.9, 0], rUp: [-1.2, 0, 0.9] }, root: [0, -0.1, 0.3] }], ready),
    sunder: mkClip(0.56, [
      { t: 0.36, e: 'out', b: { hips: [-0.1, -0.2, 0], spine: [-0.18, 0, 0], chest: [-0.25, 0, 0], rUp: [-2.85, 0, -0.25], rFore: [-0.9, 0, 0], rHand: [-0.9, 0, 0], lUp: [-2.85, 0, -0.4], lFore: [-1.0, 0, 0], head: [-0.2, 0.3, 0] }, root: [0, 0.03, -0.05] },
      { t: 0.56, e: 'in', b: { hips: [0.32, -0.2, 0], spine: [0.3, 0, 0], chest: [0.4, 0, 0], rUp: [-1.0, 0, 0.1], rFore: [-0.15, 0, 0], rHand: [0.95, 0, 0], lUp: [-1.0, 0, -0.55], lFore: [-0.3, 0, 0], lThigh: [-1.0, 0, 0.1], lShin: [1.0, 0, 0], rThigh: [0.3, 0, -0.12], rShin: [0.7, 0, 0], head: [0.1, 0.3, 0] }, root: [0, -0.22, 0.38] },
      { t: 0.74, b: {}, root: [0, -0.22, 0.38] }], ready)
  };
  LF.HEROES.reaver = { build, style: { carry, ready, readyRoot: -0.04, clips, swingL: 0.9, swingR: 0.08, strideAmp: 0.98, stride: 1.04, gait: { bounce: 1.0, sway: 1.35, lean: 1.2 }, downPose: DOWN_POSE } };
})();

/* ---------- FLETCHER: lean, deep hood, patched cloak, longbow ---------- */
(function () {
  const P = { sh: 0.19, hp: 0.09 };
  function build(opt) {
    const rig = humanRig(P), g = new Geo(rig), H = HW;
    for (const s of [1, -1]) {
      g.mat(C(0x33372b), 0.95, 0, T_CLOTH, 1.5); H.leg(g, P, s, { y0: 0.3, y1: 0.99, k: 0.96, wr: 0.05 });
      g.mat(C(0x4a3524), 0.78, 0, T_LEATHER, 1.9); H.boot(g, P, s, { top: 0.45 });
    }
    g.mat(C(0x3c3a27), 0.95, 0, T_QUILT, 1.0); H.torso(g, { grow: 0.016, y0: 0.99, y1: 1.5, k: 0.95, blouse: 0.012 }); H.skirt(g, { y0: 1.04, y1: 0.72, grow: 0.018, flare: 0.045, thick: 0.012 });
    for (const s of [1, -1]) { g.mat(C(0x3c3a27), 0.95, 0, T_QUILT, 0.6); H.arm(g, P, s, { grow: 0.013, k: 1.0, cap1: true }); g.mat(COL.leather, 0.7, 0, T_LEATHER, 0.5); H.fist(g, P, s); }
    H.vambrace(g, P, 1, { col: COL.leatherDk, metal: 0, ty: T_LEATHER, rough: 0.66 });
    H.belt(g, { grow: 0.03 }); H.satchel(g, -0.17, 1.02, -0.07, -2.0, 0.85); H.pouch(g, 0.17, 1.0, 0.04, 0.9);
    H.strap(g, { side: -1, grow: 0.03 }); H.quiver(g);
    H.head(g, { skin: COL.skinDk }); H.veil(g, { col: C(0x26251f), top: 1.672 });
    H.cloak(g, P, { hem: 0.46, wrap: 0.55, col: C(0x2b2a21), flare: 0.1, fold: 0.1 });
    H.hood(g, P, { col: C(0x302d1e), open: 0.62, peak: 0.07 });
    const bw = H.bow(g, P, {});
    const fig = finishHero(g, rig, P, opt, { tip: ['wL', P.sh + 0.03, 0.835, 0], nock: ['str', bw.nock[0], bw.nock[1], bw.nock[2]] });
    fig.hideB[rig.names.arw] = 1; return fig;
  }
  const carry = stance({ lUp: [0.06, 0, 0.14], lFore: [-0.4, 0.3, 0], rUp: [0.03, 0, -0.1], rFore: [-0.25, 0, 0] });
  const ready = rdy({ hips: [0.04, -0.85, 0], chest: [0.04, -0.15, 0], neck: [0.05, 0.35, 0], head: [0, 0.6, 0], lUp: [0, 1.1, 0.75], lFore: [-0.25, 0, 0], rUp: [-0.5, 0, -0.25], rFore: [-1.7, 0, 0], lThigh: [-0.3, 0.3, 0.12], rThigh: [0.12, -0.2, -0.1] });
  const drawn = { hips: [0.0, -1.15, 0], spine: [-0.04, -0.2, 0], chest: [-0.04, -0.2, 0], neck: [0, 0.5, 0], head: [0, 0.95, 0], lUp: [0, 1.57, 1.52], lFore: [-0.08, 0, 0], rUp: [0, 1.2, -1.5], rFore: [-2.45, 0, 0], rHand: [0, 0, 0] };
  const mkShoot = (pitch) => mkClip(0.6, [
    { t: 0.22, e: 'out', b: { hips: [0, -1.1, 0], spine: [0, -0.2, 0], chest: [0, -0.2, 0], neck: [0, 0.5, 0], head: [0, 0.9, 0], lUp: [0, 1.57, 1.3 + pitch], lFore: [-0.15, 0, 0], rUp: [0, 1.2, -1.2 - pitch * 0.3], rFore: [-1.5, 0, 0] }, tb: { str: [0, 0.05, 0] } },
    { t: 0.5, e: 'io', b: Object.assign({}, drawn, { lUp: [0, 1.57, 1.52 + pitch], spine: [-0.04, -0.2, pitch * 0.4] }), tb: { str: [0, 0.5, 0] } },
    { t: 0.6, e: 'lin', b: {}, tb: { str: [0, 0.52, 0] } },
    { t: 0.63, e: 'snap', b: { rUp: [0, 1.2, -1.75], rFore: [-2.1, 0, 0] }, tb: { str: [0, 0, 0] } },
    { t: 0.8, b: {}, tb: { str: [0, 0, 0] } }], ready);
  const clips = { attack: mkShoot(0), aimed: mkShoot(0), volley: mkShoot(0.45) };
  const post = (an) => { const f = an.f; f.hideB[f.rig.names.arw] = (an.act && an.actU > 0.12 && an.actU < an.act.hit) ? 0 : 1; };
  LF.HEROES.fletcher = { build, style: { carry, ready, readyRoot: -0.02, clips, swingL: 0.35, swingR: 1.0, strideAmp: 1.08, stride: 1.02, gait: { bounce: 1.35, sway: 0.6, lean: 0.8, lift: 1.5 }, downPose: DOWN_POSE, post } };
})();

/* ---------- LAMPLIGHTER: waxed coat, wide hat, the lantern on its hooked pole ---------- */
(function () {
  const P = { sh: 0.2, hp: 0.095 }; P.lan = [P.sh + 0.03, 0.835 - 0.17, 1.45 - 0.02];
  function build(opt) {
    const rig = humanRig(P), g = new Geo(rig), H = HW;
    for (const s of [1, -1]) {
      g.mat(C(0x2f2a24), 0.95, 0, T_CLOTH, 1.6); H.leg(g, P, s, { y0: 0.3, y1: 0.99, k: 1.03, wr: 0.05 });
      g.mat(COL.leatherDk, 0.76, 0, T_LEATHER, 2.0); H.boot(g, P, s, { top: 0.4 });
    }
    g.mat(C(0x4a3f2e), 0.95, 0, T_CLOTH, 1.3); H.skirt(g, { y0: 1.04, y1: 0.62, grow: 0.008, flare: 0.05, wave: 0.03 });
    g.mat(C(0x4a3f2e), 0.95, 0, T_CLOTH, 0.8); H.torso(g, { grow: 0.01, y0: 0.99, y1: 1.5 });
    // long waxed coat, open down the front
    const gap = 0.3, arc = [PI / 2 + gap, PI / 2 - gap + TAU];
    g.mat(COL.waxed, 0.56, 0, T_LEATHER, 1.2); H.torso(g, { grow: 0.024, y0: 1.0, y1: 1.5, arc: [PI / 2 + 0.2, PI / 2 - 0.2 + TAU], thick: 0.006, wr: 0.035, wra: 4, wry: 18 });
    g.mat(COL.waxed, 0.56, 0, T_LEATHER, 1.8); H.skirt(g, { y0: 1.04, y1: 0.34, grow: 0.028, flare: 0.1, arc, seg: 26, thick: 0.007, wave: 0.045, folds: 7 });
    for (const s of [1, -1]) { g.mat(COL.waxed, 0.56, 0, T_LEATHER, 0.8); H.arm(g, P, s, { grow: 0.02, k: 1.08, wr: 0.07, cap1: true }); g.mat(COL.leather, 0.7, 0, T_LEATHER, 0.5); H.fist(g, P, s); }
    H.belt(g, { grow: 0.04, w: 0.03 }); H.satchel(g, 0.16, 1.02, -0.1, 2.2, 1.0); H.pouch(g, -0.18, 1.0, 0.05, 1.0); H.pouch(g, -0.12, 1.0, 0.11, 0.8, COL.leatherTan);
    H.strap(g, { side: 1, grow: 0.04 });
    // short shoulder cape, scarf, hat
    H.cloak(g, P, { hem: 1.16, wrap: 1.25, col: C(0x1f1c17), flare: 0.035, fold: 0.05, clasp: false });
    H.cowl(g, P, { col: C(0x5c4a2a), r: 0.034, y: 1.5, wide: 0.0 });
    H.head(g, { beard: 0.85, hair: COL.hairGrey }); H.hat(g);
    const hook = H.staff(g, P, 1, { z0: -1.08, z1: 1.45, head: 'crook' });
    H.lanternBody(g, 'lan', hook[0], hook[1], hook[2], 1.0);
    return finishHero(g, rig, P, opt, { lan: ['lan', hook[0], hook[1] - 0.26, hook[2]], tip: ['lan', hook[0], hook[1] - 0.26, hook[2]], hand: ['rHand', -P.sh - 0.03, 0.82, 0.03] });
  }
  const carry = stance({ lUp: [-0.1, 0, 0.1], lFore: [-1.42, 0, 0], rUp: [0.03, 0, -0.1], rFore: [-0.25, 0, 0] });
  const ready = rdy({ hips: [0.05, -0.3, 0], head: [0, 0.3, 0], lUp: [-0.45, 0, 0.18], lFore: [-1.25, 0, 0], rUp: [-0.5, 0, -0.3], rFore: [-1.1, 0, 0] });
  const clips = {
    attack: mkClip(0.5, [
      { t: 0.3, e: 'out', b: { chest: [-0.1, 0.3, 0], lUp: [-0.3, 0, 0.3], lFore: [-1.7, 0, 0], lHand: [-0.55, 0, 0], rUp: [-1.5, 0, -0.35], rFore: [-0.9, 0, 0], hips: [0.0, 0.1, 0] }, root: [0, -0.02, -0.05] },
      { t: 0.5, e: 'in', b: { hips: [0.12, -0.5, 0], chest: [0.26, -0.3, 0], lUp: [-0.95, 0, 0.12], lFore: [-0.85, 0, 0], lHand: [1.0, 0, 0], rUp: [-1.45, 0, 0.1], rFore: [-0.15, 0, 0], lThigh: [-0.75, 0.1, 0.08], lShin: [0.7, 0, 0] }, root: [0, -0.07, 0.2] },
      { t: 0.7, b: {}, root: [0, -0.07, 0.2] }], ready),
    kindle: mkClip(0.5, [
      { t: 0.25, e: 'out', b: { spine: [0.15, 0, 0], chest: [0.15, 0, 0], lUp: [-0.5, 0, 0.2], lFore: [-1.6, 0, 0], rUp: [-0.5, 0, -0.2], rFore: [-1.6, 0, 0] }, root: [0, -0.08, 0] },
      { t: 0.5, e: 'out', b: { hips: [-0.05, -0.1, 0], spine: [-0.1, 0, 0], chest: [-0.15, 0, 0], head: [-0.3, 0.1, 0], lUp: [-2.1, 0, 0.2], lFore: [-0.85, 0, 0], rUp: [-2.0, 0, -0.5], rFore: [-0.6, 0, 0] }, root: [0, 0.02, 0] },
      { t: 0.78, b: {}, root: [0, 0.02, 0] }], ready)
  };
  clips.cinder = clips.kindle;
  LF.HEROES.lamplighter = { build, style: { carry, ready, readyRoot: -0.03, clips, swingL: 0.04, swingR: 0.95, gait: { bounce: 0.9, sway: 1.1, lean: 1.4 }, downPose: DOWN_POSE } };
})();

/* ---------- APOTHECARY: hooded, apron-coat, bandolier of flasks, heavy pack ---------- */
(function () {
  const P = { sh: 0.195, hp: 0.095 };
  function build(opt) {
    const rig = humanRig(P), g = new Geo(rig), H = HW;
    for (const s of [1, -1]) {
      g.mat(C(0x2d2a26), 0.95, 0, T_CLOTH, 1.6); H.leg(g, P, s, { y0: 0.3, y1: 0.99, wr: 0.05 });
      g.mat(COL.leather, 0.76, 0, T_LEATHER, 2.0); H.boot(g, P, s, { top: 0.38 });
    }
    const coat = C(0x443d31);
    g.mat(coat, 0.95, 0, T_CLOTH, 0.9); H.torso(g, { grow: 0.016, y0: 0.99, y1: 1.5, wr: 0.03, wra: 4, wry: 18, blouse: 0.016 });
    g.mat(coat, 0.95, 0, T_CLOTH, 1.7); H.skirt(g, { y0: 1.04, y1: 0.4, grow: 0.02, flare: 0.095, seg: 26, thick: 0.007, wave: 0.05, folds: 8 });
    for (const s of [1, -1]) { g.mat(coat, 0.95, 0, T_CLOTH, 0.7); H.arm(g, P, s, { grow: 0.018, k: 1.05, wr: 0.08, cap1: true }); g.mat(COL.leatherDk, 0.7, 0, T_LEATHER, 0.6); H.fist(g, P, s); H.vambrace(g, P, s, { col: COL.leatherDk, metal: 0, ty: T_LEATHER, rough: 0.7 }); }
    // stained leather apron
    g.mat(C(0x4a3423), 0.7, 0, T_LEATHER, 1.2); H.torso(g, { grow: 0.026, y0: 1.0, y1: 1.4, arc: [PI / 2 - 1.05, PI / 2 + 1.05], seg: 10, thick: 0.006, wr: 0.03 });
    g.mat(C(0x4a3423), 0.7, 0, T_LEATHER, 1.8); H.skirt(g, { y0: 1.04, y1: 0.5, grow: 0.034, flare: 0.085, arc: [PI / 2 - 0.95, PI / 2 + 0.95], seg: 12, thick: 0.006, wave: 0.03, folds: 5 });
    H.belt(g, { grow: 0.04, w: 0.03 });
    // bandolier with stoppered flasks
    H.strap(g, { side: 1, grow: 0.042, w: 0.024, col: COL.leatherDk });
    const fc = [C(0x5a6a3a), C(0x8a5a2a), C(0x3a4a5a), C(0x6a3a2a), C(0x58603a)];
    for (let i = 0; i < 5; i++) { const t = i / 4, x = lerp(0.115, -0.125, t), y = lerp(1.385, 1.13, t); H.flask(g, x, y, 0.158 - 0.02 * Math.abs(t - 0.4), 0.82, fc[i], i === 1 ? 0.5 : (i === 3 ? 0 : 0), HW.TW, 0.1, 0.35); }
    H.flask(g, -0.2, 0.94, 0.04, 1.1, C(0x7ab04a), 0.35, HW.skirtW(1.04), 0, 0.1); H.flask(g, 0.2, 0.95, 0.02, 1.0, C(0x5a4a3a), 0, HW.skirtW(1.04), 0, -0.1);
    H.satchel(g, 0.15, 1.01, -0.1, 2.3, 0.9);
    H.head(g, { skin: COL.skinDk }); H.veil(g, { col: C(0x4a4638), top: 1.682 }); H.hood(g, P, { col: C(0x2e2c26), open: 0.62, peak: 0.03 });
    H.pack(g);
    H.flask(g, -P.sh - 0.03, 0.84, 0.03, 1.25, C(0xffa040), 0.7, 'wR', -0.3, 0);
    return finishHero(g, rig, P, opt, { tip: ['wR', -P.sh - 0.03, 0.86, 0.03], hand: ['wR', -P.sh - 0.03, 0.86, 0.03] });
  }
  const carry = stance({ lUp: [0.03, 0, 0.1], lFore: [-0.5, 0, 0], rUp: [-0.1, 0, -0.1], rFore: [-0.85, 0, 0], spine: [0.1, 0, 0] });
  const ready = rdy({ hips: [0.05, -0.3, 0], head: [0, 0.3, 0], lUp: [-0.3, 0, 0.25], lFore: [-0.9, 0, 0], rUp: [-0.3, 0, -0.3], rFore: [-1.5, 0, 0] });
  const clips = {
    attack: mkClip(0.5, [
      { t: 0.3, e: 'out', b: { hips: [0, -0.7, 0], chest: [-0.15, -0.4, 0], rUp: [-2.5, 0, -0.6], rFore: [-1.6, 0, 0], lUp: [-0.9, 0, 0.2], lFore: [-0.5, 0, 0] }, root: [0, 0, -0.06] },
      { t: 0.5, e: 'in', b: { hips: [0.12, 0.1, 0], chest: [0.32, 0.5, 0], rUp: [-1.5, 0, 0.15], rFore: [-0.15, 0, 0], lUp: [0.2, 0, 0.3], lThigh: [-0.8, 0.1, 0.08], lShin: [0.7, 0, 0] }, root: [0, -0.08, 0.22] },
      { t: 0.7, e: 'out', b: { rUp: [-0.5, 0, 0.3], chest: [0.36, 0.6, 0] }, root: [0, -0.08, 0.22] }], ready),
    tonic: mkClip(0.5, [
      { t: 0.28, e: 'out', b: { chest: [0.1, -0.3, 0], rUp: [0.6, 0, -0.25], rFore: [-0.5, 0, 0] }, root: [0, -0.06, 0] },
      { t: 0.5, e: 'in', b: { chest: [-0.05, 0.3, 0], rUp: [-1.7, 0, -0.1], rFore: [-0.4, 0, 0] }, root: [0, 0, 0.08] },
      { t: 0.7, b: {}, root: [0, 0, 0.08] }], ready)
  };
  clips.firepot = clips.attack; clips.quick = clips.tonic;
  LF.HEROES.apothecary = { build, style: { carry, ready, readyRoot: -0.03, clips, swingL: 0.9, swingR: 0.35, strideAmp: 0.92, stride: 0.92, gait: { bounce: 1.1, sway: 1.2, lean: 1.6 }, downPose: DOWN_POSE } };
})();

/* ---------- RIMEBINDER: layered robes, fur collar, staff headed with a pale shard ---------- */
(function () {
  const P = { sh: 0.19, hp: 0.092 };
  function build(opt) {
    const rig = humanRig(P), g = new Geo(rig), H = HW;
    for (const s of [1, -1]) {
      g.mat(C(0x26282c), 0.95, 0, T_CLOTH, 1.5); H.leg(g, P, s, { y0: 0.3, y1: 0.99, k: 0.98 });
      g.mat(COL.leatherDk, 0.76, 0, T_LEATHER, 2.0); H.boot(g, P, s, { top: 0.36 });
    }
    const under = C(0x3a434a), over = C(0x1f2428);
    g.mat(under, 0.95, 0, T_CLOTH, 0.8); H.torso(g, { grow: 0.012, y0: 0.99, y1: 1.5, k: 0.97, blouse: 0.012 });
    g.mat(under, 0.95, 0, T_CLOTH, 1.9); H.skirt(g, { y0: 1.04, y1: 0.13, grow: 0.014, flare: 0.13, seg: 30, thick: 0.007, wave: 0.055, folds: 9 });
    const gap = 0.42;
    g.mat(over, 0.95, 0, T_CLOTH, 0.9); H.torso(g, { grow: 0.026, y0: 1.0, y1: 1.5, k: 0.97, arc: [PI / 2 + 0.25, PI / 2 - 0.25 + TAU], thick: 0.007, wr: 0.035, wra: 4, wry: 16 });
    g.mat(over, 0.95, 0, T_CLOTH, 1.6); H.skirt(g, { y0: 1.04, y1: 0.46, grow: 0.03, flare: 0.11, arc: [PI / 2 + gap, PI / 2 - gap + TAU], seg: 26, thick: 0.009, wave: 0.05, folds: 7 });
    // fur trim along the over-robe hem
    g.mat(COL.furGrey, 1, 0, T_FUR, 1.4); g.bone(H.skirtW(1.04));
    { const N = 26, pts = []; for (let i = 0; i <= N; i++) { const a = PI / 2 + gap + (TAU - 2 * gap) * i / N, c = Math.cos(a), s = Math.sin(a); pts.push([c * 0.292 * (1 + 0.04 * Math.sin(a * 7)), 0.47, s * (s > 0 ? 0.228 : 0.262)]); } g.tube(pts, 0.024, { seg: 6, sub: 1 }); }
    for (const s of [1, -1]) { g.mat(over, 0.95, 0, T_CLOTH, 0.7); H.bellSleeve(g, P, s); g.mat(COL.woolGrey, 0.95, 0, T_CLOTH, 0.4); H.arm(g, P, s, { y0: 0.9, y1: 1.0, grow: 0.006, cap1: false }); g.mat(C(0x33363a), 0.9, 0, T_CLOTH, 0.4); H.fist(g, P, s); }
    H.belt(g, { grow: 0.04, w: 0.022, col: COL.leather });
    g.bone(H.skirtW(1.04)); g.mat(COL.rope, 0.9, 0, T_CLOTH, 0.6);
    for (const cx of [-0.1, -0.06, 0.09]) { g.tube([[cx, 1.03, 0.15], [cx + 0.01, 0.9, 0.165], [cx, 0.78 + cx, 0.17]], 0.005, { seg: 4, sub: 2 }); g.tr(cx, 0.78 + cx, 0.17); g.mat(C(0x9ac8e8), 0.3, 0, T_GLOW, 0.25); g.loft([{ y: -0.05, rx: 0.002 }, { y: -0.02, rx: 0.012 }, { y: 0.0, rx: 0.004 }], { seg: 4, sub: 1, flat: true }); g.mat(COL.rope, 0.9, 0, T_CLOTH, 0.6); g.pop(); }
    H.satchel(g, -0.16, 1.01, -0.09, -2.2, 0.85, COL.leatherDk);
    H.head(g, { skin: COL.skinDk }); H.veil(g, { col: C(0x5c6166), top: 1.68 }); H.hood(g, P, { col: C(0x2a3036), open: 0.64, peak: 0.02 });
    H.furMantle(g, P, { col: COL.furGrey, back: 0.08 });
    const tip = H.staff(g, P, -1, { z0: -1.1, z1: 0.98, head: 'shard', col: COL.woodDk });
    return finishHero(g, rig, P, opt, { tip: ['wR', tip[0], tip[1], tip[2]], hand: ['lHand', P.sh + 0.03, 0.82, 0.03] });
  }
  const carry = stance({ rUp: [-0.1, 0, -0.1], rFore: [-1.42, 0, 0], lUp: [0.03, 0, 0.1], lFore: [-0.3, 0, 0] });
  const ready = rdy({ hips: [0.04, 0.3, 0], head: [0, -0.3, 0], lThigh: [0.15, 0.2, 0.1], lShin: [0.3, 0, 0], rThigh: [-0.4, -0.1, -0.08], rShin: [0.45, 0, 0], rFoot: [0, 0, 0], lFoot: [-0.35, 0, 0], rUp: [-0.45, 0, -0.15], rFore: [-1.2, 0, 0], rHand: [0.25, 0, 0], lUp: [-0.5, 0, 0.3], lFore: [-1.0, 0, 0] });
  const clips = {
    attack: mkClip(0.5, [
      { t: 0.3, e: 'out', b: { chest: [-0.1, -0.3, 0], rUp: [-2.3, 0, -0.3], rFore: [-0.7, 0, 0], rHand: [-0.35, 0, 0], lUp: [-1.9, 0, -0.2], lFore: [-0.9, 0, 0], spine: [-0.12, 0, 0] }, root: [0, -0.02, -0.05] },
      { t: 0.5, e: 'in', b: { hips: [0.1, 0.5, 0], chest: [0.22, 0.3, 0], rUp: [-1.45, 0, 0.05], rFore: [-0.25, 0, 0], rHand: [1.35, 0, 0], lUp: [-1.25, 0, -0.45], lFore: [-0.7, 0, 0], spine: [0.2, 0, 0] }, root: [0, -0.06, 0.18] },
      { t: 0.72, b: {}, root: [0, -0.06, 0.18] }], ready),
    hoar: mkClip(0.52, [
      { t: 0.32, e: 'out', b: { spine: [-0.12, 0, 0], chest: [-0.15, 0, 0], rUp: [-1.3, 0, -0.2], rFore: [-1.5, 0, 0], lUp: [-1.5, 0, 0.3], lFore: [-1.2, 0, 0], head: [-0.2, -0.3, 0] }, root: [0, 0.03, 0] },
      { t: 0.52, e: 'in', b: { spine: [0.22, 0, 0], chest: [0.22, 0, 0], rUp: [-0.5, 0, -0.15], rFore: [-1.1, 0, 0], lUp: [-0.6, 0, 0.5], lFore: [-0.6, 0, 0], lShin: [0.6, 0, 0], rShin: [0.8, 0, 0], lThigh: [0.0, 0.2, 0.1], rThigh: [-0.6, -0.1, -0.08] }, root: [0, -0.16, 0.05] },
      { t: 0.75, b: {}, root: [0, -0.16, 0.05] }], ready)
  };
  clips.shatter = clips.hoar;
  LF.HEROES.rimebinder = { build, style: { carry, ready, readyRoot: -0.03, clips, swingL: 0.9, swingR: 0.04, strideAmp: 0.9, stride: 0.9, gait: { bounce: 0.7, sway: 0.8, lean: 0.9 }, downPose: DOWN_POSE } };
})();
LF.HERO_ORDER = ['warden', 'reaver', 'fletcher', 'lamplighter', 'apothecary', 'rimebinder'];
