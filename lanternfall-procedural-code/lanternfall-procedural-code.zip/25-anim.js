/* LANTERNFALL - animation: clips + procedural locomotion composed into a pose each frame */
function mkClip(hit, keys, base) {
  // keys: [{t, e, b:{bone:[x,y,z]}, tb:{bone:[x,y,z]}, root:[x,y,z]}]; missing bones carry from the previous key; starts and ends at `base`
  base = base || {};
  const bones = {}, tbs = {}; for (const k of keys) { for (const n in (k.b || {})) bones[n] = 1; for (const n in (k.tb || {})) tbs[n] = 1; }
  const ks = keys.slice();
  if (!ks.length || ks[0].t > 0) ks.unshift({ t: 0, _base: true });
  if (ks[ks.length - 1].t < 1) ks.push({ t: 1, _base: true });
  const tr = {}, tt = {}, root = [], last = {}, lastT = {}; let lastRoot = [0, 0, 0];
  for (const n in bones) { tr[n] = []; last[n] = base[n] || [0, 0, 0]; }
  for (const n in tbs) { tt[n] = []; lastT[n] = [0, 0, 0]; }
  for (const k of ks) {
    for (const n in bones) { const v = k._base ? (base[n] || [0, 0, 0]) : ((k.b && k.b[n]) || last[n]); last[n] = v; tr[n].push([k.t, v[0], v[1], v[2], k.e || 'io']); }
    for (const n in tbs) { const v = k._base ? [0, 0, 0] : ((k.tb && k.tb[n]) || lastT[n]); lastT[n] = v; tt[n].push([k.t, v[0], v[1], v[2], k.e || 'io']); }
    lastRoot = k._base ? [0, 0, 0] : (k.root || lastRoot); root.push([k.t, lastRoot[0], lastRoot[1], lastRoot[2], k.e || 'io']);
  }
  return { hit, tr, tt, root, names: Object.keys(bones), tnames: Object.keys(tbs) };
}
function sampTrack(tk, t, out) {
  const n = tk.length; if (t <= tk[0][0]) { out[0] = tk[0][1]; out[1] = tk[0][2]; out[2] = tk[0][3]; return; }
  if (t >= tk[n - 1][0]) { out[0] = tk[n - 1][1]; out[1] = tk[n - 1][2]; out[2] = tk[n - 1][3]; return; }
  for (let i = 0; i < n - 1; i++) { const a = tk[i], b = tk[i + 1]; if (t <= b[0]) { const u = ease[b[4]]((t - a[0]) / (b[0] - a[0])); out[0] = lerp(a[1], b[1], u); out[1] = lerp(a[2], b[2], u); out[2] = lerp(a[3], b[3], u); return; } }
}
function eulerToR(x, y, z, R, r) {
  const cx = Math.cos(x), sx = Math.sin(x), cy = Math.cos(y), sy = Math.sin(y), cz = Math.cos(z), sz = Math.sin(z);
  R[r] = cz * cy; R[r + 1] = -sz; R[r + 2] = cz * sy; R[r + 3] = cx * sz * cy + sx * sy; R[r + 4] = cx * cz; R[r + 5] = cx * sz * sy - sx * cy; R[r + 6] = sx * sz * cy - cx * sy; R[r + 7] = sx * cz; R[r + 8] = sx * sz * sy + cx * cy;
}
const _tv = [0, 0, 0], LEGB = ['hips', 'lThigh', 'lShin', 'lFoot', 'rThigh', 'rShin', 'rFoot'];
// out = (rotation taking unit u to unit v) * R[o..o+8]
function rotUV(ux, uy, uz, vx, vy, vz, R, o, out) {
  const ax = uy * vz - uz * vy, ay = uz * vx - ux * vz, az = ux * vy - uy * vx, s = Math.hypot(ax, ay, az), c = ux * vx + uy * vy + uz * vz;
  if (s < 1e-7) { for (let i = 0; i < 9; i++) out[i] = R[o + i]; return; }
  const x = ax / s, y = ay / s, z = az / s, t = 1 - c;
  const q0 = t * x * x + c, q1 = t * x * y - s * z, q2 = t * x * z + s * y, q3 = t * x * y + s * z, q4 = t * y * y + c, q5 = t * y * z - s * x, q6 = t * x * z - s * y, q7 = t * y * z + s * x, q8 = t * z * z + c;
  for (let j = 0; j < 3; j++) { const a = R[o + j], b = R[o + 3 + j], d = R[o + 6 + j]; out[j] = q0 * a + q1 * b + q2 * d; out[3 + j] = q3 * a + q4 * b + q5 * d; out[6 + j] = q6 * a + q7 * b + q8 * d; }
}
class HumanAnim {
  constructor(fig, style) {
    this.f = fig; this.st = style; this.ph = Math.random() * TAU; this.t = Math.random() * 20; this.moveW = 0; this.readyW = 0;
    this.act = null; this.actT = 0; this.actDur = 1; this.actHit = 0.2; this.stag = 0; this.stagDir = 1; this.downW = 0; this.down = false;
    this.ck = [0, 0, 0, 0, 0, 0]; this.lan = [0, 0, 0, 0]; this.lastSpeed = 0; this.aimPitch = 0; this.scaleStride = style.stride || 1;
    const n = fig.rig.names; this.ix = {}; for (const k in n) this.ix[k] = n[k] * 3;
  }
  // start an action: windup seconds until the hit frame, recover seconds after
  play(name, windup, recover) { const c = this.st.clips[name]; if (!c) return; this.act = c; this.actT = 0; this.actW = windup; this.actR = recover; }
  add(b, x, y, z) { const i = this.ix[b], E = this.f.euler; E[i] += x; E[i + 1] += y; E[i + 2] += z; }
  mixPose(pose, w) { const E = this.f.euler; for (const b in pose) { const i = this.ix[b], v = pose[b]; E[i] = lerp(E[i], v[0], w); E[i + 1] = lerp(E[i + 1], v[1], w); E[i + 2] = lerp(E[i + 2], v[2], w); } }
  update(dt, speed, combat, forceT) {
    const f = this.f, E = f.euler, Tr = f.trans, st = this.st, ix = this.ix; E.fill(0); Tr.fill(0);
    this.t += dt; const t = this.t;
    const mv = Math.min(1.3, Math.abs(speed) / 1.5);
    this.moveW = lerp(this.moveW, mv > 0.05 ? 1 : 0, 1 - Math.exp(-dt * (mv > 0.05 ? 6 : 5)));
    this.readyW = lerp(this.readyW, combat ? 1 : 0, 1 - Math.exp(-dt * 6));
    this.sSm = lerp(this.sSm === undefined ? Math.abs(speed) : this.sSm, Math.abs(speed), 1 - Math.exp(-dt * 5)); const sa = this.sSm, footB = !!combat && sa < 1.35; this.footW = lerp(this.footW || 0, footB ? 1 : 0, 1 - Math.exp(-dt * 6)); const foot = this.footW;
    // stride length scales with speed and is capped in cadence: footwork 1.6 steps/s, walk 1.9, run 2.8
    const Ls = sa < 1.35 ? Math.max(0.5, sa / 1.6) : lerp(Math.max(0.78, sa / 1.95), sa / 2.75, smooth(2.3, 3.0, sa));
    this.ph += speed * dt / Ls * PI; if (Math.abs(speed) > 0.05) this.steps = (this.steps || 0) + Math.abs(speed) * dt / Ls; this.stL = Math.cos(this.ph) < 0;
    const mw = this.moveW, rw = this.readyW * (1 - mw * lerp(0.45, 0.06, foot));
    // base carry + ready
    this.mixPose(st.carry, 1); if (rw > 0.001 && st.ready) this.mixPose(st.ready, rw);
    if (st.readyRoot && rw > 0) { Tr[ix.hips + 1] += st.readyRoot * rw; }
    // the standing pose gives way to the stride
    if (mw > 0.01) { const k = 1 - mw * lerp(0.85, 0.25, foot); for (const b of LEGB) { const i = ix[b]; E[i] *= k; E[i + 1] *= k; E[i + 2] *= k; } }
    // idle life
    const br = Math.sin(t * 1.5), sw = Math.sin(t * 0.43 + 1), idle = 1 - mw;
    E[ix.chest] += 0.014 * br; E[ix.lUp + 2] += 0.012 * br; E[ix.rUp + 2] -= 0.012 * br;
    E[ix.hips + 2] += 0.028 * sw * idle * (1 - rw); Tr[ix.hips] += 0.014 * sw * idle; E[ix.spine + 2] -= 0.02 * sw * idle * (1 - rw);
    E[ix.lShin] += Math.max(0, sw) * 0.09 * idle * (1 - rw); E[ix.lThigh] -= Math.max(0, sw) * 0.05 * idle * (1 - rw);
    E[ix.rShin] += Math.max(0, -sw) * 0.09 * idle * (1 - rw); E[ix.rThigh] -= Math.max(0, -sw) * 0.05 * idle * (1 - rw);
    E[ix.head + 1] += (0.16 * Math.sin(t * 0.31) + 0.07 * Math.sin(t * 0.87 + 2)) * idle; E[ix.head] += 0.03 * Math.sin(t * 0.5);
    // walk
    if (mw > 0.002) {
      const LEG = 0.845, A = Math.asin(Math.min(0.72, Ls / 2 / LEG)), ph = this.ph, s = Math.sin(ph), c = Math.cos(ph), w = mw, armK = smooth(1.0, 2.0, sa);
      const LGL = this.lgL || (this.lgL = { xf: 0, xs: 0, st: false }), LGR = this.lgR || (this.lgR = { xf: 0, xs: 0, st: false }), stepD = speed * dt;
      const leg = (T, S, F, sg, cg) => {
        // stance: the foot travels back in a straight line at ground speed, so it stays where it was planted; swing: it is carried forward
        let q = (Math.atan2(sg, cg) - PI / 2) / PI; q = ((q % 2) + 2) % 2; const lg = sg === s ? LGL : LGR; let xf;
        if (q < 1) { if (!lg.st) { lg.st = true; lg.xf = clamp(lg.xf, Ls * 0.28, Ls * 0.44); } lg.xf -= stepD; xf = lg.xf; } else { if (lg.st) { lg.st = false; lg.xs = lg.xf; } const u = q - 1; xf = lg.xf = lerp(lg.xs, Ls * 0.38, u * u * (3 - 2 * u)); }
        if (sg === s) this.qL = q; else this.qR = q;
        const th = Math.asin(clamp(xf / LEG, -0.78, 0.78)), flex = 0.06 + lerp(lerp(0.62, 1.05, smooth(2.2, 3.2, sa)), 0.5, foot) * Math.pow(Math.max(0, Math.cos(Math.atan2(sg, cg) + 0.35)), 1.6) * (0.6 + 0.4 * mv);
        const swing = Math.max(0, cg);
        E[ix[T]] += -th * w; E[ix[S]] += flex * w; E[ix[F]] += ((th - flex) * (1 - swing * 0.6) + 0.3 * Math.pow(Math.max(0, Math.cos(Math.atan2(sg, cg) + 1.3)), 2) - 0.22 * swing * Math.max(0, sg)) * w;
      };
      leg('lThigh', 'lShin', 'lFoot', s, c); leg('rThigh', 'rShin', 'rFoot', -s, -c);
      // hips: a steady drop that lets the stride reach, plus a small bob, exactly two per stride (2.5 cm walking, 4 cm running at most)
      const runK = smooth(2.4, 3.5, sa), bobA = Math.min(lerp(0.025, 0.04, runK), lerp(0.018, 0.032, runK) * ((st.gait && st.gait.bounce) || 1));
      { const fr = Math.min(0.72 * LEG, Ls * 0.38), need = LEG - Math.sqrt(LEG * LEG - fr * fr); Tr[ix.hips + 1] += (-need - 0.012 + bobA * (1 + Math.cos(ph * 2))) * w; }
      E[ix.hips + 1] += -0.05 * s * w; E[ix.hips + 2] += 0.03 * c * w; E[ix.spine + 1] += 0.13 * s * w; E[ix.chest + 1] += 0.1 * s * w; E[ix.spine] += (0.02 + 0.03 * mv) * w; E[ix.head + 1] += -0.05 * s * w;
      const sl = (st.swingL === undefined ? 1 : st.swingL) * armK, sr = (st.swingR === undefined ? 1 : st.swingR) * armK, B = 0.42 * (0.6 + 0.4 * mv);
      E[ix.lUp] += B * s * w * sl; E[ix.rUp] += -B * s * w * sr; E[ix.lFore] += -(0.18 + 0.22 * Math.max(0, -s)) * w * sl; E[ix.rFore] += -(0.18 + 0.22 * Math.max(0, s)) * w * sr;
      // looser body: bounce, sway, counter-rotation, lean into the run, a steady head
      const gt = st.gait || {}, run = smooth(2.4, 3.5, Math.abs(speed)), bo = gt.bounce || 1, sy = gt.sway || 1, ln = gt.lean || 1;
      { const dx = -0.014 * sy * c * w; Tr[ix.hips] += dx; E[ix.lThigh + 2] -= dx / LEG; E[ix.rThigh + 2] -= dx / LEG; }
      E[ix.hips + 1] += -0.04 * s * w * (1 + run * 2.5); E[ix.hips + 2] += 0.02 * sy * c * w; E[ix.spine + 2] += -0.035 * sy * c * w; E[ix.chest + 1] += 0.17 * s * w * (1 + run * 0.6); E[ix.chest + 2] += -0.03 * sy * c * w;
      E[ix.spine] += (0.015 * ln + 0.17 * run) * w; E[ix.chest] += 0.03 * Math.cos(ph * 2) * w * bo; E[ix.neck] -= (0.05 * ln + 0.12 * run) * w; E[ix.head + 1] -= 0.2 * s * w * (1 + run * 0.5); E[ix.head + 2] += 0.035 * sy * c * w; E[ix.head] -= 0.025 * Math.cos(ph * 2) * w * bo;
      const kl = Math.pow(Math.max(0, Math.cos(ph + 0.35)), 1.6), kr = Math.pow(Math.max(0, -Math.cos(ph + 0.35)), 1.6), lift = (gt.lift || 1);
      E[ix.lShin] += (0.2 * (lift - 1) + run * 0.55) * kl * w; E[ix.rShin] += (0.2 * (lift - 1) + run * 0.55) * kr * w; E[ix.lThigh] -= run * 0.22 * Math.max(0, c) * w; E[ix.rThigh] -= run * 0.22 * Math.max(0, -c) * w;
      E[ix.lFore] -= 0.55 * run * w * sl; E[ix.rFore] -= 0.55 * run * w * sr; E[ix.lUp] += 0.25 * B * s * run * w * sl; E[ix.rUp] -= 0.25 * B * s * run * w * sr;
      E[ix.lUp + 2] += 0.05 * w; E[ix.rUp + 2] -= 0.05 * w;
    }
    // action clip
    let rootZ = 0;
    if (this.act || forceT !== undefined) {
      const c = this.act; let u;
      if (forceT !== undefined) u = forceT;
      else { this.actT += dt; u = this.actT < this.actW ? this.actT / this.actW * c.hit : c.hit + (this.actT - this.actW) / this.actR * (1 - c.hit); }
      this.actU = u;
      if (c) {
        if (u >= 1) { this.act = null; }
        else {
          const w = Math.min(1, u / 0.07) * Math.min(1, (1 - u) / 0.16);
          for (const n of c.names) { sampTrack(c.tr[n], u, _tv); const i = ix[n]; E[i] = lerp(E[i], _tv[0], w); E[i + 1] = lerp(E[i + 1], _tv[1], w); E[i + 2] = lerp(E[i + 2], _tv[2], w); }
          for (const n of c.tnames) { sampTrack(c.tt[n], u, _tv); const i = ix[n]; Tr[i] += _tv[0] * w; Tr[i + 1] += _tv[1] * w; Tr[i + 2] += _tv[2] * w; }
          sampTrack(c.root, u, _tv); Tr[ix.root] += _tv[0] * w; Tr[ix.hips + 1] += _tv[1] * w; Tr[ix.root + 2] += _tv[2] * w; rootZ = _tv[2] * w;
        }
      }
    }
    // the body turns first
    if (this.lead) { const ld = this.lead; E[ix.chest + 1] += ld * 0.45; E[ix.spine + 1] += ld * 0.2; E[ix.head + 1] += ld * 0.5; E[ix.hips + 1] -= ld * 0.25; E[ix.spine + 2] -= ld * 0.08 * mw; }
    // stagger (additive recoil)
    if (this.stag > 0) {
      this.stag = Math.max(0, this.stag - dt * 2.6); const k = Math.sin(Math.min(1, this.stag) * PI) * 0.9 + this.stag * 0.3;
      E[ix.spine] -= 0.22 * k; E[ix.chest] -= 0.2 * k; E[ix.head] += 0.25 * k; E[ix.hips + 1] += 0.2 * k * this.stagDir; Tr[ix.root + 2] -= 0.12 * k; E[ix.lUp + 2] += 0.2 * k; E[ix.rUp + 2] -= 0.2 * k;
      E[ix.lShin] += 0.2 * k; E[ix.rShin] += 0.2 * k; E[ix.lThigh] -= 0.1 * k; E[ix.rThigh] -= 0.1 * k; Tr[ix.hips + 1] -= 0.03 * k;
    }
    // downed (hero): one knee, head bowed
    this.downW = lerp(this.downW, this.down ? 1 : 0, 1 - Math.exp(-dt * (this.down ? 3.2 : 4)));
    if (this.downW > 0.002 && st.downPose) { this.mixPose(st.downPose, this.downW); Tr[ix.hips + 1] = lerp(Tr[ix.hips + 1], st.downY || -0.46, this.downW); Tr[ix.hips + 2] = lerp(Tr[ix.hips + 2], -0.05, this.downW); }
    if (this.aimPitch) { E[ix.spine] -= this.aimPitch * 0.4; E[ix.chest] -= this.aimPitch * 0.4; }
    // cloak: lags behind motion, counter-rotates the torso lean
    const lean = E[ix.spine] + E[ix.chest] + E[ix.hips], ck = this.ck, wind = 0.05 * Math.sin(t * 1.3) + 0.03 * Math.sin(t * 3.1 + 1);
    const tgtA = -lean * 0.85 + 0.07 + Math.max(0, speed) * 0.2 + wind + 0.025 * Math.cos(this.ph * 2) * mw;
    ck[1] += ((tgtA - ck[0]) * 60 - ck[1] * 13) * dt; ck[0] += ck[1] * dt;
    ck[3] += (((ck[0] - tgtA) * -0.6 + Math.max(0, speed) * 0.1 + wind * 1.4 + 0.04 - ck[2]) * 40 - ck[3] * 6) * dt; ck[2] += ck[3] * dt;
    ck[5] += (((ck[2]) * 0.6 + wind - ck[4]) * 30 - ck[5] * 5) * dt; ck[4] += ck[5] * dt;
    E[ix.cloakA] = clamp(ck[0], -0.08, 0.5); E[ix.cloakB] = clamp(ck[2], -0.1, 0.32); E[ix.cloakC] = clamp(ck[4], -0.12, 0.3);
    E[ix.cloakA + 2] = -E[ix.hips + 2] - E[ix.spine + 2] + 0.03 * Math.sin(t * 0.9) + 0.05 * Math.sin(this.ph - 0.5) * mw; E[ix.cloakA + 1] = -(E[ix.chest + 1] + E[ix.spine + 1]) * 0.6; E[ix.cloakB + 2] = 0.1 * Math.sin(this.ph - 1.1) * mw - (this.lead || 0) * 0.2; E[ix.cloakC + 2] = 0.14 * Math.sin(this.ph - 1.8) * mw - (this.lead || 0) * 0.25;
    // lantern pendulum (absolute bones)
    const ln = this.lan, acc = (speed - this.lastSpeed) / Math.max(dt, 1e-3); this.lastSpeed = speed;
    const drive = -clamp(acc, -30, 30) * 0.012 + Math.sin(this.ph * 2) * 0.05 * mw + rootZ * -0.6;
    ln[1] += ((drive - ln[0]) * 38 - ln[1] * 2.2) * dt; ln[0] += ln[1] * dt; ln[3] += ((Math.sin(this.ph) * 0.05 * mw + 0.02 * Math.sin(t * 1.7) - ln[2]) * 30 - ln[3] * 2) * dt; ln[2] += ln[3] * dt;
    if (ix.lan !== undefined) { eulerToR(clamp(ln[0], -0.9, 0.9), 0, clamp(ln[2], -0.6, 0.6), f.absR, ix.lan * 3); eulerToR(clamp(ln[0], -0.9, 0.9), 0, clamp(ln[2], -0.6, 0.6), f.absR, ix.lanB * 3); }
    if (st.post) st.post(this, dt);
    { const hy = Tr[ix.hips + 1], k = 1 - Math.exp(-dt * 28); if (this.hy1 === undefined || dt <= 0) { this.hy1 = this.hy2 = hy; } this.hy1 += (hy - this.hy1) * k; this.hy2 += (this.hy1 - this.hy2) * k; Tr[ix.hips + 1] = this.hy2; }
    if (this.ikOn) this.legIK(dt, speed); else f.solve();
    f.skin();
  }
  // two-bone leg IK, always on for the legs. The knee bends forward along the pelvis (pole vector), knee flexion stays within 5-120 degrees,
  // a planted foot is held flat at its world position, and it is released to take a step rather than stretched or folded.
  legIK(dt, speed) {
    const f = this.f, H = f.rig.head, X = this.xf, ix = this.ix, Tr = f.trans; f.free = null; f.solve();
    if (!X || this.downW > 0.2) { if (this.pin) { this.pin.l.on = this.pin.r.on = false; this.pin.l.w = this.pin.r.w = 0; } return; }
    const P = this.pin || (this.pin = { l: { w: 0, on: false, x: 0, z: 0, y: 0, hold: 0, yaw: 0 }, r: { w: 0, on: false, x: 0, z: 0, y: 0, hold: 0, yaw: 0 } });
    const cf = Math.cos(X.f), sf = Math.sin(X.f), sc = X.s, moving = this.moveW > 0.5 && Math.abs(speed) > 0.08, W = f.Wp, C5 = Math.cos(5 * PI / 180), C120 = Math.cos(120 * PI / 180);
    const legs = this.legs || (this.legs = [['l', ix.lThigh, ix.lShin, ix.lFoot], ['r', ix.rThigh, ix.rShin, ix.rFoot]].map(q => { const L1 = Math.hypot(H[q[2]] - H[q[1]], H[q[2] + 1] - H[q[1] + 1], H[q[2] + 2] - H[q[1] + 2]), L2 = Math.hypot(H[q[3]] - H[q[2]], H[q[3] + 1] - H[q[2] + 1], H[q[3] + 2] - H[q[2] + 2]);
      return { side: q[0], t: q[1], s: q[2], a: q[3], L1, L2, dMax: Math.sqrt(L1 * L1 + L2 * L2 + 2 * L1 * L2 * C5), dMin: Math.sqrt(L1 * L1 + L2 * L2 + 2 * L1 * L2 * C120), fr: [{ R: new Array(9), p: [0, 0, 0] }, { R: new Array(9), p: [0, 0, 0] }, { R: new Array(9), p: [0, 0, 0] }], T: [0, 0, 0], w: 0, ok: false }; }));
    const KS = this.ks || (this.ks = { frames: 0, kMin: 999, kMax: 0, poleBad: 0, behind: 0, footBad: 0, kStep: 0 });
    let drop = 0;
    for (const L of legs) {
      const p = P[L.side], lg = L.side === 'l' ? this.lgL : this.lgR, ax = W[L.a], ay = W[L.a + 1], az = W[L.a + 2], rest = H[L.a + 1];
      if (p.hold > 0) p.hold -= dt;
      const want = (moving ? !!(lg && lg.st) : true) && p.hold <= 0;
      if (!want && p.on) p.on = false;
      if (want && !p.on) { const bl = p.w > 0.01 && L.ok, mx = bl ? L.T[0] : ax, mz = bl ? L.T[2] : az; p.y = bl ? L.T[1] : ay; p.on = true; p.w = Math.max(p.w, 0.001); p.x = X.x + sc * (cf * mx + sf * mz); p.z = X.z + sc * (-sf * mx + cf * mz); p.yaw = X.f; p.fresh = !bl; }
      // the weight eases in and out over about 120 ms; a fresh plant is already where the foot is, so it may snap
      if (p.on) p.w = p.fresh ? 1 : Math.min(1, p.w + dt * 8.3); else p.w = Math.max(0, p.w - dt * 8.3); p.fresh = false;
      { let yT = rest; if (p.on) { const hx0 = W[L.t], hz0 = W[L.t + 2], dxw0 = (p.x - X.x) / sc, dzw0 = (p.z - X.z) / sc, tx0 = cf * dxw0 - sf * dzw0, tz0 = sf * dxw0 + cf * dzw0, hor0 = Math.hypot(tx0 - hx0, tz0 - hz0); if (tz0 < hz0 - 0.08) { const v = Math.sqrt(Math.max(0, L.dMax * L.dMax * 0.98 - hor0 * hor0)); yT = clamp(W[L.t + 1] - v, rest, rest + 0.11); } } p.y = lerp(p.y, yT, 1 - Math.exp(-dt * 16)); p.lift = p.y - rest; }
      const dxw = (p.x - X.x) / sc, dzw = (p.z - X.z) / sc, tx = cf * dxw - sf * dzw, tz = sf * dxw + cf * dzw;
      if (p.on) { // out of comfortable reach, too far behind the hip, folded under, or the toes turned too far from the facing: let go and step
        const hx = W[L.t], hz = W[L.t + 2], hor = Math.hypot(tx - hx, tz - hz), Lm = L.L1 + L.L2, d3 = Math.hypot(tx - hx, p.y - W[L.t + 1], tz - hz);
        if (hor > Lm * 0.9 || tz - hz < (moving ? -0.56 : -0.33) || d3 < L.dMin + 0.03 || Math.abs(angDiff(p.yaw, X.f)) > 0.66 || (!moving && Math.hypot(tx - ax, tz - az) > 0.36)) { p.on = false; p.hold = moving ? 0 : 0.16; }
        else { const need = W[L.t + 1] - (p.y + Math.sqrt(Math.max(0, L.dMax * L.dMax * 0.98 - hor * hor))); if (need > drop) drop = need; if (tz - hz < -0.35) KS.behind++; }
      }
      const w = p.w * p.w * (3 - 2 * p.w); L.T[0] = lerp(ax, tx, w); L.T[1] = lerp(ay, p.y, w); L.T[2] = lerp(az, tz, w); L.w = w; L.on = p.on; L.lift = Math.max(0, p.lift || 0) * w; L.yaw = angDiff(X.f, p.yaw);
    }
    this.dropS = lerp(this.dropS || 0, Math.min(0.3, drop), 1 - Math.exp(-dt * 5)); if (this.dropS > 1e-4) { Tr[ix.hips + 1] -= this.dropS; f.solve(); }
    // pole: the pelvis' forward direction, flattened
    const R = f.R, h9 = ix.hips * 3; let fx = R[h9 + 2], fz = R[h9 + 8]; { const l = Math.hypot(fx, fz) || 1; fx /= l; fz /= l; if (fz < 0.5) { fx = 0; fz = 1; } }
    const fr = {};
    for (const L of legs) {
      const t9 = L.t * 3, s9 = L.s * 3, a9 = L.a * 3;
      const hx = W[L.t], hy = W[L.t + 1], hz = W[L.t + 2], kx = W[L.s] - hx, ky = W[L.s + 1] - hy, kz = W[L.s + 2] - hz;
      let dx = L.T[0] - hx, dy = L.T[1] - hy, dz = L.T[2] - hz, d = Math.hypot(dx, dy, dz) || 1e-6; dx /= d; dy /= d; dz /= d; d = clamp(d, L.dMin, L.dMax);
      { // the knee angle follows through a critically damped spring and never turns faster than 400 degrees a second
        const want = Math.acos(clamp((d * d - L.L1 * L.L1 - L.L2 * L.L2) / (2 * L.L1 * L.L2), -1, 1));
        if (L.fs === undefined || dt <= 0 || dt > 0.1) { L.fs = want; L.fv = 0; }
        else { const om = 34, prev = L.fs; L.fv += (om * om * (want - L.fs) - 2 * om * L.fv) * dt; L.fs += L.fv * dt; const cap = 400 * PI / 180 * dt; if (L.fs - prev > cap) { L.fs = prev + cap; L.fv = cap / dt; } else if (L.fs - prev < -cap) { L.fs = prev - cap; L.fv = -cap / dt; }
          L.fs = clamp(L.fs, 5 * PI / 180, 120 * PI / 180); const st = Math.abs(L.fs - prev) * 180 / PI; if (st > KS.kStep) KS.kStep = st; }
        d = Math.sqrt(L.L1 * L.L1 + L.L2 * L.L2 + 2 * L.L1 * L.L2 * Math.cos(L.fs)); }
      const a = (L.L1 * L.L1 - L.L2 * L.L2 + d * d) / (2 * d), h = Math.sqrt(Math.max(0, L.L1 * L.L1 - a * a)), pd = fx * dx + fz * dz;
      let px = fx - dx * pd, py = -dy * pd, pz = fz - dz * pd, pl = Math.hypot(px, py, pz); if (pl < 0.05) { px = 0; py = 1; pz = 0; const q = dy; px -= dx * q; py -= dy * q; pz -= dz * q; pl = Math.hypot(px, py, pz) || 1; } px /= pl; py /= pl; pz /= pl;
      const Kx = hx + dx * a + px * h, Ky = hy + dy * a + py * h, Kz = hz + dz * a + pz * h, Tx = hx + dx * d, Ty = hy + dy * d, Tz = hz + dz * d;
      const F0 = L.fr[0], F1 = L.fr[1], F2 = L.fr[2], k1 = Math.hypot(kx, ky, kz) || 1;
      rotUV(kx / k1, ky / k1, kz / k1, (Kx - hx) / L.L1, (Ky - hy) / L.L1, (Kz - hz) / L.L1, R, t9, F0.R); F0.p[0] = hx; F0.p[1] = hy; F0.p[2] = hz;
      const ux = W[L.a] - W[L.s], uy = W[L.a + 1] - W[L.s + 1], uz = W[L.a + 2] - W[L.s + 2], u1 = Math.hypot(ux, uy, uz) || 1;
      rotUV(ux / u1, uy / u1, uz / u1, (Tx - Kx) / L.L2, (Ty - Ky) / L.L2, (Tz - Kz) / L.L2, R, s9, F1.R); F1.p[0] = Kx; F1.p[1] = Ky; F1.p[2] = Kz;
      // foot: flat on the ground at the yaw it was planted with, blended with the animated foot while the pin eases
      { const yw = clamp(L.yaw, -0.7, 0.7), c = Math.cos(yw), s = Math.sin(yw), w = L.w, pt = Math.asin(clamp(L.lift / 0.2, 0, 0.6)), cp = Math.cos(pt), sp = Math.sin(pt), G0 = [c, s * sp, s * cp, 0, cp, -sp, -s, c * sp, c * cp]; for (let i = 0; i < 9; i++) F2.R[i] = lerp(R[a9 + i], G0[i], w); }
      F2.p[0] = Tx; F2.p[1] = Ty; F2.p[2] = Tz;
      fr[L.t / 3] = F0; fr[L.s / 3] = F1; fr[L.a / 3] = F2; L.T[0] = Tx; L.T[1] = Ty; L.T[2] = Tz; L.ok = true;
      // numbers for review
      const cosF = clamp(((Kx - hx) * (Tx - Kx) + (Ky - hy) * (Ty - Ky) + (Kz - hz) * (Tz - Kz)) / (L.L1 * L.L2), -1, 1), flex = Math.acos(cosF) * 180 / PI; if (flex < KS.kMin) KS.kMin = flex; if (flex > KS.kMax) KS.kMax = flex;
      if (flex > 8) { const mx = hx + dx * a, my = hy + dy * a, mz = hz + dz * a, ox = Kx - mx, oz = Kz - mz, ol = Math.hypot(ox, Ky - my, oz) || 1; const fw = ox * fx + oz * fz, lat = Math.abs(ox * fz - oz * fx); if (Math.hypot(ox, oz) > 0.03 && (fw <= 0 || Math.atan2(lat, fw) > 25 * PI / 180)) KS.poleBad++; }
      if (L.on && Math.abs(L.yaw) > 0.7) KS.footBad++;
    }
    KS.frames++; f.free = fr; f.solve(); f.free = null;
  }
    }
