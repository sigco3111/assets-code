/* LANTERNFALL - effects: particles, projectiles, ground marks, loot, floaters */
LF.fx = (function () {
  const F = {}; let scene, cam;
  const NA = 3200, NS = 900; // additive sparks/embers, soft smoke/dust
  function mkPoints(n, additive) {
    const g = new THREE.BufferGeometry(), pos = new Float32Array(n * 3), col = new Float32Array(n * 4), size = new Float32Array(n);
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage)); g.setAttribute('aCol', new THREE.BufferAttribute(col, 4).setUsage(THREE.DynamicDrawUsage)); g.setAttribute('aSize', new THREE.BufferAttribute(size, 1).setUsage(THREE.DynamicDrawUsage));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    const m = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, uniforms: { uScale: { value: 1000 } },
      vertexShader: 'attribute vec4 aCol; attribute float aSize; varying vec4 vC; uniform float uScale; void main(){ vC = aCol; vec4 mv = modelViewMatrix * vec4(position,1.); gl_Position = projectionMatrix * mv; gl_PointSize = clamp(aSize * uScale / max(-mv.z, .1), 0., 220.); }',
      fragmentShader: additive ? 'varying vec4 vC; void main(){ vec2 d = gl_PointCoord - .5; float r = dot(d,d)*4.; float a = exp(-r*3.5) * (1.-smoothstep(.7,1.,r)); gl_FragColor = vec4(vC.rgb * a * vC.a, 1.); }'
        : 'varying vec4 vC; void main(){ vec2 d = gl_PointCoord - .5; float r = dot(d,d)*4.; float a = (1.-smoothstep(.1,1.,r)) * vC.a; gl_FragColor = vec4(vC.rgb, a); }' });
    const p = new THREE.Points(g, m); p.frustumCulled = false; p.renderOrder = additive ? 20 : 15;
    return { p, pos, col, size, n, g, live: 0, P: [] };
  }
  let A, S; const pool = [];
  function spawn(sys, x, y, z, vx, vy, vz, life, size, r, g, b, a, grav, drag, grow, kind) {
    if (LF.quiet) return; const L = sys.P; if (L.length >= sys.n) return;
    const o = pool.pop() || {}; o.x = x; o.y = y; o.z = z; o.vx = vx; o.vy = vy; o.vz = vz; o.t = 0; o.life = life; o.size = size; o.r = r; o.g = g; o.b = b; o.a = a; o.grav = grav; o.drag = drag; o.grow = grow || 0; o.kind = kind || 0; L.push(o);
  }
  function stepSys(sys, dt) {
    const L = sys.P, pos = sys.pos, col = sys.col, size = sys.size; let n = 0;
    for (let i = 0; i < L.length; i++) {
      const o = L[i]; o.t += dt; if (o.t >= o.life) { pool.push(o); L[i] = L[L.length - 1]; L.pop(); i--; continue; }
      o.vy -= o.grav * dt; const d = Math.exp(-o.drag * dt); o.vx *= d; o.vy *= d; o.vz *= d; o.x += o.vx * dt; o.y += o.vy * dt; o.z += o.vz * dt;
      if (o.y < 0.02 && o.grav > 0) { o.y = 0.02; o.vy *= -0.3; o.vx *= 0.5; o.vz *= 0.5; }
      const u = o.t / o.life, fade = o.kind === 1 ? Math.sin(u * PI) : (o.kind === 2 ? (u < 0.15 ? u / 0.15 : 1 - (u - 0.15) / 0.85) : 1 - u * u);
      pos[n * 3] = o.x; pos[n * 3 + 1] = o.y; pos[n * 3 + 2] = o.z; col[n * 4] = o.r; col[n * 4 + 1] = o.g; col[n * 4 + 2] = o.b; col[n * 4 + 3] = o.a * fade; size[n] = o.size * (1 + o.grow * u); n++;
    }
    sys.g.setDrawRange(0, n); sys.g.attributes.position.needsUpdate = true; sys.g.attributes.aCol.needsUpdate = true; sys.g.attributes.aSize.needsUpdate = true;
  }
  const rnd = (a) => (Math.random() - 0.5) * 2 * a;
  /* ----- emitters ----- */
  F.sparks = function (x, y, z, n, col, speed, dx, dz) {
    col = col || [3.5, 2.0, 0.7]; speed = speed || 4;
    for (let i = 0; i < n; i++) spawn(A, x, y, z, rnd(speed) + (dx || 0) * speed, Math.random() * speed * 0.9, rnd(speed) + (dz || 0) * speed, 0.18 + Math.random() * 0.35, 0.05 + Math.random() * 0.05, col[0], col[1], col[2], 1, 12, 1.5, -0.5);
  };
  F.embers = function (x, y, z, n, col, spread, up) {
    col = col || [3.0, 1.2, 0.25];
    for (let i = 0; i < n; i++) spawn(A, x + rnd(spread || 0.3), y + rnd((spread || 0.3) * 0.5), z + rnd(spread || 0.3), rnd(0.5), (up || 1) * (0.5 + Math.random() * 1.4), rnd(0.5), 0.7 + Math.random() * 1.3, 0.035 + Math.random() * 0.05, col[0], col[1], col[2], 1, -0.3, 0.6, -0.6, 1);
  };
  F.dust = function (x, y, z, n, col, spread, speed) {
    col = col || [0.09, 0.08, 0.07];
    for (let i = 0; i < n; i++) spawn(S, x + rnd(spread || 0.3), y + Math.random() * 0.25, z + rnd(spread || 0.3), rnd(speed || 1.2), Math.random() * 0.7, rnd(speed || 1.2), 0.7 + Math.random() * 0.9, 0.5 + Math.random() * 0.6, col[0], col[1], col[2], 0.28, -0.1, 1.8, 1.4, 2);
  };
  F.smoke = function (x, y, z, n, col) {
    col = col || [0.05, 0.05, 0.055];
    for (let i = 0; i < n; i++) spawn(S, x + rnd(0.2), y + rnd(0.2), z + rnd(0.2), rnd(0.3), 0.5 + Math.random() * 0.8, rnd(0.3), 1.2 + Math.random() * 1.2, 0.45 + Math.random() * 0.4, col[0], col[1], col[2], 0.3, -0.2, 0.8, 1.8, 2);
  };
  F.chips = function (x, y, z, n, col, speed) { // solid bits: splinters, stone chips, leaves
    for (let i = 0; i < n; i++) spawn(S, x, y, z, rnd(speed || 3), 1 + Math.random() * (speed || 3), rnd(speed || 3), 0.5 + Math.random() * 0.6, 0.05 + Math.random() * 0.06, col[0], col[1], col[2], 1, 13, 0.8, 0);
  };
  F.frost = function (x, y, z, n, spread) {
    for (let i = 0; i < n; i++) spawn(A, x + rnd(spread || 0.4), y + rnd(0.3), z + rnd(spread || 0.4), rnd(2), Math.random() * 2, rnd(2), 0.3 + Math.random() * 0.6, 0.04 + Math.random() * 0.05, 1.2, 2.2, 3.4, 1, 5, 2.5, -0.4);
  };
  F.glow = function (x, y, z, size, col, life) { spawn(A, x, y, z, 0, 0, 0, life || 0.25, size, col[0], col[1], col[2], 1, 0, 0, 0.6, 1); };
  /* ----- flash light ----- */
  let flT = 0, flDur = 0.2, flI = 0;
  F.flash = function (x, y, z, col, intensity, dur) {
    if (LF.quiet) return; const L = LF.world.fxLight; if (flT > 0 && flI * (flT / flDur) > intensity) return;
    L.position.set(x, y, z); L.color.setRGB(col[0], col[1], col[2]); flI = intensity; flDur = dur || 0.25; flT = flDur;
  };
  /* ----- meshes: rings, arcs, projectiles, loot ----- */
  const rings = [], arcs = [], projs = [], loots = [], marks = [];
  let ringGeo, arcGeo, discGeo, arrowGeo, orbGeo, lootGeo, shardGeo;
  function addMat(col, op) { return new THREE.MeshBasicMaterial({ color: new THREE.Color(col[0], col[1], col[2]), transparent: true, opacity: op === undefined ? 1 : op, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }); }
  F.ring = function (x, z, r0, r1, dur, col, y) {
    if (LF.quiet) return; let o = rings.find(q => !q.on);
    if (!o) { if (rings.length > 40) return; o = { m: new THREE.Mesh(ringGeo, addMat([1, 1, 1])) }; o.m.renderOrder = 18; scene.add(o.m); rings.push(o); }
    o.on = true; o.t = 0; o.dur = dur; o.r0 = r0; o.r1 = r1; o.m.visible = true; o.m.position.set(x, (y || 0.06), z); o.m.material.color.setRGB(col[0], col[1], col[2]); o.col = col;
  };
  // sweeping blade arc in the model's facing plane
  F.arc = function (x, y, z, face, radius, a0, a1, tilt, col, dur) {
    if (LF.quiet) return; let o = arcs.find(q => !q.on);
    if (!o) { if (arcs.length > 24) return; o = { m: new THREE.Mesh(arcGeo.clone(), addMat([1, 1, 1])) }; o.m.geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5); o.m.frustumCulled = false; o.m.renderOrder = 19; scene.add(o.m); arcs.push(o); }
    o.on = true; o.t = 0; o.dur = dur || 0.16; o.m.visible = true; o.m.position.set(x, y, z); o.m.rotation.set(0, 0, 0); o.m.rotation.order = 'YXZ'; o.m.rotation.y = face; o.m.rotation.z = tilt || 0; o.m.scale.setScalar(radius); o.a0 = a0; o.a1 = a1; o.col = col || [1.6, 1.5, 1.3];
  };
  // ground marks: telegraphs, burning ground, frost
  F.mark = function (kind, x, z, r, dur) {
    if (LF.quiet) return null; let o = marks.find(q => !q.on && q.kind === kind);
    if (!o) {
      const col = kind === 'tele' ? [1.6, 0.25, 0.08] : kind === 'fire' ? [1.5, 0.5, 0.1] : kind === 'frost' ? [0.3, 0.7, 1.3] : [1.2, 0.9, 0.5];
      o = { kind, m: new THREE.Mesh(discGeo, new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, uniforms: { uT: { value: 0 }, uA: { value: 1 }, uC: { value: new THREE.Color(col[0], col[1], col[2]) }, uK: { value: kind === 'tele' ? 1 : (kind === 'click' ? 2 : 0) }, uP: { value: 0 } },
        vertexShader: 'varying vec2 vU; void main(){ vU = uv*2.-1.; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }',
        fragmentShader: `varying vec2 vU; uniform float uT, uA, uK, uP; uniform vec3 uC;
float h(vec2 p){ vec3 p3=fract(vec3(p.xyx)*.1031); p3+=dot(p3,p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }
float n(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(h(i),h(i+vec2(1.,0.)),f.x),mix(h(i+vec2(0.,1.)),h(i+vec2(1.,1.)),f.x),f.y); }
void main(){ float r = length(vU); if (r > 1.) discard; float a;
  if (uK > 1.5) { a = smoothstep(.12,.0,abs(r-.8)); }
  else if (uK > .5) { a = smoothstep(.06,.0,abs(r-.96))*1.2 + .16*step(r, uP) + smoothstep(.05,.0,abs(r-uP))*.7; }
  else { float q = n(vU*5. + vec2(0., -uT*1.6)) * n(vU*11. - uT*.9); a = (1.-smoothstep(.35,1.,r)) * (.04 + q*q*2.2) * .13; }
  gl_FragColor = vec4(uC * a * uA, 1.); }` })) };
      o.m.rotation.x = -PI / 2; o.m.renderOrder = 12; scene.add(o.m); marks.push(o);
    }
    o.on = true; o.t = 0; o.dur = dur; o.m.visible = true; o.m.position.set(x, 0.05, z); o.m.scale.setScalar(r); o.r = r; return o;
  };
  F.proj = function (kind, sx, sy, sz, tx, ty, tz, dur, arc, onHit) {
    if (LF.quiet) { if (onHit) onHit(tx, ty, tz); return {}; }
    let o = projs.find(q => !q.on && q.kind === kind);
    if (!o) {
      let m;
      if (kind === 'arrow') { m = new THREE.Mesh(arrowGeo, LF.world.propMat); m.castShadow = true; }
      else if (kind === 'lance') m = new THREE.Mesh(shardGeo, new THREE.MeshBasicMaterial({ color: new THREE.Color(2.5, 4.5, 7) }));
      else if (kind === 'flask') m = new THREE.Mesh(orbGeo, new THREE.MeshBasicMaterial({ color: new THREE.Color(3.5, 1.6, 0.4) }));
      else m = new THREE.Mesh(orbGeo, new THREE.MeshBasicMaterial({ color: kind === 'gloam' ? new THREE.Color(1.6, 5, 2.6) : new THREE.Color(6, 2.6, 0.7) }));
      o = { kind, m }; if (!LF.quiet || true) scene.add(m); projs.push(o);
    }
    o.on = true; o.t = 0; o.dur = Math.max(0.05, dur); o.s = [sx, sy, sz]; o.e = [tx, ty, tz]; o.arc = arc || 0; o.onHit = onHit; o.m.visible = !LF.quiet; o.m.scale.setScalar(kind === 'flask' ? 0.8 : kind === 'cinder' ? 0.35 : kind === 'ember' ? 0.75 : kind === 'gloam' ? 1.0 : 1); o.tgt = null;
    return o;
  };
  F.loot = function (x, z, grade, onGet) {
    if (LF.quiet) { if (onGet) onGet(); return; }
    const cols = [[0.9, 0.85, 0.7], [0.5, 0.9, 1.6], [2.2, 1.3, 0.3], [4.0, 1.2, 0.3], [1.5, 1.5, 1.2]];
    let o = loots.find(q => !q.on); if (!o) { if (loots.length > 30) { if (onGet) onGet(); return; } o = { m: new THREE.Mesh(lootGeo, new THREE.MeshBasicMaterial()) }; scene.add(o.m); loots.push(o); }
    const c = cols[grade]; o.m.material.color.setRGB(c[0], c[1], c[2]); o.on = true; o.t = 0; o.x = x; o.z = z; o.vx = rnd(1.6); o.vz = rnd(1.6); o.vy = 3.5 + Math.random() * 1.5; o.y = 0.8; o.grade = grade; o.onGet = onGet; o.m.visible = true; o.m.scale.setScalar(grade === 4 ? 0.5 : 0.8 + grade * 0.18); o.col = c;
  };
  /* ----- floaters (2D) ----- */
  const floats = []; let ctx, cv;
  F.float = function (x, y, z, text, col, size, rise) { if (LF.quiet) return; if (floats.length > 40) floats.shift(); let k = 0; for (const f of floats) if (f.t < 0.5 && Math.abs(f.x - x) < 1.2 && Math.abs(f.z - z) < 1.2) k++; y += k * 0.34; if (k > 3) return; floats.push({ x, y, z, text, col: col || '#e8dcc0', size: size || 15, t: 0, dur: 1.0, rise: rise || 1, ox: (k % 2 ? 1 : -1) * (6 + k * 9) }); };
  const v3 = new THREE.Vector3();
  F.project = function (x, y, z) { v3.set(x, y, z).project(cam); return [(v3.x * 0.5 + 0.5) * LF.gfx.cw, (-v3.y * 0.5 + 0.5) * LF.gfx.ch, v3.z]; };
  F.bars = []; // filled by the game each frame: {x,y,z,f,w,boss}
  F.init = function (sc, camera) {
    scene = sc; cam = camera; A = mkPoints(NA, true); S = mkPoints(NS, false); scene.add(S.p); scene.add(A.p);
    ringGeo = new THREE.RingGeometry(0.955, 1, 64); ringGeo.rotateX(-PI / 2);
    { // arc: a unit crescent in the XZ plane from angle 0..1 mapped per instance by morphing vertices each frame
      const n = 20, pos = new Float32Array((n + 1) * 2 * 3); arcGeo = new THREE.BufferGeometry(); arcGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage)); const idx = []; for (let i = 0; i < n; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 2, a + 1, a + 3); } arcGeo.setIndex(idx); arcGeo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5); arcGeo.userData.n = n;
    }
    discGeo = new THREE.PlaneGeometry(2, 2);
    { const g = new Geo(); g.mat(COL.wood, 0.7, 0, T_WOOD, 0); g.tr(0, 0, 0, PI / 2, 0, 0); g.tube([[0, -0.4, 0], [0, 0.4, 0]], 0.006, { seg: 4, sub: 1 }); g.mat(COL.iron, 0.4, 1, T_PLATE, 0); g.lathe([[0.012, 0.4], [0.008, 0.42], [0, 0.47]], 4); g.mat(COL.bone, 0.9, 0, T_CLOTH, 0); for (let i = 0; i < 3; i++) { const a = i / 3 * TAU; g.surf(1, 1, (u, v) => [Math.cos(a) * 0.02 * v, -0.4 + u * 0.1, Math.sin(a) * 0.02 * v]); } g.pop(); arrowGeo = g.toGeometry(); }
    orbGeo = new THREE.SphereGeometry(0.09, 10, 8); lootGeo = new THREE.OctahedronGeometry(0.11, 0);
    shardGeo = new THREE.ConeGeometry(0.07, 1.1, 5); shardGeo.rotateX(PI / 2);
    cv = document.getElementById('fx2d'); ctx = cv.getContext('2d');
  };
  F.resize = function () { const d = Math.min(2, window.devicePixelRatio || 1); cv.width = Math.round(window.innerWidth * d); cv.height = Math.round(window.innerHeight * d); ctx.setTransform(d, 0, 0, d, 0, 0); };
  let moteT = 0;
  F.update = function (dt, time, partyX, partyZ) {
    // ambient motes in the lantern light, drizzle
    const W = LF.world, lp = W.lantern.position;
    moteT += dt; if (moteT > 0.05 && !LF.quiet) { moteT = 0; const c = W.cur.mote; for (let i = 0; i < 2; i++) spawn(A, lp.x + rnd(7), 0.2 + Math.random() * 3.5, lp.z + rnd(7), rnd(0.25) + 0.3, rnd(0.1), rnd(0.25), 2.5 + Math.random() * 2, 0.02 + Math.random() * 0.025, c.r * 0.9, c.g * 0.7, c.b * 0.45, 0.7, 0, 0.1, 0, 1);
      const dz = W.cur.drizzle; if (dz > 0.02) for (let i = 0; i < Math.round(dz * 10); i++) spawn(A, lp.x + rnd(9), 5 + Math.random() * 2, lp.z + rnd(9), 0.6, -11, 0.2, 0.55, 0.022, 0.5, 0.55, 0.65, 0.5, 0, 0, 0); }
    stepSys(A, dt); stepSys(S, dt);
    const sc = LF.gfx.H / (2 * Math.tan(cam.fov * PI / 360)); A.p.material.uniforms.uScale.value = sc; S.p.material.uniforms.uScale.value = sc;
    if (flT > 0) { flT -= dt; W.fxLight.intensity = flI * Math.max(0, flT / flDur); } else W.fxLight.intensity = 0;
    for (const o of rings) if (o.on) { o.t += dt; const u = o.t / o.dur; if (u >= 1) { o.on = false; o.m.visible = false; continue; } const r = lerp(o.r0, o.r1, 1 - Math.pow(1 - u, 3)); o.m.scale.setScalar(r); const k = (1 - u) * (1 - u); o.m.material.color.setRGB(o.col[0] * k, o.col[1] * k, o.col[2] * k); }
    for (const o of arcs) if (o.on) {
      o.t += dt; const u = o.t / o.dur; if (u >= 1) { o.on = false; o.m.visible = false; continue; }
      const n = arcGeo.userData.n, P = o.m.geometry.attributes.position.array, head = lerp(o.a0, o.a1, Math.min(1, u * 1.6)), tail = lerp(o.a0, o.a1, Math.max(0, u * 1.6 - 0.6));
      for (let i = 0; i <= n; i++) { const t = i / n, a = lerp(tail, head, t), w = Math.sin(t * PI) * 0.16 + 0.01, r1 = 1, r0 = 1 - w; P[i * 6] = Math.sin(a) * r1; P[i * 6 + 1] = 0; P[i * 6 + 2] = Math.cos(a) * r1; P[i * 6 + 3] = Math.sin(a) * r0; P[i * 6 + 4] = 0; P[i * 6 + 5] = Math.cos(a) * r0; }
      o.m.geometry.attributes.position.needsUpdate = true; const k = 1 - u; o.m.material.color.setRGB(o.col[0] * k, o.col[1] * k, o.col[2] * k);
    }
    for (const o of marks) if (o.on) { o.t += dt; if (o.t >= o.dur) { o.on = false; o.m.visible = false; continue; } const u = o.t / o.dur, U = o.m.material.uniforms; U.uT.value = time; U.uP.value = u; U.uA.value = Math.min(1, o.t * 5) * Math.min(1, (o.dur - o.t) * 2.5) * (o.kind === 'tele' ? 0.75 + 0.25 * Math.sin(time * 14) : 1);
      if (o.kind === 'fire') { const nf = Math.min(6, Math.floor(dt * 60 * o.r) + (Math.random() < 0.5 ? 1 : 0)); for (let q = 0; q < nf; q++) { const a = Math.random() * TAU, d = Math.sqrt(Math.random()) * o.r * 0.85, fx = o.m.position.x + Math.cos(a) * d, fz = o.m.position.z + Math.sin(a) * d, hot = Math.random(); spawn(A, fx, 0.08, fz, rnd(0.15), 1.1 + Math.random() * 1.3, rnd(0.15), 0.35 + Math.random() * 0.35, 0.16 + Math.random() * 0.12, 1.5 + hot * 0.9, 0.42 + hot * 0.4, 0.05 + hot * 0.1, 0.55, -1.2, 1.4, -0.75, 1); if (Math.random() < 0.12) F.embers(fx, 0.3, fz, 1, null, 0.1, 1.6); } }
      if (o.kind === 'frost' && Math.random() < dt * 8) { const a = Math.random() * TAU, d = Math.sqrt(Math.random()) * o.r; F.frost(o.m.position.x + Math.cos(a) * d, 0.2, o.m.position.z + Math.sin(a) * d, 1, 0.1); } }
    for (const o of projs) if (o.on) {
      o.t += dt; let u = o.t / o.dur; if (o.tgt) { o.e[0] = o.tgt.x; o.e[2] = o.tgt.z; }
      if (u >= 1) { o.on = false; o.m.visible = false; if (o.onHit) o.onHit(o.e[0], o.e[1], o.e[2]); continue; }
      const x = lerp(o.s[0], o.e[0], u), z = lerp(o.s[2], o.e[2], u), y = lerp(o.s[1], o.e[1], u) + o.arc * 4 * u * (1 - u);
      const u2 = Math.min(1, u + 0.03), x2 = lerp(o.s[0], o.e[0], u2), z2 = lerp(o.s[2], o.e[2], u2), y2 = lerp(o.s[1], o.e[1], u2) + o.arc * 4 * u2 * (1 - u2);
      o.m.position.set(x, y, z); if (o.kind === 'arrow' || o.kind === 'lance') o.m.lookAt(x2 + (x2 - x) * 5, y2 + (y2 - y) * 5, z2 + (z2 - z) * 5);
      if (!LF.quiet) { if (o.kind === 'ember') { F.embers(x, y, z, 1, null, 0.05, 0.3); spawn(A, x, y, z, 0, 0, 0, 0.16, 0.3, 3.0, 1.2, 0.25, 0.6, 0, 0, 0, 1); } else if (o.kind === 'cinder') { spawn(A, x, y, z, 0, 0, 0, 0.14, 0.12, 3.0, 1.2, 0.25, 0.8, 0, 0, 0, 1); } else if (o.kind === 'gloam') spawn(A, x, y, z, rnd(0.3), rnd(0.3), rnd(0.3), 0.3, 0.3, 0.5, 2.0, 1.0, 0.8, 0, 0, 0, 1); else if (o.kind === 'lance') F.frost(x, y, z, 1, 0.05); else if (o.kind === 'flask') spawn(A, x, y, z, 0, 0, 0, 0.12, 0.2, 2.5, 1.0, 0.2, 0.6, 0, 0, 0, 1); }
    }
    for (const o of loots) if (o.on) {
      o.t += dt;
      if (o.t < 0.9) { o.vy -= 14 * dt; o.x += o.vx * dt; o.z += o.vz * dt; o.y += o.vy * dt; if (o.y < 0.15) { o.y = 0.15; o.vy *= -0.35; o.vx *= 0.5; o.vz *= 0.5; } }
      else { const k = Math.min(1, (o.t - 0.9) * 3.2), tx = partyX, tz = partyZ; o.x = lerp(o.x, tx, k * 0.25); o.z = lerp(o.z, tz, k * 0.25); o.y = lerp(o.y, 1.1, k * 0.25); if (Math.hypot(o.x - tx, o.z - tz) < 0.5 || o.t > 2.2) { o.on = false; o.m.visible = false; if (o.onGet) o.onGet(); continue; } }
      o.m.position.set(o.x, o.y, o.z); o.m.rotation.y += dt * 6; o.m.rotation.x += dt * 3;
      if (o.grade >= 2 && Math.random() < dt * 20) spawn(A, o.x, o.y, o.z, rnd(0.4), 0.5, rnd(0.4), 0.4, 0.06, o.col[0], o.col[1], o.col[2], 1, 0, 0, 0, 1);
    }
  };
  // 2D overlay: floaters and enemy bars
  F.draw2d = function (dt) {
    ctx.clearRect(0, 0, cv.width, cv.height);
    for (const b of F.bars) {
      const p = F.project(b.x, b.y, b.z); if (p[2] > 1) continue; const w = b.w, x = p[0] - w / 2, y = p[1];
      ctx.fillStyle = 'rgba(8,8,10,0.75)'; ctx.fillRect(x - 1, y - 1, w + 2, 6); ctx.fillStyle = b.elite ? '#c9a45a' : '#a3382c'; ctx.fillRect(x, y, w * clamp(b.f, 0, 1), 4);
      if (b.chill) { ctx.fillStyle = 'rgba(140,200,255,0.9)'; ctx.fillRect(x, y + 5, w, 1.5); }
    }
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (let i = 0; i < floats.length; i++) {
      const f = floats[i]; f.t += dt; if (f.t >= f.dur) { floats.splice(i, 1); i--; continue; }
      const p = F.project(f.x, f.y, f.z); if (p[2] > 1) continue; const u = f.t / f.dur, a = u < 0.1 ? u / 0.1 : 1 - Math.pow(Math.max(0, (u - 0.5) / 0.5), 2);
      const sz = f.size * (u < 0.12 ? 0.7 + u / 0.12 * 0.5 : 1.2 - Math.min(0.2, (u - 0.12) * 1.5));
      ctx.font = '600 ' + sz.toFixed(1) + 'px "Segoe UI","Malgun Gothic","Apple SD Gothic Neo",Tahoma,Verdana,sans-serif'; ctx.globalAlpha = clamp(a, 0, 1);
      ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,5,8,0.85)'; const y = p[1] - u * 44 * f.rise; ctx.strokeText(f.text, p[0] + f.ox, y); ctx.fillStyle = f.col; ctx.fillText(f.text, p[0] + f.ox, y);
    }
    ctx.globalAlpha = 1;
  };
  F.clear = function () { for (const o of rings) { o.on = false; o.m.visible = false; } for (const o of marks) { o.on = false; o.m.visible = false; } for (const o of projs) { o.on = false; o.m.visible = false; } for (const o of loots) { o.on = false; o.m.visible = false; } floats.length = 0; };
  F.shift = function (dx) { for (const sys of [A, S]) for (const o of sys.P) o.x -= dx; for (const o of rings) o.m.position.x -= dx; for (const o of marks) o.m.position.x -= dx; for (const o of projs) { o.s[0] -= dx; o.e[0] -= dx; } for (const o of loots) o.x -= dx; for (const f of floats) f.x -= dx; };
  return F;
})();
