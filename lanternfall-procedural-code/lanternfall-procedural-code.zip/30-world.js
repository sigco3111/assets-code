/* LANTERNFALL - world: ground, grass, sky, lights, props, waylights, reaches */
const GLSL_TERR = `
const float KW1 = 0.00153398;
float pathZ(float x){ return 2.4*sin(x*KW1*20.) + 1.3*sin(x*KW1*9.+1.7); }
float terrH(vec2 p){ float d = abs(p.y - pathZ(p.x)); float k = smoothstep(6.5,20.,d), far = smoothstep(30.,150.,d);
  float h1 = 1.6*sin(p.x*KW1*13.+p.y*.071+1.3) + 1.2*sin(p.x*KW1*31.-p.y*.113+4.1) + .5*sin(p.x*KW1*67.+p.y*.31) + .35*sin(-p.x*KW1*113.+p.y*.47+2.);
  float h2 = far*far*(14.+9.*sin(p.x*KW1*5.+p.y*.011)+6.*sin(p.x*KW1*11.-p.y*.023+1.));
  return k*h1*.6+h2; }
`;
const REACHES = [
  { name: '\ub0ae\uc740 \ud669\ubb34\uc9c0', fog: [0.0126, 0.0189, 0.0302], dens: 0.016, gA: 0x232612, gB: 0x3a341c, mud: 0x18150f, wet: 0.45, gr: [0x3c4420, 0x5f5a2c, 0x8c7c48], grassH: 1.0, moon: 1.0, cloud: 0.75, mote: [1.0, 0.8, 0.5], drizzle: 0.25,
    props: { rock: 5, standing: 1.2, tree: 1.4, wall: 2.2, cairn: 0.8, fence: 1.4 } },
  { name: '\ubb3c\uc5d0 \uc7a0\uae34 \ub2aa', fog: [0.0109, 0.0218, 0.0231], dens: 0.027, gA: 0x1a2414, gB: 0x2c3018, mud: 0x141310, wet: 1.0, gr: [0x33421f, 0x52592a, 0x76703c], grassH: 1.45, moon: 0.75, cloud: 0.9, mote: [0.6, 0.9, 0.7], drizzle: 0.6,
    props: { rock: 2, standing: 0.4, tree: 2.6, wall: 0.4, cairn: 0.3, fence: 2.2 } },
  { name: '\uace0\ubd84 \uad6c\ub989\uc9c0', fog: [0.0168, 0.0210, 0.0294], dens: 0.013, gA: 0x26281a, gB: 0x413c26, mud: 0x201a13, wet: 0.2, gr: [0x424626, 0x6a6436, 0x9a8a58], grassH: 0.75, moon: 1.35, cloud: 0.5, mote: [0.8, 0.85, 1.0], drizzle: 0.0,
    props: { rock: 4, standing: 4.5, tree: 0.5, wall: 1.2, cairn: 3.0, fence: 0.3 } },
  { name: '\uac00\uc2dc\uc232', fog: [0.0092, 0.0126, 0.0168], dens: 0.024, gA: 0x1c1c10, gB: 0x2c2616, mud: 0x17110c, wet: 0.5, gr: [0x2e3418, 0x4a4422, 0x665a30], grassH: 0.9, moon: 0.6, cloud: 0.95, mote: [0.9, 0.7, 0.4], drizzle: 0.35,
    props: { rock: 3, standing: 0.5, tree: 7.5, wall: 0.8, cairn: 0.5, fence: 0.8 } },
  { name: '\uc7bf\ube5b \ubc14\uc704\uc0b0', fog: [0.0231, 0.0189, 0.0176], dens: 0.019, gA: 0x24211d, gB: 0x383129, mud: 0x1e1a17, wet: 0.1, gr: [0x3a352a, 0x5a5040, 0x7a6a50], grassH: 0.5, moon: 1.1, cloud: 0.7, mote: [1.0, 0.5, 0.2], drizzle: 0.0,
    props: { rock: 9, standing: 2.0, tree: 1.2, wall: 0.6, cairn: 1.5, fence: 0.2 } }
];

LF.world = (function () {
  const W = {}; let scene, propMat, grass, grassU, groundU, sky, skyU, near, far;
  const cur = { fog: new THREE.Color(), dens: 0.016, gA: new THREE.Color(), gB: new THREE.Color(), mud: new THREE.Color(), wet: 0.4, g1: new THREE.Color(), g2: new THREE.Color(), g3: new THREE.Color(), grassH: 1, moon: 1, cloud: 0.7, mote: new THREE.Color(), drizzle: 0 };
  let tgt = REACHES[0]; W.cur = cur; W.reachIdx = 0;
  const MOON_DIR = new THREE.Vector3(0.50, 0.40, -0.77).normalize(); W.MOON_DIR = MOON_DIR;
  const chunks = new Map(), CH = 20; W.waylights = [];
  const geoCache = {};

  /* ----- prop geometry ----- */
  function gRock(seed, sx, sy, sz, col) {
    const g = new Geo(), r = mulberry(seed), ox = r() * 50, oy = r() * 50;
    g.mat(col || C(0x4a4a46), 0.92, 0, T_STONE, 0);
    g.surf(14, 9, (u, v) => {
      const a = u * TAU, b = (v - 0.5) * PI, cb = Math.cos(b), x = Math.cos(a) * cb, y = Math.sin(b), z = Math.sin(a) * cb;
      const d = 0.72 + 0.5 * fbm3(x * 1.3 + ox, y * 1.3 + oy, z * 1.3, 3) + 0.12 * Math.round(vnoise3(x * 2 + oy, y * 2, z * 2 + ox) * 2);
      return [x * d * sx, Math.max(-0.25 * sy, y * d * sy), z * d * sz];
    }, { closeU: true });
    return g;
  }
  function gStanding(seed) {
    const g = new Geo(), r = mulberry(seed), h = 2.0 + r() * 1.9, rx = 0.34 + r() * 0.22, rz = 0.17 + r() * 0.12;
    g.mat(C(0x45474a), 0.93, 0, T_STONE, 0);
    g.tr(0, 0, 0, (r() - 0.5) * 0.22, r() * TAU, (r() - 0.5) * 0.3);
    const rings = []; const n = 6;
    for (let i = 0; i <= n; i++) { const t = i / n; rings.push({ y: -0.4 + t * (h + 0.4), rx: rx * (1 - 0.35 * t * t) * (0.9 + r() * 0.2), rz: rz * (1 - 0.3 * t) * (0.9 + r() * 0.2), x: (r() - 0.5) * 0.08, z: (r() - 0.5) * 0.05, sq: 3.2 }); }
    rings.push({ y: h + 0.06, rx: rx * 0.3, rz: rz * 0.35, x: 0.04, sq: 2.5 });
    g.loft(rings, { seg: 12, sub: 2, cap1: true }); g.pop();
    return g;
  }
  function gTree(seed) {
    const g = new Geo(), r = mulberry(seed);
    g.mat(C(0x2a221b), 0.95, 0, T_PEAT, 0);
    const branch = (p, d, len, rad, depth) => {
      const pts = [p.slice()]; let q = p.slice(), dir = d.slice(); const n = 4;
      for (let i = 0; i < n; i++) {
        dir[0] += 0.22 + (r() - 0.5) * 0.5; dir[1] += (r() - 0.35) * 0.35; dir[2] += (r() - 0.5) * 0.5; const l = Math.hypot(dir[0], dir[1], dir[2]); dir = dir.map(v => v / l);
        q = [q[0] + dir[0] * len / n, q[1] + dir[1] * len / n, q[2] + dir[2] * len / n]; pts.push(q);
      }
      g.tube(pts, t => rad * (1 - t * 0.6), { seg: depth > 1 ? 8 : 5, sub: 2 });
      if (depth > 0) {
        const kids = depth > 2 ? 3 : 2 + (r() < 0.4 ? 1 : 0);
        for (let k = 0; k < kids; k++) {
          const at = pts[1 + Math.floor(r() * 3) + (k === 0 ? 1 : 0)] || pts[n];
          const nd = [dir[0] + (r() - 0.5) * 1.6, dir[1] + (r() - 0.2) * 0.9, dir[2] + (r() - 0.5) * 1.6]; const l = Math.hypot(nd[0], nd[1], nd[2]);
          branch(at, nd.map(v => v / l), len * (0.55 + r() * 0.2), rad * (k === 0 ? 0.62 : 0.45), depth - 1);
        }
      }
    };
    branch([0, -0.3, 0], [0.05, 1, 0], 2.6 + r() * 1.6, 0.16 + r() * 0.1, 4);
    return g;
  }
  function gWall(seed) {
    const g = new Geo(), r = mulberry(seed), L = 4.2;
    const broke = r() < 0.5 ? r() * L : -9;
    for (let c = 0; c < 5; c++) {
      let x = -L / 2 + (c % 2) * 0.15;
      while (x < L / 2) {
        const w = 0.26 + r() * 0.26, h = 0.15 + r() * 0.07, d = 0.3 + r() * 0.14;
        const gap = Math.abs(x + L / 2 - broke) < 0.5 + c * 0.22;
        if (!(gap && c > 0) && !(c === 4 && r() < 0.25)) {
          const s = 0.35 + r() * 0.3; g.mat([s * 0.2 + 0.03, s * 0.2 + 0.03, s * 0.2 + 0.03], 0.93, 0, T_STONE, 0);
          g.tr(x + w / 2, c * 0.2 + (r() - 0.5) * 0.02, (r() - 0.5) * 0.08, (r() - 0.5) * 0.14, (r() - 0.5) * 0.3, (r() - 0.5) * 0.12);
          if (c === 4) g.tr(0, 0, 0, 0, 0, 1.2, 0.8, 1.6, 1);
          g.loft([{ y: 0, rx: w / 2 * 0.85, rz: d / 2 * 0.85, sq: 3 }, { y: h * 0.5, rx: w / 2, rz: d / 2, sq: 3.5 }, { y: h, rx: w / 2 * 0.8, rz: d / 2 * 0.82, sq: 3 }], { seg: 8, sub: 1, cap0: true, cap1: true });
          if (c === 4) g.pop(); g.pop();
        } else if (gap && c === 1 && r() < 0.7) { // tumbled stones
          g.mat(C(0x444444), 0.93, 0, T_STONE, 0); g.tr(x, 0.05, 0.4 + r() * 0.7, r(), r() * 3, r());
          g.loft([{ y: 0, rx: w / 2, rz: d / 2, sq: 3 }, { y: h, rx: w / 2 * 0.8, rz: d / 2 * 0.8, sq: 3 }], { seg: 8, sub: 1, cap0: true, cap1: true }); g.pop();
        }
        x += w + 0.015;
      }
    }
    return g;
  }
  function gCairn(seed) {
    const g = new Geo(), r = mulberry(seed); let y = 0; const n = 5 + Math.floor(r() * 4);
    for (let i = 0; i < n; i++) {
      const s = 0.42 * (1 - i / n * 0.72) * (0.85 + r() * 0.3), h = 0.1 + r() * 0.07, c = 0.16 + r() * 0.12;
      g.mat([c, c, c * 0.98], 0.93, 0, T_STONE, 0); g.tr((r() - 0.5) * 0.06, y, (r() - 0.5) * 0.06, (r() - 0.5) * 0.12, r() * TAU, (r() - 0.5) * 0.12);
      g.loft([{ y: 0, rx: s * 0.8, rz: s * 0.6, sq: 2.6 }, { y: h * 0.5, rx: s, rz: s * 0.74, sq: 3 }, { y: h, rx: s * 0.75, rz: s * 0.55, sq: 2.6 }], { seg: 9, sub: 1, cap0: true, cap1: true }); g.pop();
      y += h * 0.9;
    }
    return g;
  }
  function gFence(seed) {
    const g = new Geo(), r = mulberry(seed);
    g.mat(C(0x3a3027), 0.9, 0, T_WOOD, 0);
    const tops = [];
    for (let i = 0; i < 3; i++) {
      const x = (i - 1) * 1.9 + (r() - 0.5) * 0.2, lean = (r() - 0.5) * 0.35, lz = (r() - 0.5) * 0.3, h = 1.0 + r() * 0.3;
      g.tube([[x, -0.3, 0], [x + lean * 0.5, h * 0.5, lz * 0.5], [x + lean, h, lz]], t => 0.055 - t * 0.012, { seg: 6, sub: 2 }); tops.push([x + lean * 0.8, h * 0.78, lz * 0.8]);
    }
    for (let i = 0; i < 2; i++) if (r() < 0.75) { const a = tops[i], b = tops[i + 1], sag = r() < 0.4; g.tube([a, [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2 - 0.03, (a[2] + b[2]) / 2 + 0.03], sag ? [b[0] - 0.3, 0.05, b[2] + 0.2] : b], 0.032, { seg: 5, sub: 2 }); }
    return g;
  }
  function gWaylight() {
    const g = new Geo(), iron = C(0x1d1c1b);
    // plinth
    g.mat(C(0x47474a), 0.93, 0, T_STONE, 0);
    g.loft([{ y: -0.2, rx: 0.52, rz: 0.52, sq: 5 }, { y: 0.16, rx: 0.5, rz: 0.5, sq: 5 }, { y: 0.2, rx: 0.4, rz: 0.4, sq: 5 }, { y: 0.44, rx: 0.36, rz: 0.36, sq: 5 }], { seg: 12, sub: 1, cap1: true });
    g.mat(iron, 0.62, 0.85, T_PLATE, 0);
    g.lathe([[0.09, 0.44], [0.1, 0.5], [0.06, 0.56], [0.05, 1.2], [0.07, 1.24], [0.07, 1.3], [0.045, 1.34], [0.04, 2.9], [0.06, 2.94], [0.06, 3.0], [0.035, 3.04], [0.03, 3.5], [0.0, 3.62]], 8);
    // crook arm
    g.tube([[0, 3.3, 0], [0.12, 3.62, 0], [0.42, 3.78, 0], [0.7, 3.62, 0], [0.74, 3.38, 0]], 0.022, { seg: 6, sub: 4 });
    g.tube([[0, 2.95, 0], [0.25, 3.2, 0], [0.5, 3.6, 0]], 0.014, { seg: 5, sub: 3 });
    // lantern cage hanging at (0.74, 3.0..3.36)
    g.tr(0.74, 2.92, 0);
    g.lathe([[0.0, 0.46], [0.03, 0.44], [0.05, 0.4], [0.17, 0.33], [0.18, 0.31], [0.14, 0.31]], 6);
    g.lathe([[0.14, 0.0], [0.16, 0.0], [0.16, 0.03], [0.1, 0.03], [0.05, -0.03], [0.0, -0.04]], 6);
    for (let i = 0; i < 6; i++) { const a = i / 6 * TAU; g.tube([[Math.cos(a) * 0.145, 0.02, Math.sin(a) * 0.145], [Math.cos(a) * 0.145, 0.32, Math.sin(a) * 0.145]], 0.011, { seg: 4, sub: 1 }); }
    g.mat(C(0xffb45a), 0.4, 0, T_GLOW, 1.0);
    g.lathe([[0.0, 0.04], [0.125, 0.04], [0.125, 0.3], [0.0, 0.3]], 6);
    g.pop();
    return g;
  }
  W.gRock = gRock;
  function cached(kind, variant, make) { const k = kind + variant; if (!geoCache[k]) geoCache[k] = make().toGeometry(); return geoCache[k]; }

  /* ----- chunks ----- */
  function buildChunk(ci) {
    const grp = new THREE.Group(), r = mulberry((LF.seed | 0) * 7919 + ci * 104729 + 17), x0 = ci * CH, R = tgt.props;
    const put = (geo, x, z, s, ry, sink, rx) => {
      const m = new THREE.Mesh(geo, propMat); m.position.set(x, terrH(x, z) - (sink || 0), z); m.rotation.set(rx || 0, ry, 0); m.scale.setScalar(s); m.castShadow = true; m.receiveShadow = true; m.matrixAutoUpdate = false; m.updateMatrix(); grp.add(m); return m;
    };
    const side = () => r() < 0.62 ? -1 : 1; // more on the far side of the road (camera looks north)
    const zAt = (x, lo, hi, s) => pathZ(x) + s * (lo + Math.pow(r(), 1.6) * (hi - lo));
    const count = w => { const f = w * (0.6 + r() * 0.8); return Math.floor(f) + (r() < f % 1 ? 1 : 0); };
    for (let i = count(R.rock * 1.4); i-- > 0;) { const x = x0 + r() * CH, s = side(), big = r() < 0.3; put(cached('rock', Math.floor(r() * 5), () => gRock(11 + Math.floor(r() * 99), 0.5, 0.36, 0.42)), x, zAt(x, big ? 5.5 : 2.6, big ? 42 : 12, s), big ? 1.2 + r() * 2.6 : 0.22 + r() * 0.5, r() * TAU, 0.02); }
    for (let i = count(R.rock * 2.2); i-- > 0;) { const x = x0 + r() * CH; put(cached('rock', Math.floor(r() * 5), () => gRock(11 + Math.floor(r() * 99), 0.5, 0.36, 0.42)), x, pathZ(x) + (r() - 0.5) * 4.6, 0.05 + r() * 0.12, r() * TAU, 0.01); }
    for (let i = count(R.standing); i-- > 0;) { const x = x0 + r() * CH; put(cached('stand', Math.floor(r() * 4), () => gStanding(31 + Math.floor(r() * 99))), x, zAt(x, 6.5, 46, side()), 0.9 + r() * 0.7, r() * TAU, 0.1); }
    for (let i = count(R.tree); i-- > 0;) { const x = x0 + r() * CH; put(cached('tree', Math.floor(r() * 5), () => gTree(51 + Math.floor(r() * 99))), x, zAt(x, 6.5, 50, side()), 0.8 + r() * 0.9, r() * TAU, 0.1); }
    for (let i = count(R.cairn); i-- > 0;) { const x = x0 + r() * CH; put(cached('cairn', Math.floor(r() * 3), () => gCairn(71 + Math.floor(r() * 99))), x, zAt(x, 4.2, 24, side()), 0.8 + r() * 0.6, r() * TAU, 0.03); }
    if (r() < R.wall * 0.35) { // a run of wall, roughly along the road
      const s = side(), n = 2 + Math.floor(r() * 3); let off = 5.5 + r() * 9, x = x0 + r() * 4, ang = (r() - 0.5) * 0.5;
      for (let k = 0; k < n; k++) { const z = pathZ(x) + s * off; put(cached('wall', Math.floor(r() * 4), () => gWall(91 + Math.floor(r() * 99))), x, z, 1, -ang + Math.atan(pathDZ(x)) * -1, 0.04); x += 4.1 * Math.cos(ang); off += Math.sin(ang) * 4.1 * s; ang += (r() - 0.5) * 0.3; }
    }
    if (r() < R.fence * 0.3) { const s = side(), off = 3.4 + r() * 3; let x = x0 + r() * 6; for (let k = 0; k < 2 + Math.floor(r() * 2); k++) { put(cached('fence', Math.floor(r() * 4), () => gFence(111 + Math.floor(r() * 99))), x, pathZ(x) + s * off, 1, -Math.atan(pathDZ(x)), 0); x += 5.6; } }
    scene.add(grp); return grp;
  }
  function disposeChunk(g) { scene.remove(g); }

  /* ----- waylights ----- */
  W.addWaylight = function (x, lit) {
    const geo = cached('way', 0, gWaylight), mat = makeSurfMat(); mat.userData.u.uGlow.value = lit ? 6 : 0;
    const z = pathZ(x) - 3.1, m = new THREE.Mesh(geo, mat); m.position.set(x, 0, z); m.rotation.y = -PI / 2 + 0.3; m.castShadow = true; m.receiveShadow = true; scene.add(m);
    const light = new THREE.PointLight(0xffa24a, 0, 26, 1.7); light.position.set(x + 0.2, 3.1, z + 0.72); scene.add(light);
    const w = { x, z, mesh: m, mat, light, lit: !!lit, glow: lit ? 1 : 0, lp: new THREE.Vector3(x + 0.22, 3.1, z + 0.7) };
    W.waylights.push(w); return w;
  };
  W.clearWaylights = function () { for (const w of W.waylights) { scene.remove(w.mesh); scene.remove(w.light); w.mat.dispose(); } W.waylights.length = 0; };

  /* ----- init ----- */
  W.init = function (sc, renderer) {
    scene = sc; propMat = makeSurfMat(); W.propMat = propMat;
    // lights
    W.hemi = new THREE.HemisphereLight(0x2c4a7a, 0x0b0a08, 0.34); scene.add(W.hemi);
    const moon = W.moon = new THREE.DirectionalLight(0x8fb2f2, 2.0); moon.castShadow = true; moon.shadow.mapSize.set(2048, 2048);
    const sc2 = moon.shadow.camera; sc2.left = -24; sc2.right = 24; sc2.top = 24; sc2.bottom = -24; sc2.near = 1; sc2.far = 120; moon.shadow.bias = -0.0015; moon.shadow.normalBias = 0.09; moon.shadow.radius = 3;
    scene.add(moon); scene.add(moon.target);
    const lan = W.lantern = new THREE.PointLight(0xffb878, 40, 26, 1.25); lan.castShadow = true; lan.shadow.mapSize.set(1024, 1024); lan.shadow.camera.near = 0.42; lan.shadow.camera.far = 26; lan.shadow.bias = -0.004; lan.shadow.normalBias = 0.05; lan.shadow.radius = 2.5;
    lan.position.set(0, 2.5, 0); scene.add(lan);
    W.fxLight = new THREE.PointLight(0xffffff, 0, 14, 1.8); scene.add(W.fxLight);
    W.fill = new THREE.DirectionalLight(0x8a9ab8, 0.16); scene.add(W.fill); scene.add(W.fill.target);
    // environment (for metal): a dim night sky with a moon patch and a warm low glow
    const es = new THREE.Scene(), eg = new THREE.SphereGeometry(10, 24, 12);
    const em = new THREE.ShaderMaterial({ side: THREE.BackSide, uniforms: { m: { value: MOON_DIR } }, vertexShader: 'varying vec3 d; void main(){ d=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }',
      fragmentShader: 'varying vec3 d; uniform vec3 m; void main(){ vec3 n=normalize(d); float h=n.y; vec3 c=mix(vec3(.035,.05,.085), vec3(.012,.018,.035), smoothstep(-.1,.8,h)); c=mix(c, vec3(.02,.016,.012), smoothstep(.0,-.4,h)); c+=vec3(.75,.85,1.1)*pow(max(dot(n,m),0.),40.)*1.4; c+=vec3(.5,.25,.08)*pow(max(dot(n,normalize(vec3(-.3,.1,.9))),0.),6.)*.22; gl_FragColor=vec4(c,1.); }' });
    es.add(new THREE.Mesh(eg, em)); const pm = new THREE.PMREMGenerator(renderer); scene.environment = pm.fromScene(es, 0.04).texture; pm.dispose(); eg.dispose(); em.dispose();

    // ground
    const gU = groundU = { uGA: { value: cur.gA }, uGB: { value: cur.gB }, uMud: { value: cur.mud }, uWet: { value: 0.4 } };
    const gmat = new THREE.MeshStandardMaterial({ roughness: 1, metalness: 0, envMapIntensity: 1.0 });
    gmat.onBeforeCompile = sh => {
      Object.assign(sh.uniforms, gU);
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWp;\n' + GLSL_TERR)
        .replace('#include <beginnormal_vertex>', 'vec3 gw=(modelMatrix*vec4(position,1.)).xyz; float ge=.6; float hC=terrH(gw.xz);\nvec3 objectNormal=normalize(vec3(terrH(gw.xz-vec2(ge,0.))-terrH(gw.xz+vec2(ge,0.)),2.*ge,terrH(gw.xz-vec2(0.,ge))-terrH(gw.xz+vec2(0.,ge))));')
        .replace('#include <begin_vertex>', 'vec3 transformed=vec3(position.x,position.y+hC,position.z); vWp=vec3(gw.x,hC,gw.z);');
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
varying vec3 vWp; uniform vec3 uGA,uGB,uMud; uniform float uWet; float lfRough, lfH;
${GLSL_TERR}
float gh(vec2 p){ vec3 p3=fract(vec3(p.xyx)*.1031); p3+=dot(p3,p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }
float gn(vec2 p, float per){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); float x0=mod(i.x,per), x1=mod(i.x+1.,per);
  return mix(mix(gh(vec2(x0,i.y)),gh(vec2(x1,i.y)),f.x),mix(gh(vec2(x0,i.y+1.)),gh(vec2(x1,i.y+1.)),f.x),f.y); }
#define GN(p,f) gn((p)*(f), 4096.*(f))
`).replace('#include <color_fragment>', `#include <color_fragment>
{
  vec2 p = vWp.xz; float s = p.y - pathZ(p.x), dd = abs(s);
  float n0=GN(p,.125), n1=GN(p,.5), n2=GN(p,1.), n3=GN(p,4.), n4=GN(p,16.), n5=GN(p,64.);
  float edge = dd + (n2-.5)*1.5 + (n3-.5)*.5;
  float track = 1.-smoothstep(1.0, 2.5, edge);
  float rut = smoothstep(.2,.03, abs(dd-.62+(n2-.5)*.2)) * track;
  float hoof = smoothstep(.62,.8, n3) * track;
  float h = n3*.012 + n4*.012 + n5*.005 - rut*.05 - hoof*.03 + (1.-track)*(n2*.05 + n3*.03);
  vec3 heath = mix(uGA, uGB, smoothstep(.3,.7,n2)) * (.55+.9*n4);
  heath = mix(heath, vec3(.12,.1,.05), smoothstep(.55,.8,n0)*.45*(.5+n4));
  heath = mix(heath, vec3(.05,.035,.05)*1.2, smoothstep(.6,.75,GN(p,.25))*.5);
  vec3 mud = uMud*(.5+.7*n4)*(.8+.4*n1);
  vec3 col = mix(heath, mud, track*.92);
  float low = smoothstep(.62-.3*uWet, .78-.3*uWet, n1*.65+n0*.35);
  float wet = clamp(low*(.35+track*.8) + rut*uWet*.9 + hoof*uWet*.5, 0., 1.);
  float wn = wet + (n3-.5)*.05; float water = smoothstep(.74,.79, wn) * step(dd, 9.); float shore = smoothstep(.6,.79, wn) * step(dd, 9.);
  col *= mix(1., .5, wet); float rough = mix(.96, .42, wet*track + wet*.3);
  // pebbles
  vec2 pw = p*11. + vec2(n3, n4)*.9; vec2 pc = floor(pw), pf = fract(pw); vec2 pk = vec2(mod(pc.x,45056.),pc.y); float ph = gh(pk); vec2 po = vec2(gh(pk+3.1), gh(pk+7.7))*.6+.2;
  float pr = .1 + .3*gh(pk+1.7); float pd = length((pf-po)*vec2(1., .7+.6*gh(pk+5.)))/pr; float peb = step(.9-.12*track, ph)*smoothstep(1.,.55,pd)*(1.-water);
  col = mix(col, vec3(.05,.05,.048)*(.4+1.2*gh(pk+9.)), peb*.9); h += peb*.022*(1.-pd*pd); rough = mix(rough, .85, peb);
  col *= mix(1., .6, shore); rough = mix(rough, .3, shore*.8); h = mix(h, -.012, shore);
  col = mix(col, vec3(.008,.011,.014), water); rough = mix(rough, .035, water);
  diffuseColor.rgb = col; lfRough = rough; lfH = h*1.2*(1.-water);
}
`).replace('#include <roughnessmap_fragment>', 'float roughnessFactor = lfRough;')
        .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\n' + SURF_FNORMAL);
    };
    const ng = new THREE.PlaneGeometry(180, 110, 180, 110); ng.rotateX(-PI / 2);
    near = new THREE.Mesh(ng, gmat); near.receiveShadow = true; near.frustumCulled = false; scene.add(near);
    const fg = new THREE.PlaneGeometry(1100, 800, 138, 100); fg.rotateX(-PI / 2);
    far = new THREE.Mesh(fg, gmat); far.frustumCulled = false; far.position.y = -0.25; scene.add(far);

    // grass
    const TX = 72, TZ = 48, r = mulberry(4242), NC = 8600; const P = [], B = [], Rn = [], I = [];
    for (let c = 0; c < NC; c++) {
      const cx = r() * TX, cz = r() * TZ, kind = r(), tall = kind < 0.3, heath = kind > 0.72, n = tall ? 14 + Math.floor(r() * 14) : (heath ? 16 + Math.floor(r() * 10) : 7 + Math.floor(r() * 8)), rad = tall ? 0.1 + r() * 0.22 : (heath ? 0.16 + r() * 0.2 : 0.18 + r() * 0.3), hue = r(), ca = r() * TAU;
      for (let b = 0; b < n; b++) {
        const a = r() * TAU, d = Math.sqrt(r()) * rad, bx = cx + Math.cos(a) * d, bz = cz + Math.sin(a) * d;
        const h = tall ? 0.34 + r() * 0.5 : (heath ? (0.12 + r() * 0.14) * (1 - 0.5 * d / rad) : 0.1 + r() * 0.2), ang = tall ? a + (r() - 0.5) * 1.2 : r() * TAU, lean = tall ? 0.15 + d / rad * 0.75 + r() * 0.3 : (heath ? d / rad * 0.9 : r() * 0.8), wd = tall ? 0.011 + r() * 0.008 : (heath ? 0.02 + r() * 0.012 : 0.012 + r() * 0.01);
        const base = P.length / 3;
        const T = [0, 0.36, 0.7];
        for (let s = 0; s < 3; s++) { P.push(-1, T[s], 0, 1, T[s], 0); }
        P.push(0, 1, 0);
        for (let q = 0; q < 7; q++) { B.push(bx, bz, h); Rn.push(ang, lean, heath ? -0.2 - hue * 0.6 : (tall ? 0.55 + hue * 0.45 : hue * 0.5), wd); }
        I.push(base, base + 1, base + 2, base + 2, base + 1, base + 3, base + 2, base + 3, base + 4, base + 4, base + 3, base + 5, base + 4, base + 5, base + 6);
      }
    }
    const gg = new THREE.BufferGeometry(); gg.setAttribute('position', new THREE.BufferAttribute(new Float32Array(P), 3)); gg.setAttribute('aBase', new THREE.BufferAttribute(new Float32Array(B), 3)); gg.setAttribute('aRnd', new THREE.BufferAttribute(new Float32Array(Rn), 4));
    gg.setIndex(new THREE.BufferAttribute(new Uint32Array(I), 1)); gg.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    grassU = { uCenter: { value: new THREE.Vector3() }, uTile: { value: new THREE.Vector2(TX, TZ) }, uTime: { value: 0 }, uGrassH: { value: 1 }, uHeath: { value: 1 }, uGc1: { value: cur.g1 }, uGc2: { value: cur.g2 }, uGc3: { value: cur.g3 }, uPush: { value: [new THREE.Vector4(), new THREE.Vector4(), new THREE.Vector4(), new THREE.Vector4()] } };
    const grm = new THREE.MeshStandardMaterial({ roughness: 0.78, metalness: 0, side: THREE.DoubleSide, envMapIntensity: 0.6 });
    grm.onBeforeCompile = sh => {
      Object.assign(sh.uniforms, grassU);
      sh.vertexShader = sh.vertexShader.replace('#include <common>', `#include <common>
attribute vec3 aBase; attribute vec4 aRnd; uniform vec3 uCenter; uniform vec2 uTile; uniform float uTime, uGrassH, uHeath; uniform vec3 uGc1,uGc2,uGc3; varying vec3 vGc;
${GLSL_TERR}`).replace('#include <beginnormal_vertex>', `
vec2 gxz = mod(aBase.xy - uCenter.xz + .5*uTile, uTile) - .5*uTile + uCenter.xz;
float gdd = abs(gxz.y - pathZ(gxz.x));
float gkeep = smoothstep(1.2, 3.0, gdd + (fract(aRnd.x*7.31)-.5)*1.8);
vec2 gq = abs(gxz - uCenter.xz)/(.5*uTile); float gfade = 1.-smoothstep(.84,1.,max(gq.x,gq.y));
float gt = position.y;
float gH = aBase.z * gkeep * gfade * mix(1., uGrassH, step(.5, aRnd.z)) * (aRnd.z < 0. ? uHeath : 1.);
vec2 gdir = vec2(cos(aRnd.x), sin(aRnd.x));
float gwind = sin(uTime*1.1 + gxz.x*.31 + gxz.y*.2)*.5 + sin(uTime*2.3 + gxz.x*.9 - gxz.y*.6)*.3 + sin(uTime*5.1 + aRnd.x*9.)*.12;
float glean = aRnd.y + gwind*.26;
vec2 gld = normalize(gdir*.8 + vec2(.75,.2));
float ghz = gH*gt*gt*sin(clamp(glean,-1.4,1.4))*.9, gvt = gH*gt*(1.-.3*gt*abs(sin(glean)));
vec3 objectNormal = normalize(vec3(gdir.y*.5*position.x + gld.x*.25*gt, 1., -gdir.x*.5*position.x + gld.y*.25*gt));
`).replace('#include <begin_vertex>', `
vec3 transformed = vec3(gxz.x, terrH(gxz), gxz.y) + vec3(gdir.y,0.,-gdir.x)*position.x*aRnd.w*(1.-gt*.86) + vec3(gld.x*ghz, gvt, gld.y*ghz);
vGc = mix(mix(uGc1, uGc2, smoothstep(0.,.5,aRnd.z)), uGc3, smoothstep(.5,1.,aRnd.z)) * mix(.22, 1.05, gt) * (.8+.4*fract(aRnd.x*3.7));
if (aRnd.z < 0.) vGc = mix(vec3(.028,.02,.03), vec3(.07,.035,.06), -aRnd.z) * mix(.4, 1.3, gt);
`);
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vGc;')
        .replace('#include <color_fragment>', 'diffuseColor.rgb = vGc;')
        .replace('#include <normal_fragment_begin>', '#include <normal_fragment_begin>\nnormal = normalize(vNormal);');
    };
    grass = new THREE.Mesh(gg, grm); grass.frustumCulled = false; grass.receiveShadow = true; scene.add(grass);

    // sky
    skyU = W.skyU = { uMoon: { value: MOON_DIR }, uA: { value: new THREE.Color(0.006, 0.011, 0.024) }, uB: { value: new THREE.Color(0.03, 0.045, 0.07) }, uTime: { value: 0 }, uCloud: { value: 0.7 }, uMoonI: { value: 1 } };
    sky = new THREE.Mesh(new THREE.SphereGeometry(2000, 32, 16), new THREE.ShaderMaterial({ side: THREE.BackSide, depthWrite: false, uniforms: skyU,
      vertexShader: 'varying vec3 vD; void main(){ vD = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.); gl_Position = p.xyww; }',
      fragmentShader: `varying vec3 vD; uniform vec3 uMoon, uA, uB; uniform float uTime, uCloud, uMoonI;
float h(vec2 p){ vec3 p3=fract(vec3(p.xyx)*.1031); p3+=dot(p3,p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }
float n(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(h(i),h(i+vec2(1.,0.)),f.x),mix(h(i+vec2(0.,1.)),h(i+vec2(1.,1.)),f.x),f.y); }
float fb(vec2 p){ float s=0., a=.5; for(int i=0;i<5;i++){ s+=a*n(p); p=p*2.03+vec2(3.1,1.7); a*=.5; } return s; }
void main(){ vec3 d = normalize(vD); float hz = 1.-clamp(d.y,0.,1.);
  vec3 c = mix(uA, uB, pow(hz, 2.6));
  float m = max(dot(d, uMoon), 0.);
  vec2 uv = d.xz/(abs(d.y)+.18)*.9; float cl = fb(uv + vec2(uTime*.006, uTime*.002)); float cl2 = fb(uv*2.3 - vec2(uTime*.01,0.) + 9.);
  float dens = smoothstep(1.02-uCloud*.75, 1.25-uCloud*.6, cl+cl2*.45) * smoothstep(-.02,.08,d.y);
  float st = step(.9975, h(floor(d.xz/(abs(d.y)+.4)*420.))) * smoothstep(.05,.4,d.y);
  c += vec3(.55,.62,.8)*st*.5*(1.-dens);
  float disc = smoothstep(.99925,.99955,m);
  c += uMoonI*(vec3(.9,1.,1.25)*disc*4.*(1.-dens*.92) + vec3(.35,.45,.7)*(pow(m,400.)*.5 + pow(m,24.)*.11 + pow(m,4.)*.03));
  vec3 cc = mix(vec3(.012,.017,.03), vec3(.16,.2,.3)*uMoonI, pow(m,7.)*(1.-smoothstep(.2,.9,cl))*1.2 + .05);
  c = mix(c, cc, dens*.93);
  gl_FragColor = vec4(c,1.); }` }));
    sky.frustumCulled = false; sky.renderOrder = -10; scene.add(sky);
    W.setReach(0, true);
  };
  W.setReach = function (i, instant) {
    W.reachIdx = i % REACHES.length; tgt = REACHES[W.reachIdx]; W.tgt = tgt;
    if (instant) W.blend(1);
  };
  const tc = new THREE.Color();
  W.blend = function (k) {
    cur.fog.lerp(tc.setRGB(tgt.fog[0], tgt.fog[1], tgt.fog[2]), k); cur.dens = lerp(cur.dens, tgt.dens, k);
    cur.gA.lerp(tc.setRGB(...C(tgt.gA)), k); cur.gB.lerp(tc.setRGB(...C(tgt.gB)), k); cur.mud.lerp(tc.setRGB(...C(tgt.mud)), k); cur.wet = lerp(cur.wet, tgt.wet, k);
    cur.g1.lerp(tc.setRGB(...C(tgt.gr[0])), k); cur.g2.lerp(tc.setRGB(...C(tgt.gr[1])), k); cur.g3.lerp(tc.setRGB(...C(tgt.gr[2])), k);
    cur.grassH = lerp(cur.grassH, tgt.grassH, k); cur.moon = lerp(cur.moon, tgt.moon, k); cur.cloud = lerp(cur.cloud, tgt.cloud, k); cur.drizzle = lerp(cur.drizzle, tgt.drizzle, k);
    cur.mote.lerp(tc.setRGB(tgt.mote[0], tgt.mote[1], tgt.mote[2]), k);
  };
  let time = 0;
  W.update = function (dt, fx, fz, camX) {
    time += dt; W.blend(1 - Math.exp(-dt * 0.35));
    groundU.uWet.value = cur.wet; grassU.uGrassH.value = cur.grassH; grassU.uTime.value = time; skyU.uTime.value = time; skyU.uCloud.value = cur.cloud; skyU.uMoonI.value = cur.moon;
    W.moon.intensity = 2.0 * cur.moon; W.hemi.intensity = 0.4 + 0.1 * cur.moon;
    grassU.uCenter.value.set(fx + 6, 0, fz - 6);
    near.position.set(Math.round(fx), 0, Math.round(fz - 10)); far.position.set(Math.round(fx / 8) * 8, -0.25, Math.round((fz - 120) / 8) * 8);
    sky.position.set(fx, 0, fz); W.fill.position.set(fx - 6, 9, fz + 14); W.fill.target.position.set(fx, 0, fz); W.fill.target.updateMatrixWorld();
    // moon shadow follows focus, snapped to texels
    const tx = Math.round(fx / 0.5) * 0.5, tz = Math.round(fz / 0.5) * 0.5;
    W.moon.target.position.set(tx + 3, 0, tz); W.moon.position.set(tx + 3 + MOON_DIR.x * 60, MOON_DIR.y * 60, tz + MOON_DIR.z * 60); W.moon.target.updateMatrixWorld();
    // chunks
    const c0 = Math.floor((fx - 50) / CH), c1 = Math.floor((fx + 110) / CH);
    for (let c = c0; c <= c1; c++) { const key = c + LF.chunkBase; if (!chunks.has(key)) { const g = buildChunk(key); g.position.x = -LF.chunkBase * CH; g.updateMatrixWorld(true); chunks.set(key, g); } }
    for (const [key, g] of chunks) { const c = key - LF.chunkBase; if (c < c0 - 1 || c > c1 + 1) { disposeChunk(g); chunks.delete(key); } }
    for (const w of W.waylights) {
      w.glow = lerp(w.glow, w.lit ? 1 : 0, 1 - Math.exp(-dt * 1.6));
      const fl = 0.86 + 0.1 * Math.sin(time * 9.1 + w.x) + 0.06 * Math.sin(time * 23.7 + w.x * 2.0);
      w.mat.userData.u.uGlow.value = w.glow * 7 * fl; w.light.intensity = w.glow * 150 * fl; w.light.visible = w.glow > 0.01;
    }
  };
  // world periodicity: everything shifts back by WORLD_L
  W.shift = function (dx) {
    LF.chunkBase += Math.round(dx / CH);
    for (const [, g] of chunks) { g.position.x -= dx; g.updateMatrixWorld(true); }
    for (const w of W.waylights) { w.x -= dx; w.mesh.position.x -= dx; w.light.position.x -= dx; w.lp.x -= dx; }
  };
  W.resetChunks = function () { for (const [, g] of chunks) disposeChunk(g); chunks.clear(); };
  return W;
})();
LF.chunkBase = 0; LF.seed = qnum('seed', 7);
