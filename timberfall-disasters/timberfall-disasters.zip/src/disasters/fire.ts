// Fire: it starts where it's lit, spreads from piece to piece through whatever burns, and takes the
// structure down by burning through what holds it up.
//
// - Only timber and boards burn. Brick, stone, tile and steel don't; glass near a fire cracks.
// - A burning piece heats the pieces close to it: the ones above it most (flames go up), the ones
//   beside it less, the ones under it hardly at all. A thin board catches in a few seconds, a
//   20 cm post takes ten, so fire runs up cladding and across a roof long before the frame is alight.
// - As a piece burns it chars, glows, and its joints let go one by one; a board or a lath is burnt
//   away altogether, a heavy timber burns through and drops in two. The frame then has to carry its
//   load on what is left, and the solver's welds decide when it comes down.
// - Pieces that fall still burning set light to what they land on.
//
// It reads nothing but each piece's material, box and pose, so it works on any structure.

import * as THREE from 'three/webgpu';
import type { V3 } from '../physics/builder.ts';
import type { DisasterHost } from './index.ts';

/** Seconds between looks at the fire's spread. */
const TICK = 0.1;
/** The grid the pieces are found in (m). */
const CELL = 0.8;
/** How far heat carries: sideways, upwards and downwards from a burning piece's box (m). */
const SIDE = 0.3;
const UP = 1.3;
const DOWN = 0.15;
/** Flames, smoke puffs and embers at most per second, whatever is burning. */
const FLAMES = 1500;
const SMOKE = 60;
const EMBERS = 30;
const LIGHTS = 3;

const FRESH = 0;
const BURNING = 1;
const BURNT = 2;

export class Fire {
  private heat = new Float32Array(0);
  private burn = new Float32Array(0);
  private life = new Float32Array(0);
  private state = new Uint8Array(0);
  private charred = new Float32Array(0);
  private emit = new Float32Array(0);
  private stamp = new Int32Array(0);
  private burning: number[] = [];
  private readonly grid = new Map<number, number[]>();
  private gridAge = 1;
  private tick = 0;
  private round = 0;
  private smoke = 0;
  private embers = 0;
  private lightAge = 1;
  private clock = 0;
  readonly lights: THREE.PointLight[] = [];
  private readonly lightTo: { at: THREE.Vector3; power: number }[] = [];
  /** Where the fire is, and how much of it there is (for its sound). */
  centre: V3 | null = null;
  size = 0;

  constructor(private readonly host: DisasterHost) {
    // Always in the scene, dark until something burns (a light added later would recompile every material)
    for (let k = 0; k < LIGHTS; k++) {
      const light = new THREE.PointLight(0xff8436, 0, 34, 1.8);
      light.position.set(0, 0, -400);
      host.view.scene.add(light);
      this.lights.push(light);
      this.lightTo.push({ at: new THREE.Vector3(0, 0, -400), power: 0 });
    }
  }

  get active(): boolean {
    return this.burning.length > 0;
  }

  /** How many pieces are alight. */
  get count(): number {
    return this.burning.length;
  }

  private ensure(): void {
    const n = this.host.site.s.pieces.length;
    if (this.heat.length >= n) return;
    const grow = <T extends Float32Array | Uint8Array | Int32Array>(a: T): T => {
      const b = new (a.constructor as new (n: number) => T)(n + 256);
      b.set(a);
      return b;
    };
    this.heat = grow(this.heat);
    this.burn = grow(this.burn);
    this.life = grow(this.life);
    this.state = grow(this.state);
    this.charred = grow(this.charred);
    this.emit = grow(this.emit);
    this.stamp = grow(this.stamp);
  }

  private burns(i: number): boolean {
    const p = this.host.site.s.pieces[i];
    return !p.fixed && (p.mat === 'timber' || p.mat === 'board');
  }

  /** Set light to a piece. False if it won't burn (or already has). */
  light(piece: number): boolean {
    this.ensure();
    if (!this.burns(piece) || this.state[piece] !== FRESH || !this.host.site.s.bodies[piece]) return false;
    this.ignite(piece);
    return true;
  }

  /** Put every fire out. */
  douse(): void {
    const { site } = this.host;
    for (const i of this.burning) {
      this.state[i] = this.burn[i] / this.life[i] > 0.6 ? BURNT : FRESH;
      this.heat[i] = 0;
      const b = site.s.bodies[i];
      if (b) site.data.glow(b, 0);
    }
    this.burning = [];
  }

  private ignite(i: number): void {
    const p = this.host.site.s.pieces[i];
    const thin = Math.min(p.size[0], p.size[1], p.size[2]);
    this.state[i] = BURNING;
    this.burn[i] = 0;
    // A board burns through in a third of a minute, a 20 cm post in most of one
    this.life[i] = (p.mat === 'board' ? 12 + 300 * thin : 18 + 190 * thin) * (0.85 + 0.3 * hash(i * 7 + 3));
    this.burning.push(i);
  }

  /** Half sizes of a piece's box along the world's axes, as it lies now. */
  private extent(i: number, q: ArrayLike<number>, out: V3): V3 {
    const s = this.host.site.s.pieces[i].size;
    const [x, y, z, w] = [q[0], q[1], q[2], q[3]];
    const m = [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y), 2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x), 2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)];
    for (let r = 0; r < 3; r++) out[r] = (Math.abs(m[r * 3]) * s[0] + Math.abs(m[r * 3 + 1]) * s[1] + Math.abs(m[r * 3 + 2]) * s[2]) / 2;
    return out;
  }

  /** Everything that could catch, by the cells its box lies in. */
  private rebuild(): void {
    const s = this.host.site.s;
    this.grid.clear();
    const e: V3 = [0, 0, 0];
    for (let i = 0; i < s.pieces.length; i++) {
      if (this.state[i] !== FRESH) continue;
      const p = s.pieces[i];
      if (p.fixed || (p.mat !== 'timber' && p.mat !== 'board' && p.mat !== 'glass')) continue;
      const b = s.bodies[i];
      if (!b) continue;
      const at = b.position;
      this.extent(i, b.rotation, e);
      const x0 = Math.floor((at[0] - e[0]) / CELL);
      const x1 = Math.floor((at[0] + e[0]) / CELL);
      const y0 = Math.floor((at[1] - e[1]) / CELL);
      const y1 = Math.floor((at[1] + e[1]) / CELL);
      const z0 = Math.floor((at[2] - e[2]) / CELL);
      const z1 = Math.floor((at[2] + e[2]) / CELL);
      for (let x = x0; x <= x1; x++)
        for (let y = y0; y <= y1; y++)
          for (let z = z0; z <= z1; z++) {
            const key = cellKey(x, y, z);
            const list = this.grid.get(key);
            if (list) list.push(i);
            else this.grid.set(key, [i]);
          }
    }
  }

  update(dt: number): void {
    this.clock += dt;
    if (!this.burning.length) {
      this.size = 0;
      this.centre = null;
      for (let k = 0; k < LIGHTS; k++) {
        const l = this.lights[k];
        l.intensity *= Math.exp(-dt * 4);
        if (l.intensity < 0.5) l.intensity = 0;
      }
      return;
    }
    this.ensure();
    this.tick += dt;
    while (this.tick >= TICK) {
      this.tick -= TICK;
      this.spread(TICK);
    }
    this.show(dt);
  }

  /** One look at the fire: heat passed on, pieces burning down, joints letting go. */
  private spread(h: number): void {
    const { site } = this.host;
    const s = site.s;
    this.gridAge += h;
    if (this.gridAge >= 0.5) {
      this.gridAge = 0;
      this.rebuild();
    }
    const ei: V3 = [0, 0, 0];
    const ej: V3 = [0, 0, 0];
    const caught: number[] = [];
    const done: number[] = [];
    for (const i of this.burning) {
      const b = s.bodies[i];
      if (!b) {
        done.push(i);
        continue;
      }
      this.burn[i] += h;
      const frac = Math.min(1, this.burn[i] / this.life[i]);
      // How hard it burns: up in two seconds, falling away over its last third
      const strength = Math.min(1, this.burn[i] / 2) * (frac < 0.65 ? 1 : 1 - 0.75 * ((frac - 0.65) / 0.35));
      // Char, and embers showing through it
      const char = frac ** 0.6;
      if (char > this.charred[i]) {
        site.data.char(b, char - this.charred[i]);
        this.charred[i] = char;
      }
      site.data.glow(b, 0.35 + 0.65 * strength);
      // Its joints let go one by one as it burns
      for (const w of s.weldsOf[i]) {
        if (!s.joints[w]) continue;
        if (frac >= 0.3 + 0.6 * hash(w * 13 + 5)) s.cut(w);
      }
      if (frac >= 1) {
        done.push(i);
        continue;
      }
      // Heat for what's near it
      const at = b.position;
      this.extent(i, b.rotation, ei);
      const x0 = Math.floor((at[0] - ei[0] - SIDE) / CELL);
      const x1 = Math.floor((at[0] + ei[0] + SIDE) / CELL);
      const y0 = Math.floor((at[1] - ei[1] - SIDE) / CELL);
      const y1 = Math.floor((at[1] + ei[1] + SIDE) / CELL);
      const z0 = Math.floor((at[2] - ei[2] - DOWN) / CELL);
      const z1 = Math.floor((at[2] + ei[2] + UP) / CELL);
      const mark = ++this.round;
      for (let x = x0; x <= x1; x++)
        for (let y = y0; y <= y1; y++)
          for (let z = z0; z <= z1; z++) {
            const list = this.grid.get(cellKey(x, y, z));
            if (!list) continue;
            for (const j of list) {
              if (this.stamp[j] === mark || this.state[j] !== FRESH) continue;
              this.stamp[j] = mark;
              const bj = s.bodies[j];
              if (!bj) continue;
              const aj = bj.position;
              this.extent(j, bj.rotation, ej);
              const gx = Math.max(0, Math.abs(aj[0] - at[0]) - ei[0] - ej[0]);
              const gy = Math.max(0, Math.abs(aj[1] - at[1]) - ei[1] - ej[1]);
              const gap = Math.hypot(gx, gy);
              if (gap > SIDE) continue;
              const above = aj[2] - ej[2] - (at[2] + ei[2]);
              const below = at[2] - ei[2] - (aj[2] + ej[2]);
              let w: number;
              if (above > -0.05) w = above < UP ? (1 - above / UP) * (1 - gap / SIDE) : 0;
              else if (below > 0.02) w = below < DOWN ? 0.12 : 0;
              else w = 0.4 * (1 - gap / SIDE);
              if (w <= 0) continue;
              const pj = s.pieces[j];
              const thin = Math.min(pj.size[0], pj.size[1], pj.size[2]);
              const takes = pj.mat === 'glass' ? 6 : 3.2 + 34 * thin;
              this.heat[j] += (strength * w * h) / takes;
              if (this.heat[j] >= 1) caught.push(j);
            }
          }
    }
    for (const j of caught) {
      if (this.state[j] !== FRESH) continue;
      if (s.pieces[j].mat === 'glass') {
        this.state[j] = BURNT;
        site.shatter(j);
      } else this.ignite(j);
    }
    if (done.length) {
      const gone = new Set(done);
      this.burning = this.burning.filter((i) => !gone.has(i));
      for (const i of done) this.burntOut(i);
    }
  }

  /** A piece has burnt as far as it will: a board is gone, a timber is through. */
  private burntOut(i: number): void {
    const { site, particles } = this.host;
    const s = site.s;
    this.state[i] = BURNT;
    const b = s.bodies[i];
    if (!b) return;
    const p = s.pieces[i];
    const at = b.position as V3;
    const thin = Math.min(p.size[0], p.size[1], p.size[2]);
    const long = Math.max(p.size[0], p.size[1], p.size[2]);
    if (p.mat === 'board' || thin < 0.075 || long < 0.5) {
      particles.fireSmoke(at, 1, 0.6);
      particles.sparks(at, 4, 2);
      site.burnAway(i);
      return;
    }
    // Burnt through somewhere along it: two charred lengths, still glowing a little
    const made = site.cutOut(i, [at[0] + (Math.random() - 0.5) * long * 0.5, at[1] + (Math.random() - 0.5) * long * 0.5, at[2] + (Math.random() - 0.5) * long * 0.5], null, 2, 0.22);
    this.ensure();
    for (const id of made) {
      this.state[id] = BURNT;
      this.charred[id] = 1;
      const body = s.bodies[id];
      if (!body) continue;
      site.data.char(body, 1);
      site.data.glow(body, 0.22);
    }
    particles.sparks(at, 10, 3);
  }

  /** Flames, smoke, embers and light for what's burning. */
  private show(dt: number): void {
    const { site, particles } = this.host;
    const s = site.s;
    const n = this.burning.length;
    // Each piece's flames by its length; all of them together capped
    let wanted = 0;
    const rate = (i: number) => {
      const p = s.pieces[i];
      const frac = this.burn[i] / this.life[i];
      const strength = Math.min(1, this.burn[i] / 2) * (frac < 0.65 ? 1 : 1 - 0.75 * ((frac - 0.65) / 0.35));
      return strength * (2.5 + 5 * Math.max(p.size[0], p.size[1], p.size[2]));
    };
    for (const i of this.burning) wanted += rate(i);
    const share = Math.min(1, FLAMES / Math.max(wanted, 1));
    const flames: number[] = [];
    const smoke: number[] = [];
    let cx = 0;
    let cy = 0;
    let cz = 0;
    this.smoke += dt * Math.min(SMOKE, wanted * 0.12);
    this.embers += dt * Math.min(EMBERS, n * 0.25);
    let smokes = Math.floor(this.smoke);
    this.smoke -= smokes;
    let embers = Math.floor(this.embers);
    this.embers -= embers;
    const v = new THREE.Vector3();
    const q = new THREE.Quaternion();
    for (const i of this.burning) {
      const b = s.bodies[i];
      if (!b) continue;
      const p = s.pieces[i];
      const at = b.position;
      cx += at[0];
      cy += at[1];
      cz += at[2];
      this.emit[i] += rate(i) * share * dt;
      const k = Math.floor(this.emit[i]);
      const point = (): V3 => {
        const r = b.rotation;
        q.set(r[0], r[1], r[2], r[3]);
        v.set((Math.random() - 0.5) * p.size[0], (Math.random() - 0.5) * p.size[1], (Math.random() - 0.5) * p.size[2]).applyQuaternion(q);
        return [at[0] + v.x, at[1] + v.y, at[2] + v.z + 0.12];
      };
      if (k > 0) {
        this.emit[i] -= k;
        for (let j = 0; j < k; j++) flames.push(...point());
      }
      if (smokes > 0 && Math.random() < smokes / n + 0.02) {
        smokes--;
        const at2 = point();
        smoke.push(at2[0], at2[1], at2[2] + 1.6);
      }
      if (embers > 0 && Math.random() < embers / n + 0.01) {
        embers--;
        particles.sparks(point(), 1 + Math.floor(Math.random() * 2), 2 + Math.random() * 2.5);
      }
    }
    this.centre = [cx / n, cy / n, cz / n];
    this.size = n;
    const big = Math.min(1, n / 120);
    particles.flames(flames, 1 + 0.6 * big);
    // (Thin enough to see the fire through: thick smoke over a whole frame alight hid it under a dome)
    particles.fireSmoke(smoke, 1.1 + 0.9 * big, 0.5 + n / 700);

    // Light: the fire's on its surroundings (a few lights at the thick of it) and on its own smoke
    this.lightAge += dt;
    if (this.lightAge > 0.3) {
      this.lightAge = 0;
      this.cluster();
      for (const c of this.lightTo) if (c.power > 0) particles.glow([c.at.x, c.at.y, c.at.z], 0.45, 3.5 + 2.5 * big, 0.7 + 0.9 * Math.min(1, c.power / 40));
    }
    for (let k = 0; k < LIGHTS; k++) {
      const l = this.lights[k];
      const c = this.lightTo[k];
      if (c.power > 0 && l.intensity === 0) l.position.copy(c.at);
      l.position.lerp(c.at, Math.min(1, dt * 3));
      const flicker = 0.82 + 0.12 * Math.sin(this.clock * 11.3 + k * 2.1) + 0.06 * Math.sin(this.clock * 23.7 + k);
      const want = c.power > 0 ? 26 * Math.sqrt(c.power) * flicker : 0;
      l.intensity += (want - l.intensity) * Math.min(1, dt * 6);
    }
  }

  /** Where the fire is thickest: up to three places (k-means, a few rounds from where they were). */
  private cluster(): void {
    const s = this.host.site.s;
    const pts: number[] = [];
    for (const i of this.burning) {
      const b = s.bodies[i];
      if (!b) continue;
      const at = b.position;
      pts.push(at[0], at[1], at[2]);
    }
    const n = pts.length / 3;
    const k = Math.min(LIGHTS, n);
    const c = this.lightTo;
    for (let j = 0; j < LIGHTS; j++) if (j >= k) c[j].power = 0;
    if (!k) return;
    // Seeds: where they were if still lit, else spread through the list
    for (let j = 0; j < k; j++) if (c[j].power <= 0) c[j].at.set(pts[Math.floor(((j + 0.5) / k) * n) * 3], pts[Math.floor(((j + 0.5) / k) * n) * 3 + 1], pts[Math.floor(((j + 0.5) / k) * n) * 3 + 2]);
    const sum = new Float64Array(k * 4);
    for (let round = 0; round < 3; round++) {
      sum.fill(0);
      for (let i = 0; i < n; i++) {
        let best = 0;
        let bd = Infinity;
        for (let j = 0; j < k; j++) {
          const d = (pts[i * 3] - c[j].at.x) ** 2 + (pts[i * 3 + 1] - c[j].at.y) ** 2 + (pts[i * 3 + 2] - c[j].at.z) ** 2;
          if (d < bd) {
            bd = d;
            best = j;
          }
        }
        sum[best * 4] += pts[i * 3];
        sum[best * 4 + 1] += pts[i * 3 + 1];
        sum[best * 4 + 2] += pts[i * 3 + 2];
        sum[best * 4 + 3]++;
      }
      for (let j = 0; j < k; j++) {
        const m = sum[j * 4 + 3];
        c[j].power = m;
        if (m > 0) c[j].at.set(sum[j * 4] / m, sum[j * 4 + 1] / m, sum[j * 4 + 2] / m + 0.9);
      }
    }
  }
}

const cellKey = (x: number, y: number, z: number) => (x + 512) + (y + 512) * 1024 + (z + 64) * 1048576;

const hash = (i: number) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
