// The forces a disaster puts on every body, worked out on the GPU where the bodies live: a compute
// pass over three-avbd's body buffer before each step, as the library's own pushes are (lib/push.ts),
// but for all bodies at once and from each body's pose and velocity as the GPU has them now.
//
// - Wind (the tornado): a vortex with a core, inflow near the ground and an updraft round the core.
//   Each piece is pushed by the air's drag on the face it shows the wind, ½ρC·A·|u|·u with u the wind
//   past the piece, so a tile or a board (a lot of face for its weight) goes long before a post or
//   a stone. Pieces still built into the structure only feel the wind as far as they are exposed
//   to it (exposure.ts), and the ones in the envelope are also sucked outwards: by the fast air
//   over them and by the drop in pressure in the core. Their welds carry all of that until they fail.
//   A piece already torn off is debris in the same wind, and hits what still stands.
// - The ground's shaking (the earthquake): the site is simulated in the ground's own frame, so
//   every body feels the ground's acceleration the other way, as people in a quake do.
//
// Units are the solver's: metres, seconds, tonnes, so forces are kN and pressures kPa.

import type { World } from 'three-avbd';
import { B_ANGVEL, B_MOMENT, B_POS, B_ROT, B_SIZE, B_VEL, BODY_FLOATS } from 'three-avbd/advanced';

/** Air density (t/m³). */
export const AIR = 0.0012;

/** A vortex: where its foot is, how wide its core, how fast its strongest wind, and how it travels. */
export interface Vortex {
  x: number;
  y: number;
  /** Core radius (m): the wind is fastest here. */
  radius: number;
  /** Strongest tangential wind (m/s). */
  speed: number;
  /** How fast the whole storm moves over the ground (m/s). */
  vx: number;
  vy: number;
  /** How high the funnel reaches (m): the wind fades above it. */
  height: number;
}

/** The wind (m/s) a vortex makes at a point: the same sums as the kernel below, for the CPU's use. */
export function windAt(v: Vortex, px: number, py: number, pz: number, out: [number, number, number] = [0, 0, 0], ground = 0): [number, number, number] {
  const dx = px - v.x;
  const dy = py - v.y;
  const r = Math.max(Math.hypot(dx, dy), 0.5);
  const x = r / v.radius;
  const z = Math.max(pz - ground, 0);
  const vt = v.speed * (x < 1 ? x : x ** -0.7) * (0.6 + 0.4 * Math.min(1, z / 6));
  const vr = -vt * 0.45 * Math.exp(-z / 14) * smooth(0.8, 1.6, x);
  const w = v.speed * (0.55 * Math.exp(-(((x - 1) / 0.8) ** 2)) * Math.min(1, z / 5) + 0.12 * Math.exp(-x / 3) * Math.min(1, z / 8));
  const top = 1 - smooth(v.height, v.height * 1.4, z);
  out[0] = ((-dy / r) * vt + (dx / r) * vr) * top + v.vx;
  out[1] = ((dx / r) * vt + (dy / r) * vr) * top + v.vy;
  out[2] = w * top;
  return out;
}

const smooth = (a: number, b: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

const WGSL = /* wgsl */ `
struct Params {
  vortex: vec4f,   // foot x, y, core radius, strongest wind (0: no wind)
  travel: vec4f,   // the storm's own velocity x, y, the funnel's height, time (s)
  quake: vec4f,    // the ground's acceleration (m/s²), w: ½ρC for a piece still built in
  air: vec4f,      // dt, body count, ½ρC for a loose piece (t/m³), how sealed the building is (0..1)
  site: vec4f,     // x: the ground's height (m): the wind's heights are above it
}
@group(0) @binding(0) var<storage, read_write> bodies: array<vec4f>;
@group(0) @binding(1) var<storage, read> shelter: array<vec4f>;  // per body: open direction (its length: how one-sided), exposure 0..1
@group(0) @binding(2) var<uniform> P: Params;

fn turn(q: vec4f, v: vec3f) -> vec3f {
  let t = 2.0 * cross(q.xyz, v);
  return v + q.w * t + cross(q.xyz, t);
}

/** The face a box of sizes s, turned by q, shows along the unit direction d (m²). */
fn face(q: vec4f, s: vec3f, d: vec3f) -> f32 {
  let l = abs(turn(vec4f(-q.xyz, q.w), d));
  return l.x * s.y * s.z + l.y * s.x * s.z + l.z * s.x * s.y;
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3u) {
  let i = id.x;
  if (i >= u32(P.air.y)) { return; }
  let b = i * ${BODY_FLOATS / 4}u;
  let size = bodies[b + ${B_SIZE / 4}u];
  let mass = size.w;
  if (mass <= 0.0) { return; }
  let dt = P.air.x;
  var vel = bodies[b + ${B_VEL / 4}u];
  let pos = bodies[b + ${B_POS / 4}u].xyz;
  // Parked far below (a spare slot): nothing to do
  if (pos.z < -30.0) { return; }

  // The ground shaking under it
  vel = vec4f(vel.xyz - P.quake.xyz * dt, vel.w);

  let vmax = P.vortex.w;
  if (vmax > 0.0) {
    let q = bodies[b + ${B_ROT / 4}u];
    let d = pos.xy - P.vortex.xy;
    let r = max(length(d), 0.5);
    let x = r / P.vortex.z;
    let z = max(pos.z - P.site.x, 0.0);
    let H = P.travel.z;
    let t = P.travel.w;
    let vt = vmax * select(pow(x, -0.7), x, x < 1.0) * (0.6 + 0.4 * min(1.0, z / 6.0));
    let vr = -vt * 0.45 * exp(-z / 14.0) * smoothstep(0.8, 1.6, x);
    let up = vmax * (0.55 * exp(-pow((x - 1.0) / 0.8, 2.0)) * min(1.0, z / 5.0) + 0.12 * exp(-x / 3.0) * min(1.0, z / 8.0));
    let top = 1.0 - smoothstep(H, H * 1.4, z);
    let rad = d / r;
    // Gusts: the wind is never steady (a quarter either way, on a scale of a few metres and a second)
    let gust = 1.0 + 0.25 * sin(dot(pos, vec3f(0.31, 0.17, 0.23)) + t * 3.1) * sin(dot(pos, vec3f(-0.13, 0.29, 0.11)) - t * 2.3);
    let wind = (vec3f(-rad.y * vt + rad.x * vr, rad.x * vt + rad.y * vr, up) * top + vec3f(P.travel.xy, 0.0)) * gust;

    let sh = shelter[i];
    let speedNow = length(vel.xyz);
    // Loose and moving, it is in the open whatever it was built into
    let loose = smoothstep(1.5, 5.0, speedNow);
    let oneSided = length(sh.xyz) * (1.0 - loose);
    let open = sh.xyz / max(length(sh.xyz), 1e-4);
    let u = wind - vel.xyz;
    let us = length(u);
    if (us > 0.5) {
      let ud = u / us;
      // Behind the wall it is part of, a piece is out of the wind (the suction below has it instead)
      let lee = mix(1.0, clamp(0.6 - 0.6 * dot(open, ud), 0.0, 1.0), oneSided);
      let exposure = mix(sh.w, 1.0, loose) * lee;
      let k = mix(P.quake.w, P.air.z, loose) * face(q, size.xyz, ud) * us * exposure / mass * dt;
      // (Implicit: drag can only bring a piece to the wind's speed, never past it)
      vel = vec4f(vel.xyz + u * (k / (1.0 + k)), vel.w);
      // Loose pieces tumble: the wind never pushes through a board's exact middle
      if (loose > 0.0) {
        let w = bodies[b + ${B_ANGVEL / 4}u];
        let lever = turn(q, size.xyz * vec3f(0.13, -0.11, 0.09));
        let spin = cross(lever, u * (k / (1.0 + k))) * mass / max(max(bodies[b + ${B_MOMENT / 4}u].x, bodies[b + ${B_MOMENT / 4}u].y), 1e-9);
        let ws = length(w.xyz);
        if (ws < 14.0) { bodies[b + ${B_ANGVEL / 4}u] = vec4f(w.xyz + spin * loose * min(1.0, 4.0 * dt), w.w); }
      }
    }
    if (oneSided > 0.05) {
      // The envelope: fast air over a roof or round a corner sucks at it (½ρv², as much again as
      // the drag on a face), and the core's low pressure pulls on a building that hasn't vented yet
      let ws = length(wind);
      let drop = ${AIR} * vmax * vmax * select(0.5 / (x * x), 1.0 - 0.5 * x * x, x < 1.0) * top;
      let suck = (P.quake.w * ws * ws + drop * P.air.w) * face(q, size.xyz, open) * oneSided / mass;
      vel = vec4f(vel.xyz + open * min(suck * dt, 3.0), vel.w);
    }
  }
  bodies[b + ${B_VEL / 4}u] = vel;
}
`;

export class ForceField {
  private readonly device: GPUDevice;
  private readonly pipeline: GPUComputePipeline;
  private readonly params: GPUBuffer;
  private readonly shelterBuffer: GPUBuffer;
  private readonly group: GPUBindGroup;
  private readonly data: Float32Array<ArrayBuffer> = new Float32Array(20);
  /** The ground's height under the structure (m): the wind's profile is by height above it. */
  ground = 0;
  /** Per body slot: open direction xyz, exposure. Loose things nobody has looked at are in the open. */
  readonly shelter: Float32Array<ArrayBuffer>;
  private shelterDirty = true;
  private readonly count: number;
  /** The wind, or none. */
  vortex: Vortex | null = null;
  /** The ground's acceleration now (m/s²). */
  readonly quake: [number, number, number] = [0, 0, 0];
  /** Drag on a loose piece: C about 1.2 for a plate or a beam face on to the wind. */
  dragCoefficient = 1.2;
  /**
   * The wind's load on a piece still built into the structure, as a coefficient. The game's welds are armed to
   * hold a few times each piece's weight, about a quarter of what real fixings and mortar hold against wind;
   * the load is scaled the same way, so walls blow in and frames rack at the wind speeds real ones do (brick
   * infill near 60 m/s, a heavy timber frame past 70) instead of in a stiff breeze.
   */
  builtCoefficient = 0.5;
  /** How much of the core's pressure drop a building holds in (it leaks: far from all of it). */
  sealed = 0.25;
  private time = 0;
  /** Called before each step's forces go on (the earthquake moves the ground on by a step here). */
  onStep: ((dt: number) => void) | null = null;

  constructor(private readonly world: World) {
    this.device = world.device;
    this.count = world.maxBodies;
    const device = this.device;
    this.pipeline = device.createComputePipeline({ layout: 'auto', compute: { module: device.createShaderModule({ label: 'disaster forces', code: WGSL }), entryPoint: 'main' } });
    this.params = device.createBuffer({ label: 'disaster params', size: 80, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    this.shelter = new Float32Array(this.count * 4);
    for (let i = 0; i < this.count; i++) this.shelter[i * 4 + 3] = 1;
    this.shelterBuffer = device.createBuffer({ label: 'disaster shelter', size: this.shelter.byteLength, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
    this.group = device.createBindGroup({
      layout: this.pipeline.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: { buffer: world.solver.bodyBuffer } },
        { binding: 1, resource: { buffer: this.shelterBuffer } },
        { binding: 2, resource: { buffer: this.params } },
      ],
    });
    // Before every step the world takes, whoever asks for it
    const step = world.step.bind(world);
    world.step = (options) => {
      this.apply();
      step(options);
    };
  }

  /** How sheltered a body slot is: `open` the way it faces the open air (its length how one-sided), `exposure` 0..1. */
  setShelter(slot: number, ox: number, oy: number, oz: number, exposure: number): void {
    const o = slot * 4;
    const s = this.shelter;
    if (s[o] === ox && s[o + 1] === oy && s[o + 2] === oz && s[o + 3] === exposure) return;
    s[o] = ox;
    s[o + 1] = oy;
    s[o + 2] = oz;
    s[o + 3] = exposure;
    this.shelterDirty = true;
  }

  get active(): boolean {
    return !!this.vortex || this.quake[0] !== 0 || this.quake[1] !== 0 || this.quake[2] !== 0;
  }

  /** Run the pass once with nothing blowing or shaking, so its pipeline is compiled before it's needed. */
  warm(): void {
    this.run(0);
  }

  /** One step's worth of the forces, onto the bodies' velocities. */
  private apply(): void {
    const dt = this.world.dt;
    this.time += dt;
    this.onStep?.(dt);
    if (!this.active) return;
    this.run(dt);
  }

  private run(dt: number): void {
    const d = this.data;
    const v = this.vortex;
    d.set(v ? [v.x, v.y, v.radius, v.speed, v.vx, v.vy, v.height, this.time] : [0, 0, 1, 0, 0, 0, 1, this.time], 0);
    d.set([this.quake[0], this.quake[1], this.quake[2], 0.5 * AIR * this.builtCoefficient], 8);
    d.set([dt, this.count, 0.5 * AIR * this.dragCoefficient, this.sealed], 12);
    d.set([this.ground, 0, 0, 0], 16);
    this.device.queue.writeBuffer(this.params, 0, d);
    if (this.shelterDirty) {
      this.shelterDirty = false;
      this.device.queue.writeBuffer(this.shelterBuffer, 0, this.shelter);
    }
    const encoder = this.device.createCommandEncoder({ label: 'disaster forces' });
    const pass = encoder.beginComputePass({ label: 'disaster forces' });
    pass.setPipeline(this.pipeline);
    pass.setBindGroup(0, this.group);
    pass.dispatchWorkgroups(Math.ceil(this.count / 64));
    pass.end();
    this.device.queue.submit([encoder.finish()]);
  }

  destroy(): void {
    this.params.destroy();
    this.shelterBuffer.destroy();
  }
}
