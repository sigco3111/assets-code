// An earthquake: the ground's motion, as a strong-motion record has it.
//
// First the P wave: a fast rattle, mostly up and down, a tenth of what follows. A few seconds later
// the S wave: the strong sideways shaking, at a few hertz. Then the surface waves, slower and
// longer, rolling on as the rest dies away. A bigger earthquake shakes harder, for longer, and
// with more of its energy in slow waves, which is what brings tall and heavy things down.
//
// The site is simulated in the ground's own frame (field.ts): every body feels the ground's
// acceleration the other way, exactly as if the ground moved under it, and nothing fixed has to be
// moved. Whoever watches stands on that ground too, so the view sways by the same push (`sway`).
//
// Peak ground acceleration and the length of strong shaking are a near-source site's on soft
// ground: about 0.08 g for 6 s at magnitude 5, 0.5 g for 22 s at 7, 0.85 g for over a minute at 9.

import type { ForceField } from './field.ts';

const G = 9.81;
/**
 * Magnitudes on offer: peak ground acceleration (g), seconds of strong shaking, and how much of the slow
 * surface waves reach the site (1: all a magnitude makes). The slow waves are what bring a frame down:
 * with all of them a magnitude 8 levelled the mill as surely as a 9, and a 7 sometimes did. So 7 and 8 are
 * given less, and the steps read: 5 nothing breaks, 6 mortar cracks, 7 the chimney and the water tower
 * fall, 8 the infill is shaken out of a frame left standing, 9 nothing stands.
 */
export const MAGNITUDES: { m: number; pga: number; seconds: number; slow: number }[] = [
  { m: 5, pga: 0.08, seconds: 6, slow: 1 },
  { m: 6, pga: 0.16, seconds: 12, slow: 1 },
  { m: 7, pga: 0.5, seconds: 22, slow: 0.6 },
  { m: 8, pga: 0.58, seconds: 40, slow: 0.4 },
  { m: 9, pga: 0.85, seconds: 70, slow: 1 },
];
/** Lengths on offer (s): the magnitude's own, or one of these. */
export const LENGTHS = [0, 10, 20, 40];

interface Wave {
  /** Angular frequency (rad/s), phase, and amplitude along x, y, z (m/s²). */
  w: number;
  p: number;
  a: [number, number, number];
  /** Which train it belongs to: 0 P, 1 S, 2 surface. */
  train: number;
}

export class Quake {
  /** Tuning (scripts/disaster.mjs --set): the whole motion scaled, and its slow surface waves scaled. */
  gain = 1;
  slow = 1;
  /** Choices: index into MAGNITUDES and into LENGTHS. */
  level = 2;
  length = 0;
  private waves: Wave[] = [];
  private t = -1;
  private seconds = 0;
  private sArrives = 0;
  /** The shaking's strength now (0..1 of its peak), for sound and dust. */
  intensity = 0;
  /** The ground's acceleration now (m/s²). */
  readonly accel: [number, number, number] = [0, 0, 0];
  /** How far the watcher's head is thrown (m): a body standing on the ground, swaying at about 1.2 Hz. */
  readonly sway: [number, number, number] = [0, 0, 0];
  private readonly swayV: [number, number, number] = [0, 0, 0];

  constructor(private readonly field: ForceField) {}

  get active(): boolean {
    return this.t >= 0;
  }

  /** Seconds of it left. */
  get left(): number {
    return this.t >= 0 ? Math.max(0, this.seconds - this.t) : 0;
  }

  /** How long one would run with the choices as they are (s). */
  get planned(): number {
    return LENGTHS[this.length] || MAGNITUDES[this.level].seconds;
  }

  start(seed = Math.floor(Math.random() * 1e9)): void {
    const { m, pga, slow } = MAGNITUDES[this.level];
    const strong = this.planned;
    const rnd = mulberry(seed);
    // The S wave follows the P by a few seconds (about 8 km of travel per second between them)
    this.sArrives = 1.6 + rnd() * 1.4;
    this.seconds = this.sArrives + strong + 4;
    this.waves = [];
    const peak = pga * G * this.gain;
    const dir = rnd() * Math.PI * 2;
    // Bigger earthquakes shake slower: the S band runs from 2.2-7 Hz at magnitude 5 down to 0.6-3 Hz at 9,
    // which is what gives a big one its ground speed (half a metre a second and more) for the same push
    const k = (m - 5) / 4;
    const sLow = 2.2 - 1.6 * k;
    const sHigh = 7 - 4 * k;
    const add = (n: number, train: number, lo: number, hi: number, amp: number, vertical: number, along: number) => {
      for (let i = 0; i < n; i++) {
        const f = lo * (hi / lo) ** ((i + rnd()) / n);
        // Mostly along one line (the fault's), with a good share across it
        const a = dir + (rnd() < along ? 0 : Math.PI / 2) + (rnd() - 0.5) * 0.5;
        const h = amp * (0.6 + 0.8 * rnd()) / Math.sqrt(n / 2);
        this.waves.push({ w: 2 * Math.PI * f, p: rnd() * Math.PI * 2, a: [Math.cos(a) * h, Math.sin(a) * h, vertical * amp * (0.6 + 0.8 * rnd()) / Math.sqrt(n / 2)], train });
      }
    };
    add(8, 0, 5, 12, peak * 0.1, 1.6, 0.5);
    add(14, 1, sLow, sHigh, peak, 0.35, 0.65);
    add(8, 2, 0.3 + 0.25 * (1 - k), 1.1, peak * (0.22 + 0.2 * k) * slow * this.slow, 0.25, 0.6);
    // Scaled so its strongest sideways moment is the peak asked for (waves with random phases add up as they like)
    let top = 0;
    for (let t = 0; t < this.seconds; t += 1 / 120) {
      const env = [this.envelope(0, t), this.envelope(1, t), this.envelope(2, t)];
      let x = 0;
      let y = 0;
      for (const w of this.waves) {
        const sn = Math.sin(w.w * t + w.p) * env[w.train];
        x += w.a[0] * sn;
        y += w.a[1] * sn;
      }
      top = Math.max(top, Math.hypot(x, y));
    }
    const scale = top > 0 ? peak / top : 1;
    for (const w of this.waves) for (let i = 0; i < 3; i++) w.a[i] *= scale;
    this.t = 0;
  }

  stop(): void {
    if (this.t >= 0) this.seconds = Math.min(this.seconds, this.t + 1.5);
  }

  /** How strong each train is at time t (0..1). */
  private envelope(train: number, t: number): number {
    const end = this.seconds;
    const s = this.sArrives;
    const strong = end - s - 4;
    const fade = Math.min(1, Math.max(0, (end - t) / 1.5));
    if (train === 0) return Math.min(1, t / 0.4) * (t < s ? 1 : Math.exp(-(t - s) / 1.5)) * fade;
    if (t < s) return 0;
    const u = t - s;
    if (train === 1) {
      // Up in a second or two, held for the strong part, then dying away
      const hold = strong * 0.55;
      return Math.min(1, u / 1.4) ** 1.5 * (u < hold ? 1 : Math.exp(-(u - hold) / (strong * 0.22))) * fade;
    }
    const late = u - 1.5;
    if (late < 0) return 0;
    return Math.min(1, late / 2.5) * (late < strong * 0.7 ? 1 : Math.exp(-(late - strong * 0.7) / (strong * 0.3))) * fade;
  }

  /** Advance it by one physics step. */
  step(dt: number): void {
    const a = this.accel;
    if (this.t < 0) {
      a[0] = a[1] = a[2] = 0;
    } else {
      this.t += dt;
      const env = [this.envelope(0, this.t), this.envelope(1, this.t), this.envelope(2, this.t)];
      a[0] = a[1] = a[2] = 0;
      for (const w of this.waves) {
        const s = Math.sin(w.w * this.t + w.p) * env[w.train];
        a[0] += w.a[0] * s;
        a[1] += w.a[1] * s;
        a[2] += w.a[2] * s;
      }
      this.intensity = Math.max(env[1], env[2] * 0.6, env[0] * 0.15);
      if (this.t >= this.seconds) {
        this.t = -1;
        this.intensity = 0;
        a[0] = a[1] = a[2] = 0;
      }
    }
    this.field.quake[0] = a[0];
    this.field.quake[1] = a[1];
    this.field.quake[2] = a[2];
    // The watcher: thrown the other way, sprung back (1.2 Hz, half damped)
    const w0 = 2 * Math.PI * 1.2;
    for (let k = 0; k < 3; k++) {
      const acc = -a[k] * (k === 2 ? 0.5 : 1) - 2 * 0.5 * w0 * this.swayV[k] - w0 * w0 * this.sway[k];
      this.swayV[k] += acc * dt;
      this.sway[k] = Math.max(-0.3, Math.min(0.3, this.sway[k] + this.swayV[k] * dt));
    }
  }
}

function mulberry(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
