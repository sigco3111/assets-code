// How exposed each piece of a structure is to the wind, and which way it faces the open air.
//
// The standing pieces are drawn into a grid of 25 cm cells, and from each piece a handful of rays
// look outwards through it. A roof tile sees the sky and nothing else: it is in the envelope, facing
// up. A weatherboard sees out one side. A joist inside sees walls every way: the wind doesn't reach
// it. As the cladding goes the rays get through, and what was inside is in the wind too. So a
// building is stripped from the outside in, and a wall that loses its windows lets the wind inside.
//
// It works on any structure: all it reads is each piece's box and where it is now.
//
// A round is worked through a little each frame (`work`, by the clock): first the grid is drawn, a few
// hundred pieces at a time, into a second grid while the rays go on reading the last whole one; then every
// piece still in place looks out. Only pieces still about where they were built are shelter or sheltered:
// one that has fallen or flown is in the open, and the grid covers the structure as built, not the
// field its debris ends up strewn over (a grid that followed the debris was 100 MB to clear twice a second).

import type { Structure } from '../physics/structure.ts';
import type { ForceField } from './field.ts';

const CELL = 0.25;
/** How far a ray looks before it calls the way open (m): past the far wall of a room. */
const REACH = 14;
/** A piece further than this from where it was built is debris, not part of the building (m). */
const IN_PLACE = 1.5;
/** Rays: the four sides, straight up, and four up at 45°. Nothing looks down (the ground is there). */
const S = Math.SQRT1_2;
const DIRS: [number, number, number][] = [
  [1, 0, 0],
  [-1, 0, 0],
  [0, 1, 0],
  [0, -1, 0],
  [0, 0, 1],
  [S, 0, S],
  [-S, 0, S],
  [0, S, S],
  [0, -S, S],
];

export class Exposure {
  /** The last whole grid (what the rays read), and the one being drawn. */
  private grid: Int32Array;
  private next: Int32Array;
  private readonly dims: [number, number, number];
  private readonly origin: [number, number, number];
  /** This round: the pieces still in place, how many of them are drawn, and how many have looked out. */
  private round: number[] = [];
  private drawn = 0;
  private looked = 0;
  private working = false;
  /** Each piece's exposure (0..1) as last worked out. */
  exposure = new Float32Array(0);
  /** Pieces already told they're in the open for good (fallen, flown). */
  private out = new Uint8Array(0);

  constructor(
    private readonly s: Structure,
    private readonly field: ForceField,
  ) {
    // The box round the structure as built, with room for the rays' first steps
    const lo = [Infinity, Infinity, Infinity];
    const hi = [-Infinity, -Infinity, -Infinity];
    for (const p of s.pieces) {
      if (p.fixed) continue;
      const r = Math.max(p.size[0], p.size[1], p.size[2]) / 2;
      for (let a = 0; a < 3; a++) {
        lo[a] = Math.min(lo[a], p.pos[a] - r);
        hi[a] = Math.max(hi[a], p.pos[a] + r);
      }
    }
    if (!(hi[0] > lo[0])) lo[0] = lo[1] = lo[2] = hi[0] = hi[1] = hi[2] = 0;
    this.origin = [lo[0] - 1, lo[1] - 1, lo[2]];
    // (The lowest the structure goes is its ground for the wind: a bridge's ring starts down in its beck)
    field.ground = lo[2];
    this.dims = [Math.min(480, Math.ceil((hi[0] - lo[0] + 2) / CELL)), Math.min(480, Math.ceil((hi[1] - lo[1] + 2) / CELL)), Math.min(200, Math.ceil((hi[2] - lo[2] + 1) / CELL))];
    const cells = this.dims[0] * this.dims[1] * this.dims[2];
    this.grid = new Int32Array(cells);
    this.next = new Int32Array(cells);
  }

  /** Whether a round is still being worked through. */
  get busy(): boolean {
    return this.working;
  }

  /** Start a round: note which pieces are still in place. `work` then draws them and has them look out. */
  begin(): void {
    const s = this.s;
    const n = s.pieces.length;
    if (this.exposure.length < n) {
      const e = new Float32Array(n + 256);
      e.set(this.exposure);
      this.exposure = e;
      const o = new Uint8Array(n + 256);
      o.set(this.out);
      this.out = o;
    }
    const round: number[] = [];
    for (let i = 0; i < n; i++) {
      if (this.out[i]) continue;
      const b = s.bodies[i];
      const p = s.pieces[i];
      if (!b || p.fixed) continue;
      const at = b.position;
      const moved = Math.abs(at[0] - p.pos[0]) + Math.abs(at[1] - p.pos[1]) + Math.abs(at[2] - p.pos[2]);
      if (moved > IN_PLACE) {
        // Gone from where it was built: in the open from now on (the force pass already treats anything
        // moving fast as in the open, wherever it is)
        this.out[i] = 1;
        this.exposure[i] = 1;
        this.field.setShelter(b.index, 0, 0, 0, 1);
        continue;
      }
      round.push(i);
    }
    this.round = round;
    this.drawn = 0;
    this.looked = 0;
    this.next.fill(0);
    this.working = round.length > 0;
  }

  /** Work on the round for up to `ms` of this frame. */
  work(ms: number): void {
    if (!this.working) return;
    const until = performance.now() + ms;
    const s = this.s;
    const { dims, origin, round } = this;
    // Each piece into the cells it fills: points through its box no further apart than half a cell
    const next = this.next;
    while (this.drawn < round.length) {
      const i = round[this.drawn++];
      const b = s.bodies[i];
      if (b) {
        const p = s.pieces[i];
        const at = b.position;
        const ax = axes(b.rotation);
        const nx = Math.max(1, Math.ceil(p.size[0] / (CELL * 0.5)));
        const ny = Math.max(1, Math.ceil(p.size[1] / (CELL * 0.5)));
        const nz = Math.max(1, Math.ceil(p.size[2] / (CELL * 0.5)));
        for (let ix = 0; ix < nx; ix++) {
          const fx = ((ix + 0.5) / nx - 0.5) * p.size[0];
          for (let iy = 0; iy < ny; iy++) {
            const fy = ((iy + 0.5) / ny - 0.5) * p.size[1];
            for (let iz = 0; iz < nz; iz++) {
              const fz = ((iz + 0.5) / nz - 0.5) * p.size[2];
              const cx = Math.floor((at[0] + ax[0] * fx + ax[3] * fy + ax[6] * fz - origin[0]) / CELL);
              const cy = Math.floor((at[1] + ax[1] * fx + ax[4] * fy + ax[7] * fz - origin[1]) / CELL);
              const cz = Math.floor((at[2] + ax[2] * fx + ax[5] * fy + ax[8] * fz - origin[2]) / CELL);
              if (cx < 0 || cy < 0 || cz < 0 || cx >= dims[0] || cy >= dims[1] || cz >= dims[2]) continue;
              next[cx + dims[0] * (cy + dims[1] * cz)] = i + 1;
            }
          }
        }
      }
      if ((this.drawn & 31) === 0 && performance.now() > until) return;
    }
    if (this.looked === 0) {
      // The grid is whole: the rays read it from here on
      this.next = this.grid;
      this.grid = next;
    }
    const grid = this.grid;
    while (this.looked < round.length) {
      const i = round[this.looked++];
      const b = s.bodies[i];
      if (b) {
        const p = s.pieces[i];
        const at = b.position;
        const ax = axes(b.rotation);
        let ox = 0;
        let oy = 0;
        let oz = 0;
        let open = 0;
        for (const d of DIRS) {
          // From just outside the piece's own box along this way
          const half = (Math.abs(ax[0] * d[0] + ax[1] * d[1] + ax[2] * d[2]) * p.size[0] + Math.abs(ax[3] * d[0] + ax[4] * d[1] + ax[5] * d[2]) * p.size[1] + Math.abs(ax[6] * d[0] + ax[7] * d[1] + ax[8] * d[2]) * p.size[2]) / 2;
          let blocked = false;
          for (let t = half + CELL * 0.75; t < REACH; t += CELL) {
            const cx = Math.floor((at[0] + d[0] * t - origin[0]) / CELL);
            const cy = Math.floor((at[1] + d[1] * t - origin[1]) / CELL);
            const cz = Math.floor((at[2] + d[2] * t - origin[2]) / CELL);
            if (cx < 0 || cy < 0 || cz < 0 || cx >= dims[0] || cy >= dims[1] || cz >= dims[2]) break;
            const hit = grid[cx + dims[0] * (cy + dims[1] * cz)];
            if (hit && hit !== i + 1) {
              blocked = true;
              break;
            }
          }
          if (!blocked) {
            open++;
            ox += d[0];
            oy += d[1];
            oz += d[2];
          }
        }
        // Exposed by how many ways it sees out (three or more: fully); one-sided by how far they agree
        const exposure = Math.min(1, open / 3);
        const len = Math.hypot(ox, oy, oz);
        const sided = open ? Math.min(1, len / open) * (1 - Math.max(0, open / DIRS.length - 0.6) / 0.4) : 0;
        const k1 = len > 1e-6 ? sided / len : 0;
        this.exposure[i] = exposure;
        this.field.setShelter(b.index, ox * k1, oy * k1, oz * k1, exposure);
      }
      if ((this.looked & 15) === 0 && performance.now() > until) return;
    }
    this.working = false;
  }
}

/** A quaternion's axes: the box's x, y and z in the world (nine numbers, column by column). */
function axes(q: ArrayLike<number>): number[] {
  const [x, y, z, w] = [q[0], q[1], q[2], q[3]];
  return [1 - 2 * (y * y + z * z), 2 * (x * y + w * z), 2 * (x * z - w * y), 2 * (x * y - w * z), 1 - 2 * (x * x + z * z), 2 * (y * z + w * x), 2 * (x * z + w * y), 2 * (y * z - w * x), 1 - 2 * (x * x + y * y)];
}
