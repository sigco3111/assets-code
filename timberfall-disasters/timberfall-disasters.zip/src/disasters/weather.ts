// The light and the weather round a disaster: the time of day (a fire is best seen at dusk or at
// night), and a storm's sky for a tornado: the cloud closes over, the sun goes, the air thickens
// to a grey-green murk, and it rains, the rain slanted by the wind.
//
// Everything here is a uniform or a light's setting: nothing is recompiled when it changes.

import { attribute, cameraFar, cameraNear, cameraPosition, float, floor, normalize, perspectiveDepthToViewZ, positionLocal, positionView, screenUV, smoothstep, uniform, vec3, vec4 } from 'three/tsl';
import * as THREE from 'three/webgpu';
import type { View } from '../render/view.ts';

// biome-ignore lint: TSL nodes
type N = any;

export type TimeOfDay = 'day' | 'dusk' | 'night';
export const TIMES: TimeOfDay[] = ['day', 'dusk', 'night'];
export const TIME_NAME: Record<TimeOfDay, string> = { day: '오후', dusk: '해질녘', night: '밤' };

/** The sun's height (degrees), the sky's fill light and the sky's reflections, at each time. */
const LOOK: Record<TimeOfDay, { el: number; hemi: number; env: number; bright: number }> = {
  day: { el: 24, hemi: 0.35, env: 0.42, bright: 1 },
  dusk: { el: 1.6, hemi: 0.2, env: 0.2, bright: 0.45 },
  night: { el: -16, hemi: 0.07, env: 0.035, bright: 0.07 },
};
const SUN_AZIMUTH = (-128 * Math.PI) / 180;
const MOON = new THREE.Vector3(Math.cos(0.7) * Math.cos(1.1), Math.cos(0.7) * Math.sin(1.1), Math.sin(0.7)).normalize();
const MOON_COLOUR = new THREE.Color(0.6, 0.71, 1);
const STORM_AIR = new THREE.Color(0.17, 0.2, 0.185);
const DROPS = 3600;

export class Weather {
  time: TimeOfDay = 'day';
  /** The sun's height now (degrees): it eases to the time's. */
  private el = LOOK.day.el;
  private hemi = LOOK.day.hemi;
  private env = LOOK.day.env;
  private bright = 1;
  /** 0..1: how far the storm has closed in. */
  storm = 0;
  private readonly rain: THREE.LineSegments;
  private readonly rainTime = uniform(0);
  private readonly rainAmount = uniform(0);
  private readonly rainSlant = uniform(new THREE.Vector3());
  private readonly rainLight = uniform(new THREE.Color(0.5, 0.52, 0.55));
  private readonly dir = new THREE.Vector3();
  private readonly colour = new THREE.Color();

  constructor(private readonly view: View) {
    this.rain = this.makeRain();
    view.smokeScene.add(this.rain);
  }

  /** Draw the rain (unseen) so its pipeline is made behind the loader, not in the storm's first second. */
  warm(on: boolean): void {
    this.rain.visible = on;
    this.rainAmount.value = on ? 0.004 : 0;
  }

  /** The next time of day. */
  next(): TimeOfDay {
    this.time = TIMES[(TIMES.indexOf(this.time) + 1) % TIMES.length];
    return this.time;
  }

  /** `storm` 0..1 is how much of one there should be; `wind` the wind where the camera is (m/s). */
  update(dt: number, storm: number, wind: ArrayLike<number>): void {
    const view = this.view;
    const want = LOOK[this.time];
    const ease = 1 - Math.exp(-dt * 1.4);
    // The sun crosses the sky at an even pace (12° a second), the rest follows
    this.el += Math.sign(want.el - this.el) * Math.min(Math.abs(want.el - this.el), dt * 12);
    this.hemi += (want.hemi - this.hemi) * ease;
    this.env += (want.env - this.env) * ease;
    this.bright += (want.bright - this.bright) * ease;
    this.storm += (storm - this.storm) * (1 - Math.exp(-dt * (storm > this.storm ? 0.6 : 0.22)));
    const s = this.storm;

    const el = (this.el * Math.PI) / 180;
    this.dir.set(Math.cos(el) * Math.cos(SUN_AZIMUTH), Math.cos(el) * Math.sin(SUN_AZIMUTH), Math.sin(el)).normalize();
    view.sky.sun.copy(this.dir);
    view.sky.coverage = 0.38 + 0.62 * s;
    view.sky.storm = s;
    // The key light: the sun while it's up, the moon once it's well down
    const moon = Math.min(1, Math.max(0, -this.el / 8));
    const up = this.el > 0;
    const key = up ? this.dir : MOON;
    view.sunDirection.copy(key);
    view.sun.position.copy(view.sun.target.position).addScaledVector(key, 90);
    view.sun.color.copy(up ? view.sky.sunColor : MOON_COLOUR);
    view.sun.intensity = (up ? view.sky.sunIntensity() * 1.05 : 0.3 * moon) * (1 - 0.93 * s);
    view.handSun.position.copy(key).multiplyScalar(10);
    view.handSun.color.copy(view.sun.color);
    view.handSun.intensity = view.sun.intensity * 0.8;
    view.hemi.intensity = this.hemi * (1 - 0.5 * s);
    view.handHemi.intensity = (this.hemi / 0.35) * 0.9 * (1 - 0.5 * s);
    view.scene.environmentIntensity = this.env * (1 - 0.8 * s);
    view.handScene.environmentIntensity = (this.env / 0.42) * 0.6 * (1 - 0.8 * s);
    // The air: the horizon's colour, a storm's murk laid over it and thickened
    const fog = view.scene.fog as THREE.FogExp2;
    this.colour.copy(view.sky.horizon).multiplyScalar(0.85);
    this.colour.r = Math.max(this.colour.r, 0.008);
    this.colour.g = Math.max(this.colour.g, 0.011);
    this.colour.b = Math.max(this.colour.b, 0.018);
    const murk = STORM_AIR.clone().multiplyScalar(0.25 + 0.75 * this.bright);
    view.sky.murk.copy(murk).multiplyScalar(0.8);
    fog.color.copy(this.colour).lerp(murk, 0.85 * s);
    fog.density = 0.0065 + 0.009 * s;

    // Rain
    this.rainTime.value += dt;
    this.rainAmount.value = Math.max(0, (s - 0.25) / 0.75);
    this.rain.visible = this.rainAmount.value > 0.01;
    const w = Math.hypot(wind[0], wind[1]);
    const k = w > 14 ? 14 / w : 1;
    this.rainSlant.value.set(wind[0] * k, wind[1] * k, 0);
    this.rainLight.value.copy(fog.color).multiplyScalar(1.5).addScalar(0.02);
  }

  /** Streaks of rain in a box that follows the camera, slanted by the wind, hidden behind the scene. */
  private makeRain(): THREE.LineSegments {
    const g = new THREE.BufferGeometry();
    const base = new Float32Array(DROPS * 6);
    const end = new Float32Array(DROPS * 2);
    const seed = new Float32Array(DROPS * 2);
    for (let i = 0; i < DROPS; i++) {
      const p = [Math.random(), Math.random(), Math.random()];
      base.set(p, i * 6);
      base.set(p, i * 6 + 3);
      end[i * 2 + 1] = 1;
      seed[i * 2] = seed[i * 2 + 1] = Math.random();
    }
    g.setAttribute('position', new THREE.BufferAttribute(base, 3));
    g.setAttribute('end', new THREE.BufferAttribute(end, 1));
    g.setAttribute('seed', new THREE.BufferAttribute(seed, 1));
    const m = new THREE.LineBasicNodeMaterial({ transparent: true, depthWrite: false, depthTest: false });
    const box: N = vec3(40, 40, 26);
    const s: N = attribute('seed', 'float');
    const fall: N = s.mul(7).add(15);
    const vel: N = vec3(this.rainSlant.x, this.rainSlant.y, fall.negate());
    const at: N = positionLocal.mul(box).add(vel.mul(this.rainTime));
    const rel: N = at.sub(cameraPosition).add(box.mul(0.5));
    const wrapped: N = rel.sub(floor(rel.div(box)).mul(box)).sub(box.mul(0.5)).add(cameraPosition).add(vec3(0, 0, 8));
    m.positionNode = wrapped.sub(normalize(vel).mul(attribute('end', 'float').mul(s.mul(0.35).add(0.45)))) as THREE.Node<'vec3'>;
    const sceneZ: N = perspectiveDepthToViewZ(this.view.sceneDepth.sample(screenUV).x, cameraNear, cameraFar);
    const infront: N = smoothstep(0, 0.3, positionView.z.sub(sceneZ));
    // (Thin and faint: a streak is two pixels wide in this half-size pass, and rain is seen as a haze of them)
    const near: N = smoothstep(0.6, 2.5, positionView.z.negate()).mul(smoothstep(24, 9, positionView.z.negate()));
    m.colorNode = (vec4 as N)(this.rainLight, float(0.15).mul(this.rainAmount).mul(infront).mul(near)) as unknown as THREE.Node<'vec4'>;
    const rain = new THREE.LineSegments(g, m);
    rain.frustumCulled = false;
    rain.visible = false;
    return rain;
  }
}
