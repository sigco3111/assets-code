// A tornado: a vortex that touches down beyond what it's sent at, tracks through it and lifts.
//
// The wind is one field (field.ts): it loads every piece of the structure on the GPU, and the same
// vortex carries the funnel's cloud and the dust at its foot (the particles' flow, fx/particles.ts).
// Nothing here says what breaks: the pieces' welds carry the wind until they fail. Strength is the
// Enhanced Fujita scale's, by the strongest wind:
//
//   EF0  32 m/s  tiles and loose boards go, glass rattles
//   EF1  42 m/s  the roof is stripped, cladding peels
//   EF2  54 m/s  the roof frame lifts off, walls rack
//   EF3  67 m/s  the upper storey goes
//   EF4  82 m/s  the frame is levelled
//   EF5  98 m/s  swept to the plinth

import * as THREE from 'three/webgpu';
import type { V3 } from '../physics/builder.ts';
import type { Mat } from '../physics/materials.ts';
import { terrainHeight } from '../render/view.ts';
import { type ForceField, type Vortex, windAt } from './field.ts';
import type { DisasterHost } from './index.ts';

/** Each strength: its strongest wind (m/s, all of it: the turn, the updraft and its travel together), its core, its height, its pace. */
export const EF: { name: string; wind: number; radius: number; height: number; travel: number }[] = [
  { name: 'EF0', wind: 32, radius: 5, height: 60, travel: 6 },
  { name: 'EF1', wind: 42, radius: 6.5, height: 70, travel: 6.5 },
  { name: 'EF2', wind: 54, radius: 8, height: 80, travel: 7 },
  { name: 'EF3', wind: 67, radius: 10, height: 90, travel: 7.5 },
  { name: 'EF4', wind: 82, radius: 12.5, height: 100, travel: 8 },
  { name: 'EF5', wind: 98, radius: 15, height: 110, travel: 8.5 },
];
/**
 * The vortex's own tangential wind for a strength: at the core's edge the updraft adds to it (together 1.14
 * times the turn alone), and the storm's travel adds on the side where they run the same way.
 */
const turnOf = (ef: (typeof EF)[number]) => (ef.wind - ef.travel) / 1.14;

/** How far beyond its mark it touches down, and how far past it lifts (m). */
const APPROACH = 75;
const BEYOND = 70;
/** Seconds to reach the ground, and to lift. */
const FORM = 4;
const LIFT = 4;
/** Seconds the sky darkens for before the funnel starts down. */
const BREW = 4.5;

/**
 * What the wind tears off, and at what speed (m/s, give or take the second number): the cladding, by
 * what real buildings lose first. Tiles lift at about 40 m/s, glass goes at 45 or so (sooner to
 * debris), boards and sheet steel peel in the 50s and 60s, and exposed brickwork is knocked out
 * past 70. Only pieces in the open are judged (exposure.ts), each by the wind where it is. Posts,
 * beams and stone are never torn off by rule: they stand or fall by the load on their welds.
 */
const TEARS: Partial<Record<Mat, [number, number]>> = { tile: [36, 6], glass: [46, 8], board: [56, 8], plaster: [50, 8], steel: [64, 8], brick: [74, 9] };
/**
 * Stone has no one speed: a block goes when the wind's push on its biggest face beats the friction under it
 * and the mortar round it (taken as its weight again), so a coping stone lifts off a parapet at about 90 m/s
 * and a walling stone of a quarter of a tonne never does.
 */
const STONE = { friction: 0.8, mortar: 2, drag: 1.2 };
/** Steel thicker than this isn't cladding (m). */
const SHEET = 0.07;
const CLOUD = new THREE.Color(0.4, 0.41, 0.44);
const DIRT = new THREE.Color(0.2, 0.17, 0.12);

export class Tornado {
  /** Strength chosen (index into EF). */
  level = 3;
  /** Where it is, or null when there's none. */
  private at: THREE.Vector2 | null = null;
  private heading = new THREE.Vector2(1, 0);
  private target = new THREE.Vector2();
  /** Metres still to travel past the mark before it lifts. */
  private passed = false;
  private beyond = 0;
  /** 0..1: how much of its strength it has (forming, lifting). */
  private power = 0;
  private lifting = false;
  private clock = 0;
  private cloud = 0;
  private dust = 0;
  private readonly vortex: Vortex = { x: 0, y: 0, radius: 8, speed: 0, vx: 0, vy: 0, height: 80 };
  /** The strength it has now (it eases to the one chosen). */
  private speed = 0;
  private radius = 8;
  private height = 80;
  /** Pieces the wind has already torn off. */
  private torn = new Uint8Array(0);
  private glass = 0;

  constructor(
    private readonly host: DisasterHost,
    private readonly field: ForceField,
  ) {}

  get active(): boolean {
    return !!this.at;
  }

  /** How dark the weather is for it (0..1). */
  get storm(): number {
    return this.at ? (this.lifting ? Math.max(0.5, this.power) : 1) : 0;
  }

  /** Where its foot is (m), or null. */
  get position(): V3 | null {
    return this.at ? [this.at.x, this.at.y, 0] : null;
  }

  /** The wind (m/s) at a point now. */
  wind(x: number, y: number, z: number): V3 {
    return this.at && this.vortex.speed > 0 ? windAt(this.vortex, x, y, z, [0, 0, 0], this.field.ground) : [0, 0, 0];
  }

  /**
   * Send it through a point on the ground: a new one touches down beyond it (off to the side of
   * whoever asked, so they see it come), one already down turns for it.
   */
  send(to: V3, from: V3): void {
    this.target.set(to[0], to[1]);
    this.passed = false;
    this.lifting = false;
    if (this.at) return;
    const away = new THREE.Vector2(to[0] - from[0], to[1] - from[1]);
    if (away.lengthSq() < 1) away.set(0, 1);
    away.normalize().rotateAround(new THREE.Vector2(), 1.0);
    this.at = this.target.clone().addScaledVector(away, APPROACH);
    this.heading.copy(away).negate();
    this.power = 0;
    this.clock = 0;
    const ef = EF[this.level];
    this.speed = turnOf(ef);
    this.radius = ef.radius;
    this.height = ef.height;
    this.glass = this.host.site.s.pieces.reduce((n, p, i) => n + (p.mat === 'glass' && this.host.site.s.bodies[i] ? 1 : 0), 0);
  }

  /** Lift it now. */
  end(): void {
    if (this.at) this.lifting = true;
  }

  update(dt: number): void {
    const { field, host } = this;
    if (!this.at) {
      field.vortex = null;
      host.particles.vortex.value.w = 0;
      return;
    }
    this.clock += dt;
    const ef = EF[this.level];
    // The sky closes over first
    if (this.clock < BREW && !this.lifting) {
      field.vortex = null;
      host.particles.vortex.value.w = 0;
      return;
    }
    // Forming, holding, lifting; and easing to the strength chosen if that changed
    this.power = this.lifting ? Math.max(0, this.power - dt / LIFT) : Math.min(1, this.power + dt / FORM);
    const ease = 1 - Math.exp(-dt * 0.8);
    this.speed += (turnOf(ef) - this.speed) * ease;
    this.radius += (ef.radius - this.radius) * ease;
    this.height += (ef.height - this.height) * ease;
    if (this.lifting && this.power <= 0) {
      this.at = null;
      field.vortex = null;
      host.particles.vortex.value.w = 0;
      return;
    }
    // The track: towards the mark, turning no faster than a real one wanders, then on past it
    const to = this.target.clone().sub(this.at);
    const far = to.length();
    if (!this.passed) {
      if (far < 3 || to.dot(this.heading) < 0) {
        this.passed = true;
        this.beyond = BEYOND;
      } else {
        const want = to.normalize();
        const turn = Math.atan2(this.heading.x * want.y - this.heading.y * want.x, this.heading.dot(want));
        const step = Math.sign(turn) * Math.min(Math.abs(turn), 0.5 * dt);
        this.heading.rotateAround(new THREE.Vector2(), step);
      }
    }
    const wander = Math.sin(this.clock * 0.7) * 0.25 + Math.sin(this.clock * 1.9 + 1.3) * 0.12;
    const side = new THREE.Vector2(-this.heading.y, this.heading.x);
    const vel = this.heading.clone().multiplyScalar(ef.travel).addScaledVector(side, wander * ef.travel);
    this.at.addScaledVector(vel, dt);
    if (this.passed) {
      this.beyond -= ef.travel * dt;
      if (this.beyond <= 0) this.lifting = true;
    }
    const v = this.vortex;
    v.x = this.at.x;
    v.y = this.at.y;
    v.radius = this.radius;
    v.speed = this.speed * this.power;
    v.vx = vel.x;
    v.vy = vel.y;
    v.height = this.height;
    field.vortex = v.speed > 1 ? v : null;

    // The funnel's cloud and the dust at its foot, carried by the same vortex
    const p = host.particles;
    p.vortex.value.set(v.x, v.y, v.radius, v.speed);
    p.vortexShape.value.set(v.height, 1, 0.3, 0);
    const reach = Math.min(1, this.power * 1.4);
    // (It comes down from the cloud and goes back up into it: the wall is drawn from the top as
    // far down as it reaches now)
    const bottom = 1 - reach;
    this.cloud += dt * 520 * (0.5 + 0.1 * this.level);
    const nc = Math.floor(this.cloud);
    this.cloud -= nc;
    if (nc > 0) {
      const o = new Float32Array(nc * 3);
      for (let k = 0; k < nc; k++) {
        const u = bottom + (1 - bottom) * Math.random() ** 1.35;
        const z = u * v.height;
        const wall = v.radius * (0.4 + 0.6 * u ** 1.5 + 1.3 * u ** 5) * (0.85 + 0.3 * Math.random());
        const a = Math.random() * Math.PI * 2;
        o.set([v.x + Math.cos(a) * wall, v.y + Math.sin(a) * wall, z + 0.5], k * 3);
      }
      p.puffs(o, false, 1.3 + v.radius * 0.24, 2.8, CLOUD, 0.55 * Math.min(1, this.power * 2), 0.9);
    }
    // Dust and dirt torn off the ground, once it's down
    if (reach > 0.85) {
      this.dust += dt * 190 * (0.5 + 0.12 * this.level) * this.power;
      const nd = Math.floor(this.dust);
      this.dust -= nd;
      if (nd > 0) {
        const o = new Float32Array(nd * 3);
        for (let k = 0; k < nd; k++) {
          const r = v.radius * (0.3 + 2.1 * Math.random() ** 0.8);
          const a = Math.random() * Math.PI * 2;
          const dx = v.x + Math.cos(a) * r;
          const dy = v.y + Math.sin(a) * r;
          o.set([dx, dy, terrainHeight(dx, dy) + 0.4 + Math.random() * 2.5], k * 3);
        }
        p.puffs(o, true, 1.6 + v.radius * 0.16, 3.2, DIRT, 0.5, 1.4);
      }
    }
  }

  /** After a readback: the wind tears off what it can reach (TEARS), panes blow in, and a holed building vents. */
  readback(): void {
    if (!this.at || this.vortex.speed < 1) return;
    const { site, exposure } = this.host;
    const s = site.s;
    const n = s.pieces.length;
    if (this.torn.length < n) {
      const t = new Uint8Array(n + 256);
      t.set(this.torn);
      this.torn = t;
    }
    const w: V3 = [0, 0, 0];
    let panes = 0;
    for (let i = 0; i < n; i++) {
      const p = s.pieces[i];
      let rule = TEARS[p.mat];
      if (p.mat === 'stone' && !this.torn[i] && !p.fixed) {
        const [a, b] = [...p.size].sort((x, y) => y - x);
        const fail = Math.sqrt((2 * STONE.mortar * STONE.friction * s.mass[i] * 9.81) / (0.0012 * STONE.drag * a * b));
        rule = [fail, fail * 0.15];
      }
      if (!rule || this.torn[i] || p.fixed) continue;
      const b = s.bodies[i];
      if (!b) continue;
      if (p.mat === 'glass') panes++;
      if (p.mat === 'steel' && Math.min(p.size[0], p.size[1], p.size[2]) > SHEET) continue;
      const open = exposure.exposure[i] ?? 1;
      if (open <= 0.05) continue;
      const at = b.position;
      windAt(this.vortex, at[0], at[1], at[2], w, this.field.ground);
      // (Gusting a fifth either way, piece by piece; and felt by how much of it is in the open)
      const speed = Math.hypot(w[0], w[1], w[2]) * (1 + 0.2 * Math.sin(this.clock * 2.3 + i * 1.7)) * Math.sqrt(open);
      if (speed < rule[0] + rule[1] * (2 * hash(i) - 1)) continue;
      this.torn[i] = 1;
      if (p.mat === 'glass') site.shatter(i, [w[0] * 0.2, w[1] * 0.2, w[2] * 0.1]);
      else s.release(i);
    }
    // With its windows gone a building no longer holds the core's low pressure out
    this.field.sealed = this.glass > 0 ? 0.25 * (panes / this.glass) : 0.05;
  }
}

const hash = (i: number) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
