// Disasters: a tornado, an earthquake and fire, for any structure built of pieces and welds.
//
// They need nothing from a level but its Site (the structure's pieces, bodies and welds as
// physics/structure.ts keeps them): none of them knows what a mill is. To use them in a level:
//
//   const disasters = new Disasters(site, view, fx);   // once, before the first frame is drawn
//   disasters.update(dt, eye);                         // every frame, before the physics steps
//   disasters.readback();                              // after each readback (site.reads changed)
//
// and then `disasters.tornado.send(point, from)`, `disasters.quake.start()`, `disasters.fire.light(piece)`.
// The forces go on inside the world's own step (field.ts hooks it), so the level's loop is unchanged.

import type * as THREE from 'three/webgpu';
import { lap } from '../dev/laps.ts';
import type { Particles } from '../fx/particles.ts';
import type { Fx } from '../game/fx.ts';
import type { Site } from '../game/site.ts';
import type { V3 } from '../physics/builder.ts';
import type { WeldKind } from '../physics/materials.ts';
import type { View } from '../render/view.ts';
import { Exposure } from './exposure.ts';
import { ForceField } from './field.ts';
import { Fire } from './fire.ts';
import { LENGTHS, MAGNITUDES, Quake } from './quake.ts';
import { EF, Tornado } from './tornado.ts';
import { TIME_NAME, type TimeOfDay, Weather } from './weather.ts';

export { EF, LENGTHS, MAGNITUDES, TIME_NAME };
export type { TimeOfDay };

/** What a disaster works on. */
export interface DisasterHost {
  site: Site;
  view: View;
  fx: Fx;
  particles: Particles;
  exposure: Exposure;
}

const G = 9.81;
/**
 * The welds that hold cladding and glass on. The game arms them for a few g (a sledge knocks a board off);
 * while the wind blows or the ground shakes they are held as real fixings hold, several times that, so
 * cladding passes its load to the frame and stays on a frame that racks, as it does on a real building.
 * Afterwards each goes back to how it was armed, once it is off its load.
 */
const FIXINGS: ReadonlySet<WeldKind> = new Set<WeldKind>(['nail', 'putty']);
const BRACED = 8;

export class Disasters {
  readonly field: ForceField;
  readonly exposure: Exposure;
  readonly tornado: Tornado;
  readonly quake: Quake;
  readonly fire: Fire;
  readonly weather: Weather;
  private readonly host: DisasterHost;
  private look = 0;
  private rumble = 0;
  private braced = false;
  /** Seconds of calm since the last disaster, while fixings are still to be put back. */
  private calm = 0;
  /** How far the view is thrown about by the ground (m), to add to the camera. */
  readonly sway: V3 = [0, 0, 0];

  constructor(site: Site, view: View, fx: Fx) {
    this.field = new ForceField(site.world);
    this.exposure = new Exposure(site.s, this.field);
    this.host = { site, view, fx, particles: fx.particles, exposure: this.exposure };
    this.tornado = new Tornado(this.host, this.field);
    this.quake = new Quake(this.field);
    this.fire = new Fire(this.host);
    this.weather = new Weather(view);
    this.field.onStep = (dt) => this.quake.step(dt);
    // What's exposed as built, ready for the first gust: started here and worked through a little a frame
    // (update), so setting up holds the page for none of it
    this.exposure.begin();
  }

  /**
   * Behind the loader: everything a disaster draws or runs for the first time, drawn and run once now (a
   * pipeline's first use stalls the frame it lands in). Call with true before the level's warm-up frames
   * and false after them.
   */
  warm(on: boolean): void {
    this.weather.warm(on);
    if (on) {
      this.field.warm();
      this.host.site.s.warmBrace();
    }
  }

  /** Every frame, before the physics steps. `eye` is where the player's head is. */
  update(dt: number, eye: THREE.Vector3): void {
    const { site, fx } = this.host;
    const rough = this.tornado.active || this.quake.active;
    if (rough) {
      if (!this.braced || this.calm > 0) lap('brace', () => site.s.brace(FIXINGS, BRACED));
      this.braced = true;
      this.calm = 0;
    } else if (this.braced) {
      const before = Math.floor(this.calm);
      this.calm += dt;
      if (this.calm > 3 && Math.floor(this.calm) !== before && (site.s.relax() === 0 || this.calm > 60)) this.braced = false;
    }
    if (this.judge) {
      this.judge = false;
      lap('tornadoRules', () => this.tornado.readback());
    }
    lap('tornado', () => this.tornado.update(dt));
    lap('fire', () => this.fire.update(dt));
    // While the wind blows, what's exposed is looked at again as the building comes apart
    if (!this.tornado.active) lap('exposure', () => this.exposure.work(1.5));
    else {
      this.look += dt;
      if (!this.exposure.busy && this.look > 0.5) {
        this.look = 0;
        lap('exposure', () => this.exposure.begin());
      }
      // (A millisecond or so a frame: a whole round at once was a 10 to 15 ms spike twice a second)
      lap('exposure', () => this.exposure.work(1.2));
    }
    // Debris in a tornado flies faster than anything in a collapse
    site.speedLimit = this.tornado.active ? 52 : 40;
    const wind = this.tornado.wind(eye.x, eye.y, eye.z);
    lap('weather', () => this.weather.update(dt, this.tornado.storm, wind));

    // Felt: the wind buffets the view, the ground throws it about
    const blow = Math.hypot(wind[0], wind[1], wind[2]);
    if (blow > 8) fx.trauma = Math.max(fx.trauma, Math.min(0.45, (blow / 70) ** 2 * 0.5));
    const a = this.quake.accel;
    const shake = Math.hypot(a[0], a[1], a[2]) / G;
    if (shake > 0.01) fx.trauma = Math.max(fx.trauma, Math.min(0.8, shake * 1.2));
    for (let k = 0; k < 3; k++) this.sway[k] = this.quake.sway[k];

    // Heard
    const sounds = fx.sounds;
    const at = this.tornado.position;
    const far = at ? Math.hypot(at[0] - eye.x, at[1] - eye.y) : 0;
    sounds.ambient('wind_storm', at ? Math.min(1, 0.25 + 22 / (22 + far)) * Math.min(1, this.weather.storm * 1.4) : 0, at ? [at[0], at[1], 6] : undefined, 0.85 + 0.06 * this.tornado.level);
    sounds.ambient('rain', Math.max(0, this.weather.storm - 0.25) * 0.55);
    this.rumble += (this.quake.intensity - this.rumble) * Math.min(1, dt * 4);
    sounds.ambient('quake', this.rumble * 0.9);
    const fc = this.fire.centre;
    sounds.ambient('fire', fc ? Math.min(0.8, 0.14 * Math.sqrt(this.fire.size)) / (1 + Math.hypot(fc[0] - eye.x, fc[1] - eye.y, fc[2] - eye.z) / 18) : 0, fc ?? undefined);
  }

  /**
   * After each readback of the bodies. What the wind tears off is judged in the next frame, not this one: this
   * one already carries the readback's own work, and the two together made a slow frame.
   */
  readback(): void {
    this.judge = true;
  }
  private judge = false;

  /** A word for each disaster's setting, for a HUD. */
  get status(): { tornado: string; quake: string; fire: string } {
    return {
      tornado: `${EF[this.tornado.level].name}${this.tornado.active ? ' ·' : ''}`,
      quake: this.quake.active ? `${Math.ceil(this.quake.left)} s` : `M${MAGNITUDES[this.quake.level].m} · ${this.quake.planned} s`,
      fire: this.fire.active ? `${this.fire.count}` : '',
    };
  }
}
