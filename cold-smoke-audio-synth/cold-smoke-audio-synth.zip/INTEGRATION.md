# 통합 메모 (원본 게임과의 결합 지점)

두 파일 모두 브라우저 Web Audio API 전용이며, 원본 게임(cold-smoke)의 전역을 참조합니다. 다른 게임에 붙이려면 아래 입력을 어댑터로 대체해야 합니다.

## 18_sound.js (효과음, 전역 `Sound`)
- 게임이 매 프레임 상태를 밀어 넣는 구조: 속도·엣지 각도·눈 하중·지면 접촉·점프/착지·날씨(원본에서 Render.R, Game, Course, Weather 참조).
- 주요 진입점(원본 호출부 기준): `Sound.build(ctx)` 초기 구성, `Sound.unlock()` 사용자 제스처 후 오디오 시작, `Sound.rig` 노드 그래프, `Sound.event(...)` 단발 효과(착지·충돌 등), `Sound.level`, `Sound.setOn(bool)`, `Sound.snapshot()`.
- 소스 재료(화이트/핑크 노이즈 등)는 최초 1회 합성. 스키 활주·엣지 스크레이프·눈 삐걱임·귓가 바람은 필드 레코딩 측정치를 바탕으로 설계됐다고 원 주석에 기록.

## 18b_music.js (생성 음악, 전역 `Music`)
- 5개 레이어(베드·펄스·베이스·시머·리드)가 90bpm 한 시계에 얹히는 생성형 스코어. 게임 상태(속도·엣지·시간대·점프)가 레이어 인/아웃과 조성을 바꿈.
- 진입점: `Music.build(ctx, dest)`, `Music.titleOn()`. 내부 상태 참조는 Variants(선택)와 Game 시간척도뿐이라 사운드보다 분리가 쉽습니다.
- A 장조 7음 고정, 시간대별 홈음 변경(낮 D / 황혼 A / 밤 B 등) 로직 포함.

## 공통 의존
- `core/00_util.js`의 RNG(시드 난수) — 동봉.
- `core/00b_variants.js`의 Variants — 선택 사항. 없으면 `typeof Variants !== 'undefined'` 가드로 기본값 사용. 동봉.
- 슬로모션(Game.timeScale)에 템포·피치가 따라가는 부분 등 Game 참조는 어댑터에서 제거하거나 상수로 대체.
