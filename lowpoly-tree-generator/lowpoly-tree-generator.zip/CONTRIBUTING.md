# Contributing

Issues and focused pull requests are welcome. Keep the geometry API scene-independent and keep optional
animation or controller features out of the base entrypoint.

## Development

```sh
npm install
npm test
npm pack --dry-run
```

Changes to CSG ordering, junction repair, curve sampling, or skin weights should include a regression test.
Generated models, textures, purchased assets, and proprietary Rand Monster game code must not be added to
this repository.

## Credits

Credit any algorithm, code, dataset, or asset introduced by a contribution. If code is adapted, preserve
its license notice and confirm that its license is compatible with MIT distribution. Add research and
product references to `CREDITS.md`; add runtime library notices to `THIRD_PARTY_NOTICES.md`.
