import assert from 'node:assert/strict'
import test from 'node:test'
import {
  LOWPOLY_TREE_ARCHETYPES,
  buildLowpolyTreeVineGeometry,
  createLowpolyTreeArchetypeParams,
  createLowpolyTreeRecipe,
  createLowpolyTreeVineRecipe,
  normalizeLowpolyTreeVineParameters,
} from '../src/index.js'

test('curated archetypes expose distinct editable silhouettes', () => {
  const ids = Object.keys(LOWPOLY_TREE_ARCHETYPES)
  assert.equal(ids.length, 6)
  const signatures = new Set()
  for (const id of ids) {
    const params = createLowpolyTreeArchetypeParams(id)
    const recipe = createLowpolyTreeRecipe(params, { kind: id })
    signatures.add([
      params.height,
      params.baseRadius,
      recipe.roots.length,
      recipe.branches.length,
      recipe.secondaryBranches.length,
      recipe.canopy.clusters.length,
    ].join(':'))
  }
  assert.equal(signatures.size, ids.length)
})

test('vine parameters are bounded and remain serializable', () => {
  const params = normalizeLowpolyTreeVineParameters({
    vineEnabled: true,
    vineCount: 99,
    vineSegments: 2,
    vineDrag: 4,
    vineRadius: -2,
  })
  assert.equal(params.vineEnabled, true)
  assert.equal(params.vineCount, 16)
  assert.equal(params.vineSegments, 4)
  assert.equal(params.vineDrag, 0.999)
  assert.equal(params.vineRadius, 0.008)
  assert.deepEqual(JSON.parse(JSON.stringify(params)), params)
})

test('vine recipes use semantic branch anchors and deterministic foliage', () => {
  const tree = createLowpolyTreeRecipe({
    branchCount: 4,
    secondaryBranchCount: 8,
    vineEnabled: true,
    vineCount: 6,
    vineDualAnchorCount: 3,
    vineBranchCount: 2,
    vineLeavesPerBranch: 3,
    vineSeed: 77,
  })
  const repeated = createLowpolyTreeVineRecipe(tree, tree.params)
  assert.deepEqual(tree.vines, repeated)
  assert.equal(tree.vines.vines.length, 6)
  assert.equal(tree.vines.vines.filter((vine) => vine.end).length, 3)
  assert.ok(tree.vines.vines.filter((vine) => vine.start.level === 'secondary').length >= 3)
  assert.ok(tree.vines.vines.some((vine) => vine.start.level === 'primary'))
  assert.ok(tree.vines.vines.every((vine) => vine.start.level !== 'trunk'))
  assert.ok(tree.vines.vines.every((vine) => vine.branchlets.length === 2))
  assert.ok(tree.vines.vines.every((vine) => vine.branchlets.every((branch) => branch.leafCount === 3)))
})

test('static vine mesh includes faceted cables, branches, leaves, and vertex colors', () => {
  const tree = createLowpolyTreeRecipe(createLowpolyTreeArchetypeParams('ancientGuardian'))
  const { geometry, stats } = buildLowpolyTreeVineGeometry(tree.vines)
  assert.equal(stats.vines, 6)
  assert.equal(stats.dualAnchored, 3)
  assert.equal(stats.sideBranches, 12)
  assert.equal(stats.leaves, 24)
  assert.ok(stats.triangles > 500)
  assert.ok(geometry.getAttribute('position').count > 0)
  assert.equal(geometry.getAttribute('position').count, geometry.getAttribute('color').count)
  assert.ok(Array.from(geometry.getAttribute('position').array).every(Number.isFinite))
  geometry.dispose()
})

test('default recipes keep optional vines disabled', () => {
  const tree = createLowpolyTreeRecipe()
  assert.equal(tree.vines.enabled, false)
  assert.deepEqual(tree.vines.vines, [])
})
