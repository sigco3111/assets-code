import assert from 'node:assert/strict'
import test from 'node:test'
import * as THREE from 'three'
import {
  LOWPOLY_TREE_PARAMETER_DEFAULTS,
  auditLowpolyTreeGeometry,
  buildLowpolyTreeGeometry,
  buildLowpolyTreePreviewGeometry,
  buildSweepTubeGeometry,
  countLowpolyTreeConnectedComponents,
  countLowpolyTreeTriangles,
  createLowpolyTreeRecipe,
} from '../src/index.js'
import {
  LOWPOLY_TREE_ANIMATION_PRESETS,
  applyLowpolyTreeKeyframes,
  captureLowpolyTreeRigPose,
  createLowpolyTreeKeyframeClip,
  createLowpolyTreePresetClips,
  createLowpolyTreeRig,
  createLowpolyTreeWalkClip,
  createLowpolyTreeWindClip,
  resetLowpolyTreeRigPose,
  updateLowpolyTreeRig,
  updateLowpolyTreePresetRig,
  updateLowpolyTreeWalkRig,
} from '../src/animation.js'
import { createLowpolyTreeAnimationController } from '../src/controller.js'
import * as generatorApi from '../src/index.js'
import * as animationApi from '../src/animation.js'

test('public entrypoints keep generation, animation, and control independent', () => {
  assert.equal('buildLowpolyTreeGeometry' in generatorApi, true)
  assert.equal('createLowpolyTreeRig' in generatorApi, false)
  assert.equal('createLowpolyTreeRig' in animationApi, true)
  assert.equal('buildLowpolyTreeGeometry' in animationApi, false)
})

test('default tree is grounded, welded, and under budget', () => {
  const recipe = createLowpolyTreeRecipe()
  const { geometry, stats } = buildLowpolyTreeGeometry(recipe)
  assert.equal(stats.branchCount, 2)
  assert.equal(stats.secondaryBranchCount, 2)
  assert.equal(stats.canopyCount, 3)
  assert.equal(stats.canopyTriangles, 60)
  assert.equal(stats.csgClipMode, 'robust-cdt')
  assert.equal(stats.woodConnectedComponents, 1)
  assert.equal(stats.junctionGuaranteed, true)
  assert.ok(geometry.getAttribute('color'))
  assert.equal(stats.budgetSatisfied, true)
  assert.ok(countLowpolyTreeTriangles(geometry) <= 500)
  assert.deepEqual(auditLowpolyTreeGeometry(geometry), {
    boundaryEdges: stats.topology.boundaryEdges,
    boundaryEdgesAboveGround: 0,
    nonManifoldEdges: 0,
    belowGroundVertices: 0,
  })
  geometry.dispose()
})

test('extreme requested resolution falls back without deleting roots or branches', () => {
  const recipe = createLowpolyTreeRecipe({
    ...LOWPOLY_TREE_PARAMETER_DEFAULTS,
    sections: 11,
    sides: 9,
    rootCount: 6,
    rootSegments: 5,
    rootProfileSides: 6,
    rootLength: 1.5,
    rootWidth: 0.46,
    rootHeight: 0.5,
    rootSpread: 0.42,
    rootWander: 0.55,
    branchCount: 4,
    branchSegments: 5,
    branchSides: 6,
    branchLength: 1.8,
    branchRadiusScale: 0.9,
    secondaryBranchCount: 0,
  })
  const { geometry, stats } = buildLowpolyTreeGeometry(recipe)
  assert.equal(stats.rootCount, 6)
  assert.equal(stats.branchCount, 4)
  assert.equal(stats.secondaryBranchCount, 0)
  assert.equal(stats.canopyCount, 3)
  assert.equal(stats.canopyDetail, 'budget-8')
  assert.equal(stats.budgetSatisfied, true)
  assert.ok(stats.triangles <= 500)
  assert.notEqual(stats.resolutionLevel, 'requested')
  assert.equal(stats.topology.boundaryEdgesAboveGround, 0)
  geometry.dispose()
})

test('rootless recipes retain a grounded open base', () => {
  const recipe = createLowpolyTreeRecipe({ rootCount: 0 })
  const { geometry, stats } = buildLowpolyTreeGeometry(recipe)
  assert.equal(stats.rootCount, 0)
  assert.equal(stats.topology.boundaryEdgesAboveGround, 0)
  assert.equal(stats.topology.belowGroundVertices, 0)
  geometry.dispose()
})

test('branchless and rootless recipes build a single clean trunk', () => {
  const recipe = createLowpolyTreeRecipe({ rootCount: 0, branchCount: 0, canopyEnabled: false })
  const { geometry, stats } = buildLowpolyTreeGeometry(recipe)
  assert.equal(stats.mergedParts, 1)
  assert.equal(stats.csgPasses, 0)
  assert.equal(stats.topology.boundaryEdgesAboveGround, 0)
  assert.equal(stats.topology.nonManifoldEdges, 0)
  geometry.dispose()
})

test('preview preserves all parts without running CSG', () => {
  const recipe = createLowpolyTreeRecipe({ rootCount: 6, branchCount: 4 })
  const { geometry, stats } = buildLowpolyTreePreviewGeometry(recipe)
  assert.equal(stats.preview, true)
  assert.equal(stats.junctionMode, 'overlap-preview')
  assert.equal(stats.mergedParts, 16)
  assert.equal(stats.rootCount, 6)
  assert.equal(stats.branchCount, 4)
  assert.equal(stats.secondaryBranchCount, 2)
  assert.equal(stats.canopyCount, 3)
  assert.equal(stats.canopyTriangles, 60)
  assert.ok(countLowpolyTreeTriangles(geometry) > 0)
  geometry.dispose()
})

test('curve point offsets move the trunk, roots, and branch anchors together', () => {
  const baseline = createLowpolyTreeRecipe({ sections: 5 })
  const offset = [0.24, 0.08, -0.13]
  const edited = createLowpolyTreeRecipe({
    sections: 5,
    curvePointOffsets: Array.from({ length: 5 }, () => offset),
  })
  for (let i = 0; i < edited.points.length; i++) {
    assert.ok(Math.abs(edited.points[i][0] - baseline.points[i][0] - offset[0]) < 1e-4)
    assert.ok(Math.abs(edited.points[i][1] - baseline.points[i][1] - offset[1]) < 1e-4)
    assert.ok(Math.abs(edited.points[i][2] - baseline.points[i][2] - offset[2]) < 1e-4)
  }
  assert.ok(Math.abs(edited.roots[0].points[0][0] - baseline.roots[0].points[0][0] - offset[0]) < 1e-4)
  assert.ok(Math.abs(edited.roots[0].points[0][2] - baseline.roots[0].points[0][2] - offset[2]) < 1e-4)
  assert.ok(Math.abs(edited.branches[0].points[0][0] - baseline.branches[0].points[0][0] - offset[0]) < 1e-4)
  assert.ok(Math.abs(edited.branches[0].points[0][1] - baseline.branches[0].points[0][1] - offset[1]) < 1e-4)
  assert.ok(Math.abs(edited.branches[0].points[0][2] - baseline.branches[0].points[0][2] - offset[2]) < 1e-4)
  assert.ok(Math.abs(edited.canopy.clusters[0].center[0] - baseline.canopy.clusters[0].center[0] - offset[0]) < 1e-4)
  assert.ok(Math.abs(edited.canopy.clusters[0].center[1] - baseline.canopy.clusters[0].center[1] - offset[1]) < 1e-4)
  assert.ok(Math.abs(edited.canopy.clusters[0].center[2] - baseline.canopy.clusters[0].center[2] - offset[2]) < 1e-4)
})

test('root point offsets preserve the trunk joint and allow grounded vertical shaping', () => {
  const baseline = createLowpolyTreeRecipe({ rootSegments: 4 })
  const pointOffset = [0.14, 0.18, -0.12]
  const zero = [0, 0, 0]
  const edited = createLowpolyTreeRecipe({
    rootSegments: 4,
    rootPointOffsets: [
      [zero, pointOffset, zero, zero],
      [zero, zero, zero, zero],
      [zero, zero, zero, zero],
      [zero, zero, zero, zero],
      [zero, zero, zero, zero],
    ],
  })
  assert.deepEqual(edited.roots[0].points[0], baseline.roots[0].points[0])
  assert.ok(Math.abs(edited.roots[0].points[1][0] - baseline.roots[0].points[1][0] - pointOffset[0]) < 1e-4)
  assert.ok(Math.abs(edited.roots[0].points[1][1] - pointOffset[1]) < 1e-4)
  assert.ok(Math.abs(edited.roots[0].points[1][2] - baseline.roots[0].points[1][2] - pointOffset[2]) < 1e-4)
  assert.ok(edited.roots.every((root) => root.points.every((point) => point[1] >= 0)))
  const { geometry, stats } = buildLowpolyTreeGeometry(edited)
  assert.equal(stats.budgetSatisfied, true)
  assert.equal(stats.topology.boundaryEdgesAboveGround, 0)
  assert.equal(stats.topology.belowGroundVertices, 0)
  geometry.dispose()
})

test('profile twist rotates sweep rings without changing the triangle budget', () => {
  const options = {
    points: [[0, 0, 0], [0, 1, 0], [0, 2, 0]],
    radii: [0.4, 0.3, 0.2],
    sides: 5,
    capStart: true,
    capEnd: true,
  }
  const baseline = buildSweepTubeGeometry(options)
  const twisted = buildSweepTubeGeometry({ ...options, twistTurns: 0.75, twistPhase: 0.2 })
  const baselinePosition = baseline.getAttribute('position')
  const twistedPosition = twisted.getAttribute('position')
  assert.equal(countLowpolyTreeTriangles(twisted), countLowpolyTreeTriangles(baseline))
  assert.notEqual(twistedPosition.getX(options.sides), baselinePosition.getX(options.sides))
  assert.ok(Math.abs(Math.hypot(
    twistedPosition.getX(options.sides),
    twistedPosition.getZ(options.sides),
  ) - options.radii[1]) < 1e-5)
  baseline.dispose()
  twisted.dispose()
})

test('core sockets keep roots connected through extreme trunk rotations', () => {
  const variants = [
    {
      sides: 4,
      baseRadius: 0.16,
      rootCount: 6,
      rootSegments: 3,
      rootWidth: 0.08,
      rootHeight: 0.06,
      profileTwistTurns: 2.5,
      profileTwistPhase: 3.14,
    },
    {
      sides: 9,
      baseRadius: 0.62,
      rootCount: 6,
      rootSegments: 5,
      profileTwistTurns: -2.5,
      profileTwistPhase: -3.14,
      twistRadius: 0.32,
      twistTurns: 1.5,
      twistPhase: 2.8,
    },
    {
      sides: 5,
      rootCount: 5,
      rootWander: 0.55,
      rootSpread: 0.42,
      profileTwistTurns: 2.2,
      profileTwistPhase: 1.7,
      sCurveX: 0.8,
      sCurveZ: -0.8,
    },
  ]
  for (const params of variants) {
    const recipe = createLowpolyTreeRecipe({
      ...params,
      branchCount: 0,
      secondaryBranchCount: 0,
      canopyEnabled: false,
    })
    const { geometry, stats } = buildLowpolyTreeGeometry(recipe)
    assert.equal(stats.woodConnectedComponents, 1)
    assert.equal(stats.junctionGuaranteed, true)
    assert.equal(countLowpolyTreeConnectedComponents(geometry), 1)
    assert.equal(stats.topology.boundaryEdgesAboveGround, 0)
    assert.ok(stats.triangles <= 500)
    geometry.dispose()
  }
})

test('primary branch point offsets preserve the trunk joint and move descendants', () => {
  const baseline = createLowpolyTreeRecipe({ branchSegments: 4, secondaryBranchCount: 2 })
  const pointOffset = [0.16, 0.08, -0.09]
  const zero = [0, 0, 0]
  const edited = createLowpolyTreeRecipe({
    branchSegments: 4,
    secondaryBranchCount: 2,
    primaryBranchPointOffsets: [
      [zero, pointOffset, zero, zero],
      [zero, zero, zero, zero],
    ],
  })
  assert.deepEqual(edited.branches[0].points[0], baseline.branches[0].points[0])
  for (let axis = 0; axis < 3; axis++) {
    assert.ok(Math.abs(
      edited.branches[0].points[1][axis]
      - baseline.branches[0].points[1][axis]
      - pointOffset[axis]
    ) < 1e-4)
  }
  assert.notDeepEqual(edited.secondaryBranches[0].points.at(-1), baseline.secondaryBranches[0].points.at(-1))
  assert.notDeepEqual(edited.canopy.clusters[1].attachPoint, baseline.canopy.clusters[1].attachPoint)
  const { geometry, stats } = buildLowpolyTreeGeometry(edited)
  assert.equal(stats.budgetSatisfied, true)
  assert.equal(stats.topology.boundaryEdgesAboveGround, 0)
  geometry.dispose()
})

test('secondary branch point offsets preserve the parent joint and move its canopy tip', () => {
  const baseline = createLowpolyTreeRecipe({ secondaryBranchSegments: 4, canopyClusterCount: 3 })
  const middleOffset = [-0.08, 0.07, 0.12]
  const tipOffset = [0.14, 0.1, -0.11]
  const zero = [0, 0, 0]
  const edited = createLowpolyTreeRecipe({
    secondaryBranchSegments: 4,
    canopyClusterCount: 3,
    secondaryBranchPointOffsets: [
      [zero, middleOffset, zero, tipOffset],
      [zero, zero, zero, zero],
    ],
  })
  assert.deepEqual(edited.secondaryBranches[0].points[0], baseline.secondaryBranches[0].points[0])
  for (let axis = 0; axis < 3; axis++) {
    assert.ok(Math.abs(
      edited.secondaryBranches[0].points[1][axis]
      - baseline.secondaryBranches[0].points[1][axis]
      - middleOffset[axis]
    ) < 1e-4)
    assert.ok(Math.abs(
      edited.secondaryBranches[0].points.at(-1)[axis]
      - baseline.secondaryBranches[0].points.at(-1)[axis]
      - tipOffset[axis]
    ) < 1e-4)
    assert.ok(Math.abs(
      edited.canopy.clusters[1].attachPoint[axis]
      - edited.secondaryBranches[0].points.at(-1)[axis]
    ) < 1e-4)
  }
  const { geometry, stats } = buildLowpolyTreeGeometry(edited)
  assert.equal(stats.budgetSatisfied, true)
  assert.equal(stats.topology.boundaryEdgesAboveGround, 0)
  geometry.dispose()
})

test('secondary branch tip offsets drive terminal canopy attachments', () => {
  const baseline = createLowpolyTreeRecipe({ secondaryBranchCount: 2, canopyClusterCount: 3 })
  const tipOffset = [0.22, 0.11, -0.16]
  const edited = createLowpolyTreeRecipe({
    secondaryBranchCount: 2,
    canopyClusterCount: 3,
    secondaryBranchTipOffsets: [tipOffset, [0, 0, 0]],
  })
  const baselineTip = baseline.secondaryBranches[0].points.at(-1)
  const editedTip = edited.secondaryBranches[0].points.at(-1)
  for (let axis = 0; axis < 3; axis++) {
    assert.ok(Math.abs(editedTip[axis] - baselineTip[axis] - tipOffset[axis]) < 1e-4)
    assert.ok(Math.abs(edited.canopy.clusters[1].attachPoint[axis] - editedTip[axis]) < 1e-4)
  }
  assert.equal(edited.canopy.clusters[1].anchor, 'secondary-branch-1')
  const attachedCluster = edited.canopy.clusters[1]
  const attachmentDistance = Math.hypot(...attachedCluster.attachPoint.map((value, axis) => (
    (value - attachedCluster.center[axis]) / attachedCluster.scale[axis]
  )))
  assert.ok(attachmentDistance <= 0.721)
  const { geometry, stats } = buildLowpolyTreeGeometry(edited)
  assert.equal(stats.secondaryBranchCount, 2)
  assert.equal(stats.budgetSatisfied, true)
  assert.equal(stats.topology.boundaryEdgesAboveGround, 0)
  geometry.dispose()
})

test('curve hierarchy creates normalized weights and baked wind and walk clips', () => {
  const recipe = createLowpolyTreeRecipe({
    sections: 7,
    branchCount: 2,
    branchSegments: 3,
    secondaryBranchCount: 2,
    secondaryBranchSegments: 3,
    canopyClusterCount: 4,
  })
  const { geometry, stats } = buildLowpolyTreeGeometry(recipe)
  const root = new THREE.Group()
  const mesh = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ vertexColors: true }))
  mesh.name = 'csg-union-wood-and-lowpoly-canopy'
  root.add(mesh)
  const rig = createLowpolyTreeRig(root, recipe)

  assert.equal(rig.mesh.isSkinnedMesh, true)
  assert.equal(rig.bones.length, 39)
  assert.equal(rig.trunkBones.length, 7)
  assert.deepEqual(rig.rootBoneChains.map((chain) => chain.length), [4, 4, 4, 4, 4])
  assert.deepEqual(rig.primaryBoneChains.map((chain) => chain.length), [3, 3])
  assert.deepEqual(rig.secondaryBoneChains.map((chain) => chain.length), [3, 3])
  assert.equal(rig.mesh.geometry.getAttribute('skinIndex').count, rig.mesh.geometry.getAttribute('position').count)
  const weights = rig.mesh.geometry.getAttribute('skinWeight')
  const indices = rig.mesh.geometry.getAttribute('skinIndex')
  for (let index = 0; index < weights.count; index++) {
    const total = weights.getX(index) + weights.getY(index) + weights.getZ(index) + weights.getW(index)
    assert.ok(Math.abs(total - 1) < 1e-5)
  }
  const rootBoneIndices = new Set(rig.rootBoneChains.flat().map((bone) => rig.bones.indexOf(bone)))
  const usedBoneIndices = new Set(Array.from({ length: indices.count }, (_, index) => [
    indices.getX(index),
    indices.getY(index),
    indices.getZ(index),
    indices.getW(index),
  ]).flat())
  assert.ok([...usedBoneIndices].some((boneIndex) => rootBoneIndices.has(boneIndex)))
  assert.deepEqual(new Set([...usedBoneIndices].map((boneIndex) => rig.bones[boneIndex].userData.treeRigLevel)), new Set([
    'trunk',
    'root',
    'primary',
    'secondary',
  ]))

  const before = rig.animatedBones.map((entry) => entry.bone.quaternion.clone())
  updateLowpolyTreeRig(rig, 1.25)
  assert.ok(rig.animatedBones.some((entry, index) => !entry.bone.quaternion.equals(before[index])))
  const clip = createLowpolyTreeWindClip(rig)
  assert.equal(clip.name, 'TreeWind')
  assert.equal(clip.duration, 4)
  assert.equal(clip.tracks.length, rig.animatedBones.length)
  for (const track of clip.tracks) {
    const size = track.getValueSize()
    const first = track.values.slice(0, size)
    const last = track.values.slice(-size)
    for (let index = 0; index < size; index++) assert.ok(Math.abs(first[index] - last[index]) < 1e-6)
  }
  const rootBefore = rig.walkRootBones.map((entry) => entry.bone.quaternion.clone())
  updateLowpolyTreeWalkRig(rig, 0.6)
  assert.ok(rig.walkRootBones.some((entry, index) => !entry.bone.quaternion.equals(rootBefore[index])))
  const walkClip = createLowpolyTreeWalkClip(rig)
  assert.equal(walkClip.name, 'TreeWalk')
  assert.equal(walkClip.duration, 2.4)
  assert.equal(walkClip.tracks.length, rig.walkTrunkBones.length + rig.walkRootBones.length + 1)
  assert.ok(walkClip.tracks.some((track) => track.name === 'rm-tree-trunk-00.position'))
  for (const track of walkClip.tracks) {
    const size = track.getValueSize()
    const first = track.values.slice(0, size)
    const last = track.values.slice(-size)
    for (let index = 0; index < size; index++) assert.ok(Math.abs(first[index] - last[index]) < 1e-6)
  }

  const presetClips = createLowpolyTreePresetClips(rig)
  assert.deepEqual(presetClips.map((presetClip) => presetClip.name), [
    'TreeIdle',
    'TreeWind',
    'TreeWalk',
    'TreeRun',
    'TreeStomp',
    'TreeAttack',
  ])
  assert.deepEqual(Object.keys(LOWPOLY_TREE_ANIMATION_PRESETS), ['idle', 'wind', 'walk', 'run', 'stomp', 'attack'])
  assert.ok(presetClips.every((presetClip) => presetClip.tracks.length > 0))

  updateLowpolyTreePresetRig(rig, 'attack', 0.45)
  const attackPose = captureLowpolyTreeRigPose(rig)
  resetLowpolyTreeRigPose(rig)
  const restPose = captureLowpolyTreeRigPose(rig)
  const customKeys = [
    { phase: 0, pose: restPose },
    { phase: 0.5, pose: attackPose },
  ]
  applyLowpolyTreeKeyframes(rig, customKeys, 1.5, { duration: 3 })
  assert.ok(rig.bones.some((bone) => !bone.quaternion.equals(new THREE.Quaternion(...restPose.bones[bone.name].quaternion))))
  const customClip = createLowpolyTreeKeyframeClip(rig, customKeys)
  assert.equal(customClip.name, 'TreeCustom')
  assert.ok(customClip.tracks.length > 0)
  const controller = createLowpolyTreeAnimationController({ clips: [...presetClips, customClip] })
  assert.equal(controller.entry, 'idle')
  assert.deepEqual(controller.states.map((state) => state.id), ['idle', 'walk', 'run', 'stomp', 'attack', 'custom'])
  assert.ok(controller.layers.some((layer) => layer.id === 'wind' && layer.mode === 'additive'))
  assert.equal(stats.budgetSatisfied, true)

  rig.skeleton.dispose()
  rig.mesh.geometry.dispose()
  rig.mesh.material.dispose()
})
