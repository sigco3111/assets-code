import assert from 'node:assert/strict'
import test from 'node:test'

import {
  LOWPOLY_TREE_ANIMATION_PROFILE_DEFAULTS,
  createLowpolyTreeAnimationProfile,
  createLowpolyTreeLiveAnimationProfile,
} from '../src/profile.js'

test('animation profiles normalize bounded motion and tuning values', () => {
  const profile = createLowpolyTreeAnimationProfile({
    walk: { duration: -4, strength: 99, windStrength: 0.9 },
    tuning: { body: 1.4, branches: -2, roots: 9 },
  })
  assert.equal(profile.walk.duration, 0.08)
  assert.equal(profile.walk.strength, 6)
  assert.equal(profile.walk.windStrength, 0.9)
  assert.equal(profile.tuning.body, 1.4)
  assert.equal(profile.tuning.branches, 0)
  assert.equal(profile.tuning.roots, 3)
  assert.equal(profile.idle.duration, LOWPOLY_TREE_ANIMATION_PROFILE_DEFAULTS.idle.duration)
})

test('live animation profiles patch in place, notify, snapshot, and reset', () => {
  const store = createLowpolyTreeLiveAnimationProfile()
  let notifications = 0
  const unsubscribe = store.subscribe(() => notifications++)
  store.patchMotion('run', { duration: 0.44, strength: 2.7 })
  store.patchTuning({ branches: 1.8 })
  const snapshot = store.snapshot()
  snapshot.run.duration = 8
  assert.equal(store.get().run.duration, 0.44)
  assert.equal(store.get().run.strength, 2.7)
  assert.equal(store.get().tuning.branches, 1.8)
  assert.equal(notifications, 2)
  assert.throws(() => store.patchMotion('fly', {}), /Unknown tree animation motion/)
  store.reset()
  assert.equal(store.get().run.duration, LOWPOLY_TREE_ANIMATION_PROFILE_DEFAULTS.run.duration)
  unsubscribe()
})
