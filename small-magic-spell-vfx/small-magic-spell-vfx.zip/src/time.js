// Time. Pressed, everything stops where it is: stones in the air, fire, smoke, leaves, the grass in mid sway. They
// alone go on walking, through it. Held, time is wound back: what fell flies up and sets itself where it was, welds
// close, trees stand, burnt ground is green again, smoke goes back down into its fire. Let go, it stands still
// again at that moment; pressed once more, time is let go from there.
//
// How: while time runs, what changes is written down thirty times a second, each entry holding what it changed
// from and to (the pieces that moved, the trees, the ground and its fire, how many welds had gone). Nothing is
// written while nothing happens, so winding back goes straight from one thing happening to the one before it.
// Winding back undoes entries from the last; when time is let go the physics is put where the pieces then are,
// going as they were, and the welds that had not yet broken are made again (ruin.js `memory`).
//
// Seen: the colour drains to a cold silver (gold while it winds back), a great dial of runes is written across the
// sky and turns backward as time does, and motes hang in the stopped air.
import * as THREE from 'three';
import { SIGIL } from './sigil.js';

const RATE = 30;            // entries a second while things are happening
const MOST = 140e6;         // bytes of it kept; the oldest goes first
const CELLS_EVERY = 3;      // the ground is looked at every so many entries

export function createTime({ air, world, fx, fire, ruin, blast, hole, twister, scene }) {
  const U = air.uniforms, shared = () => Object.fromEntries(Object.keys(U).map((k) => [k, U[k]]));
  const M = ruin?.memory ?? null, F = fire.memory, S = world.state, data = S.data, N = S.N;

  // --- what is written down ---
  // (`wt` is the world's own time, in seconds: each entry is stamped with it, and winding back runs it down)
  let log = [], bytes = 0, acc = 0, since = 0, wt = 0;
  const lastPos = M ? M.pos.slice() : null, lastRot = M ? M.rot.slice() : null;
  const sig = (o) => `${o.state}|${o.O.map((v) => v.toFixed(3))}|${o.Q.map((v) => v.toFixed(4))}|${o.strip.toFixed(3)}|${o.burnt.toFixed(2)}|${o.frost.toFixed(2)}|${o.burning.toFixed(2)}`;
  let lastTrees = M ? M.trees() : [], lastSigs = lastTrees.map(sig);
  const lastData = data.slice(), lastHeat = F.heat.slice(), lastFuel = F.fuel.slice(), lastReach = F.reach.slice();
  let keptNow = M ? M.breaks.length : 0;
  // (the great spells as they are, each as one line of text: written down when it changes, and put back; and how
  // many times the earth has been torn bare)
  const big = { b: blast, h: hole, t: twister }, lastBig = { b: JSON.stringify(blast.memory()), h: JSON.stringify(hole.memory()), t: JSON.stringify(twister.memory()) };
  const WHOLE = new Set(['struck', 'seed', 'nextFlash', 'flashes', 'ink', 'pace']);
  let bareNow = world.bared, went = 0;
  // (every tree's fire: how burnt, how frozen, whether it burns and how near to catching it is. All of them, those that cannot be felled too.)
  const woods = world.trees, lastFire = woods.map((w) => (w ? [w.burnt ?? 0, w.frost ?? 0, w.burning ?? 0, w.warm ?? 0] : null));
  const scratch = M ? new Uint16Array(M.count) : null;

  function note(dt) {
    const e = { t: wt, dt, idx: null, a: null, b: null, trees: null, fires: null, cells: null, big: null, bareA: bareNow, bareB: bareNow, keptA: keptNow, keptB: keptNow, size: 64 };
    let any = false;
    if (M) {
      const { pos, rot, count } = M;
      let n = 0;
      for (let k = 0; k < count; k++) {
        const p = k * 3, q = k * 4;
        if (Math.abs(pos[p] - lastPos[p]) + Math.abs(pos[p + 1] - lastPos[p + 1]) + Math.abs(pos[p + 2] - lastPos[p + 2]) > 4e-4 || Math.abs(rot[q] - lastRot[q]) + Math.abs(rot[q + 1] - lastRot[q + 1]) + Math.abs(rot[q + 2] - lastRot[q + 2]) + Math.abs(rot[q + 3] - lastRot[q + 3]) > 4e-4) scratch[n++] = k;
      }
      if (n) {
        e.idx = scratch.slice(0, n); e.a = new Float32Array(n * 7); e.b = new Float32Array(n * 7);
        for (let i = 0; i < n; i++) {
          const k = scratch[i], p = k * 3, q = k * 4, o = i * 7;
          e.a[o] = lastPos[p]; e.a[o + 1] = lastPos[p + 1]; e.a[o + 2] = lastPos[p + 2]; e.a[o + 3] = lastRot[q]; e.a[o + 4] = lastRot[q + 1]; e.a[o + 5] = lastRot[q + 2]; e.a[o + 6] = lastRot[q + 3];
          e.b[o] = lastPos[p] = pos[p]; e.b[o + 1] = lastPos[p + 1] = pos[p + 1]; e.b[o + 2] = lastPos[p + 2] = pos[p + 2]; e.b[o + 3] = lastRot[q] = rot[q]; e.b[o + 4] = lastRot[q + 1] = rot[q + 1]; e.b[o + 5] = lastRot[q + 2] = rot[q + 2]; e.b[o + 6] = lastRot[q + 3] = rot[q + 3];
        }
        e.size += n * 58; any = true;
      }
      const trees = M.trees();
      for (let g = 0; g < trees.length; g++) {
        const s = sig(trees[g]);
        if (s === lastSigs[g]) continue;
        (e.trees ??= []).push([g, lastTrees[g], trees[g]]);
        lastTrees[g] = trees[g]; lastSigs[g] = s; e.size += 600; any = true;
      }
      if (M.breaks.length !== keptNow) { e.keptB = keptNow = M.breaks.length; any = true; }
    }
    for (const key in big) { const s = JSON.stringify(big[key].memory()); if (s !== lastBig[key]) { (e.big ??= {})[key] = [JSON.parse(lastBig[key]), JSON.parse(s)]; lastBig[key] = s; e.size += 900; any = true; } }
    if (world.bared !== bareNow) { e.bareB = bareNow = world.bared; any = true; }
    for (let i = 1; i < woods.length; i++) {
      const w = woods[i], l = lastFire[i];
      if (!w || !l || ((w.burnt ?? 0) === l[0] && (w.frost ?? 0) === l[1] && (w.burning ?? 0) === l[2])) continue;
      const now = [w.burnt ?? 0, w.frost ?? 0, w.burning ?? 0, w.warm ?? 0];
      (e.fires ??= []).push([i, l, now]); lastFire[i] = now; e.size += 80; any = true;
    }
    if (++since >= CELLS_EVERY) {
      since = 0;
      const ks = [];
      for (let k = 0; k < N * N; k++) { const o = k * 4; if (data[o] !== lastData[o] || data[o + 1] !== lastData[o + 1] || data[o + 2] !== lastData[o + 2] || data[o + 3] !== lastData[o + 3] || F.heat[k] !== lastHeat[k] || F.fuel[k] !== lastFuel[k]) ks.push(k); }
      if (ks.length) {
        const n = ks.length, c = { k: Uint32Array.from(ks), da: new Uint8Array(n * 4), db: new Uint8Array(n * 4), fa: new Float32Array(n * 3), fb: new Float32Array(n * 3) };
        for (let i = 0; i < n; i++) {
          const k = ks[i], o = k * 4;
          for (let j = 0; j < 4; j++) { c.da[i * 4 + j] = lastData[o + j]; c.db[i * 4 + j] = lastData[o + j] = data[o + j]; }
          c.fa[i * 3] = lastHeat[k]; c.fa[i * 3 + 1] = lastFuel[k]; c.fa[i * 3 + 2] = lastReach[k];
          c.fb[i * 3] = lastHeat[k] = F.heat[k]; c.fb[i * 3 + 1] = lastFuel[k] = F.fuel[k]; c.fb[i * 3 + 2] = lastReach[k] = F.reach[k];
        }
        e.cells = c; e.size += n * 36; any = true;
      }
    }
    if (!any) return;
    log.push(e); bytes += e.size;
    while (bytes > MOST && log.length > 1) bytes -= log.shift().size;
  }

  // --- going back over it ---
  let phase = 'idle', frac = 0, speed = 0, wound = false, backFor = 0, pressed = false, heldFor = 0, fresh = false, woundNow = false, most = 1;
  const treeNow = new Map();
  const put = (e, f) => {
    // the pieces of an entry, somewhere between as it left them (f 0) and as it found them (f 1)
    const g = 1 - f;
    // (a great spell, between as it was left and as it was found: its numbers between the two, the rest from the nearer)
    if (e.big && f > 0 && f < 1) for (const key in e.big) { const [a, b] = e.big[key], o = {}; for (const n in b) o[n] = typeof b[n] === 'number' && typeof a[n] === 'number' && !WHOLE.has(n) ? b[n] * g + a[n] * f : f < 0.5 ? b[n] : a[n]; big[key].recall(o); }
    if (!e.idx) return;
    const { pos, rot } = M;
    for (let i = 0; i < e.idx.length; i++) {
      const k = e.idx[i], p = k * 3, q = k * 4, o = i * 7;
      pos[p] = e.b[o] * g + e.a[o] * f; pos[p + 1] = e.b[o + 1] * g + e.a[o + 1] * f; pos[p + 2] = e.b[o + 2] * g + e.a[o + 2] * f;
      const d = e.a[o + 3] * e.b[o + 3] + e.a[o + 4] * e.b[o + 4] + e.a[o + 5] * e.b[o + 5] + e.a[o + 6] * e.b[o + 6] < 0 ? -1 : 1;
      let x = e.b[o + 3] * g + d * e.a[o + 3] * f, y = e.b[o + 4] * g + d * e.a[o + 4] * f, z = e.b[o + 5] * g + d * e.a[o + 5] * f, w = e.b[o + 6] * g + d * e.a[o + 6] * f;
      const l = Math.hypot(x, y, z, w) || 1;
      rot[q] = x / l; rot[q + 1] = y / l; rot[q + 2] = z / l; rot[q + 3] = w / l;
    }
    if (e.trees && f > 0 && f < 1) for (const [n, a, b] of e.trees) {
      if (a.state !== b.state) continue;
      const O = b.O.map((v, i) => v * g + a.O[i] * f), d = a.Q[0] * b.Q[0] + a.Q[1] * b.Q[1] + a.Q[2] * b.Q[2] + a.Q[3] * b.Q[3] < 0 ? -1 : 1, Q = b.Q.map((v, i) => v * g + d * a.Q[i] * f), l = Math.hypot(...Q) || 1;
      M.setTree(n, { ...b, O, Q: Q.map((v) => v / l), strip: b.strip * g + a.strip * f }, false);
    }
  };
  const undo = (e) => {
    put(e, 1);
    if (e.trees) for (const [n, a] of e.trees) { M.setTree(n, a, false); treeNow.set(n, a); }
    if (e.cells) {
      const c = e.cells;
      for (let i = 0; i < c.k.length; i++) {
        const k = c.k[i], o = k * 4;
        data[o] = c.da[i * 4]; data[o + 1] = c.da[i * 4 + 1]; data[o + 2] = c.da[i * 4 + 2]; data[o + 3] = c.da[i * 4 + 3];
        F.heat[k] = c.fa[i * 3]; F.fuel[k] = c.fa[i * 3 + 1]; F.reach[k] = c.fa[i * 3 + 2];
        if (F.heat[k] > 0) F.active.add(k); else F.active.delete(k);
      }
      S.touch();
    }
    if (e.big) for (const key in e.big) big[key].recall(e.big[key][0]);
    if (e.bareA !== e.bareB) world.unbare(e.bareA);
    bareNow = e.bareA;
    if (e.fires) for (const [i, a] of e.fires) { const w = woods[i]; w.burnt = a[0]; w.frost = a[1]; w.burning = a[2]; w.warm = a[3]; lastFire[i] = a; world.treeChanged(w); }
    keptNow = e.keptA;
  };
  /** Time is let go: if it was wound back, the world is made to be as it is now drawn. */
  function letGo() {
    if (wound && M) {
      if (frac > 0 && log.length) { const e = log.pop(); undo(e); wt = e.t - e.dt; frac = 0; }
      const vel = new Float32Array(M.count * 3), spin = new Float32Array(M.count * 3), e = log[log.length - 1];
      if (e?.idx && e.dt >= 0.5 / RATE) for (let i = 0; i < e.idx.length; i++) {
        const k = e.idx[i], o = i * 7, a = e.a, b = e.b;
        vel[k * 3] = (b[o] - a[o]) / e.dt; vel[k * 3 + 1] = (b[o + 1] - a[o + 1]) / e.dt; vel[k * 3 + 2] = (b[o + 2] - a[o + 2]) / e.dt;
        // (how it was turning: twice the vector part of what turned it from then to now, over the time)
        let x = b[o + 6] * -a[o + 3] + b[o + 3] * a[o + 6] + b[o + 4] * -a[o + 5] - b[o + 5] * -a[o + 4], y = b[o + 6] * -a[o + 4] - b[o + 3] * -a[o + 5] + b[o + 4] * a[o + 6] + b[o + 5] * -a[o + 3], z = b[o + 6] * -a[o + 5] + b[o + 3] * -a[o + 4] - b[o + 4] * -a[o + 3] + b[o + 5] * a[o + 6];
        const w = b[o + 6] * a[o + 6] + b[o + 3] * a[o + 3] + b[o + 4] * a[o + 4] + b[o + 5] * a[o + 5], sgn = w < 0 ? -2 : 2;
        spin[k * 3] = Math.max(-12, Math.min(12, (sgn * x) / e.dt)); spin[k * 3 + 1] = Math.max(-12, Math.min(12, (sgn * y) / e.dt)); spin[k * 3 + 2] = Math.max(-12, Math.min(12, (sgn * z) / e.dt));
      }
      for (const [n, o] of treeNow) M.setTree(n, o, true);
      M.replay = false;
      M.restore(vel, spin, keptNow);
      // (what is written down goes on from here)
      lastPos.set(M.pos); lastRot.set(M.rot); lastTrees = M.trees(); lastSigs = lastTrees.map(sig);
      lastData.set(data); lastHeat.set(F.heat); lastFuel.set(F.fuel); lastReach.set(F.reach);
      bytes = log.reduce((s, x) => s + x.size, 0);
    }
    // (a whirlwind or a singularity gone back to has nobody holding it now: it is let go, and ends as it would)
    if (wound) { if (twister.phase !== 'idle' && twister.phase !== 'lift') twister.release(); if (hole.phase === 'open') hole.release(); for (const key in big) lastBig[key] = JSON.stringify(big[key].memory()); bareNow = world.bared; }
    treeNow.clear();
    ring = 0; flash = 0.5;
    phase = 'idle'; wound = false; speed = 0; frac = 0; acc = 0;
  }

  // --- what is seen of it ---
  // The dial: a clock across the whole sky, a hundred metres up and four hundred across, so that its far side stands
  // over the horizon when they look level and its middle is overhead. A rim of three rings with sixty marks, every
  // fifth long; twelve great runes for the hours, in a band that creeps round; a rosette of twelve petals; rings
  // about a hub; and two hands of light. Stopped, nothing on it moves. Wound back, its hands run backward as fast
  // as time does, and rings of light run in from its rim to its hub. It brings a dusk of its own with it (the sky
  // behind it is darkened), so that it is gold against dark by day as well, and not white on white.
  const flat = new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2);
  const dial = (radius, height) => {
    const m = new THREE.Mesh(flat, new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, side: THREE.DoubleSide,
      blending: THREE.CustomBlending, blendSrc: THREE.OneFactor, blendDst: THREE.OneMinusSrcAlphaFactor, blendSrcAlpha: THREE.ZeroFactor, blendDstAlpha: THREE.OneFactor,
      uniforms: { ...shared(), uOn: { value: 0 }, uWritten: { value: 0 }, uHands: { value: 0 }, uSpin: { value: 0 }, uGold: { value: 0 }, uRipple: { value: 0 }, uReal: { value: 0 } },
      vertexShader: /* glsl */ `varying vec2 vC; void main() { vC = uv * 2.0 - 1.0; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: /* glsl */ `
        varying vec2 vC; uniform sampler2D tRunes; uniform float uOn; uniform float uWritten; uniform float uHands; uniform float uSpin; uniform float uGold; uniform float uRipple; uniform float uReal;
        ` + SIGIL + /* glsl */ `
        const float TAU = 6.2831853;
        float hsh(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
        float nz(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(hsh(i), hsh(i + vec2(1.0, 0.0)), f.x), mix(hsh(i + vec2(0.0, 1.0)), hsh(i + vec2(1.0, 1.0)), f.x), f.y); }
        float hand(vec2 c, float ang, float len, float w, float px) {
          vec2 d = vec2(cos(ang), sin(ang)); float along = dot(c, d), across = abs(dot(c, vec2(-d.y, d.x))), u = along / len;
          // a blade, with a lozenge near its point, a bar across it, and a ring for its tail
          float hw = w * (0.5 - 0.3 * clamp(u, 0.0, 1.0)) + w * 2.2 * max(0.0, 1.0 - abs(u - 0.74) / 0.09);
          float I = sgLine(across, hw, px) * step(0.0, along) * step(along, len);
          I = max(I, sgLine(abs(along - len * 0.52), w * 0.35, px) * step(across, w * 2.6));
          return max(I, sgLine(abs(length(c + d * len * 0.1) - w * 2.4), w * 0.4, px));
        }
        void main() {
          float r0 = length(vC);
          if (r0 > 1.0) discard;
          float a = atan(vC.y, vC.x), px = length(fwidth(vC)), I = 0.0;
          // (drawn by a hand, not turned on a lathe: its rings waver a little)
          float r = r0 + (nz(vec2(a * 9.0, 1.7)) - 0.5) * 0.007 + (nz(vec2(a * 31.0, 5.3)) - 0.5) * 0.003;
          // the rim: a heavy ring and a fine one, with the minutes between
          I += sgLine(abs(r - 0.985), 0.008, px) + sgLine(abs(r - 0.952), 0.004, px);
          float m60 = abs(fract(a / TAU * 60.0) - 0.5) * r * TAU / 60.0, m12 = abs(fract(a / TAU * 12.0) - 0.5) * r * TAU / 12.0;
          I += 0.8 * sgLine(m60, 0.0028, px) * step(0.93, r) * step(r, 0.952) + sgLine(m12, 0.007, px) * step(0.918, r) * step(r, 0.975);
          // a line of small script inside the rim, creeping the other way
          float as = a - uSpin * 0.6, ks = floor(as / TAU * 72.0), os = as - (ks + 0.5) / 72.0 * TAU;
          I += 0.85 * sgGlyph(ks * 7.0 + 1.0, vec2(r * sin(os) / 0.05 * 0.5 + 0.5, (r * cos(os) - 0.868) / 0.045)) * step(0.865, r) * step(r, 0.916);
          I += 0.7 * sgLine(abs(r - 0.86), 0.0028, px);
          // the hours: twelve runes, each in a ring of its own, on a broken ring
          float ar = a + uSpin, k = floor(ar / TAU * 12.0), off = ar - (k + 0.5) / 12.0 * TAU;
          vec2 hc = vec2(r * sin(off), r * cos(off) - 0.772); float hd = length(hc);
          I += 1.15 * sgGlyph(k * 5.0 + 3.0, vec2(hc.x / 0.1 * 0.5 + 0.5, hc.y / 0.12 + 0.5));
          I += sgLine(abs(hd - 0.078), 0.0045, px) + 0.6 * sgLine(abs(hd - 0.092), 0.002, px);
          I += sgLine(abs(r - 0.772), 0.003, px) * step(0.1, hd) * step(0.3, fract(ar / TAU * 36.0 + 0.1));
          // a toothed ring, as of a wheel in a clock, turning
          float aw = a - uSpin * 2.0, tooth = step(0.5, fract(aw / TAU * 60.0));
          I += sgLine(abs(r - (0.668 + 0.014 * tooth)), 0.003, px) + sgLine(abs(fract(aw / TAU * 120.0 + 0.5) - 0.5) * r * TAU / 120.0, 0.0022, px) * step(0.668, r) * step(r, 0.682);
          I += 0.8 * sgLine(abs(r - 0.648), 0.0028, px);
          // its middle: the circle every spell of this staff is written with, of twelve sides
          if (r0 < 0.635) I += sigil(vC / 0.635, 12.0, uSpin * 2.0, uWritten, px / 0.635);
          // ink: it runs thin in places, and the light in it is not even, and moves
          float dry = smoothstep(0.16, 0.34, nz(vec2(a * 13.0 + floor(r0 * 50.0) * 3.1, r0 * 26.0)));
          I *= (0.5 + 0.5 * dry) * (0.8 + 0.4 * nz(vec2(a * 5.0 - uReal * 0.35, r0 * 9.0 + uReal * 0.2)));
          // (it is written from its rim inward)
          I *= smoothstep(0.0, 0.14, r0 - (1.0 - uWritten * 1.16));
          // the hands, last
          I = max(I, 1.5 * max(hand(vC, uHands, 0.6, 0.011, px), hand(vC, uHands / 12.0 + 2.2, 0.38, 0.014, px)) * smoothstep(0.75, 1.0, uWritten));
          // wound back: rings of light run in from the rim
          float rip = fract(uRipple), ring2 = fract(uRipple + 0.5);
          I += uGold * (0.55 * sgLine(abs(r0 - (1.0 - rip)), 0.006, px) * (1.0 - rip) + 0.55 * sgLine(abs(r0 - (1.0 - ring2)), 0.006, px) * (1.0 - ring2));
          vec3 gold = mix(vec3(1.0, 0.75, 0.34), vec3(1.0, 0.66, 0.22), uGold) * 1.25;
          vec3 col = gold * min(I, 1.3) + vec3(1.0, 0.95, 0.85) * max(I - 0.85, 0.0) * 0.5;
          // its dusk: deepest about its middle, gone at its rim
          float dusk = 0.62 * (1.0 - smoothstep(0.3, 1.0, r0)) * uOn;
          // (each stroke covers what is behind it, so that it is gold over bright cloud too, and not gold added to white)
          gl_FragColor = vec4(col * uOn + vec3(0.012, 0.014, 0.05) * dusk, max(dusk, min(I, 1.0) * 0.92 * uOn));
        }`,
    }));
    m.scale.setScalar(radius); m.userData.h = height; m.visible = false; m.frustumCulled = false; m.renderOrder = 6;
    scene.add(m);
    return m;
  };
  const dials = [dial(215, 100)];
  // (motes that hang in the stopped air: they do not move, so walking among them shows that nothing else does either)
  const MOTES = 900, mp = new Float32Array(MOTES * 3), ms = new Float32Array(MOTES);
  const mg = new THREE.BufferGeometry();
  mg.setAttribute('position', new THREE.BufferAttribute(mp, 3)); mg.setAttribute('seed', new THREE.BufferAttribute(ms, 1));
  const motes = new THREE.Points(mg, new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    uniforms: { uOn: { value: 0 }, uReal: { value: 0 }, uTall: { value: 720 }, uHue: { value: new THREE.Vector3(1.6, 1.25, 0.7) } },
    vertexShader: /* glsl */ `attribute float seed; uniform float uTall; uniform float uReal; varying float vA;
      void main() { vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * mv; float tw = 0.55 + 0.45 * sin(uReal * (0.7 + 1.6 * seed) + seed * 40.0); vA = tw * smoothstep(0.6, 2.5, -mv.z) * (1.0 - smoothstep(22.0, 34.0, -mv.z)); gl_PointSize = uTall * (0.03 + 0.06 * seed * seed) / max(0.6, -mv.z); }`,
    fragmentShader: /* glsl */ `uniform float uOn; uniform vec3 uHue; varying float vA; void main() { vec2 d = gl_PointCoord - 0.5; float r = length(d) * 2.0; float a = exp(-r * r * 5.0) + 0.6 * exp(-r * 26.0); gl_FragColor = vec4(uHue * a * vA * uOn, 1.0); }`,
  }));
  motes.frustumCulled = false; motes.visible = false; motes.renderOrder = 9;
  scene.add(motes);

  let hands = 0.9, spin = 0, ripple = 0, streak = 0, inkFor = 0, wave = 9;
  let warming = 0, on = 0, written = 0, angle = 0, real = 0, ring = -1, flash = 0, gold = 0;
  const centre = new THREE.Vector3();
  const cues = [];

  function stop(feet, tip) {
    // (what has happened since the last entry is written down first, the ground with it, so that nothing is left out of what can be gone back over)
    since = CELLS_EVERY; note(Math.max(acc, 1e-3)); acc = 0;
    phase = 'still'; frac = 0; speed = 0; wound = false; backFor = 0; most = Math.max(1, log.length);
    centre.set(tip?.x ?? feet.x, tip?.y ?? feet.y, tip?.z ?? feet.z);
    inkFor = 0.09; wave = 0;
    for (let i = 0; i < MOTES; i++) {
      const a = Math.random() * 6.283, r = 1.2 + 22 * Math.random() ** 0.7, x = feet.x + Math.cos(a) * r, z = feet.z + Math.sin(a) * r;
      mp[i * 3] = x; mp[i * 3 + 1] = world.ground(x, z) + 0.2 + 5.5 * Math.random() ** 1.6; mp[i * 3 + 2] = z; ms[i] = Math.random();
    }
    mg.attributes.position.needsUpdate = true; mg.attributes.seed.needsUpdate = true;
    for (const m of dials) m.position.set(feet.x, feet.y + m.userData.h, feet.z);
    ring = 0; flash = 1; written = 0;
    cues.push('stop');
  }

  return {
    get phase() { return phase; },
    /** How fast the world's own time runs: not at all while it is stopped or wound back. */
    get pace() { return phase === 'idle' ? 1 : 0; },
    /** How fast it is being wound back, in seconds of the world a second (0 when it is not). */
    get back() { return phase === 'back' && log.length ? speed : 0; },
    /** How much of what is written down is still ahead of where time now stands (1: none wound back; 0: all of it). */
    get left() { return phase === 'idle' ? 0 : Math.min(1, log.length / most); },
    // (the colour is drained by half, toward a cold silver, so that fire is still fire; toward old gold while it winds back)
    get dark() { return on * 0.86; },
    get tint() { return [0.4 + 0.2 * gold, 0.47 + 0.02 * gold, 0.62 - 0.32 * gold, 0.5]; },
    get white() { return flash * 0.35; },
    get shockR() { return ring < 0 ? 0 : ring; },
    get shockP() { return ring < 0 ? 0 : Math.max(0, 1 - ring / 90) * 0.8; },
    get centre() { return centre; },
    get on() { return on; },
    /** A frame of ink as it stops: 1, then -1, then none. */
    get ink() { return inkFor > 0.045 ? 1 : inkFor > 0 ? -1 : 0; },
    /** How far out from the middle of the view the colour has gone (9: all of it). */
    get wave() { return wave; },
    /** How much the picture is drawn out and its colours parted, while it is wound back. */
    get streak() { return streak; },
    /** How much of the world's time was gone back over this frame, in seconds (stretches skipped and all). */
    get went() { return went; },
    /** What has just happened, for the sound: 'stop', 'back', 'still', 'go'. Taken once. */
    heard() { return cues.splice(0); },
    get entries() { return log.length; },
    get bytes() { return bytes; },

    /** The button, each frame, while this spell is in hand. */
    hold(down, dt, feet, tip) {
      if (down && !pressed) {
        pressed = true; heldFor = 0;
        if (phase === 'idle') { stop(feet, tip); fresh = true; } else fresh = false;
      } else if (!down && pressed) {
        pressed = false;
        // (a press that wound time back leaves it stopped; only a short press of its own lets it go)
        if (phase === 'back') { phase = 'still'; speed = 0; cues.push('still'); }
        else if (phase === 'still' && !fresh && !woundNow) { letGo(); cues.push('go'); }
        woundNow = false;
      }
      if (down && phase !== 'idle') {
        heldFor += dt;
        if (phase === 'still' && heldFor > (fresh ? 0.5 : 0.22) && log.length) { phase = 'back'; backFor = 0; woundNow = true; if (!wound) { wound = true; if (M) M.replay = true; } cues.push('back'); }
      }
    },
    /** Another spell is taken in hand: time is let go. */
    end() { pressed = false; if (phase !== 'idle') { letGo(); cues.push('go'); } },

    /** Before the world is drawn: if time is being wound back, the world is put back by so much. */
    before(dt) {
      real += dt; went = 0;
      if (phase === 'back') {
        backFor += dt;
        speed = 0.6 + 2.6 * Math.min(1, backFor / 3.5) ** 1.5;
        let by = speed * dt;
        wt -= by;
        // (a stretch in which nothing happened is not waited through: time goes straight to the last thing that did)
        const top = log[log.length - 1];
        if (top && wt > top.t + 0.12) { by += wt - top.t - 0.12; wt = top.t + 0.12; }
        while (log.length && wt <= log[log.length - 1].t - log[log.length - 1].dt) undo(log.pop());
        frac = 0;
        if (!log.length) { phase = 'still'; speed = 0; cues.push('still'); }
        else { const e = log[log.length - 1]; if (wt < e.t) { frac = Math.min(1, (e.t - wt) / e.dt); if (M) put(e, frac); } }
        went = by;
      }
      // what is seen
      const want = phase === 'idle' ? 0 : 1;
      on += (want - on) * Math.min(1, dt * (want ? 9 : 3.5));
      gold += ((phase === 'back' ? 1 : 0) - gold) * Math.min(1, dt * 5);
      if (phase !== 'idle') written = Math.min(1, written + dt * 1.5);
      // (its hands run back as far as time has; its band of hours creeps; rings of light run in while it is wound)
      hands -= went * 1.15; spin += went * 0.1; if (phase === 'back') ripple += dt * 0.75;
      streak += ((phase === 'back' ? 0.5 + 0.17 * speed : 0) - streak) * Math.min(1, dt * 6);
      inkFor = Math.max(0, inkFor - dt);
      if (wave < 9) { wave += dt * 3.4; if (wave > 1.5) wave = 9; }
      if (ring >= 0) { ring += dt * 150; if (ring > 90) ring = -1; }
      flash = Math.max(0, flash - dt * 4);
      const show = on > 0.004 || warming-- > 0;
      dials.forEach((m) => { m.visible = show; const u = m.material.uniforms; u.uOn.value = on; u.uWritten.value = written; u.uHands.value = hands; u.uSpin.value = spin; u.uGold.value = gold; u.uRipple.value = ripple; u.uReal.value = real; });
      motes.visible = show; motes.material.uniforms.uOn.value = on * 0.9; motes.material.uniforms.uReal.value = real;
    },
    /** After the world has moved on by dt of its own time: it is written down. */
    after(dt) {
      // (where the pieces are comes back from the physics a frame or two late: what arrives after time has stopped is
      // written down too, until it is first wound back, or it would be left out of what can be undone)
      if (phase === 'still' && !wound) { since = CELLS_EVERY; note(1e-3); return; }
      if (phase !== 'idle' || dt <= 0) return;
      acc += dt; wt += dt;
      if (acc >= 1 / RATE) { note(acc); acc = 0; }
    },
    /** Drawn once, unseen, while the game loads: the card builds what it needs for them then, and not at the first cast. */
    warm() { warming = 2; },
    resize(tall) { motes.material.uniforms.uTall.value = tall; },
  };
}
