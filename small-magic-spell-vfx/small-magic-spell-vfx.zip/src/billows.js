// The body of an explosion: billows.
//
// A fireball seen from far off can be one soft glowing thing; seen from near, or from inside, that is a fog with
// nothing in it. What an explosion is made of is billows: round masses that come forth from its middle one after
// another, roll over on themselves, and cool. So that is what is drawn: some eighty round bodies, lumpy, each
// turning over as it goes, painted flat in a few tones with hard edges and drawn solid, so that they hide one
// another and stand in front of and behind things, from any distance and from among them.
//
// How one cools is what makes it read as fire and not as a coloured ball: white at first, all of it; then its
// swellings darken to a crust while its folds still glow, yellow, then orange, then red; then it is smoke, black
// where it is thick and grey where the day lights it, and it is eaten away from its edges until it is gone.
//
// They are placed by the same numbers as the fireball's glow (how wide it is, how high it has climbed, how old it
// is), so the two agree, and nothing of them is remembered from frame to frame: given an age they are where they
// are. Time wound back runs them back.
//   the cap     a cluster about the top of it, which rises and flattens
//   the stem    a column under the cap
//   the skirt   a ring along the ground, going outward: the first to go
import * as THREE from 'three';
import { AIR } from './air.js';
import { FIRE } from './flames.js';

export function createBillows(air, scene) {
  const U = air.uniforms, CAP = 46, STEM = 14, SKIRT = 24, N = CAP + STEM + SKIRT;
  const g = new THREE.InstancedBufferGeometry();
  g.setAttribute('position', new THREE.IcosahedronGeometry(1, 4).getAttribute('position'));
  const A = new Float32Array(N * 4), B = new Float32Array(N * 4), R = Math.random;
  for (let i = 0; i < N; i++) {
    const kind = i < CAP ? 0 : i < CAP + STEM ? 1 : 2, a = R() * Math.PI * 2;
    if (kind === 0) { const y = -0.3 + 1.3 * R(), h = Math.sqrt(Math.max(0, 1 - Math.min(1, y) ** 2)); A.set([Math.cos(a) * h, y, Math.sin(a) * h, 0], i * 4); B.set([0.26 + 0.17 * R(), 0.34 * R(), R(), R()], i * 4); }
    else if (kind === 1) { A.set([R() * 2 - 1, 0, R() * 2 - 1, 1], i * 4); B.set([0.15 + 0.09 * R(), 0.05 + 0.25 * R(), R(), 0.06 + 0.78 * ((i - CAP) / STEM)], i * 4); }
    else { A.set([Math.cos(a), 0, Math.sin(a), 2], i * 4); B.set([0.11 + 0.1 * R(), 0.24 * R(), R(), R()], i * 4); }
  }
  g.setAttribute('iA', new THREE.InstancedBufferAttribute(A, 4)); g.setAttribute('iB', new THREE.InstancedBufferAttribute(B, 4));
  g.instanceCount = N;
  const own = { uC: { value: new THREE.Vector3() }, uBall: { value: new THREE.Vector4(1, 1, 0, 0) } };
  // (the lumps of one, at a place on it: the same in both shaders, so its tones lie on its swellings)
  const LUMPS = /* glsl */ `float lumps(vec3 q, float seed) { return aNoise3(q * 2.1 + seed * 31.0) * 0.62 + aNoise3(q * 4.6 + seed * 17.0 + 4.0) * 0.38; }`;
  const mesh = new THREE.Mesh(g, new THREE.ShaderMaterial({
    side: THREE.DoubleSide, alphaToCoverage: true,
    uniforms: { ...Object.fromEntries(Object.keys(U).map((k) => [k, U[k]])), ...own },
    vertexShader: AIR + LUMPS + /* glsl */ `
      attribute vec4 iA; attribute vec4 iB;
      uniform vec3 uC; uniform vec4 uBall;
      varying vec3 vW; varying vec3 vN; varying vec3 vQ; varying vec4 vK;
      void main() {
        float R = uBall.x, H = uBall.y, age = uBall.z, kind = iA.w, seed = iB.z;
        // it comes forth from the middle, a little after the one before it
        float forth = smoothstep(iB.y, iB.y + 0.4, age);
        vec3 centre;
        if (kind < 0.5) centre = uC + vec3(0.0, H, 0.0) + vec3(iA.x, iA.y * 0.6, iA.z) * R * 0.66 * forth;
        else if (kind < 1.5) centre = uC + vec3(iA.x * R * 0.13, H * iB.w * forth, iA.z * R * 0.13);
        // (the skirt goes on outward along the ground, and lifts a little as it goes)
        else centre = uC + vec3(iA.x, 0.0, iA.z) * (R * (0.5 + 0.62 * iB.w) * forth + age * 1.6) + vec3(0.0, 0.7 + R * 0.06 + iB.w + age * 0.5, 0.0);
        float rad = R * iB.x * (0.3 + 0.7 * forth);
        // it turns over as it goes: its lumps climb its inner side, go over the top and down the outside
        vec3 n = normalize(position), way = kind > 0.5 && kind < 1.5 ? vec3(cos(seed * 40.0), 0.0, sin(seed * 40.0)) : normalize(vec3(iA.x, 0.0, iA.z) + vec3(1e-3, 0.0, 0.0));
        vec3 axis = vec3(-way.z, 0.0, way.x);
        float ang = -age * (0.75 + 0.5 * fract(seed * 5.1));
        vec3 q = n * cos(ang) + cross(axis, n) * sin(ang) + axis * dot(axis, n) * (1.0 - cos(ang));
        vec3 w = centre + n * rad * (0.72 + 0.56 * lumps(q, seed));
        // how hot it still is: the cap longest, the skirt least
        float heat = exp(-max(age - iB.y, 0.0) * (0.42 + 0.4 * fract(seed * 3.3)) * (kind > 1.5 ? 1.7 : kind > 0.5 ? 1.25 : 1.0));
        vN = n; vQ = q; vW = w; vK = vec4(heat, seed, kind, max(age - iB.y, 0.0));
        gl_Position = projectionMatrix * viewMatrix * vec4(w, 1.0);
      }`,
    fragmentShader: AIR + FIRE + LUMPS + /* glsl */ `
      uniform vec3 uC; uniform vec4 uBall;
      varying vec3 vW; varying vec3 vN; varying vec3 vQ; varying vec4 vK;
      void main() {
        float age = uBall.z, heat = vK.x, seed = vK.y, kind = vK.z, mine = vK.w;
        vec3 N = normalize(vN), toEye = normalize(cameraPosition - vW);
        // its swellings and folds, and finer ones on those
        float lump = lumps(vQ, seed) + (aNoise3(vQ * 9.5 + seed * 7.0) - 0.5) * 0.16;
        // what drifts up through the place, for its smoke to be eaten by
        float drift = aNoise3(vW * 0.45 + vec3(0.0, -age * 0.8, 0.0) + seed * 9.0) * 0.6 + aNoise3(vW * 1.25 + vec3(0.0, -age * 1.3, 0.0)) * 0.4;
        // it is eaten away: the skirt soon, the stem after, the cap last
        float from = kind > 1.5 ? 1.3 : kind > 0.5 ? 3.2 : 4.2, to = kind > 1.5 ? 3.6 : kind > 0.5 ? 7.4 : 9.4;
        float gone = smoothstep(from, to, age + (seed - 0.5) * 1.6);
        if (drift * 0.75 + lump * 0.25 < gone * 1.08) discard;
        // (the side of it that faces the heart of the blast is lit by it)
        float inner = max(dot(N, normalize(vec3(uC.x, uC.y + uBall.y * 0.7, uC.z) - vW)), 0.0);
        // White at first, all of it. Then the swellings cool before the folds do: a dark crust, with fire in its cracks.
        float temp = heat * 1.2 + 0.7 * exp(-mine * 2.6) + 0.55 * inner * heat - (lump - 0.4) * 1.5 * (1.0 - 0.75 * heat) * step(0.0, lump - 0.4);
        temp += (0.4 - lump) * 0.9 * heat * step(0.0, 0.4 - lump);
        // Seen from near there is finer work on it, laid by where it is in the world and not by its own size: the crust
        // is cracked, in long cracks and short, and the fire inside shows through them; and it is hotter in patches.
        float w1 = aNoise3(vW * 0.8 + vec3(0.0, -age * 0.35, 0.0) + seed * 5.0), w2 = aNoise3(vW * 2.1 + vec3(0.0, -age * 0.5, 0.0) + seed * 3.0), w3 = aNoise3(vW * 5.0 + seed * 11.0);
        float seen = 1.0 - smoothstep(22.0, 55.0, distance(cameraPosition, vW));
        float crack = max(1.0 - smoothstep(0.012, 0.05, abs(w1 - 0.5)), 0.75 * (1.0 - smoothstep(0.02, 0.07, abs(w2 - 0.5)))) * seen;
        temp += crack * heat * 0.95 + ((w2 - 0.5) * 0.45 + (w3 - 0.5) * 0.25 * seen) * heat;
        // One that the eye is close to, or inside, is not a wall in front of it: it is torn open there, more the
        // nearer, and what is beyond is seen through the tears (the others, the light within, the day).
        if (w2 * 0.65 + w3 * 0.35 > 0.1 + 0.98 * smoothstep(1.5, 10.0, distance(cameraPosition, vW))) discard;
        float a = 1.0;
        float aa = fwidth(temp) * 1.2 + 0.006;
        float tone = 0.17 + 0.33 * smoothstep(0.52 - aa, 0.52 + aa, temp) + 0.36 * smoothstep(0.86 - aa, 0.86 + aa, temp);
        // smoke: black where it is thick, grey where the day reaches it, and greyer as it thins
        float lit = smoothstep(0.5, 0.56, N.y * 0.5 + 0.3 * drift + 0.3 * lump + 0.1 + (w2 - 0.5) * 0.35 + (w3 - 0.5) * 0.2 * seen);
        vec3 smoke = mix(vec3(0.06, 0.055, 0.06), mix(vec3(0.25, 0.235, 0.24), vec3(0.46, 0.45, 0.47), gone), lit);
        smoke = mix(smoke, vec3(0.45, 0.1, 0.03), smoothstep(0.04, 0.1, heat) * smoothstep(0.4, 0.6, inner));
        vec3 col = mix(smoke, fireCol(tone), smoothstep(0.24 - aa, 0.24 + aa, temp));
        gl_FragColor = vec4(col, a);
      }`,
  }));
  mesh.visible = false; mesh.frustumCulled = false; mesh.renderOrder = 4;
  scene.add(mesh);
  return {
    mesh,
    /** Where the blast is, how wide its fire is, how high that has climbed, and how old it is. */
    set(C, R, H, age) { own.uC.value.copy(C); own.uBall.value.set(R, H, age, 1); mesh.visible = true; },
    hide() { mesh.visible = false; },
  };
}
