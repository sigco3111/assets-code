// A wall of stone, pulled up out of the ground. It is slabs of rock standing side by side, each rough-hewn and
// leaning its own way, the earth they came up through still dark on their feet, with broken stone lying against
// them. It comes up from its middle outward, each slab thrown up past its height and dropping back to it, with dirt,
// torn grass and stones flung from where it breaks the ground. Struck, it shudders where it was struck, sheds stone,
// and cracks; with nothing left of it, it is knocked down, each slab toppling from the blow. Left alone, it goes back
// into the ground it came from.
//
// It is painted as the meadow's own rock is (paint.js: broad planes of colour, dark lines between). Up to four stand
// at once, made before they are wanted. What a wall stops, and who may stand on one, is asked of this file: `cross`
// (a line through the air), `push` (a body walking into it), `floor` (feet coming down on it).
import * as THREE from 'three';
import { ball, block, knead } from './shape.js';
import { rng } from './noise.js';

const STONE = ['#b8ac99', '#a39988', '#c6baa6', '#93897c', '#ada08d'], SOIL = '#4b3927', SLABS = 7, CHIPS = 96;
const R = Math.random, rnd = (a = 1) => (R() - 0.5) * 2 * a, clamp = THREE.MathUtils.clamp;
// (thrown up past where it will stand, and back)
const thrown = (p) => { const q = p - 1; return 1 + 2.9 * q * q * q + 1.9 * q * q; };

export function createWalls({ scene, world, fx, camera, rules, sound = null, shake = () => {} }) {
  const T = new THREE.Color();
  const dress = (g, colour, scale, seed) => {
    const n = g.attributes.position.count, tint = new Float32Array(n * 3), kind = new Float32Array(n * 4);
    T.set(colour);
    for (let i = 0; i < n; i++) { tint.set([T.r, T.g, T.b], i * 3); kind.set([1, scale, seed, 0], i * 4); }
    g.setAttribute('tint', new THREE.BufferAttribute(tint, 3)); g.setAttribute('kind', new THREE.BufferAttribute(kind, 4));
    g.deleteAttribute('uv');
    return g;
  };
  const floorAt = (x, z) => Math.max(world.ground(x, z), world.water);

  // --- the walls, made before they are wanted ---
  const walls = Array.from({ length: 4 }, (_, n) => {
    const rand = rng(41 + n * 13), W = rules().wide, tall = rules().tall, group = new THREE.Group(), material = world.paint.rock(), slabs = [], stones = [];
    for (let i = 0; i < SLABS; i++) {
      const u = (i - (SLABS - 1) / 2) / ((SLABS - 1) / 2), w = 0.82 + 0.42 * rand(), h = tall * (1.12 - 0.2 * u * u) + 0.4 * (rand() - 0.5), d = 0.56 + 0.26 * rand(), H = h + 0.55, slant = (rand() < 0.5 ? -1 : 1) * (0.3 + 0.75 * rand());
      const g = block(w, H, d, 0.05, 0.3), p = g.attributes.position;
      // (narrower toward its top, which is broken off at a slant)
      for (let k = 0; k < p.count; k++) { const t = (p.getY(k) + H / 2) / H, x = p.getX(k); p.setXYZ(k, x * (1 - 0.16 * t * t), p.getY(k) + t * t * t * (x / w) * slant, p.getZ(k) * (1 - 0.2 * t * t)); }
      g.computeVertexNormals();
      knead(g, 0.05, 1.1, 300 + n * 31 + i, 3, 0.4).translate(0, H / 2 - 0.55, 0);
      const mesh = new THREE.Mesh(dress(g, STONE[Math.floor(rand() * STONE.length)], 0.8 + 0.3 * rand(), (n * 7 + i) * 3.7), material);
      mesh.castShadow = mesh.receiveShadow = true; mesh.frustumCulled = false;
      group.add(mesh);
      slabs.push({ mesh, x: u * (W / 2 - 0.5) + 0.06 * (rand() - 0.5), z: 0.09 * (rand() - 0.5), h, twist: 0.3 * (rand() - 0.5), lean: -u * 0.09 + 0.06 * (rand() - 0.5), nod: 0.06 * (rand() - 0.5), delay: Math.abs(u) * 0.13 + 0.03 * rand(), y: 0, tilt: 0, tiltV: 0, out: false, set: false, gone: false, broke: false });
    }
    // (broken stone lying against its foot, both sides)
    for (let i = 0; i < 9; i++) {
      const r = 0.16 + 0.2 * rand(), g = knead(ball(1, 1).scale(r * (0.9 + 0.5 * rand()), r * (0.6 + 0.3 * rand()), r * (0.8 + 0.4 * rand())), r * 0.2, 1.4 / r, 500 + n * 17 + i, 3, r * 0.7);
      const mesh = new THREE.Mesh(dress(g, STONE[Math.floor(rand() * STONE.length)], 1.3, (n * 5 + i) * 2.3), material);
      mesh.castShadow = mesh.receiveShadow = true; mesh.frustumCulled = false; mesh.rotation.set(rand() * 6, rand() * 6, rand() * 6);
      group.add(mesh);
      stones.push({ mesh, x: (rand() * 2 - 1) * (W / 2 - 0.1), z: (rand() < 0.5 ? -1 : 1) * (0.42 + 0.3 * rand()), r, delay: 0.1 + 0.25 * rand(), y: 0 });
    }
    // (and the earth heaved up along its foot)
    const heave = new THREE.Mesh(dress(knead(ball(1, 2).scale(W / 2 + 0.45, 0.34, 0.95), 0.1, 0.9, 700 + n, 5, 0.5), SOIL, 1.3, n * 4.1), material);
    heave.receiveShadow = true; heave.frustumCulled = false;
    group.add(heave);
    group.visible = false;
    scene.add(group);
    return { group, material, slabs, stones, heave, on: false, solid: false, id: '', who: null, x: 0, z: 0, yaw: 0, cos: 1, sin: 0, base: 0, top: 0, t: 0, hp: 0, state: 'up', ft: 0, from: 1 };
  });

  // --- stone thrown from them: the same few lumps, many times over ---
  const chipMat = world.paint.rock(), chips = new THREE.InstancedMesh(dress(knead(ball(1, 1), 0.28, 1.1, 77, 4, 0.6), STONE[1], 1.6, 9), chipMat, CHIPS), flying = [];
  chips.castShadow = true; chips.frustumCulled = false; chips.count = 0;
  scene.add(chips);
  const M = new THREE.Matrix4(), Q = new THREE.Quaternion(), P = new THREE.Vector3(), HIT = new THREE.Vector3(), S = new THREE.Vector3(), AX = new THREE.Vector3();
  function chip(x, y, z, vx, vy, vz, size) {
    if (flying.length >= CHIPS) flying.shift();
    flying.push({ p: [x, y, z], v: [vx, vy, vz], axis: [rnd(), rnd(), rnd()], a: R() * 6, spin: rnd(9), size, squash: [0.7 + 0.6 * R(), 0.5 + 0.5 * R(), 0.7 + 0.6 * R()], t: 0, life: 1.1 + 0.9 * R() });
  }
  /** Earth and stone thrown from a place: dust, clods and torn grass in the air, and lumps of stone that fall and lie. */
  function spray(x, y, z, much, dirx = 0, dirz = 0, stone = 1) {
    for (let i = 0, n = Math.round(3.4 * much); i < n; i++) fx.spawn({ kind: 2, x: x + rnd(0.4), y: y + 0.1 + 0.25 * R(), z: z + rnd(0.4), vx: dirx * 1.2 + rnd(1.5), vy: 0.3 + 0.8 * R(), vz: dirz * 1.2 + rnd(1.5), life: 0.55 + 0.55 * R(), size: [0.3, 0.9 + 0.5 * R()], colour: [0.56, 0.48, 0.36], alpha: 0.27, drag: 1.8, wind: 0.5 });
    for (let i = 0, n = Math.round(7 * much); i < n; i++) fx.spawn({ kind: 4, x: x + rnd(0.3), y: y + 0.1, z: z + rnd(0.3), vx: dirx * 2 + rnd(2.6), vy: 2.5 + 3.5 * R(), vz: dirz * 2 + rnd(2.6), life: 0.8 + 0.7 * R(), size: [0.06 + 0.05 * R(), 0.06], colour: R() < 0.55 ? [0.27, 0.19, 0.12] : [0.36, 0.7, 0.24], grav: -9, drag: 0.6, spin: rnd(10) });
    for (let i = 0, n = Math.round(2.2 * much * stone); i < n; i++) chip(x + rnd(0.3), y + 0.2 + 0.4 * R(), z + rnd(0.3), dirx * 2.5 + rnd(2.6), 3 + 3.5 * R(), dirz * 2.5 + rnd(2.6), 0.06 + 0.11 * R());
  }
  const local = (w, x, z, out) => { const dx = x - w.x, dz = z - w.z; out[0] = dx * w.cos - dz * w.sin; out[1] = dx * w.sin + dz * w.cos; return out; };
  const world3 = (w, lx, lz, out) => { out[0] = w.x + lx * w.cos + lz * w.sin; out[1] = w.z - lx * w.sin + lz * w.cos; return out; };
  const l2 = [0, 0], w2 = [0, 0], near = () => clamp(1 - (Math.hypot(camera.position.x - l2[0], camera.position.z - l2[1]) - 3) / 22, 0, 1);

  /** A wall goes back down (left alone long enough), or is knocked down (`broken`, by a blow from `from`: which face). */
  function fall(w, broken = false, from = 1) {
    if (w.state !== 'up') return;
    w.state = broken ? 'breaking' : 'falling'; w.ft = 0; w.solid = false; w.from = from;
    sound?.cue('wall', { what: broken ? 'broken' : 'down', p: w.group.position });
    if (broken) { l2[0] = w.x; l2[1] = w.z; shake(0.5 * near()); }
  }

  let warm = 4;
  { const w = walls[0]; w.group.visible = true; w.group.position.set(world.start.x, -40, world.start.z); chips.count = 1; chips.setMatrixAt(0, M.makeTranslation(world.start.x, -40, world.start.z)); }

  return {
    list: walls,
    /** Raises one: across the way `yaw` faces, its middle at (x, z). */
    raise({ id, who, x, z, yaw }) {
      const w = walls.find((v) => !v.on) ?? walls.reduce((a, b) => (a.t > b.t ? a : b)), U = rules();
      Object.assign(w, { on: true, solid: false, id, who, x, z, yaw, cos: Math.cos(yaw), sin: Math.sin(yaw), t: 0, hp: U.hp, state: 'up', ft: 0 });
      w.base = floorAt(x, z); w.top = w.base + U.tall;
      w.group.position.set(x, 0, z); w.group.rotation.set(0, yaw, 0); w.group.visible = true; w.material.crack.value = 0;
      for (const s of w.slabs) { world3(w, s.x, s.z, w2); s.y = floorAt(w2[0], w2[1]); s.tilt = s.tiltV = 0; s.out = s.set = s.gone = s.broke = s.flat = false; s.mesh.visible = true; s.mesh.position.set(s.x, s.y - s.h - 0.7, s.z); s.mesh.rotation.set(s.nod, s.twist, s.lean); }
      for (const s of w.stones) { world3(w, s.x, s.z, w2); s.y = floorAt(w2[0], w2[1]); s.mesh.visible = true; s.mesh.position.set(s.x, s.y - 0.6, s.z); }
      w.heave.position.set(0, w.base - 0.6, 0);
      sound?.cue('wall', { what: 'up', p: w.group.position });
      return w;
    },
    /** What a line from a to b first meets of a standing wall: { t (0 to 1 along it), wall, point }, or null. */
    cross(a, b, out = HIT) {
      let best = null, bt = 2;
      for (const w of walls) {
        if (!w.solid) continue;
        const U = rules(), ax = (a.x - w.x) * w.cos - (a.z - w.z) * w.sin, az = (a.x - w.x) * w.sin + (a.z - w.z) * w.cos, bx = (b.x - w.x) * w.cos - (b.z - w.z) * w.sin, bz = (b.x - w.x) * w.sin + (b.z - w.z) * w.cos;
        let t0 = 0, t1 = 1, ok = true;
        for (const [p, d, lo, hi] of [[ax, bx - ax, -U.wide / 2, U.wide / 2], [az, bz - az, -U.thick / 2, U.thick / 2], [a.y, b.y - a.y, w.base - 2, w.top]]) {
          if (Math.abs(d) < 1e-9) { if (p < lo || p > hi) { ok = false; break; } continue; }
          let u0 = (lo - p) / d, u1 = (hi - p) / d; if (u0 > u1) [u0, u1] = [u1, u0];
          t0 = Math.max(t0, u0); t1 = Math.min(t1, u1); if (t0 > t1) { ok = false; break; }
        }
        if (ok && t0 < bt) { bt = t0; best = w; }
      }
      return best ? { t: bt, wall: best, point: out.copy(a).lerp(b, bt), side: Math.sign((a.x - best.x) * best.sin + (a.z - best.z) * best.cos) || 1 } : null;
    },
    /** A body walking into one is kept out of it (its feet are moved): unless it is above it. Says which wall, if any. */
    push(f, r = 0.32) {
      let moved = null;
      for (const w of walls) {
        if (!w.solid || f.y > w.top - 0.35) continue;
        const U = rules(); local(w, f.x, f.z, l2);
        const px = U.wide / 2 + r - Math.abs(l2[0]), pz = U.thick / 2 + r - Math.abs(l2[1]);
        if (px <= 0 || pz <= 0) continue;
        if (pz < px) l2[1] = (l2[1] < 0 ? -1 : 1) * (U.thick / 2 + r); else l2[0] = (l2[0] < 0 ? -1 : 1) * (U.wide / 2 + r);
        world3(w, l2[0], l2[1], w2); f.x = w2[0]; f.z = w2[1]; moved = w;
      }
      return moved;
    },
    /** The ground under feet at (x, z) that are so high: the top of a wall, if they are over one and above it. */
    floor(x, z, y, ground) {
      for (const w of walls) {
        if (!w.solid || y < w.top - 0.35) continue;
        const U = rules(); local(w, x, z, l2);
        if (Math.abs(l2[0]) < U.wide / 2 + 0.12 && Math.abs(l2[1]) < U.thick / 2 + 0.16) ground = Math.max(ground, w.top);
      }
      return ground;
    },
    /** Struck at a place, so hard (0 to 1): it shudders there and sheds stone. (What it has left is `left`'s to say.) */
    struck(w, at, hard = 0.5) {
      local(w, at.x, at.z, l2);
      const side = l2[1] < 0 ? -1 : 1;
      for (const s of w.slabs) s.tiltV -= side * (0.9 + 1.6 * hard) * Math.exp(-((s.x - l2[0]) ** 2) / 1.4);
      spray(at.x, at.y - 0.3, at.z, 0.7 + 1.2 * hard, w.sin * side * 0.6, w.cos * side * 0.6, 1.4);
      sound?.cue('wall', { what: 'hit', p: at, hard });
      l2[0] = at.x; l2[1] = at.z; shake(0.22 * hard * near());
      return side;
    },
    /** How much of it is left, as whoever it belongs to says: with none, it is knocked down (away from `side`). */
    left(w, hp, side = 1) { w.hp = Math.max(0, hp); if (w.hp <= 0) fall(w, true, side); },
    find: (id) => walls.find((w) => w.on && w.id === id) ?? null,
    fall,
    /** Every wall gone at once (a round beginning). */
    clear() { for (const w of walls) { w.on = w.solid = false; w.group.visible = false; } flying.length = 0; chips.count = 0; },
    update(dt) {
      // (the first frames drawn, while the game loads: one wall is drawn far under the ground, so that what the card
      // builds for a wall and for its shadow is built then, and not the first time a wall is raised. It is shown here
      // each frame, since a round beginning clears every wall away.)
      if (warm > 0) { warm--; if (!walls[0].on) walls[0].group.visible = warm > 0; }
      const U = rules();
      for (const w of walls) {
        if (!w.on) continue;
        w.t += dt;
        if (w.state === 'up') { w.solid = w.t >= U.rise; if (w.t > U.lasts) fall(w); }
        else w.ft += dt;
        w.material.crack.value += (clamp(1 - w.hp / U.hp, 0, 1) - w.material.crack.value) * Math.min(1, dt * 12);
        let left = 0;
        for (const s of w.slabs) {
          if (s.gone) continue;
          left++;
          const p = clamp((w.t - s.delay) / 0.2, 0, 1);
          let y = s.y - (s.h + 0.7) * (1 - thrown(p)), over = 0;
          world3(w, s.x, s.z, w2);
          // (it breaks the ground: earth, grass and stone thrown from there; and again, less, as it drops back to its height)
          if (!s.out && p > 0) { s.out = true; spray(w2[0], s.y, w2[1], 1.5, 0, 0); l2[0] = w2[0]; l2[1] = w2[1]; shake(0.2 * near()); }
          if (!s.set && p >= 1) { s.set = true; spray(w2[0], s.y, w2[1], 0.5, 0, 0, 0); s.tiltV += rnd(0.5); }
          // (struck, it rocks on its foot and comes to rest)
          s.tiltV += (-s.tilt * 190 - s.tiltV * 13) * dt; s.tilt += s.tiltV * dt;
          if (w.state === 'falling') {
            // back into the ground, the ends of it first, shaking as it goes
            const q = clamp((w.ft - (0.28 - s.delay * 1.6)) / 0.55, 0, 1);
            y -= (s.h + 0.7) * q * q; over = q > 0 && q < 1 ? 0.03 * Math.sin(w.ft * 70 + s.x * 9) : 0;
            if (q > 0 && q < 1 && R() < 22 * dt) spray(w2[0], s.y, w2[1], 0.35, 0, 0, 0.3);
            if (q >= 1) { s.gone = true; s.mesh.visible = false; }
          } else if (w.state === 'breaking') {
            // knocked down: it goes over away from the blow, breaking as it goes
            // (and where it lies, it goes into the ground)
            const q = clamp((w.ft - s.delay * 0.7) / 0.55, 0, 1), under = clamp((w.ft - s.delay * 0.7 - 0.5) / 0.55, 0, 1);
            over = -w.from * q * q * 1.4; y -= q * q * s.h * 0.4 + under * under * 1.3;
            if (q > 0 && !s.broke) { s.broke = true; for (let k = 0; k < 5; k++) { const hy = s.y + 0.3 + (s.h - 0.4) * R(); chip(w2[0] + rnd(0.3), hy, w2[1] + rnd(0.3), -w.from * w.sin * (2 + 3 * R()) + rnd(2), 1.5 + 3 * R(), -w.from * w.cos * (2 + 3 * R()) + rnd(2), 0.12 + 0.16 * R()); } spray(w2[0], s.y + s.h * 0.5, w2[1], 1.3, -w.from * w.sin, -w.from * w.cos, 0.6); }
            if (q >= 1 && !s.flat) { s.flat = true; spray(w2[0] - w.from * w.sin * s.h * 0.6, s.y, w2[1] - w.from * w.cos * s.h * 0.6, 1.1, 0, 0, 0.8); }
            if (under >= 1) { s.gone = true; s.mesh.visible = false; }
          }
          s.mesh.position.y = y;
          s.mesh.rotation.x = s.nod + s.tilt + over;
        }
        { const p = clamp(w.t / 0.3, 0, 1), sink = w.state === 'up' ? 0 : clamp(w.ft / 0.7, 0, 1); w.heave.position.y = w.base - 0.1 - 0.45 * (1 - thrown(p)) - 0.4 * sink * sink; }
        for (const s of w.stones) {
          const p = clamp((w.t - s.delay) / 0.22, 0, 1), sink = w.state === 'up' ? 0 : clamp(w.ft / 0.6, 0, 1);
          s.mesh.position.y = s.y - 0.6 * (1 - thrown(p)) - sink * sink * 0.6 + s.r * 0.25;
        }
        if (w.state !== 'up' && left === 0) { w.on = false; w.group.visible = false; }
      }
      // the stone in the air: it falls, strikes the ground once or twice, lies a moment, and is gone
      for (let i = flying.length - 1; i >= 0; i--) {
        const c = flying[i]; c.t += dt;
        if (c.t > c.life) { flying.splice(i, 1); continue; }
        c.v[1] -= 15 * dt; c.p[0] += c.v[0] * dt; c.p[1] += c.v[1] * dt; c.p[2] += c.v[2] * dt; c.a += c.spin * dt;
        const g = floorAt(c.p[0], c.p[2]) + c.size * 0.5;
        if (c.p[1] < g) { c.p[1] = g; if (c.v[1] < -1.5) { c.v[1] *= -0.32; c.v[0] *= 0.55; c.v[2] *= 0.55; c.spin *= 0.5; } else { c.v[0] *= 0.8; c.v[1] = 0; c.v[2] *= 0.8; c.spin *= 0.8; } }
      }
      chips.count = Math.max(flying.length, warm > 0 ? 1 : 0);
      for (let i = 0; i < flying.length; i++) {
        const c = flying[i], k = c.size * Math.min(1, (c.life - c.t) / 0.3);
        chips.setMatrixAt(i, M.compose(P.set(c.p[0], c.p[1], c.p[2]), Q.setFromAxisAngle(AX.set(c.axis[0], c.axis[1], c.axis[2]).normalize(), c.a), S.set(k * c.squash[0], k * c.squash[1], k * c.squash[2])));
      }
      if (flying.length) chips.instanceMatrix.needsUpdate = true;
    },
  };
}
