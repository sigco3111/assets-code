// Lightning, as it is seen. A stroke is a real path through the air, not a picture of one: it breaks its way from the
// staff to where it strikes, never straight for long and never the same way twice, and forks leave it on the way and
// die out. So it is lightning from wherever it is looked at, and most of all from behind whoever cast it, looking
// along it. It strikes, gutters, strikes again down the same path (the path keeps its big turns and changes its small
// ones), and what is left of it thins and goes. Whoever it strikes has arcs of it crawling over them for a moment,
// and it runs out along the ground from where it earths.
//
// Every strand of it is a line with a width: white-hot down its middle, its colour round that, drawn toward the eye
// and never thinner than can be seen, however far off. All of it is one mesh, written again each frame there is any.
import * as THREE from 'three';

const SEGS = 1536, LASTS = 0.4, WIDE = 0.3;
// (numbers that come the same again from the same seed: what a stroke keeps from one strike to the next)
const rng = (seed) => { let a = (seed * 2654435761) >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };
const clamp = THREE.MathUtils.clamp;

/** How bright a stroke is, so long after it was cast: it strikes, gutters, strikes again fainter, and what is left goes. */
export const glare = (t) => (t < 0.055 ? 1.7 : t < 0.09 ? 0.3 : t < 0.15 ? 1.15 : t < 0.185 ? 0.25 : t < LASTS ? 0.75 * (1 - (t - 0.185) / (LASTS - 0.185)) ** 1.5 : 0);
const strikeOf = (t) => (t < 0.09 ? 0 : t < 0.185 ? 1 : 2);

/** A broken path from one place to another, into `out`: each stretch of it is halved and its middle thrown aside, by
 *  less each time. Its big turns come from `coarse`, its small ones (from the `split`th halving on) from `fine`. */
function jag(out, a, b, levels, amp, coarse, fine, split, flat = 0.8) {
  const n = (1 << levels) + 1, last = (n - 1) * 3;
  out[0] = a.x; out[1] = a.y; out[2] = a.z; out[last] = b.x; out[last + 1] = b.y; out[last + 2] = b.z;
  for (let step = n - 1, level = 0, k = amp; step > 1; step >>= 1, level++, k *= 0.66) {
    const half = step >> 1, r = level < split ? coarse : fine;
    for (let i = half; i < n - 1; i += step) {
      const p = (i - half) * 3, q = (i + half) * 3, m = i * 3;
      out[m] = (out[p] + out[q]) / 2 + (r() * 2 - 1) * k;
      out[m + 1] = (out[p + 1] + out[q + 1]) / 2 + (r() * 2 - 1) * k * flat;
      out[m + 2] = (out[p + 2] + out[q + 2]) / 2 + (r() * 2 - 1) * k;
    }
  }
  return n;
}

export function createStrokes(scene, ground = null) {
  const V4 = SEGS * 4, at = new Float32Array(V4 * 3), prev = new Float32Array(V4 * 3), next = new Float32Array(V4 * 3), look = new Float32Array(V4 * 4), col = new Float32Array(V4 * 4), index = new Uint32Array(SEGS * 6);
  for (let s = 0; s < SEGS; s++) index.set([s * 4, s * 4 + 1, s * 4 + 2, s * 4 + 1, s * 4 + 3, s * 4 + 2], s * 6);
  const g = new THREE.BufferGeometry(), attr = {};
  for (const [name, array, size] of [['position', at, 3], ['aPrev', prev, 3], ['aNext', next, 3], ['aLook', look, 4], ['aCol', col, 4]]) { attr[name] = new THREE.BufferAttribute(array, size); attr[name].setUsage(THREE.DynamicDrawUsage); g.setAttribute(name, attr[name]); }
  g.setIndex(new THREE.BufferAttribute(index, 1));
  g.setDrawRange(0, 0);
  const mesh = new THREE.Mesh(g, new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
    vertexShader: /* glsl */ `
      attribute vec3 aPrev; attribute vec3 aNext; attribute vec4 aLook; attribute vec4 aCol;
      varying float vAcross; varying vec4 vCol;
      void main() {
        // (a line with a width, laid out on the view itself: so it is as wide looked along as looked across)
        mat4 pv = projectionMatrix * viewMatrix;
        vec4 c = pv * vec4(position, 1.0), p = pv * vec4(aPrev, 1.0), n = pv * vec4(aNext, 1.0);
        float asp = projectionMatrix[1][1] / projectionMatrix[0][0], w = max(c.w, 0.05);
        vec2 cs = c.xy / w, ps = p.xy / max(p.w, 0.05), ns = n.xy / max(n.w, 0.05);
        cs.x *= asp; ps.x *= asp; ns.x *= asp;
        vec2 d1 = cs - ps, d2 = ns - cs; float l1 = length(d1), l2 = length(d2);
        d1 = l1 > 1e-5 ? d1 / l1 : vec2(0.0); d2 = l2 > 1e-5 ? d2 / l2 : vec2(0.0);
        // (its own stretch runs this way; where two stretches meet they share one edge, turned to lie between them)
        vec2 own = aCol.a > 0.5 ? d1 : d2; if (dot(own, own) < 0.5) own = d1 + d2;
        own = dot(own, own) > 1e-6 ? normalize(own) : vec2(1.0, 0.0);
        vec2 side = vec2(-own.y, own.x), join = d1 + d2;
        if (dot(join, join) > 0.04) { join = normalize(join); vec2 jn = vec2(-join.y, join.x); if (dot(jn, side) < 0.0) jn = -jn; side = jn / max(dot(jn, side), 0.5); }
        // (never thinner than can be seen; and never broad, however near: looked along from the staff it is a line, not a wall of light)
        float broad = clamp(aLook.y * projectionMatrix[1][1] / w, aLook.w, aLook.w * 1.7);
        vec2 off = side * broad * aLook.x; off.x /= asp;
        gl_Position = vec4(c.xy + off * c.w, c.z, c.w);
        vAcross = aLook.x; vCol = vec4(aCol.rgb, aLook.z);
      }`,
    fragmentShader: /* glsl */ `
      varying float vAcross; varying vec4 vCol;
      void main() {
        float v = vAcross * vAcross, core = exp(-v * 70.0), halo = exp(-v * 5.0) * (1.0 - v) * (1.0 - v);
        gl_FragColor = vec4((vec3(1.0) * core * 3.4 + vCol.rgb * (core * 1.6 + halo * 0.85)) * vCol.a, 1.0);
      }`,
  }));
  mesh.frustumCulled = false; mesh.renderOrder = 10; mesh.visible = false;
  scene.add(mesh);

  const all = [], tmp = new Float32Array(80 * 3), A = new THREE.Vector3(), B = new THREE.Vector3(), T = new THREE.Vector3(), P = new THREE.Vector3(), UP = new THREE.Vector3(0, 1, 0);
  const strand = (n, o) => ({ pts: new Float32Array(n * 3), n, w: [WIDE, WIDE], p: [1, 1], thin: 0.016, anchor: null, u: null, ...o });
  // (kept out of the ground)
  const lift = (st) => { if (ground) for (let i = 1; i < st.n - 1; i++) { const y = ground(st.pts[i * 3], st.pts[i * 3 + 2]) + 0.25; if (st.pts[i * 3 + 1] < y) st.pts[i * 3 + 1] = y; } };

  // A stroke from the staff: its trunk, and the forks that leave it. Struck again, its big turns and where its forks
  // leave it are the same, its small turns are new, and fewer forks are left each time.
  function strike(s) {
    if (s.pin) s.a.copy(s.pin);
    s.a0.copy(s.a);
    const L = s.a.distanceTo(s.b), levels = L > 9 ? 6 : L > 3.5 ? 5 : 4, amp = clamp(L * 0.055, 0.12, 0.8);
    const fine = rng(s.seed * 7 + s.struck * 131 + 1), thin = s.struck === 2 ? 0.65 : 1;
    const trunk = strand((1 << levels) + 1, { w: [WIDE * thin, WIDE * thin], u: [0, 1] });
    jag(trunk.pts, s.a, s.b, levels, amp, rng(s.seed), fine, 3);
    // (it does not go straight there: it leaves the staff rising and to one side, and comes round and down on what it
    // strikes. So whoever cast it, looking along it, sees the whole of it arc out across their view and in again)
    T.subVectors(s.b, s.a).normalize();
    const br = rng(s.seed + 5), bow = clamp(L * 0.075, 0.25, 0.95);
    P.crossVectors(T, UP).normalize().multiplyScalar(br() * 2.4 - 1.2).addScaledVector(UP, 0.8); P.addScaledVector(T, -P.dot(T)).normalize();
    for (let i = 1; i < trunk.n - 1; i++) { const k = Math.sin(Math.PI * (i / (trunk.n - 1)) ** 0.65) * bow; trunk.pts[i * 3] += P.x * k; trunk.pts[i * 3 + 1] += P.y * k; trunk.pts[i * 3 + 2] += P.z * k; }
    lift(trunk);
    s.strands = [trunk];
    for (let k = 0, forks = s.struck === 0 ? 3 + Math.min(3, Math.floor(L / 5)) : 2 - s.struck + 1; k < forks; k++) {
      const r = rng(s.seed + 1000 + k * 17), i = Math.floor((trunk.n - 1) * (0.22 + 0.6 * r())), far = clamp(L * (0.1 + 0.16 * r()), 0.7, 4.2), lean = 0.45 + 0.55 * r();
      // (it leaves the trunk at an angle, going on the way the stroke goes, and rather up than down)
      P.set(r() * 2 - 1, r() * 1.6 - 0.5, r() * 2 - 1).addScaledVector(T, -P.dot(T)).normalize();
      A.set(trunk.pts[i * 3], trunk.pts[i * 3 + 1], trunk.pts[i * 3 + 2]);
      B.copy(A).addScaledVector(T, Math.cos(lean) * far).addScaledVector(P, Math.sin(lean) * far);
      const fork = strand(17, { w: [WIDE * 0.6 * thin, WIDE * 0.22], p: [0.62, 0], thin: 0.011, u: [i / (trunk.n - 1), i / (trunk.n - 1)] });
      jag(fork.pts, A, B, 4, far * 0.13, r, fine, 2);
      lift(fork);
      s.strands.push(fork);
      // (and a fork of its own, now and then)
      if (s.struck === 0 && r() < 0.5) {
        const j = 5 + Math.floor(r() * 6), short = far * (0.3 + 0.3 * r());
        A.set(fork.pts[j * 3], fork.pts[j * 3 + 1], fork.pts[j * 3 + 2]);
        P.set(r() * 2 - 1, r() * 1.4 - 0.4, r() * 2 - 1).normalize();
        B.copy(A).addScaledVector(T, short * 0.6).addScaledVector(P, short * 0.8);
        const twig = strand(9, { w: [WIDE * 0.35, WIDE * 0.18], p: [0.4, 0], thin: 0.008, u: fork.u });
        jag(twig.pts, A, B, 3, short * 0.14, r, fine, 1);
        lift(twig);
        s.strands.push(twig);
      }
    }
  }
  // Arcs of it over a body: each from one place on them to another, new ones several times over as long as it lasts.
  function crawlOver(s) {
    const r = rng(s.seed + s.struck * 53), left = 1 - s.t / s.lasts;
    s.strands = [];
    for (let k = 0, many = Math.ceil(s.many * (0.4 + 0.6 * left)); k < many; k++) {
      const a0 = r() * 6.283, a1 = a0 + (0.7 + 1.5 * r()) * (r() < 0.5 ? -1 : 1), y0 = s.low + (s.high - s.low) * r(), y1 = clamp(y0 + (r() * 2 - 1) * (s.high - s.low) * 0.7, s.low, s.high);
      A.set(Math.cos(a0) * s.r, y0, Math.sin(a0) * s.r); B.set(Math.cos(a1) * s.r, y1, Math.sin(a1) * s.r);
      const wide = Math.min(0.075, s.r * 0.3), arc = strand(9, { w: [wide, wide], p: [0.25, 0.25], thin: 0.006, anchor: s.body });
      jag(arc.pts, A, B, 3, s.r * 0.42, r, r, 0, 1);
      // (it keeps to their outside: no part of it through the middle of them)
      for (let i = 1; i < 8; i++) { const x = arc.pts[i * 3], z = arc.pts[i * 3 + 2], d = Math.hypot(x, z), out = Math.max(d, s.r * 0.92) / (d || 1); arc.pts[i * 3] = x * out; arc.pts[i * 3 + 2] = z * out; }
      // (bright in its middle, gone at its ends)
      arc.bow = true;
      s.strands.push(arc);
    }
  }
  // It runs out along the ground from where it earthed, further each time, and is gone.
  function earth(s) {
    const r = rng(s.seed + s.struck * 71), fr = rng(s.seed), grown = Math.min(1, 0.45 + 0.3 * s.struck);
    s.strands = [];
    for (let k = 0; k < s.many; k++) {
      const a = (k + fr()) / s.many * 6.283, far = s.far * (0.55 + 0.45 * fr()) * grown;
      A.copy(s.at); B.set(s.at.x + Math.cos(a) * far, s.at.y, s.at.z + Math.sin(a) * far);
      const run = strand(9, { w: [0.1, 0.04], p: [0.85, 0], thin: 0.007 });
      jag(run.pts, A, B, 3, far * 0.2, r, r, 0, 0);
      for (let i = 0; i < 9; i++) run.pts[i * 3 + 1] = (ground ? ground(run.pts[i * 3], run.pts[i * 3 + 2]) : s.at.y) + 0.07 + 0.1 * r();
      s.strands.push(run);
    }
  }

  function write() {
    let seg = 0;
    for (const s of all) {
      const power = s.kind === 'bolt' ? glare(s.t) * (0.9 + 0.2 * Math.random()) : (1 - s.t / s.lasts) ** 0.7 * (0.6 + 0.8 * Math.random());
      // (the staff has moved since it struck: the stroke still leaves from the staff)
      const dx = s.pin ? s.pin.x - s.a0.x : 0, dy = s.pin ? s.pin.y - s.a0.y : 0, dz = s.pin ? s.pin.z - s.a0.z : 0;
      for (const st of s.strands) {
        const { pts, n } = st, ox = st.anchor?.x ?? 0, oy = st.anchor?.y ?? 0, oz = st.anchor?.z ?? 0;
        for (let i = 0; i < n; i++) {
          const u = st.u ? st.u[0] + (st.u[1] - st.u[0]) * (i / (n - 1)) : 1, held = (1 - u) * (1 - u);
          tmp[i * 3] = pts[i * 3] + ox + dx * held; tmp[i * 3 + 1] = pts[i * 3 + 1] + oy + dy * held; tmp[i * 3 + 2] = pts[i * 3 + 2] + oz + dz * held;
        }
        for (let i = 0; i < n - 1 && seg < SEGS; i++, seg++) {
          for (let v = 0; v < 4; v++) {
            const end = v >> 1, j = i + end, f = j / (n - 1), o = (seg * 4 + v) * 3, q = (seg * 4 + v) * 4, pj = Math.max(0, j - 1), nj = Math.min(n - 1, j + 1);
            at[o] = tmp[j * 3]; at[o + 1] = tmp[j * 3 + 1]; at[o + 2] = tmp[j * 3 + 2];
            prev[o] = tmp[pj * 3]; prev[o + 1] = tmp[pj * 3 + 1]; prev[o + 2] = tmp[pj * 3 + 2];
            next[o] = tmp[nj * 3]; next[o + 1] = tmp[nj * 3 + 1]; next[o + 2] = tmp[nj * 3 + 2];
            look[q] = v & 1 ? 1 : -1; look[q + 1] = st.w[0] + (st.w[1] - st.w[0]) * f;
            look[q + 2] = power * (st.bow ? st.p[0] + Math.sin(f * Math.PI) : st.p[0] + (st.p[1] - st.p[0]) * f); look[q + 3] = st.thin;
            col[q] = s.colour[0]; col[q + 1] = s.colour[1]; col[q + 2] = s.colour[2]; col[q + 3] = end;
          }
        }
      }
    }
    g.setDrawRange(0, seg * 6);
    for (const k of Object.keys(attr)) { attr[k].clearUpdateRanges(); attr[k].addUpdateRange(0, seg * 4 * attr[k].itemSize); attr[k].needsUpdate = true; }
    mesh.visible = seg > 0;
    return seg;
  }

  let count = 0;
  return {
    lasts: LASTS, glare,
    /** A stroke from one place to another, of this colour. `pin`: where it leaves from, as that moves (the staff). */
    bolt(a, b, colour, pin = null) {
      const s = { kind: 'bolt', a: a.clone(), a0: a.clone(), b: b.clone(), pin, colour, seed: 1 + Math.floor(Math.random() * 1e6), t: 0, lasts: LASTS, struck: 0, strands: [] };
      strike(s); all.push(s);
    },
    /** Arcs of it crawling over a body: `body` is where its feet are (and goes on being), so wide and from so low to so high. */
    crawl(body, colour, { r = 0.42, low = 0.25, high = 1.7, lasts = 0.5, many = 5 } = {}) {
      const s = { kind: 'crawl', body, colour, r, low, high, lasts, many, seed: 1 + Math.floor(Math.random() * 1e6), t: 0, struck: 0, every: 0.045, strands: [] };
      crawlOver(s); all.push(s);
    },
    /** It runs out along the ground from a place. */
    earth(at, colour, { far = 1.5, lasts = 0.3, many = 5 } = {}) {
      const s = { kind: 'earth', at: at.clone(), colour, far, lasts, many, seed: 1 + Math.floor(Math.random() * 1e6), t: 0, struck: 0, every: 0.06, strands: [] };
      earth(s); all.push(s);
    },
    update(dt) {
      if (!all.length) { if (count) count = write(); return; }
      for (let i = all.length - 1; i >= 0; i--) {
        const s = all[i]; s.t += dt;
        if (s.t >= s.lasts) { all.splice(i, 1); continue; }
        const now = s.kind === 'bolt' ? strikeOf(s.t) : Math.floor(s.t / s.every);
        if (now !== s.struck) { s.struck = now; (s.kind === 'bolt' ? strike : s.kind === 'crawl' ? crawlOver : earth)(s); }
      }
      count = write();
    },
    /** (for tests: how much of it there is to see) */
    get count() { return count; },
  };
}
