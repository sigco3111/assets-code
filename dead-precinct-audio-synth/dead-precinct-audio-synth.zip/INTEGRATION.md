# INTEGRATION — audio.js

Extracted section of a single-file game; reuse as reference or with light adaptation.

Globals the code expects:
- `rnd` — the game aliases `Math.random`. Define `const rnd=Math.random;` before loading.
- `shk` — screen-shake amount the game reads each frame. `sfx.shot/sting/thud` raise it.
  Define `let shk=0;` if you do not use screen shake.

Entry points:
- `initAudio(audioContext)` — builds master chain (compressor), noise buffer `nb`,
  procedural convolver reverb `rv`, music bus `mb`. Call once after a user gesture.
- `sfx.<name>(...)` — fire a one-shot. e.g. `sfx.shot(0|1|2)`, `sfx.scream(1)`, `sfx.roar()`.
- `music('dread'|'safe'|'boss')` / `music('')` — start/stop a generative track.
  Playback is scheduled by `tick()`; the original starts `setInterval(tick,40)` inside
  `initAudio` (kept). `tick()` also contains game-coupled triggers (ambient event
  stings via `state/rooms/R`, heartbeat via `pl.hp`) — stub those globals or delete
  the second half of `tick()` for standalone use.
- `setAmb(0..5)` / `setAmb(-1)` — room ambience loops; `-1` stops.
- `duck()` — dips the music bus under a sting.
