// Dead Precinct WebAudio 합성 오디오 엔진 (참고용 원본 발췌)
// 출처: https://github.com/Bao5ye/dead-precinct (commit 3292dc6, MIT, Copyright (c) 2026 Bao5ye)
// 단일 index.html 게임의 오디오 절을 그대로 발췌. 녹음 음원 없이 전량 실시간 합성.
// 구성: 효과음 26종(sfx 객체) + 생성형 음악 3곡(dread/safe/boss, seq·tick 스케줄러)
//       + 방별 환경음(setAmb) + 컨볼버 리버브 + 덕킹(duck) + 저체력 심장박동.
// 외부 의존: rnd(=Math.random). 게임 결합부: shk(화면 흔들림 전역), tick() 말미의
// state/rooms/R/pl 참조(이벤트 스팅·심장박동 트리거). 통합 방법은 INTEGRATION.md 참조.
// 사용법: initAudio(new AudioContext()) 후 sfx.shot(0) 등 호출, music('dread'|'safe'|'boss').
let ac,mg,rv,mb,nb,trk='',nxt=0,stp=0,pad=null,ambN=null,evT=0,hbT=0,shk=0;
const now=()=>ac.currentTime,mf=m=>440*Math.pow(2,(m-69)/12);
function initAudio(c,off){ac=c;const cp=c.createDynamicsCompressor();cp.threshold.value=-14;cp.ratio.value=4;cp.connect(c.destination);mg=c.createGain();mg.gain.value=1;mg.connect(cp);
 nb=c.createBuffer(1,c.sampleRate*2,c.sampleRate);const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=rnd()*2-1;
 rv=c.createConvolver();const L=c.sampleRate*2.8|0,ir=c.createBuffer(2,L,c.sampleRate);for(let k=0;k<2;k++){const x=ir.getChannelData(k);for(let i=0;i<L;i++)x[i]=(rnd()*2-1)*Math.pow(1-i/L,3.2)}rv.buffer=ir;
 const rg=c.createGain();rg.gain.value=.55;rv.connect(rg);rg.connect(mg);mb=c.createGain();mb.gain.value=.6;mb.connect(mg);const ms=c.createGain();ms.gain.value=.45;mb.connect(ms);ms.connect(rv);
 if(!off){const s=c.createBufferSource();s.buffer=c.createBuffer(1,1,22050);s.connect(c.destination);s.start(0);setInterval(tick,40)}}
function au(){try{if(!ac){initAudio(new(window.AudioContext||window.webkitAudioContext)());music(trk,1);if(rooms&&R)setAmb(rooms.indexOf(R))}if(ac.state!='running')ac.resume()}catch(e){}}
['pointerdown','pointerup','touchend','mousedown','keydown'].forEach(n=>addEventListener(n,au,true));
function chain(t,dur,v,o,src){const G=ac.createGain(),a=o.a||.005;G.gain.setValueAtTime(.0001,t);G.gain.exponentialRampToValueAtTime(v,t+a);if(o.h)G.gain.setValueAtTime(v,t+a+o.h);G.gain.exponentialRampToValueAtTime(.0001,t+Math.max(dur,a+(o.h||0)+.01));
 let n=src;if(o.ft){const f=ac.createBiquadFilter();f.type=o.ft;f.frequency.setValueAtTime(o.ff,t);if(o.ff2)f.frequency.exponentialRampToValueAtTime(o.ff2,t+dur);f.Q.value=o.q||1;n.connect(f);n=f}
 n.connect(G);G.connect(o.dst||mg);if(o.wet){const w=ac.createGain();w.gain.value=o.wet;G.connect(w);w.connect(rv)}}
function OSC(type,f,t,dur,v,o={}){if(!ac)return;const s=ac.createOscillator();s.type=type;s.frequency.setValueAtTime(f,t);if(o.f2)s.frequency.exponentialRampToValueAtTime(o.f2,t+(o.fd||dur));
 if(o.vib){const l=ac.createOscillator(),lg=ac.createGain();l.frequency.value=o.vib;lg.gain.value=f*(o.vd||.03);l.connect(lg);lg.connect(s.frequency);l.start(t);l.stop(t+dur+.05)}chain(t,dur,v,o,s);s.start(t);s.stop(t+dur+.05)}
function Nz(t,dur,v,o={}){if(!ac)return;const s=ac.createBufferSource();s.buffer=nb;s.loop=true;s.playbackRate.value=o.r||1;chain(t,dur,v,o,s);s.start(t,rnd()*1.5);s.stop(t+dur+.05)}
function voice(pts,dur,Fm,v,o={}){if(!ac)return;const t=now()+(o.d||0),s=ac.createOscillator(),G=ac.createGain();s.type='sawtooth';s.frequency.setValueAtTime(pts[0][1],t);for(const p of pts.slice(1))s.frequency.linearRampToValueAtTime(p[1],t+p[0]);
 if(o.vib){const l=ac.createOscillator(),lg=ac.createGain();l.frequency.value=o.vib;lg.gain.value=pts[0][1]*(o.vd||.03);l.connect(lg);lg.connect(s.frequency);l.start(t);l.stop(t+dur+.05)}
 const src=[s];if(o.br){const n=ac.createBufferSource(),ng=ac.createGain();n.buffer=nb;n.loop=true;ng.gain.value=o.br;n.connect(ng);src.push(ng);n.start(t,rnd());n.stop(t+dur+.05)}
 Fm.forEach((f,i)=>{const b=ac.createBiquadFilter(),bg=ac.createGain();b.type='bandpass';b.frequency.value=f;b.Q.value=o.q||6;bg.gain.value=[1,.7,.35][i]||.2;src.forEach(x=>x.connect(b));b.connect(bg);bg.connect(G)});
 G.gain.setValueAtTime(.0001,t);G.gain.exponentialRampToValueAtTime(v,t+.04);G.gain.setValueAtTime(v,t+dur*.6);G.gain.exponentialRampToValueAtTime(.0001,t+dur);G.connect(mg);
 if(o.wet){const w=ac.createGain();w.gain.value=o.wet;G.connect(w);w.connect(rv)}s.start(t);s.stop(t+dur+.05)}
function duck(){if(!ac)return;mb.gain.cancelScheduledValues(now());mb.gain.setTargetAtTime(.12,now(),.04);mb.gain.setTargetAtTime(.6,now()+2.5,.8)}
const sfx={
 shot(w){if(!ac)return;const t=now();Nz(t,w==1?.7:w==2?.2:.35,w==1?1.8:1.1,{ft:'lowpass',ff:7000,ff2:260,wet:.4});OSC('sine',w==1?110:150,t,w==1?.4:.2,w==1?1.4:.9,{f2:38});if(w==1)Nz(t+.02,.45,.6,{ft:'bandpass',ff:900,q:.7,wet:.5});shk=Math.max(shk,w==1?.35:.12)},
 step(){if(!ac)return;const t=now();Nz(t,.08,.8,{ft:'bandpass',ff:1700+rnd()*700,q:1.4,wet:.3});OSC('sine',95,t,.07,.7,{f2:55})},
 moan(v=1){voice([[0,85+rnd()*30],[.7,105+rnd()*20],[1.4,72]],1.5,[450,800,2300],1.8*v,{vib:4.5,br:.4,wet:.5})},
 snarl(){voice([[0,140],[.45,180]],.55,[620,1050,2500],2.4,{br:1,vib:9,wet:.3})},
 scream(v=1,d=0){voice([[0,480],[.12,840],[.6,780],[1.1,540]],1.15,[950,1350,3000],2.1*v,{vib:7,br:.3,wet:.45,d})},
 hurt(big){big?sfx.scream():voice([[0,340],[.22,235]],.3,[780,1200,2800],2.4,{br:.5,wet:.25})},
 bite(){if(!ac)return;const t=now();for(const d of[0,.11,.21])Nz(t+d,.13,1.4,{ft:'bandpass',ff:1500+rnd()*900,q:1.2});Nz(t+.05,.55,1.1,{ft:'lowpass',ff:900,ff2:220,q:7,wet:.2});OSC('sine',80,t,.22,1,{f2:40})},
 slash(){if(!ac)return;const t=now();Nz(t,.2,1,{ft:'highpass',ff:2500,ff2:9000,a:.01});Nz(t+.05,.3,.8,{ft:'lowpass',ff:700,q:4})},
 screech(){voice([[0,650],[.2,1700],[.55,1150]],.65,[1300,2500,3600],1.7,{vib:28,vd:.06,br:.8,wet:.4})},
 skitter(){if(!ac)return;const t=now();for(let i=0;i<7;i++)Nz(t+i*.05+rnd()*.03,.035,1.1,{ft:'bandpass',ff:3200,q:3,wet:.35})},
 roar(){if(!ac)return;voice([[0,70],[.5,96],[1.6,56]],1.8,[330,700,1900],3.2,{br:1,vib:14,vd:.08,wet:.55});OSC('sine',45,now(),1.6,1,{f2:28})},
 thud(){if(!ac)return;const t=now();OSC('sine',70,t,.45,1.4,{f2:24});Nz(t,.35,1,{ft:'lowpass',ff:400,ff2:60,wet:.45});shk=Math.max(shk,.18)},
 slam(){if(!ac)return;const t=now();Nz(t,.55,1.5,{ft:'lowpass',ff:900,ff2:60,wet:.6});OSC('sine',60,t,.4,1.1,{f2:30})},
 creak(){if(!ac)return;OSC('sawtooth',160,now(),1.2,2,{f2:420,vib:9,vd:.05,ft:'bandpass',ff:1100,q:4,wet:.4})},
 glass(){if(!ac)return;const t=now();Nz(t,.9,1.4,{ft:'highpass',ff:3500,wet:.45});for(let i=0;i<12;i++)OSC('sine',2500+rnd()*5000,t+rnd()*.5,.3,.15,{wet:.4})},
 pick(){if(!ac)return;const t=now();OSC('sine',880,t,.18,.4,{f2:1320});OSC('sine',1760,t+.08,.4,.25,{wet:.3})},
 click(){if(ac)OSC('square',1200,now(),.035,.25,{ft:'highpass',ff:800})},
 heal(){if(!ac)return;const t=now();[523,659,784].forEach((f,i)=>OSC('sine',f,t+i*.09,.6,.3,{wet:.4}))},
 die(e){e.k=='z'?voice([[0,110],[1.2,48]],1.3,[420,760,2200],2,{br:.6,wet:.45}):e.k=='c'?voice([[0,1400],[.8,280]],.9,[1300,2400,3400],1.7,{vib:30,br:.7,wet:.45}):(voice([[0,90],[2.4,30]],2.6,[300,650,1800],3.2,{br:1,vib:10,wet:.6}),setTimeout(sfx.thud,1800))},
 sting(v=1){if(!ac)return;const t=now();[1046,1108,1174,1245,2093,2217].forEach(f=>OSC('sawtooth',f*(1+rnd()*.01),t,2.2,.09*v,{a:.02,h:.35,vib:13,vd:.015,ft:'highpass',ff:700,wet:.6}));OSC('sine',55,t,2,1.3*v,{f2:28});Nz(t,.8,1.1*v,{ft:'lowpass',ff:1500,ff2:90,wet:.5});duck();shk=Math.max(shk,.45*v)},
 heart(){if(!ac)return;const t=now();OSC('sine',62,t,.14,1.2,{f2:38});OSC('sine',58,t+.25,.14,.9,{f2:36})},
 thunder(){if(!ac)return;const t=now();Nz(t,3.5,1.4,{ft:'lowpass',ff:500,ff2:55,a:.05,wet:.6,r:.5});Nz(t,.25,.9,{ft:'highpass',ff:1500,a:.002})},
 drip(){if(ac)OSC('sine',1400+rnd()*600,now(),.09,.3,{f2:500,wet:.9})},
 bang(){if(!ac)return;const t=now();Nz(t,.7,.9,{ft:'bandpass',ff:350,q:2,wet:1});OSC('triangle',120,t,.5,.4,{f2:80,wet:1})},
 alarm(){if(!ac)return;const t=now();for(let i=0;i<8;i++)OSC('square',620,t+i*.8,.45,.3,{f2:900,ft:'lowpass',ff:2200,wet:.5})},
 power(){if(!ac)return;const t=now();OSC('sawtooth',120,t,1.3,.5,{f2:28,ft:'lowpass',ff:900,wet:.4});Nz(t,.18,.7,{ft:'highpass',ff:3000})}};
function setAmb(k){if(!ac)return;if(ambN){const a=ambN;a.g.gain.setTargetAtTime(0,now(),.4);setTimeout(()=>a.s.forEach(x=>{try{x.stop()}catch(e){}}),2500);ambN=null}if(k<0)return;
 const g=ac.createGain(),s=[];g.gain.value=0;g.connect(mg);g.gain.setTargetAtTime(1,now(),.8);
 const nz=(v,ft,f,q=1)=>{const n=ac.createBufferSource(),b=ac.createBiquadFilter(),gg=ac.createGain();n.buffer=nb;n.loop=true;b.type=ft;b.frequency.value=f;b.Q.value=q;gg.gain.value=v;n.connect(b);b.connect(gg);gg.connect(g);n.start(0,rnd());s.push(n)};
 const hm=(v,f)=>{const o=ac.createOscillator(),b=ac.createBiquadFilter(),gg=ac.createGain();o.type='sawtooth';o.frequency.value=f;b.frequency.value=400;gg.gain.value=v;o.connect(b);b.connect(gg);gg.connect(g);o.start();s.push(o)};
 if(k==0){nz(.35,'bandpass',1500,.5);nz(.25,'lowpass',260)}else if(k==2||k==4){hm(.05,120);nz(.03,'highpass',6000)}else if(k==5)nz(.35,'lowpass',110);else nz(.12,'lowpass',450);ambN={g,s}}
function music(k,force){if(k==trk&&!force)return;trk=k;if(!ac)return;stp=0;nxt=now()+.05;
 if(pad){const p=pad;p.g.gain.setTargetAtTime(0,now(),.7);setTimeout(()=>p.o.forEach(o=>{try{o.stop()}catch(e){}}),3500);pad=null}
 if(k=='dread'||k=='boss'){const g=ac.createGain(),f=ac.createBiquadFilter(),l=ac.createOscillator(),lg=ac.createGain(),o=[l];f.type='lowpass';f.frequency.value=k=='boss'?700:420;f.Q.value=4;l.frequency.value=.07;lg.gain.value=220;l.connect(lg);lg.connect(f.frequency);
  for(const fr of k=='boss'?[55,55.4,82.4,110.3]:[55,55.5,77.8,116.5,155.6]){const s=ac.createOscillator();s.type='sawtooth';s.frequency.value=fr;s.connect(f);s.start();o.push(s)}l.start();
  f.connect(g);g.gain.value=0;g.gain.setTargetAtTime(k=='boss'?.16:.2,now(),1.5);g.connect(mb);pad={g,o}}}
const BPM={dread:60,safe:66,boss:140};
function bell(f,t,v,dc){OSC('sine',f,t,dc,v,{dst:mb});OSC('sine',f*2.76,t,dc*.5,v*.3,{dst:mb});OSC('sine',f*5.4,t,dc*.25,v*.12,{dst:mb})}
function seq(k,s,t){
 if(k=='dread'){if(rnd()<.11)bell(mf([45,48,52,53,57,58,60,64][rnd()*8|0]),t,.22,3.8);if(s%32==0){OSC('sawtooth',220,t,7,.04,{a:3,ft:'lowpass',ff:1100,dst:mb});OSC('sawtooth',233.1,t,7,.04,{a:3,ft:'lowpass',ff:1100,dst:mb})}if(rnd()<.015){OSC('sine',50,t,2.2,.9,{f2:28,dst:mb});Nz(t,1.2,.4,{ft:'lowpass',ff:160,dst:mb})}}
 else if(k=='safe'){const C=[[57,60,64],[53,57,60],[48,52,55],[52,56,59]][(s>>3)%4],i=[0,1,2,1,2,1,0,2][s%8];
  OSC('sine',mf(C[i]+12+(s%8==6?12:0)),t,1.6,.26,{dst:mb});OSC('sine',mf(C[i]+36),t,.5,.05,{dst:mb});if(s%8==0){OSC('triangle',mf(C[0]-12),t,3,.22,{dst:mb});OSC('sine',mf(C[1]),t,3.2,.05,{a:.4,dst:mb})}}
 else if(k=='boss'){const b=s%16;if([0,3,6,8,11,14].includes(b))OSC('sine',120,t,.25,.8,{f2:42,dst:mb});OSC('sawtooth',mf([33,33,36,33,34,33,31,33][s%8]),t,.2,.25,{ft:'lowpass',ff:520,dst:mb});
  if(b%2==0)Nz(t,.05,.12,{ft:'highpass',ff:7000,dst:mb});if(b==0)[45,48,52].forEach(m=>OSC('sawtooth',mf(m+((s>>4)%2)),t,.45,.1,{ft:'lowpass',ff:1800,dst:mb}));if(s%64==0)Nz(t,1.8,.35,{a:1.6,ft:'highpass',ff:3000,dst:mb})}}
function tick(){if(!ac||ac.state!='running')return;const t=now();
 if(trk&&BPM[trk]){const spb=30/BPM[trk];if(nxt<t-.5)nxt=t;while(nxt<t+.2){seq(trk,stp++,nxt);nxt+=spb}}
 if((state=='play'||state=='msg')&&R&&rooms){const ri=rooms.indexOf(R);
  if(t>evT){if(evT){const E=[['thunder','scream','bang'],['bang','scream'],['moan','power'],['skitter','bang','moan'],['drip','bang'],['drip','bang']][ri]||[],k=E[rnd()*E.length|0];
    if(k=='scream')sfx.scream(.18);else if(k=='moan')sfx.moan(.3);else if(k)sfx[k]()}evT=t+7+rnd()*10}
  if(pl&&pl.hp<34&&pl.hp>0&&t>hbT){hbT=t+.85;sfx.heart()}}}

