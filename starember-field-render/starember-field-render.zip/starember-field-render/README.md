# Starember Field Render Modules (별잿빛 들판 렌더링 모듈)

Three.js rendering modules extracted from gamedemo_by_Fable5.2 (星烬原野), MIT.

- src/render/toon.ts: toon shading + outline materials (charToon, toon, glowMat, outlineMat, addOutline)
- src/render/sky.ts: day/night sky
- src/render/water.ts: water surface (uses world/layout constants, swap in your own)
- src/render/grass.ts: instanced grass field (uses world/layout + world/terrain)
- src/render/fx.ts: particle/attack effects
- src/render/geoutil.ts: geometry helpers (lathe, merge, paint, transforms)
- src/world/terrain.ts + src/world/layout.ts: noise-based terrain heightfield and world layout constants
- src/core/math.ts: math + value-noise/fbm utilities

Deps: three ^0.187 (peer). TypeScript. The modules reference world/layout.ts
constants for island-specific placement; treat layout.ts as the example config
to replace for your own world.
