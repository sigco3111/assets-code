// builds human/dist/human.js: human/src/*.js (sorted) concatenated, everything under the one global `Human`.
// This collector's variant OMITS the mocap embed from the original human/build.js:
// the original also folds data/mocap/turn_cycle_cc_slalom.json (CC BY 3.0, derived from real skiing video) into the
// module as Human.MOCAP. That data is left out of this pack pending rights review; the module runs without it
// (the 'ski carve' motion clip just reports no data and the caller falls back).
const fs = require('fs'), path = require('path');
const src = path.join(__dirname, 'human', 'src');
const mod = fs.readdirSync(src).filter(f => f.endsWith('.js')).sort().map(f => fs.readFileSync(path.join(src, f), 'utf8')).join('\n');
fs.mkdirSync(path.join(__dirname, 'human', 'dist'), { recursive: true });
fs.writeFileSync(path.join(__dirname, 'human', 'dist', 'human.js'), mod);
console.log('built human/dist/human.js', (mod.length / 1024).toFixed(1) + ' KB');
