# 데이터·수치 출처 (모듈 주석 기반)

이 모듈은 외부 파일을 내려받거나 읽지 않고, 아래 공개 자료에서 피팅한 **상수**만 코드에 내장합니다(원시 데이터셋 미포함).

- ANSUR II (US Army Anthropometric Survey, 2012 조사 / 2017 공개): 신체 치수 회귀 계수 (human/src/01_params.js)
- CDC / Soucie 2011, AAOS 정상 관절 가동범위 (human/src/02_skeleton.js)
- McClure 2001 견갑상완 리듬 (human/src/02_skeleton.js)
- de Leva 1996 체절 파라미터 (human/README.md 명시)
- human/src/09a_refdata.js: MakeHuman 베이스 메쉬(CC0 1.0). MakeHuman 프로젝트는 2020-09부터 번들 에셋(베이스 메쉬·타깃 등)을 CC0로 공개함을 공식 FAQ와 LICENSE.md로 확인(2026-11-24):
  - https://static.makehumancommunity.org/oldsite/faq/what_changed_regarding_the_license_in_2020.html
  - https://github.com/makehumancommunity/makehuman/blob/master/LICENSE.md

## 이번 수집에서 뺀 것
- data/mocap/*.json (실제 스키 영상에서 추출한 턴 동작 수치, CC BY / CC BY 3.0 / Pexels License): 원영상 기반 수치라 단순 크레딧만으로 재배포 가능한지 확인이 끝나지 않아 모듈에 심지 않았습니다. 원본 human/build.js는 이 데이터를 Human.MOCAP으로 내장하지만, 수록 build-module.js는 그 단계를 생략합니다. 이 데이터가 없어도 모듈은 동작하며 'ski carve' 모션 클립만 데이터 없음으로 처리됩니다.
- human/lab/, human/tools/ (연구용 실험 페이지·렌더 도구), research/ 보고서: 게임 재사용과 무관해 미수록. 원본 저장소에서 확인 가능.
