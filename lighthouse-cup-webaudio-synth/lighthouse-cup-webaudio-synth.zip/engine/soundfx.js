// Extracted from Lighthouse Cup index.html (original English build, commit d147523)
// https://github.com/itsLucas02/lighthouse-cup
// MIT License, Copyright (c) 2026 Aizzul Luqman. See LICENSE.txt.
// Excerpt from a single-file game: reference or light adaptation, not a drop-in package.
    // --- Procedural Web Audio Synthesizer (Zero External Files) ---
    class SoundFX {
      constructor() {
        this.enabled = false;
        this.ctx = null;
        this.noiseBuf = null;
      }

      toggle() {
        this.enabled = !this.enabled;
        if (this.enabled) this.ensureCtx();
        return this.enabled;
      }

      ensureCtx() {
        if (!this.enabled) return null;
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        if (!this.ctx) {
          this.ctx = new AC();
          const sr = this.ctx.sampleRate;
          const buf = this.ctx.createBuffer(1, sr * 1.2, sr);
          const d = buf.getChannelData(0);
          for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
          this.noiseBuf = buf;
        }
        if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
        return this.ctx;
      }

      playHit(power = 0.7) {
        const ctx = this.ensureCtx();
        if (!ctx) return;
        const now = ctx.currentTime;
        // Hollow leather thump
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(160 + power * 130, now);
        osc.frequency.exponentialRampToValueAtTime(58, now + 0.09);
        g.gain.setValueAtTime(0.18 * (0.5 + power * 0.6), now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
        osc.connect(g).connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.12);
        // Palm slap transient
        if (this.noiseBuf && power > 0.45) {
          const src = ctx.createBufferSource();
          src.buffer = this.noiseBuf;
          const flt = ctx.createBiquadFilter();
          flt.type = 'bandpass';
          flt.frequency.value = 1300 + power * 900;
          flt.Q.value = 1.6;
          const ng = ctx.createGain();
          ng.gain.setValueAtTime(0.14 * power, now);
          ng.gain.exponentialRampToValueAtTime(0.001, now + 0.055);
          src.connect(flt).connect(ng).connect(ctx.destination);
          src.start(now);
          src.stop(now + 0.06);
        }
      }

      playBounce(intensity = 0.7, bounceCoeff = 0.8) {
        const ctx = this.ensureCtx();
        if (!ctx) return;
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(95 + bounceCoeff * 85, now);
        osc.frequency.exponentialRampToValueAtTime(42, now + 0.13);
        g.gain.setValueAtTime(0.16 * clamp(intensity, 0.2, 1.0), now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
        osc.connect(g).connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.15);
      }

      playSqueak(squeakFactor = 0.78) {
        const ctx = this.ensureCtx();
        if (!ctx || squeakFactor < 0.25) return;
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = 'sine';
        const f0 = 2100 + Math.random() * 900;
        osc.frequency.setValueAtTime(f0, now);
        osc.frequency.exponentialRampToValueAtTime(f0 * (0.76 + Math.random() * 0.45), now + 0.07);
        g.gain.setValueAtTime(0.001, now);
        g.gain.linearRampToValueAtTime(0.045 * squeakFactor, now + 0.014);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        osc.connect(g).connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.085);
      }

      playWhistle(double = false) {
        const ctx = this.ensureCtx();
        if (!ctx) return;
        const blow = (offset, dur) => {
          const t0 = ctx.currentTime + offset;
          const o1 = ctx.createOscillator();
          const o2 = ctx.createOscillator();
          const g = ctx.createGain();
          o1.type = 'sine';
          o2.type = 'triangle';
          o1.frequency.setValueAtTime(2860, t0);
          o2.frequency.setValueAtTime(2902, t0);
          g.gain.setValueAtTime(0.001, t0);
          g.gain.linearRampToValueAtTime(0.06, t0 + 0.02);
          g.gain.setValueAtTime(0.055, t0 + dur - 0.03);
          g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
          o1.connect(g);
          o2.connect(g);
          g.connect(ctx.destination);
          o1.start(t0); o2.start(t0);
          o1.stop(t0 + dur + 0.01); o2.stop(t0 + dur + 0.01);
        };
        blow(0, double ? 0.14 : 0.22);
        if (double) blow(0.18, 0.28);
      }

      playCrowd(intensity = 0.7) {
        const ctx = this.ensureCtx();
        if (!ctx || !this.noiseBuf) return;
        const now = ctx.currentTime;
        const src = ctx.createBufferSource();
        src.buffer = this.noiseBuf;
        const flt = ctx.createBiquadFilter();
        flt.type = 'bandpass';
        flt.frequency.setValueAtTime(620 + intensity * 320, now);
        flt.Q.value = 0.9;
        const g = ctx.createGain();
        const dur = 0.55 + intensity * 0.55;
        g.gain.setValueAtTime(0.001, now);
        g.gain.linearRampToValueAtTime(0.085 * clamp(intensity, 0.3, 1.0), now + 0.12);
        g.gain.exponentialRampToValueAtTime(0.001, now + dur);
        src.connect(flt).connect(g).connect(ctx.destination);
        src.start(now);
        src.stop(now + dur + 0.05);
      }

      playChallengePing(overturned) {
        const ctx = this.ensureCtx();
        if (!ctx) return;
        const now = ctx.currentTime;
        const freqs = overturned ? [523, 659, 784] : [440, 392];
        freqs.forEach((f, i) => {
          const osc = ctx.createOscillator();
          const g = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(f, now + i * 0.09);
          g.gain.setValueAtTime(0.08, now + i * 0.09);
          g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.09 + 0.14);
          osc.connect(g).connect(ctx.destination);
          osc.start(now + i * 0.09);
          osc.stop(now + i * 0.09 + 0.16);
        });
      }
    }

    const soundFX = new SoundFX();

