# INTEGRATION

Standalone class `SoundFX`. Create `new SoundFX()` and call its methods after a user gesture (AudioContext unlock). Original game keeps sound off by default. Method names are in the class body.
