// Extracted from Lighthouse Cup index.html (original English build, commit d147523)
// https://github.com/itsLucas02/lighthouse-cup
// MIT License, Copyright (c) 2026 Aizzul Luqman. See LICENSE.txt.
// Excerpt from a single-file game: reference or light adaptation, not a drop-in package.
// seeded leagues / rosters / commentary phrasing
    // --- Seeded Leagues, Teams & 12-Player Rosters ---
    const SKIN_TONES = ['#F4D6BC', '#E8BE9D', '#D49F7A', '#BA815C', '#9A6444', '#784B31', '#593622'];
    const HAIR_TONES = ['#211915', '#3B2418', '#6B4B2E', '#8E6F2D', '#B33E12', '#464F5C'];

    const WOMEN_FIRST = [
      'Clara','Nadia','Tessa','Maren','Sora','Hanna','Freya','Elena','Mina','Anya',
      'Leila','Petra','Signe','Klara','Ines','Lina','Yuki','Camille','Nora','Daria',
      'Bryn','Marta','Talia','Iris','Sienna','Zofia','Amara','Elin','Rina','Juno',
      'Vera','Kaia','Alma','Naomi','Rhea','Maja','Sylvie','Linnea','Greta','Celine'
    ];
    const MEN_FIRST = [
      'Tomas','Henrik','Mateo','Darius','Kenji','Lukas','Callum','Nikolai','Soren','Rafael',
      'Bram','Jovan','Oskar','Tariq','Milo','Kasper','Andrei','Ronan','Haruto','Felix',
      'Ewan','Viktor','Kieran','Marco','Stefan','Ilya','Gideon','Emil','Dante','Arvid',
      'Benoit','Jonas','Caleb','Nils','Piotr','Koji','Theo','Declan','Roman','Alec'
    ];
    const SURNAMES = [
      'Halvorsen','Kowalski','Delgado','Bramwell','Sato','Lindqvist','Okafor','Moravec','Cavalieri','Vandenberg',
      'Hargreaves','Takahashi','Solberg','Petrovic','Alvarez','Mercier','Nystrom','Keller','Bauer','Redfern',
      'Varga','Sorensen','Mendoza','Whitaker','Fujimoto','Novak','Costello','Richter','Kerrigan','Dumont',
      'Bergstrom','Lozano','Chalmers','Ibrahim','Holm','Ortega','Stanton','Bianchi','Kangas','Thornton',
      'Marchetti','Vermeer','Serrano','Ainsworth','Watanabe','Zaleski','Corbin','Svensson','Morel','Langley'
    ];

    const LEAGUE_SPECS = [
      {
        id: 'womens',
        name: "Women's Premier",
        netHeight: 2.24,
        serveBaseKmh: 76,
        spikeScale: 0.94,
        firstNames: WOMEN_FIRST,
        teams: [
          { id: 'mar', name: 'Marlowe Beacon',   code: 'MAR', jersey: '#13223A', trim: '#E85A1B', shorts: '#0B1324', libero: '#F3EAD9', coach: 'Helena Shaw',    tier: 84 },
          { id: 'kst', name: 'Kestrel Harbour',  code: 'KST', jersey: '#BD313E', trim: '#F5D24E', shorts: '#421017', libero: '#227DA0', coach: 'Miriam Lind',    tier: 83 },
          { id: 'ald', name: 'Alderbridge VC',   code: 'ALD', jersey: '#1F7A6F', trim: '#F3EAD9', shorts: '#102C1E', libero: '#E85A1B', coach: 'Corinne Vale',   tier: 82 },
          { id: 'npr', name: 'Northpier Royals', code: 'NPR', jersey: '#5C3894', trim: '#F2BD4B', shorts: '#24143D', libero: '#75C794', coach: 'Sabine Novak',   tier: 83 },
          { id: 'sol', name: 'Solent Athletics', code: 'SOL', jersey: '#D84D16', trim: '#FCF9F2', shorts: '#13223A', libero: '#359DC2', coach: 'Ingrid Falk',    tier: 81 }
        ]
      },
      {
        id: 'mens',
        name: "Men's Premier",
        netHeight: 2.43,
        serveBaseKmh: 96,
        spikeScale: 1.06,
        firstNames: MEN_FIRST,
        teams: [
          { id: 'mwb', name: 'Marlowe Mariners', code: 'MWB', jersey: '#185D78', trim: '#FF9452', shorts: '#0B1324', libero: '#F5D24E', coach: 'Graham Fletcher', tier: 85 },
          { id: 'brk', name: 'Breakwater Six',   code: 'BRK', jersey: '#942430', trim: '#F3EAD9', shorts: '#1B1F26', libero: '#49AA74', coach: 'Pavel Moravec',   tier: 84 },
          { id: 'fnh', name: 'Fernhill United',  code: 'FNH', jersey: '#236644', trim: '#F2BD4B', shorts: '#102C1E', libero: '#E85A1B', coach: 'Martin Holm',     tier: 83 },
          { id: 'cbt', name: 'Cobalt Docks',     code: 'CBT', jersey: '#1B3052', trim: '#5EBCE0', shorts: '#0B1324', libero: '#DE4953', coach: 'Tomasz Zaleski',  tier: 84 },
          { id: 'och', name: 'Ochre Foundry',    code: 'OCH', jersey: '#BA8D1D', trim: '#13223A', shorts: '#211915', libero: '#185D78', coach: 'Arthur Redfern',  tier: 82 }
        ]
      }
    ];

    // 12-player roster template:
    // Indices 0..5 = starting rotation [P1:S, P2:OH, P3:MB, P4:OPP, P5:OH, P6:MB]
    // Index 6 = Primary Libero (replaces back-row MB automatically)
    // Indices 7..11 = Bench [S2, OH3, MB3, OPP2, L2]
    const ROSTER_TEMPLATE = [
      { pos: 'S',   starter: true,  isLibero: false, biases: { serve: 2, receive: -4, set: 11, attack: -6, block: -2, defence: 3 } },
      { pos: 'OH',  starter: true,  isLibero: false, biases: { serve: 4, receive: 7,  set: -4, attack: 8,  block: 1,  defence: 4 } },
      { pos: 'MB',  starter: true,  isLibero: false, biases: { serve: -1,receive: -9, set: -8, attack: 6,  block: 11, defence: -7 } },
      { pos: 'OPP', starter: true,  isLibero: false, biases: { serve: 7, receive: -5, set: -5, attack: 11, block: 5,  defence: 0 } },
      { pos: 'OH',  starter: true,  isLibero: false, biases: { serve: 3, receive: 8,  set: -4, attack: 6,  block: 0,  defence: 5 } },
      { pos: 'MB',  starter: true,  isLibero: false, biases: { serve: -2,receive: -9, set: -8, attack: 5,  block: 10, defence: -6 } },
      { pos: 'L',   starter: false, isLibero: true,  biases: { serve: -10,receive: 13,set: 2,  attack: -20,block: -20,defence: 14 } },
      { pos: 'S',   starter: false, isLibero: false, biases: { serve: 0, receive: -5, set: 7,  attack: -7, block: -4, defence: 1 } },
      { pos: 'OH',  starter: false, isLibero: false, biases: { serve: 2, receive: 4,  set: -5, attack: 5,  block: -1, defence: 2 } },
      { pos: 'MB',  starter: false, isLibero: false, biases: { serve: -3,receive: -10,set: -9, attack: 3,  block: 8,  defence: -7 } },
      { pos: 'OPP', starter: false, isLibero: false, biases: { serve: 4, receive: -6, set: -6, attack: 7,  block: 2,  defence: -2 } },
      { pos: 'L',   starter: false, isLibero: true,  biases: { serve: -10,receive: 9, set: 0,  attack: -20,block: -20,defence: 10 } }
    ];

    function buildSeededLeagues() {
      const rng = makeRng('LIGHTHOUSE_CUP_MARLOWE_ARENA_SEED_2026');
      const usedNames = new Set();
      return LEAGUE_SPECS.map(spec => {
        const teams = spec.teams.map(tSpec => {
          const jerseyPool = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22];
          for (let i = jerseyPool.length - 1; i > 0; i--) {
            const j = Math.floor(rng() * (i + 1));
            [jerseyPool[i], jerseyPool[j]] = [jerseyPool[j], jerseyPool[i]];
          }
          const players = ROSTER_TEMPLATE.map((tpl, idx) => {
            let full = '';
            let first = '';
            let last = '';
            for (let tries = 0; tries < 40; tries++) {
              first = spec.firstNames[Math.floor(rng() * spec.firstNames.length)];
              last = SURNAMES[Math.floor(rng() * SURNAMES.length)];
              full = `${first} ${last}`;
              if (!usedNames.has(full)) break;
            }
            usedNames.add(full);
            const benchDrop = idx >= 7 ? -4 : 0;
            const rate = (bias) => clamp(Math.round(tSpec.tier + benchDrop + bias + (rng() * 10 - 5)), 52, 97);
            const heightScale =
              tpl.pos === 'MB' ? 1.07 + rng() * 0.04 :
              tpl.pos === 'OPP' ? 1.04 + rng() * 0.04 :
              tpl.pos === 'OH' ? 1.00 + rng() * 0.04 :
              tpl.pos === 'S' ? 0.96 + rng() * 0.04 :
              0.90 + rng() * 0.04;
            return {
              id: `${tSpec.id}_${idx}`,
              number: jerseyPool[idx],
              firstName: first,
              lastName: last,
              name: full,
              shortName: `${first[0]}. ${last}`,
              pos: tpl.pos,
              isLibero: tpl.isLibero,
              starter: tpl.starter,
              heightScale,
              skin: SKIN_TONES[Math.floor(rng() * SKIN_TONES.length)],
              hair: HAIR_TONES[Math.floor(rng() * HAIR_TONES.length)],
              ratings: {
                serve:   rate(tpl.biases.serve),
                receive: rate(tpl.biases.receive),
                set:     rate(tpl.biases.set),
                attack:  rate(tpl.biases.attack),
                block:   rate(tpl.biases.block),
                defence: rate(tpl.biases.defence),
                stamina: clamp(Math.round(80 + rng() * 16), 74, 96)
              }
            };
          });
          return { ...tSpec, players };
        });
        return {
          id: spec.id,
          name: spec.name,
          netHeight: spec.netHeight,
          serveBaseKmh: spec.serveBaseKmh,
          spikeScale: spec.spikeScale,
          teams
        };
      });
    }

    const LEAGUES = buildSeededLeagues();

    // --- Varied Commentary Phrasing Engine ---
    const COMM_TEMPLATES = {
      ace: [
        '{p} rifles a {kmh} km/h serve straight onto the baseline — untouched ace!',
        'Pure placement from {p}! The {kind} serve drops cleanly between passers for an ace.',
        '{p} clips the sideline at {kmh} km/h! Nothing the {opp} back row could do.',
        'Booming ace from {p} — Marlowe Arena erupts as the ball skids off the court.'
      ],
      kill: [
        '{p} climbs above the tape and hammers a {kind} kill to the open floor!',
        'Crisp tempo! {p} threads the seam of the block for a decisive {team} point.',
        '{p} unloads off the {kind} approach — thunderous finish inside the three-metre line!',
        'Smart vision from {p}, painting the deep corner with a clean {kind} winner.',
        'High hands, clean contact — {p} puts it away for {team}!'
      ],
      tip: [
        'Velvet touch by {p}! A disguised tip floats softly behind the leaping blockers.',
        '{p} spots the empty campfire and feathers a cheekily soft dink over the net.',
        'Deception at the antenna — {p} changes pace with a clever roll shot.'
      ],
      block: [
        'ROOFED! {p} shuts the door right on the net tape — monstrous stuff block!',
        'Two-hand brick wall from {p}! The ball drops straight back at the attacker’s feet.',
        'Read like a book! {p} presses over the net and turns the attack straight down.',
        'Denied at the summit — {p} seals the seam for {team}!'
      ],
      serveErr: [
        '{p} pushes the {kind} serve just long past the end line — free point to {opp}.',
        'Into the net cord from {p}; the aggressive serve fails to clear the tape.',
        '{p} misses wide off the service line, handing side-out to {opp}.'
      ],
      attackOut: [
        '{p} swings hard down the line, but the ball sails millimetres wide — out!',
        'Too much heat from {p} — the strike carries past the back boundary.',
        'Line judge raises the flag! {p}’s swing lands just outside the chalk.'
      ],
      netTouch: [
        'Whistle from the stand! {p} clips the top tape on the follow-through — net fault.',
        'Into the mesh! {p} can’t clear the net and {opp} collect the point.'
      ],
      digError: [
        'Valiant diving effort by {p}, but the deflected shot skids away off the platform.',
        '{p} gets a glove to the missile, yet it spins out into the free zone.'
      ]
    };

    function pickCommentary(rng, type, vars) {
      const list = COMM_TEMPLATES[type] || ['Point scored.'];
      let str = list[Math.floor(rng() * list.length)];
      for (const k in vars) {
        str = str.replaceAll(`{${k}}`, vars[k]);
      }
      return str;
    }

// match engine
    const COURT_HALF_X = 9.0;
    const COURT_HALF_Z = 4.5;
    const BALL_RADIUS = 0.105;
    const GRAVITY = 9.81;

    // Base rotational home coordinates (for Team 0, dir=+1, x<0, attacking +X)
    // Slots: 0=P1(RB/Serve), 1=P2(RF), 2=P3(MF), 3=P4(LF), 4=P5(LB), 5=P6(MB)
    const ROT_COORDS = [
      { bx: 6.4, bz:  2.65 }, // P1 right back
      { bx: 1.8, bz:  2.75 }, // P2 right front
      { bx: 1.4, bz:  0.00 }, // P3 middle front
      { bx: 1.8, bz: -2.75 }, // P4 left front
      { bx: 6.4, bz: -2.65 }, // P5 left back
      { bx: 7.2, bz:  0.00 }  // P6 middle back
    ];

    const SERVE_TACTICS = {
      float:      { label: 'Float',      speedMul: 0.90, errProb: 0.052, aceBonus: 0.00, flutter: 0.38, extraG: 0.0,  jump: false, short: false, desc: 'STEADY FLUTTER' },
      jump:       { label: 'Jump',       speedMul: 1.14, errProb: 0.095, aceBonus: 0.032,flutter: 0.06, extraG: 2.2,  jump: true,  short: false, desc: 'HIGH VELOCITY' },
      short:      { label: 'Short',      speedMul: 0.78, errProb: 0.064, aceBonus: 0.014,flutter: 0.24, extraG: 0.4,  jump: false, short: true,  desc: 'DROP FRONT ZONE' },
      aggressive: { label: 'Aggressive', speedMul: 1.22, errProb: 0.132, aceBonus: 0.052,flutter: 0.10, extraG: 2.8,  jump: true,  short: false, desc: 'MAX RISK / LINES' }
    };

    const ATTACK_TACTICS = {
      power: { label: 'Power', speed: 19.2, errProb: 0.075, tip: false, desc: 'HEAVY SWING' },
      tip:   { label: 'Tip',   speed: 9.8,  errProb: 0.035, tip: true,  desc: 'SOFT DINK' },
      line:  { label: 'Line',  speed: 18.4, errProb: 0.092, tip: false, desc: 'SIDELINE SEAM' },
      cross: { label: 'Cross', speed: 18.8, errProb: 0.068, tip: false, desc: 'SHARP ANGLE' },
      quick: { label: 'Quick', speed: 19.8, errProb: 0.082, tip: false, desc: 'FAST MIDDLE' }
    };

    function rotWorldPos(teamIdx, slotIdx, serving) {
      const dir = teamIdx === 0 ? 1 : -1;
      const rc = ROT_COORDS[slotIdx];
      if (serving && slotIdx === 0) {
        return { x: -dir * 9.55, z: dir * 2.35 };
      }
      return { x: -dir * rc.bx, z: dir * rc.bz };
    }

    function cloneStats() {
      return {
        points: 0, aces: 0, kills: 0, blocks: 0, digs: 0, errors: 0,
        serves: 0, serveQSum: 0, receives: 0, receiveQSum: 0
      };
    }

    function cloneTeamStats() {
      return {
        aces: 0, kills: 0, blocks: 0, errors: 0, digs: 0,
        serves: 0, serveQSum: 0, receives: 0, receiveQSum: 0,
        sideOuts: 0, sideOutOpps: 0
      };
    }

    class VolleyballEngine {
      constructor(hooks = {}) {
        this.hooks = hooks; // { onCaption, onSound, onCrowd, onUiDirty, onVideoCheck }
        this.leagueIdx = 0;
        this.teamIdx = [0, 1];
        this.formatKey = 'bo3';
        this.userTeam = 0;
        this.floorKey = 'maple';
        this.matchCounter = 1;
        this.autoNext = false;
        this.paused = false;
        this.speed = 1.0;

        this.bounceGauge = 0.80;
        this.squeakGauge = 0.78;
        this.bouncePulse = 0;
        this.squeakPulse = 0;
        this.netRipple = 0;
        this.crowdExcitement = 0.15;

        this.startNewMatch(0, 0, 1, 'bo3', 0, true);
      }

      get league() { return LEAGUES[this.leagueIdx]; }
      get format() { return FORMATS[this.formatKey]; }
      get floor()  { return FLOOR_TYPES[this.floorKey]; }

      setFloor(key) {
        if (!FLOOR_TYPES[key]) return;
        this.floorKey = key;
        this.bounceGauge = this.floor.bounce;
        this.squeakGauge = this.floor.squeak;
        this.emit('onUiDirty');
      }

      emit(name, payload) {
        if (this.hooks && typeof this.hooks[name] === 'function') {
          this.hooks[name](payload);
        }
      }

      startNewMatch(leagueIdx, t0, t1, formatKey, userTeam, deterministic = false) {
        this.leagueIdx = leagueIdx;
        if (t0 === t1) t1 = (t0 + 1) % LEAGUES[leagueIdx].teams.length;
        this.teamIdx = [t0, t1];
        this.formatKey = formatKey;
        this.userTeam = userTeam;

        const seedStr = `LC_${leagueIdx}_${t0}_${t1}_${formatKey}_${deterministic ? 1 : this.matchCounter++}`;
        this.rng = makeRng(seedStr);

        this.teams = [0, 1].map(ti => {
          const base = this.league.teams[this.teamIdx[ti]];
          const players = base.players.map((p, idx) => ({
            ...p,
            rosterIdx: idx,
            team: ti,
            stamina: 100,
            stats: cloneStats()
          }));
          return {
            ...base,
            team: ti,
            players,
            baseRotation: [0, 1, 2, 3, 4, 5], // P1..P6
            courtRotation: [0, 1, 2, 3, 4, 5],
            liberoIdx: 6,
            liberoOnSlot: -1,
            tactics: { serve: 'float', attack: 'power', block: 'read' },
            aimTarget: null, // { x, z }
            timeoutsLeft: 2,
            subsLeft: 2,
            challengesLeft: 2,
            timeoutQueued: false,
            pendingSub: null,
            momentum: 0,
            streak: 0,
            stats: cloneTeamStats()
          };
        });

        this.setNumber = 1;
        this.setsWon = [0, 0];
        this.setScores = [[0, 0]]; // index = setNumber - 1
        this.points = [0, 0];
        this.firstServerOfSet = this.rng() < 0.5 ? 0 : 1;
        this.servingTeam = this.firstServerOfSet;
        this.winnerTeam = -1;

        this.phase = 'ceremony'; // ceremony | preServe | serveToss | rally | pointEnd | timeout | challenge | setBreak | matchOver
        this.phaseTimer = 5.4;
        this.autoNextTimer = 0;

        this.rally = {
          contacts: 0,
          sideContacts: 0,
          activeSide: 0,
          stage: 'idle', // serve | receive | set | attack | blockRebound | dead
          lastHitter: null,
          lastTouchTeam: 0,
          targetPlayer: null,
          targetPos: { x: 0, y: 0, z: 0 },
          attackKind: 'power',
          serveKind: 'float',
          serveKmh: 0,
          intendedOut: false,
          netFaultPlayer: null,
          blockChecked: false,
          passQuality: 0.75,
          trail: []
        };

        this.ball = {
          x: 0, y: 1.0, z: 0,
          vx: 0, vy: 0, vz: 0,
          rotX: 0, rotZ: 0,
          extraG: 0,
          flutter: 0,
          flutterPhase: 0,
          inAir: false,
          bounces: 0,
          hitNet: false
        };

        // Actors for all 12 court players (6 per team) + benches + officials
        this.actors = [[], []];
        for (let t = 0; t < 2; t++) {
          this.updateLibero(t);
          for (let slot = 0; slot < 6; slot++) {
            const p = this.getSlotPlayer(t, slot);
            const home = rotWorldPos(t, slot, false);
            const dir = t === 0 ? 1 : -1;
            this.actors[t].push({
              team: t,
              slot,
              player: p,
              x: -dir * (3.2 + slot * 0.8),
              y: 0,
              z: 6.2, // start walking out from bench side during ceremony
              tx: home.x,
              tz: home.z,
              vy: 0,
              facing: dir > 0 ? 0 : Math.PI,
              pose: 'run',
              poseTimer: 0,
              blockReachY: 2.8
            });
          }
        }

        this.officials = {
          refSignal: 'idle', // idle | point0 | point1 | out | in | net | timeout
          refTimer: 0,
          lineJudgeFlag: [0, 0, 0, 0] // 0=down, 1=in(down-point), 2=out(up)
        };

        this.closeCall = null; // challengeable point metadata
        this.videoCheck = null; // active animated video check
        this.timeoutInfo = null;
        this.commentary = [];
        this.lastServeDisplay = null;

        this.bounceGauge = this.floor.bounce;
        this.squeakGauge = this.floor.squeak;

        this.addCommentary(
          `Welcome to Marlowe Arena! ${this.teams[0].name} meet ${this.teams[1].name} in the Lighthouse Cup Grand Final (${this.format.label}).`,
          true
        );
        this.addCommentary(
          `Coin toss won by ${this.teams[this.servingTeam].name} — they will serve first in Set 1.`,
          false
        );

        this.emit('onUiDirty');
      }

      getTargetScore() {
        const isDecider = this.format.maxSets > 1 && this.setNumber === this.format.maxSets;
        return isDecider ? this.format.deciderTarget : this.format.regularTarget;
      }

      getSlotPlayer(teamIdx, slotIdx) {
        const t = this.teams[teamIdx];
        return t.players[t.courtRotation[slotIdx]];
      }

      // Apply official back-row Libero replacement for Middle Blockers
      updateLibero(teamIdx) {
        const t = this.teams[teamIdx];
        t.courtRotation = t.baseRotation.slice();
        t.liberoOnSlot = -1;
        // Priority: P6 (5), P5 (4), then P1 (0) if not currently serving
        const backSlots = [5, 4];
        if (this.servingTeam !== teamIdx) backSlots.push(0);
        for (const s of backSlots) {
          const p = t.players[t.baseRotation[s]];
          if (p && p.pos === 'MB') {
            t.courtRotation[s] = t.liberoIdx;
            t.liberoOnSlot = s;
            break;
          }
        }
        if (this.actors && this.actors[teamIdx] && this.actors[teamIdx].length === 6) {
          for (let s = 0; s < 6; s++) {
            this.actors[teamIdx][s].player = this.getSlotPlayer(teamIdx, s);
          }
        }
      }

      rotateTeam(teamIdx) {
        const t = this.teams[teamIdx];
        const r = t.baseRotation;
        t.baseRotation = [r[1], r[2], r[3], r[4], r[5], r[0]];
        this.updateLibero(teamIdx);
      }

      setTactic(teamIdx, category, value) {
        const t = this.teams[teamIdx];
        if (!t) return;
        t.tactics[category] = value;
        this.emit('onUiDirty');
      }

      setAimTarget(teamIdx, x, z) {
        const oppDir = teamIdx === 0 ? 1 : -1;
        const clampedX = oppDir > 0 ? clamp(x, 0.8, 8.7) : clamp(x, -8.7, -0.8);
        const clampedZ = clamp(z, -4.2, 4.2);
        this.teams[teamIdx].aimTarget = { x: clampedX, z: clampedZ };
        this.emit('onUiDirty');
      }

      queueTimeout(teamIdx) {
        const t = this.teams[teamIdx];
        if (!t || t.timeoutsLeft <= 0 || this.phase === 'matchOver') return false;
        if (this.phase === 'preServe' || this.phase === 'pointEnd') {
          this.triggerTimeout(teamIdx);
          return true;
        }
        t.timeoutQueued = true;
        this.addCommentary(`Coach ${t.coach} signals for a ${t.code} timeout at the next dead ball.`, false);
        this.emit('onUiDirty');
        return true;
      }

      triggerTimeout(teamIdx) {
        const t = this.teams[teamIdx];
        if (t.timeoutsLeft <= 0) return;
        t.timeoutsLeft--;
        t.timeoutQueued = false;
        // Momentum brake + stamina breath
        const opp = this.teams[1 - teamIdx];
        opp.momentum = Math.min(opp.momentum, 0);
        opp.streak = 0;
        t.momentum = clamp(t.momentum + 0.35, -1, 1);
        for (const p of t.players) p.stamina = Math.min(100, p.stamina + 6);
        for (const p of opp.players) p.stamina = Math.min(100, p.stamina + 3);

        this.phase = 'timeout';
        this.phaseTimer = 4.2;
        this.timeoutInfo = { team: teamIdx, total: 4.2 };
        this.officials.refSignal = 'timeout';
        this.officials.refTimer = 2.0;
        this.emit('onSound', { type: 'whistle', double: true });
        this.emit('onCaption', { main: 'TIMEOUT', sub: `${t.name.toUpperCase()} HUDDLE` });
        this.addCommentary(`Timeout called by ${t.name} (${t.timeoutsLeft} remaining this set). Momentum reset.`, true);
        // Move players toward their bench side
        for (let ti = 0; ti < 2; ti++) {
          const dir = ti === 0 ? 1 : -1;
          for (let s = 0; s < 6; s++) {
            const a = this.actors[ti][s];
            a.tx = -dir * (3.0 + (s % 3) * 1.4);
            a.tz = 5.4 + Math.floor(s / 3) * 0.9;
            a.pose = 'ready';
          }
        }
        this.emit('onUiDirty');
      }

      applySubstitution(teamIdx, outBaseSlot, inRosterIdx) {
        const t = this.teams[teamIdx];
        if (!t || t.subsLeft <= 0 || this.phase === 'matchOver') return false;
        if (outBaseSlot < 0 || outBaseSlot > 5) return false;
        const inP = t.players[inRosterIdx];
        const outP = t.players[t.baseRotation[outBaseSlot]];
        if (!inP || !outP || inP.isLibero || t.baseRotation.includes(inRosterIdx)) return false;

        if (this.phase === 'rally' || this.phase === 'serveToss') {
          t.pendingSub = { outBaseSlot, inRosterIdx };
          this.addCommentary(`${t.code} prepare substitution: #${inP.number} ${inP.shortName} ready at the sideline.`, false);
          this.emit('onUiDirty');
          return true;
        }
        this.executeSubstitution(teamIdx, outBaseSlot, inRosterIdx);
        return true;
      }

      executeSubstitution(teamIdx, outBaseSlot, inRosterIdx) {
        const t = this.teams[teamIdx];
        if (t.subsLeft <= 0) return;
        const outP = t.players[t.baseRotation[outBaseSlot]];
        const inP = t.players[inRosterIdx];
        t.baseRotation[outBaseSlot] = inRosterIdx;
        t.subsLeft--;
        t.pendingSub = null;
        this.updateLibero(teamIdx);
        this.emit('onSound', { type: 'whistle', double: false });
        this.addCommentary(`Substitution (${t.code}): #${inP.number} ${inP.name} replaces #${outP.number} ${outP.name}.`, true);
        this.emit('onUiDirty');
      }

      skipCeremony() {
        if (this.phase === 'ceremony') {
          this.positionForServe();
          this.phase = 'preServe';
          this.phaseTimer = 0.55;
          this.emit('onSound', { type: 'whistle', double: false });
          this.emit('onUiDirty');
        } else if (this.phase === 'setBreak') {
          this.beginNextSet();
        } else if (this.phase === 'timeout') {
          this.phaseTimer = 0.05;
        }
      }

      triggerChallenge(teamIdx) {
        if (!this.closeCall || this.phase !== 'pointEnd') return false;
        const t = this.teams[teamIdx];
        if (!t || t.challengesLeft <= 0) return false;
        if (this.closeCall.calledWinner === teamIdx) return false;

        this.phase = 'challenge';
        this.phaseTimer = 3.1;
        this.videoCheck = {
          challengingTeam: teamIdx,
          progress: 0,
          duration: 3.1,
          resolved: false,
          ...this.closeCall
        };
        this.closeCall = null;
        this.emit('onSound', { type: 'whistle', double: true });
        this.addCommentary(`VIDEO CHECK! ${t.name} challenge the close line call at Marlowe Arena!`, true);
        this.emit('onVideoCheck', this.videoCheck);
        this.emit('onUiDirty');
        return true;
      }

      addCommentary(text, highlight = false) {
        const stamp = `S${this.setNumber} ${this.points[0]}-${this.points[1]}`;
        this.commentary.unshift({ stamp, text, highlight });
        if (this.commentary.length > 80) this.commentary.length = 80;
      }

      getPointFlag() {
        if (this.phase === 'matchOver') return 'FINAL';
        const target = this.getTargetScore();
        for (let ti = 0; ti < 2; ti++) {
          const opp = 1 - ti;
          if (this.points[ti] >= target - 1 && this.points[ti] >= this.points[opp] + 1) {
            const isMatch = this.setsWon[ti] === this.format.setsToWin - 1;
            return isMatch ? `${this.teams[ti].code} MATCH PT` : `${this.teams[ti].code} SET PT`;
          }
        }
        return '';
      }

      effectiveRating(player, key) {
        const base = player.ratings[key] || 75;
        const fatiguePenalty = (100 - player.stamina) * 0.16;
        const team = this.teams[player.team];
        const momBonus = team.momentum * 3.5;
        return clamp(base - fatiguePenalty + momBonus, 40, 99);
      }

      drainStamina(player, amount) {
        const resist = 0.72 + (100 - player.ratings.stamina) * 0.012;
        player.stamina = clamp(player.stamina - amount * resist, 36, 100);
      }

      // AI Coach adapts tactics, timeouts and subs
      runAiCoach() {
        const ai = 1 - this.userTeam;
        const t = this.teams[ai];
        const opp = this.teams[this.userTeam];

        // Timeout on big deficit streak or late set pressure
        if (t.timeoutsLeft > 0 && !t.timeoutQueued) {
          const behind = this.points[this.userTeam] - this.points[ai];
          if (opp.streak >= 4 || (this.points[this.userTeam] >= this.getTargetScore() - 4 && behind >= 2 && this.rng() < 0.45)) {
            t.timeoutQueued = true;
          }
        }

        // Occasional smart substitution for tired starter
        if (t.subsLeft > 0 && !t.pendingSub && this.points[0] + this.points[1] >= 18) {
          let tiredSlot = -1;
          let minStam = 68;
          for (let s = 0; s < 6; s++) {
            const p = t.players[t.baseRotation[s]];
            if (p.stamina < minStam) { minStam = p.stamina; tiredSlot = s; }
          }
          if (tiredSlot >= 0) {
            const outPos = t.players[t.baseRotation[tiredSlot]].pos;
            const benchMatch = t.players.findIndex((p, idx) => !p.isLibero && !t.baseRotation.includes(idx) && p.pos === outPos);
            if (benchMatch >= 0) {
              this.executeSubstitution(ai, tiredSlot, benchMatch);
            }
          }
        }

        // Dynamic tactical choices
        const sr = this.rng();
        t.tactics.serve = sr < 0.34 ? 'float' : sr < 0.66 ? 'jump' : sr < 0.84 ? 'short' : 'aggressive';
        const ar = this.rng();
        t.tactics.attack = ar < 0.30 ? 'power' : ar < 0.48 ? 'cross' : ar < 0.66 ? 'line' : ar < 0.84 ? 'quick' : 'tip';
        t.tactics.block = this.rng() < 0.62 ? 'read' : 'commit';
      }

      positionForServe() {
        for (let t = 0; t < 2; t++) {
          this.updateLibero(t);
          const dir = t === 0 ? 1 : -1;
          for (let s = 0; s < 6; s++) {
            const a = this.actors[t][s];
            const pos = rotWorldPos(t, s, t === this.servingTeam);
            a.tx = pos.x;
            a.tz = pos.z;
            a.facing = dir > 0 ? 0 : Math.PI;
            a.pose = 'ready';
            a.poseTimer = 0;
          }
        }
        const srvActor = this.actors[this.servingTeam][0];
        const dir = this.servingTeam === 0 ? 1 : -1;
        this.ball.x = srvActor.tx + dir * 0.38;
        this.ball.y = 1.15;
        this.ball.z = srvActor.tz;
        this.ball.vx = this.ball.vy = this.ball.vz = 0;
        this.ball.inAir = false;
        this.ball.bounces = 0;
        this.ball.hitNet = false;
        this.rally.trail = [];
      }

      // Compute ballistic arc from ball current pos to target (tx, ty, tz) in flight time T
      launchBall(tx, ty, tz, flightTime, extraG = 0, flutter = 0) {
        const gEff = GRAVITY + extraG;
        this.ball.vx = (tx - this.ball.x) / flightTime;
        this.ball.vz = (tz - this.ball.z) / flightTime;
        this.ball.vy = (ty - this.ball.y + 0.5 * gEff * flightTime * flightTime) / flightTime;
        this.ball.extraG = extraG;
        this.ball.flutter = flutter;
        this.ball.flutterPhase = this.rng() * Math.PI * 2;
        this.ball.inAir = true;
        this.ball.bounces = 0;
        this.ball.hitNet = false;
        this.rally.stageTime = 0;
      }

      // Predict landing point of ball when descending to targetY
      predictBallAtY(targetY) {
        const gEff = GRAVITY + this.ball.extraG;
        const a = 0.5 * gEff;
        const b = -this.ball.vy;
        const c = targetY - this.ball.y;
        const disc = b * b - 4 * a * c;
        if (disc < 0) return { x: this.ball.x, z: this.ball.z, t: 0.2 };
        const t = Math.max(0.05, (-b + Math.sqrt(disc)) / (2 * a));
        return {
          x: this.ball.x + this.ball.vx * t,
          z: this.ball.z + this.ball.vz * t,
          t
        };
      }

      startServeToss() {
        this.runAiCoach();
        const srv = this.servingTeam;
        const team = this.teams[srv];
        const tactic = SERVE_TACTICS[team.tactics.serve] || SERVE_TACTICS.float;
        const srvActor = this.actors[srv][0];
        const dir = srv === 0 ? 1 : -1;

        this.phase = 'serveToss';
        this.phaseTimer = tactic.jump ? 0.62 : 0.45;
        srvActor.pose = tactic.jump ? 'jumpServe' : 'floatServe';
        srvActor.poseTimer = 0.9;
        if (tactic.jump) srvActor.vy = 4.6;

        // Small upward toss right in front of server
        this.ball.x = srvActor.x + dir * 0.4;
        this.ball.y = 1.45;
        this.ball.z = srvActor.z;
        this.ball.vx = dir * (tactic.jump ? 1.1 : 0.25);
        this.ball.vy = tactic.jump ? 4.4 : 2.9;
        this.ball.vz = 0;
        this.ball.extraG = 0;
        this.ball.flutter = 0;
        this.ball.inAir = true;
        this.emit('onSound', { type: 'whistle', double: false });
      }

      executeServeStrike() {
        const srv = this.servingTeam;
        const rec = 1 - srv;
        const dir = srv === 0 ? 1 : -1;
        const team = this.teams[srv];
        const tactic = SERVE_TACTICS[team.tactics.serve] || SERVE_TACTICS.float;
        const srvActor = this.actors[srv][0];
        const server = srvActor.player;
        const srvRating = this.effectiveRating(server, 'serve');
        this.drainStamina(server, tactic.jump ? 1.3 : 0.8);

        // Determine target in receiving court
        let tx, tz;
        if (team.aimTarget) {
          tx = team.aimTarget.x;
          tz = team.aimTarget.z;
          team.aimTarget = null;
        } else if (tactic.short) {
          tx = dir * (2.6 + this.rng() * 2.2);
          tz = (this.rng() * 2 - 1) * 3.6;
        } else {
          tx = dir * (5.8 + this.rng() * 2.85);
          tz = (this.rng() * 2 - 1) * 4.05;
        }

        // Slight dispersion based on serve skill and risk
        const errProb = clamp(tactic.errProb - (srvRating - 80) * 0.0014, 0.028, 0.18);
        const isError = this.rng() < errProb;
        let hitNetIntended = false;
        let intendedOut = false;

        if (isError) {
          if (this.rng() < 0.42) {
            hitNetIntended = true;
          } else {
            intendedOut = true;
            // Make ~65% of out serves close enough to be dramatic line calls!
            if (this.rng() < 0.6) {
              tx = dir * (9.06 + this.rng() * 0.22);
              tz = clamp(tz, -4.2, 4.2);
            } else {
              tz = (tz >= 0 ? 1 : -1) * (4.56 + this.rng() * 0.24);
              tx = dir * clamp(Math.abs(tx), 4.0, 8.6);
            }
          }
        } else if (this.rng() < 0.22) {
          // Paint the line inside! (close in-call)
          if (this.rng() < 0.5) tx = dir * (8.82 + this.rng() * 0.14);
          else tz = (tz >= 0 ? 1 : -1) * (4.32 + this.rng() * 0.14);
        }

        const strikeY = tactic.jump ? 2.75 : 2.25;
        this.ball.x = srvActor.x + dir * 0.45;
        this.ball.y = strikeY;
        this.ball.z = srvActor.z;

        const dist = Math.hypot(tx - this.ball.x, tz - this.ball.z);
        const rawSpeed = (this.league.serveBaseKmh / 3.6) * tactic.speedMul * (0.92 + (srvRating - 75) * 0.005 + this.rng() * 0.08);
        let flightT = clamp(dist / Math.max(12.5, rawSpeed * 0.78), 0.72, 1.38);

        if (hitNetIntended) {
          // Aim slightly too flat so ball physically smacks the net mesh!
          this.launchBall(tx, 0.05, tz, flightT * 0.72, tactic.extraG + 2.5, 0);
        } else {
          // Ensure legal serve clears the net height cleanly
          const gEff = GRAVITY + tactic.extraG;
          for (let tries = 0; tries < 6; tries++) {
            const vx = (tx - this.ball.x) / flightT;
            const vy = (0.12 - strikeY + 0.5 * gEff * flightT * flightT) / flightT;
            const tNet = (0 - this.ball.x) / vx;
            const yNet = strikeY + vy * tNet - 0.5 * gEff * tNet * tNet;
            if (yNet >= this.league.netHeight + 0.18) break;
            flightT += 0.08;
          }
          this.launchBall(tx, 0.12, tz, flightT, tactic.extraG, tactic.flutter);
        }

        const kmh = Math.round(clamp(Math.hypot(this.ball.vx, this.ball.vy, this.ball.vz) * 3.6 * 1.15, 52, 128));
        const serveQuality = isError ? 0.15 : clamp(0.55 + (kmh - 65) * 0.005 + tactic.aceBonus * 3, 0.3, 1.0);
        server.stats.serves++;
        server.stats.serveQSum += serveQuality;
        team.stats.serves++;
        team.stats.serveQSum += serveQuality;
        this.teams[rec].stats.sideOutOpps++;

        this.phase = 'rally';
        this.rally.contacts = 1;
        this.rally.sideContacts = 0;
        this.rally.activeSide = rec;
        this.rally.stage = 'receive';
        this.rally.lastHitter = server;
        this.rally.lastTouchTeam = srv;
        this.rally.serveKind = tactic.label;
        this.rally.serveKmh = kmh;
        this.rally.intendedOut = intendedOut;
        this.rally.netFaultPlayer = null;
        this.rally.blockChecked = false;
        this.rally.trail = [];

        this.lastServeDisplay = { kmh, kind: tactic.label.toUpperCase(), timer: 3.4 };

        // Assign best defender to sprint to receive spot (unless obviously out!)
        this.assignReceiver(rec, tx, tz, intendedOut, tactic.aceBonus, kmh);

        // Server enters backcourt after striking
        const p1Home = rotWorldPos(srv, 0, false);
        srvActor.tx = p1Home.x;
        srvActor.tz = p1Home.z;

        this.emit('onSound', { type: 'hit', power: tactic.jump ? 0.95 : 0.65 });
        this.emit('onUiDirty');
      }

      assignReceiver(defTeam, tx, tz, intendedOut, aceBonus, kmh) {
        const actors = this.actors[defTeam];
        const dir = defTeam === 0 ? 1 : -1;
        // If serve is visibly well out, smart defenders hold off and let it bounce out
        const outMargin = Math.max(Math.abs(tx) - COURT_HALF_X, Math.abs(tz) - COURT_HALF_Z);
        if (intendedOut && outMargin > 0.04) {
          this.rally.targetPlayer = null;
          this.rally.targetPos = { x: tx, y: 0.12, z: tz };
          return;
        }

        // Pick closest back-row / OH / Libero passer
        let bestActor = actors[5];
        let bestScore = 999;
        for (let s = 0; s < 6; s++) {
          const a = actors[s];
          if (a.player.pos === 'S' && s < 4) continue; // front setter prepares to set
          const d = Math.hypot(a.x - tx, a.z - tz);
          const bonus = a.player.isLibero ? -1.4 : a.player.pos === 'OH' ? -0.6 : 0.6;
          if (d + bonus < bestScore) {
            bestScore = d + bonus;
            bestActor = a;
          }
        }

        // Check spatial ace possibility: high-velocity painted serve vs passer receive rating
        const recSkill = this.effectiveRating(bestActor.player, 'receive');
        const distToPass = Math.hypot(bestActor.x - tx, bestActor.z - tz);
        const aceChance = clamp(
          0.036 + aceBonus + (kmh - 82) * 0.0012 + (distToPass - 2.2) * 0.012 - (recSkill - 80) * 0.0022,
          0.015, 0.14
        );

        const willBeAce = this.rng() < aceChance;
        if (willBeAce) {
          // Passer reads it a fraction late and dives slightly short so the ball physically hits the floor!
          bestActor.tx = tx - (tx - bestActor.x) * 0.42;
          bestActor.tz = tz - (tz - bestActor.z) * 0.42;
          this.rally.targetPlayer = null; // won't reach before floor!
        } else {
          bestActor.tx = tx;
          bestActor.tz = tz;
          this.rally.targetPlayer = bestActor;
        }
        this.rally.targetPos = { x: tx, y: 0.95, z: tz };

        // Setter sprints to setting target near net right-centre
        const setter = this.findSetterActor(defTeam);
        if (setter && setter !== bestActor) {
          setter.tx = -dir * 1.15;
          setter.tz = dir * 1.1;
        }
      }

      findSetterActor(teamIdx) {
        const actors = this.actors[teamIdx];
        let found = actors.find(a => a.player.pos === 'S');
        if (!found) found = actors[1];
        return found;
      }

      handleReceiveOrDig(actor, isServeReceive) {
        const teamIdx = actor.team;
        const dir = teamIdx === 0 ? 1 : -1;
        const player = actor.player;
        const skill = this.effectiveRating(player, isServeReceive ? 'receive' : 'defence');
        this.drainStamina(player, isServeReceive ? 0.7 : 1.1);

        const dist = Math.hypot(actor.x - this.ball.x, actor.z - this.ball.z);
        const isDive = dist > 0.95 || (!isServeReceive && Math.hypot(this.ball.vx, this.ball.vz) > 14.5);
        actor.pose = isDive ? 'dive' : 'dig';
        actor.poseTimer = isDive ? 0.65 : 0.45;
        if (isDive) {
          this.triggerSqueak(0.9);
        }

        const passQuality = clamp(0.45 + (skill - 70) * 0.014 - dist * 0.14 + (this.rng() * 0.24 - 0.10), 0.18, 0.99);
        if (isServeReceive) {
          player.stats.receives++;
          player.stats.receiveQSum += passQuality;
          this.teams[teamIdx].stats.receives++;
          this.teams[teamIdx].stats.receiveQSum += passQuality;
        } else {
          player.stats.digs++;
          this.teams[teamIdx].stats.digs++;
        }

        this.rally.contacts++;
        this.rally.sideContacts = 1;
        this.rally.passQuality = passQuality;
        this.rally.lastHitter = player;
        this.rally.lastTouchTeam = teamIdx;

        // Pick setter (if setter just dug the ball, libero or OH steps in to bump-set)
        let setter = this.findSetterActor(teamIdx);
        if (setter === actor) {
          setter = this.actors[teamIdx].find(a => a !== actor && a.player.isLibero) ||
                   this.actors[teamIdx].find(a => a !== actor);
        }

        // High pass to setter zone
        const setX = -dir * (passQuality > 0.55 ? 1.05 : 2.35 + this.rng() * 1.1);
        const setZ = dir * (0.95 + (this.rng() * 2 - 1) * (1.1 - passQuality * 0.7));
        const setY = 2.32;
        const flightT = clamp(0.88 + (1 - passQuality) * 0.22, 0.80, 1.18);

        this.ball.y = Math.max(this.ball.y, 0.75);
        this.launchBall(setX, setY, setZ, flightT, 0, 0);

        setter.tx = setX;
        setter.tz = setZ;
        this.rally.stage = 'set';
        this.rally.targetPlayer = setter;
        this.rally.targetPos = { x: setX, y: setY, z: setZ };

        // Hitters pull back for approach!
        for (const a of this.actors[teamIdx]) {
          if (a === setter || a === actor) continue;
          if (a.slot >= 1 && a.slot <= 3) {
            a.tx = -dir * 3.1;
          }
        }

        this.emit('onSound', { type: 'hit', power: isDive ? 0.55 : 0.45 });
      }

      handleSet(actor) {
        const teamIdx = actor.team;
        const oppTeam = 1 - teamIdx;
        const dir = teamIdx === 0 ? 1 : -1;
        const team = this.teams[teamIdx];
        const setter = actor.player;
        const setSkill = this.effectiveRating(setter, 'set');
        this.drainStamina(setter, 0.5);

        actor.pose = 'set';
        actor.poseTimer = 0.48;
        actor.vy = 2.1;

        const atkKey = team.tactics.attack;
        // Pick an attacker from front row (slots 1,2,3) or back-row pipe (OH/OPP)
        const candidates = this.actors[teamIdx].filter(a => a !== actor && !a.player.isLibero && a.slot >= 1 && a.slot <= 3);
        let attacker = null;
        if (atkKey === 'quick' && this.rally.passQuality > 0.42) {
          attacker = candidates.find(a => a.player.pos === 'MB') || candidates[0];
        } else if (atkKey === 'line') {
          attacker = candidates.find(a => a.player.pos === 'OH' || a.player.pos === 'OPP') || candidates[0];
        } else {
          // Weighted by attack rating
          const pool = candidates.length ? candidates : this.actors[teamIdx].filter(a => a !== actor && !a.player.isLibero);
          attacker = pool.reduce((best, cur) => {
            const sCur = this.effectiveRating(cur.player, 'attack') + this.rng() * 14;
            const sBest = this.effectiveRating(best.player, 'attack') + this.rng() * 14;
            return sCur > sBest ? cur : best;
          }, pool[0]);
        }

        // Determine strike zone along the net
        const isQuick = atkKey === 'quick' && attacker.player.pos === 'MB';
        const strikeX = -dir * (isQuick ? 0.72 : 0.95);
        const strikeZ = isQuick
          ? dir * (-0.35 + this.rng() * 0.7)
          : attacker.slot === 3 ? -dir * 3.45
          : attacker.slot === 1 ? dir * 3.45
          : dir * (this.rng() < 0.5 ? -2.9 : 2.9);
        const strikeY = this.league.netHeight + (isQuick ? 0.48 : 0.68);
        const setTime = isQuick ? 0.42 : clamp(0.74 - (setSkill - 80) * 0.004, 0.60, 0.84);

        this.launchBall(strikeX, strikeY, strikeZ, setTime, 0, 0);

        attacker.tx = strikeX - dir * 0.35;
        attacker.tz = strikeZ;

        this.rally.contacts++;
        this.rally.sideContacts = 2;
        this.rally.stage = 'attack';
        this.rally.attackKind = atkKey;
        this.rally.lastHitter = setter;
        this.rally.lastTouchTeam = teamIdx;
        this.rally.targetPlayer = attacker;
        this.rally.targetPos = { x: strikeX, y: strikeY, z: strikeZ };

        // Defending blockers react according to Read vs Commit block system!
        const defBlockTactic = this.teams[oppTeam].tactics.block;
        const oppDir = oppTeam === 0 ? 1 : -1;
        const defFront = [this.actors[oppTeam][1], this.actors[oppTeam][2], this.actors[oppTeam][3]];
        for (const b of defFront) {
          const isMiddle = b.slot === 2;
          if (defBlockTactic === 'commit') {
            // Commit strongly toward middle or guessed pin
            b.tx = -oppDir * 0.52;
            b.tz = isMiddle ? strikeZ * 0.85 : clamp(strikeZ + (b.slot === 1 ? -oppDir * 0.65 : oppDir * 0.65), -4.0, 4.0);
          } else {
            // Read block shifts smoothly toward set Z
            b.tx = -oppDir * 0.55;
            if (isMiddle) {
              b.tz = clamp(strikeZ * 0.92, -3.5, 3.5);
            } else {
              const distZ = Math.abs(b.z - strikeZ);
              if (distZ < 3.4) b.tz = clamp(strikeZ + (b.z > strikeZ ? 0.55 : -0.55), -4.1, 4.1);
            }
          }
        }
        // Defending back row spreads into defensive perimeter
        this.actors[oppTeam][4].tx = -oppDir * 6.2; this.actors[oppTeam][4].tz = -oppDir * 2.9;
        this.actors[oppTeam][5].tx = -oppDir * 7.3; this.actors[oppTeam][5].tz = 0;
        this.actors[oppTeam][0].tx = -oppDir * 6.2; this.actors[oppTeam][0].tz = oppDir * 2.9;

        this.emit('onSound', { type: 'hit', power: 0.32 });
      }

      handleAttack(actor) {
        const teamIdx = actor.team;
        const defTeam = 1 - teamIdx;
        const dir = teamIdx === 0 ? 1 : -1;
        const team = this.teams[teamIdx];
        const hitter = actor.player;
        const atkKey = this.rally.attackKind || team.tactics.attack;
        const atkCfg = ATTACK_TACTICS[atkKey] || ATTACK_TACTICS.power;
        const atkSkill = this.effectiveRating(hitter, 'attack');
        this.drainStamina(hitter, 1.5);

        actor.pose = 'spike';
        actor.poseTimer = 0.62;
        actor.vy = 5.0;
        this.triggerSqueak(0.85);

        // Defending blockers jump at the net!
        for (let s = 1; s <= 3; s++) {
          const b = this.actors[defTeam][s];
          if (Math.abs(b.z - this.ball.z) < 2.2) {
            b.pose = 'block';
            b.poseTimer = 0.68;
            b.vy = 4.65;
            b.blockReachY = this.league.netHeight + 0.52 + (b.player.heightScale - 1) * 0.9 + (this.effectiveRating(b.player, 'block') - 80) * 0.008;
          }
        }

        // Determine landing target on opponent's court
        let tx, tz;
        if (team.aimTarget) {
          tx = team.aimTarget.x;
          tz = team.aimTarget.z;
          team.aimTarget = null;
        } else if (atkCfg.tip) {
          tx = dir * (2.2 + this.rng() * 2.2);
          tz = clamp(this.ball.z * 0.5 + (this.rng() * 2 - 1) * 2.1, -3.7, 3.7);
        } else if (atkKey === 'line') {
          tx = dir * (5.6 + this.rng() * 3.1);
          tz = (this.ball.z >= 0 ? 1 : -1) * (3.7 + this.rng() * 0.7);
        } else if (atkKey === 'cross') {
          tx = dir * (4.4 + this.rng() * 3.6);
          tz = (this.ball.z >= 0 ? -1 : 1) * (2.2 + this.rng() * 2.0);
        } else if (atkKey === 'quick') {
          tx = dir * (3.6 + this.rng() * 3.6);
          tz = (this.rng() * 2 - 1) * 3.5;
        } else {
          tx = dir * (4.8 + this.rng() * 3.8);
          tz = (this.rng() * 2 - 1) * 4.0;
        }

        const errProb = clamp(atkCfg.errProb - (atkSkill - 80) * 0.0016 + (1 - this.rally.passQuality) * 0.03, 0.035, 0.14);
        const isError = this.rng() < errProb;
        let hitNet = false;
        let intendedOut = false;

        if (isError) {
          if (this.rng() < 0.36) {
            hitNet = true;
            this.rally.netFaultPlayer = hitter;
          } else {
            intendedOut = true;
            if (this.rng() < 0.55) {
              tz = (tz >= 0 ? 1 : -1) * (4.55 + this.rng() * 0.24);
              tx = dir * clamp(Math.abs(tx), 4.2, 8.6);
            } else {
              tx = dir * (9.05 + this.rng() * 0.24);
              tz = clamp(tz, -4.2, 4.2);
            }
          }
        } else if (this.rng() < 0.24) {
          // Razor-close inside shot!
          if (this.rng() < 0.5) tx = dir * (8.80 + this.rng() * 0.16);
          else tz = (tz >= 0 ? 1 : -1) * (4.30 + this.rng() * 0.16);
        }

        const dist = Math.hypot(tx - this.ball.x, tz - this.ball.z);
        const spd = atkCfg.speed * this.league.spikeScale * (0.93 + (atkSkill - 75) * 0.005);
        let flightT = atkCfg.tip
          ? clamp(dist / 5.8, 0.72, 1.08)
          : clamp(dist / spd, 0.36, 0.78);

        if (hitNet) {
          this.ball.y = this.league.netHeight - 0.15;
          this.launchBall(tx, 0.08, tz, flightT, 2.0, 0);
        } else {
          // Ensure legal attack clears the net
          const extraG = atkCfg.tip ? 0 : 2.6;
          const gEff = GRAVITY + extraG;
          this.ball.y = Math.max(this.ball.y, this.league.netHeight + 0.42);
          for (let i = 0; i < 6; i++) {
            const vx = (tx - this.ball.x) / flightT;
            const vy = (0.12 - this.ball.y + 0.5 * gEff * flightT * flightT) / flightT;
            const tNet = (0 - this.ball.x) / vx;
            const yNet = this.ball.y + vy * tNet - 0.5 * gEff * tNet * tNet;
            if (yNet >= this.league.netHeight + 0.10) break;
            flightT += 0.06;
          }
          this.launchBall(tx, 0.12, tz, flightT, extraG, 0);
        }

        this.rally.contacts++;
        this.rally.sideContacts = 3;
        this.rally.activeSide = defTeam;
        this.rally.stage = 'dig';
        this.rally.lastHitter = hitter;
        this.rally.lastTouchTeam = teamIdx;
        this.rally.intendedOut = intendedOut;
        this.rally.blockChecked = false;

        // Assign defender to attempt dig (probability tuned for ~50% kill / ~34% dig / ~10% block!)
        this.assignDefender(defTeam, tx, tz, intendedOut, atkSkill, atkCfg.tip);

        this.emit('onSound', { type: 'hit', power: atkCfg.tip ? 0.35 : 0.96 });
      }

      assignDefender(defTeam, tx, tz, intendedOut, atkSkill, isTip) {
        const outMargin = Math.max(Math.abs(tx) - COURT_HALF_X, Math.abs(tz) - COURT_HALF_Z);
        if (intendedOut && outMargin > 0.04) {
          this.rally.targetPlayer = null;
          this.rally.targetPos = { x: tx, y: 0.12, z: tz };
          return;
        }

        const actors = this.actors[defTeam];
        let best = actors[5];
        let bestD = 999;
        for (const a of actors) {
          if (a.pose === 'block') continue;
          const d = Math.hypot(a.x - tx, a.z - tz) - (a.player.isLibero ? 1.1 : 0);
          if (d < bestD) { bestD = d; best = a; }
        }

        const defSkill = this.effectiveRating(best.player, 'defence');
        // First-ball attack (serving team defending) is slightly harder to dig than transition counter-attacks
        const isFirstBall = this.rally.contacts <= 4;
        const baseDig = isFirstBall ? 0.36 : 0.45;
        const tipBonus = isTip ? 0.12 : 0;
        const digProb = clamp(
          baseDig + tipBonus + (defSkill - atkSkill) * 0.008 - Math.max(0, bestD - 2.4) * 0.04,
          0.16, 0.68
        );

        if (this.rng() < digProb) {
          best.tx = tx;
          best.tz = tz;
          this.rally.targetPlayer = best;
        } else {
          // Defender dives toward it but comes up short -> physical floor kill!
          best.tx = tx - (tx - best.x) * 0.45;
          best.tz = tz - (tz - best.z) * 0.45;
          best.pose = 'dive';
          best.poseTimer = 0.55;
          this.rally.targetPlayer = null;
        }
        this.rally.targetPos = { x: tx, y: 0.72, z: tz };
      }

      checkBlockerIntercept() {
        if (this.rally.blockChecked || this.rally.stage !== 'dig' || this.ball.hitNet) return;
        const defTeam = this.rally.activeSide;
        const atkTeam = 1 - defTeam;
        const atkDir = atkTeam === 0 ? 1 : -1;
        // Trigger right as ball crosses the net plane
        if (Math.abs(this.ball.x) > 0.55) return;
        this.rally.blockChecked = true;

        const atkCfg = ATTACK_TACTICS[this.rally.attackKind] || ATTACK_TACTICS.power;
        if (atkCfg.tip) return; // tips go over/around the block

        const defBlockTactic = this.teams[defTeam].tactics.block;
        let bestBlocker = null;
        let minZ = 99;
        for (let s = 1; s <= 3; s++) {
          const b = this.actors[defTeam][s];
          const dz = Math.abs(b.z - this.ball.z);
          if (dz < minZ) { minZ = dz; bestBlocker = b; }
        }
        if (!bestBlocker || minZ > 1.65) return;

        const blkSkill = this.effectiveRating(bestBlocker.player, 'block');
        const atkSkill = this.rally.lastHitter ? this.effectiveRating(this.rally.lastHitter, 'attack') : 80;
        const commitBonus = defBlockTactic === 'commit'
          ? (this.rally.attackKind === 'quick' ? 0.07 : -0.02)
          : 0.02;

        const stuffProb = clamp(0.105 + commitBonus + (blkSkill - atkSkill) * 0.0035 - minZ * 0.035, 0.04, 0.22);
        const softTouchProb = 0.16;
        const roll = this.rng();

        if (roll < stuffProb) {
          // STUFF BLOCK! Position cleanly on attacker's side of net tape so it cannot clip back-mesh
          this.ball.x = -atkDir * 0.22;
          this.ball.y = Math.max(this.ball.y, this.league.netHeight + 0.18);
          const landX = -atkDir * (1.2 + this.rng() * 2.4);
          const landZ = clamp(this.ball.z + (this.rng() * 2 - 1) * 1.4, -4.1, 4.1);
          this.launchBall(landX, 0.1, landZ, 0.42, 3.0, 0);
          this.rally.activeSide = atkTeam;
          this.rally.lastHitter = bestBlocker.player;
          this.rally.lastTouchTeam = defTeam;
          this.rally.stage = 'blockRebound';
          this.rally.intendedOut = false;
          this.netRipple = 0.45;
          this.emit('onSound', { type: 'hit', power: 0.92 });

          // Small chance attacker's backcourt covers the block!
          const cover = this.actors[atkTeam][5];
          if (this.rng() < 0.22 && Math.hypot(cover.x - landX, cover.z - landZ) < 4.5) {
            cover.tx = landX;
            cover.tz = landZ;
            this.rally.targetPlayer = cover;
          } else {
            this.rally.targetPlayer = null;
          }
          this.rally.targetPos = { x: landX, y: 0.6, z: landZ };
        } else if (roll < stuffProb + softTouchProb) {
          // SOFT BLOCK TOUCH -> high playable arc cleanly on defender's side
          this.ball.x = atkDir * 0.22;
          this.ball.y = Math.max(this.ball.y, this.league.netHeight + 0.24);
          const defDir = defTeam === 0 ? 1 : -1;
          const landX = -defDir * (4.2 + this.rng() * 2.6);
          const landZ = clamp(this.ball.z + (this.rng() * 2 - 1) * 1.6, -3.9, 3.9);
          this.launchBall(landX, 0.95, landZ, 0.98, 0, 0);
          const libero = this.actors[defTeam].find(a => a.player.isLibero) || this.actors[defTeam][5];
          libero.tx = landX;
          libero.tz = landZ;
          this.rally.targetPlayer = libero;
          this.rally.targetPos = { x: landX, y: 0.95, z: landZ };
          this.rally.intendedOut = false;
          this.emit('onSound', { type: 'hit', power: 0.42 });
        }
      }

      triggerSqueak(intensity) {
        const f = this.floor.squeak;
        this.squeakPulse = Math.min(1, this.squeakPulse + intensity * f * 0.55);
        if (this.rng() < f * 0.75) {
          this.emit('onSound', { type: 'squeak', squeak: f });
        }
      }

      captureSnapshot() {
        return {
          points: this.points.slice(),
          setsWon: this.setsWon.slice(),
          setScores: this.setScores.map(s => s.slice()),
          setNumber: this.setNumber,
          servingTeam: this.servingTeam,
          teams: this.teams.map(t => ({
            baseRotation: t.baseRotation.slice(),
            momentum: t.momentum,
            streak: t.streak,
            stats: { ...t.stats },
            playerStats: t.players.map(p => ({ ...p.stats }))
          }))
        };
      }

      restoreSnapshot(snap) {
        this.points = snap.points.slice();
        this.setsWon = snap.setsWon.slice();
        this.setScores = snap.setScores.map(s => s.slice());
        this.setNumber = snap.setNumber;
        this.servingTeam = snap.servingTeam;
        for (let ti = 0; ti < 2; ti++) {
          const t = this.teams[ti];
          const st = snap.teams[ti];
          t.baseRotation = st.baseRotation.slice();
          t.momentum = st.momentum;
          t.streak = st.streak;
          t.stats = { ...st.stats };
          for (let pi = 0; pi < t.players.length; pi++) {
            t.players[pi].stats = { ...st.playerStats[pi] };
          }
          this.updateLibero(ti);
        }
      }

      resolveFloorPoint(landX, landZ, forcedReason = null) {
        const LINE_TOL = 0.03;
        const lastTeam = this.rally.lastTouchTeam;
        const oppTeam = 1 - lastTeam;
        const oppSideMatch = (oppTeam === 0 && landX < 0) || (oppTeam === 1 && landX > 0);
        const trueIn = oppSideMatch && Math.abs(landX) <= COURT_HALF_X + LINE_TOL && Math.abs(landZ) <= COURT_HALF_Z + LINE_TOL;

        // Detect close boundary call only when the other axis is within bounds
        const distEnd = Math.abs(Math.abs(landX) - (COURT_HALF_X + LINE_TOL));
        const distSide = Math.abs(Math.abs(landZ) - (COURT_HALF_Z + LINE_TOL));
        const nearEnd = distEnd < 0.28 && Math.abs(landZ) <= COURT_HALF_Z + LINE_TOL;
        const nearSide = distSide < 0.28 && Math.abs(landX) <= COURT_HALF_X + LINE_TOL;
        const isCloseCall = !forcedReason && !this.ball.hitNet && oppSideMatch && (nearEnd || nearSide);
        const lineType = (nearEnd && (!nearSide || distEnd <= distSide)) ? 'ENDLINE' : 'SIDELINE';
        const minLineDist = lineType === 'ENDLINE' ? distEnd : distSide;

        let calledIn = trueIn;
        if (isCloseCall && minLineDist < 0.17 && this.rng() < 0.36) {
          // Human line judge misreads a razor-close ball!
          calledIn = !trueIn;
        }

        const snapshot = this.captureSnapshot();

        let reason, winner;
        if (forcedReason === 'net') {
          reason = this.rally.contacts <= 1 ? 'serveErr' : 'netTouch';
          winner = oppTeam;
        } else if (!oppSideMatch) {
          reason = this.rally.contacts <= 1 ? 'serveErr' : (this.rally.stage === 'set' || this.rally.stage === 'attack') ? 'digError' : 'netTouch';
          winner = oppTeam;
        } else if (calledIn) {
          winner = lastTeam;
          if (this.rally.contacts <= 1) reason = 'ace';
          else if (this.rally.stage === 'blockRebound') reason = 'block';
          else if (this.rally.attackKind === 'tip') reason = 'tip';
          else reason = 'kill';
        } else {
          winner = oppTeam;
          reason = this.rally.contacts <= 1 ? 'serveErr' : 'attackOut';
        }

        // Save challenge opportunity if close call went against user & user has challenges
        this.closeCall = null;
        if (isCloseCall && winner !== this.userTeam && this.teams[this.userTeam].challengesLeft > 0) {
          this.closeCall = {
            snapshot,
            landX,
            landZ,
            trueIn,
            calledIn,
            calledWinner: winner,
            lastTeam,
            oppTeam,
            lineType,
            lineTol: LINE_TOL,
            wasBlockRebound: this.rally.stage === 'blockRebound',
            contacts: this.rally.contacts,
            attackKind: this.rally.attackKind,
            lastHitter: this.rally.lastHitter,
            serveKind: this.rally.serveKind,
            serveKmh: this.rally.serveKmh,
            trail: this.rally.trail.slice(-14),
            timeLeft: 4.2,
            totalTime: 4.2
          };
        }

        this.awardPoint(winner, reason, this.rally.lastHitter, {
          serveKind: this.rally.serveKind,
          serveKmh: this.rally.serveKmh,
          attackKind: this.rally.attackKind,
          isCloseCall: Boolean(this.closeCall)
        });
      }

      awardPoint(winner, reason, hitter, meta = {}) {
        const loser = 1 - winner;
        const winTeam = this.teams[winner];
        const loseTeam = this.teams[loser];

        // Track statistics
        if (reason === 'ace') {
          winTeam.stats.aces++;
          if (hitter) { hitter.stats.aces++; hitter.stats.points++; }
        } else if (reason === 'kill' || reason === 'tip') {
          winTeam.stats.kills++;
          if (hitter) { hitter.stats.kills++; hitter.stats.points++; }
        } else if (reason === 'block') {
          winTeam.stats.blocks++;
          if (hitter) { hitter.stats.blocks++; hitter.stats.points++; }
        } else {
          loseTeam.stats.errors++;
          if (hitter) hitter.stats.errors++;
        }

        // Side-out rotation check
        const wasSideOut = winner !== this.servingTeam;
        if (wasSideOut) {
          winTeam.stats.sideOuts++;
          this.servingTeam = winner;
          this.rotateTeam(winner);
        } else {
          this.updateLibero(0);
          this.updateLibero(1);
        }

        this.points[winner]++;
        this.setScores[this.setNumber - 1] = this.points.slice();

        // Momentum & streaks
        winTeam.streak++;
        loseTeam.streak = 0;
        winTeam.momentum = clamp(winTeam.momentum + 0.18, -1, 1);
        loseTeam.momentum = clamp(loseTeam.momentum - 0.14, -1, 1);

        // Player celebrations & reactions
        for (let s = 0; s < 6; s++) {
          this.actors[winner][s].pose = 'celebrate';
          this.actors[winner][s].poseTimer = 1.4;
          this.actors[loser][s].pose = 'dejected';
          this.actors[loser][s].poseTimer = 1.4;
        }

        // Officials signals
        this.officials.refSignal = winner === 0 ? 'point0' : 'point1';
        this.officials.refTimer = 1.5;
        const isOut = reason === 'attackOut' || reason === 'serveErr';
        this.officials.lineJudgeFlag = this.officials.lineJudgeFlag.map(() => isOut ? 2 : 1);

        // Crowd excitement & audio
        const bigRally = this.rally.contacts >= 7;
        const crowdAmt = (reason === 'ace' || reason === 'block' || bigRally) ? 0.95 : 0.6;
        this.crowdExcitement = Math.min(1, Math.max(this.crowdExcitement, crowdAmt));
        this.emit('onSound', { type: 'whistle', double: false });
        this.emit('onSound', { type: 'crowd', intensity: crowdAmt });

        // Event caption & commentary
        const target = this.getTargetScore();
        const setWon = this.points[winner] >= target && (this.points[winner] - this.points[loser]) >= 2;
        const flag = this.getPointFlag();

        const capMap = {
          ace:       { main: 'ACE!', sub: `${hitter ? hitter.shortName.toUpperCase() : winTeam.code} · ${meta.serveKmh || 88} KM/H` },
          kill:      { main: 'KILL!', sub: `${hitter ? hitter.shortName.toUpperCase() : winTeam.code} · ${winTeam.code}` },
          tip:       { main: 'SOFT TIP!', sub: `${hitter ? hitter.shortName.toUpperCase() : winTeam.code} FINDS OPEN FLOOR` },
          block:     { main: 'STUFF BLOCK!', sub: `${hitter ? hitter.shortName.toUpperCase() : winTeam.code} SHUTS IT DOWN` },
          serveErr:  { main: 'SERVE ERROR', sub: `POINT ${winTeam.code}` },
          attackOut: { main: 'OUT BALL', sub: `POINT ${winTeam.code}` },
          netTouch:  { main: 'NET FAULT', sub: `POINT ${winTeam.code}` }
        };

        let caption = capMap[reason] || { main: `POINT ${winTeam.code}`, sub: '' };
        if (setWon) {
          const matchWillEnd = this.setsWon[winner] + 1 >= this.format.setsToWin;
          caption = matchWillEnd
            ? { main: `${winTeam.code} CHAMPIONS!`, sub: `LIGHTHOUSE CUP GRAND FINAL` }
            : { main: `SET ${this.setNumber} · ${winTeam.code}`, sub: `${this.points[0]} — ${this.points[1]}` };
        } else if (flag && !meta.suppressFlag) {
          caption = { main: flag, sub: `${caption.main} · ${this.points[0]}–${this.points[1]}` };
        }

        if (!meta.suppressCaption) {
          this.emit('onCaption', caption);
        }

        const commText = pickCommentary(this.rng, reason, {
          p: hitter ? hitter.name : winTeam.code,
          team: winTeam.name,
          opp: loseTeam.name,
          kmh: meta.serveKmh || 85,
          kind: (reason === 'ace' || reason === 'serveErr') ? (meta.serveKind || 'float').toLowerCase() : (meta.attackKind || 'power')
        });
        this.addCommentary(
          commText + (bigRally ? ` (${this.rally.contacts}-contact rally!)` : ''),
          reason === 'ace' || reason === 'block' || bigRally || setWon
        );

        // Hold slightly longer when user can challenge a close line call
        this.phase = 'pointEnd';
        this.phaseTimer = meta.isCloseCall ? 4.2 : (setWon ? 2.4 : 1.35);
        this.rally.stage = 'dead';
        this.emit('onUiDirty');
      }

      finishSetOrAdvance() {
        const target = this.getTargetScore();
        for (let ti = 0; ti < 2; ti++) {
          const opp = 1 - ti;
          if (this.points[ti] >= target && this.points[ti] - this.points[opp] >= 2) {
            this.setsWon[ti]++;
            this.emit('onSound', { type: 'whistle', double: true });
            this.emit('onSound', { type: 'crowd', intensity: 1.0 });

            if (this.setsWon[ti] >= this.format.setsToWin) {
              this.winnerTeam = ti;
              this.phase = 'matchOver';
              this.autoNextTimer = 6.5;
              this.addCommentary(
                `MATCH OVER! ${this.teams[ti].name} lift the Lighthouse Cup (${this.setsWon[0]}–${this.setsWon[1]})!`,
                true
              );
              this.emit('onUiDirty');
              return;
            } else {
              this.phase = 'setBreak';
              this.phaseTimer = 4.0;
              this.addCommentary(
                `Set ${this.setNumber} goes to ${this.teams[ti].name} (${this.points[0]}–${this.points[1]}). Short break before Set ${this.setNumber + 1}.`,
                true
              );
              // Move to benches during set break
              for (let k = 0; k < 2; k++) {
                const dir = k === 0 ? 1 : -1;
                for (let s = 0; s < 6; s++) {
                  this.actors[k][s].tx = -dir * (3.0 + (s % 3) * 1.4);
                  this.actors[k][s].tz = 5.5 + Math.floor(s / 3) * 0.8;
                }
              }
              this.emit('onUiDirty');
              return;
            }
          }
        }

        // Apply any queued substitution or timeout at dead ball
        for (let ti = 0; ti < 2; ti++) {
          if (this.teams[ti].pendingSub) {
            const sub = this.teams[ti].pendingSub;
            this.executeSubstitution(ti, sub.outBaseSlot, sub.inRosterIdx);
          }
        }
        for (let ti = 0; ti < 2; ti++) {
          if (this.teams[ti].timeoutQueued && this.teams[ti].timeoutsLeft > 0) {
            this.triggerTimeout(ti);
            return;
          }
        }

        this.positionForServe();
        this.phase = 'preServe';
        this.phaseTimer = 0.88;
        this.emit('onUiDirty');
      }

      beginNextSet() {
        this.setNumber++;
        this.points = [0, 0];
        this.setScores.push([0, 0]);
        this.firstServerOfSet = 1 - this.firstServerOfSet;
        this.servingTeam = this.firstServerOfSet;
        for (const t of this.teams) {
          t.timeoutsLeft = 2;
          t.subsLeft = 2;
          t.challengesLeft = 2;
          t.timeoutQueued = false;
          t.pendingSub = null;
          t.streak = 0;
          t.momentum *= 0.35;
          for (const p of t.players) p.stamina = Math.min(100, p.stamina + 14);
        }
        this.positionForServe();
        this.phase = 'preServe';
        this.phaseTimer = 1.0;
        this.emit('onCaption', { main: `SET ${this.setNumber}`, sub: `TARGET ${this.getTargetScore()} POINTS` });
        this.addCommentary(`Set ${this.setNumber} begins! ${this.teams[this.servingTeam].name} to serve.`, true);
        this.emit('onUiDirty');
      }

      resolveVideoCheck() {
        const vc = this.videoCheck;
        if (!vc || vc.resolved) return;
        vc.resolved = true;
        const overturned = vc.trueIn !== vc.calledIn;
        const chTeam = this.teams[vc.challengingTeam];

        this.emit('onSound', { type: 'challenge', overturned });

        if (overturned) {
          // Restore pre-point snapshot and award to rightful winner!
          this.restoreSnapshot(vc.snapshot);
          const trueWinner = vc.trueIn ? vc.lastTeam : vc.oppTeam;
          const trueReason = vc.trueIn
            ? (vc.contacts <= 1 ? 'ace' : vc.wasBlockRebound ? 'block' : vc.attackKind === 'tip' ? 'tip' : 'kill')
            : (vc.contacts <= 1 ? 'serveErr' : 'attackOut');

          this.addCommentary(
            `CALL OVERTURNED! Video Check proves the ball was ${vc.trueIn ? 'IN' : 'OUT'}! ${chTeam.code} retain their challenge.`,
            true
          );
          this.awardPoint(trueWinner, trueReason, vc.lastHitter, {
            serveKind: vc.serveKind,
            serveKmh: vc.serveKmh,
            attackKind: vc.attackKind,
            suppressCaption: true,
            isCloseCall: false
          });
          // Stay in challenge overlay briefly to show verdict, then pointEnd
          this.phase = 'challenge';
          this.phaseTimer = 0.95;
        } else {
          chTeam.challengesLeft = Math.max(0, chTeam.challengesLeft - 1);
          this.addCommentary(
            `CALL STANDS! Video Check confirms ${vc.trueIn ? 'IN' : 'OUT'}. ${chTeam.code} lose a challenge (${chTeam.challengesLeft} left).`,
            true
          );
          this.phase = 'challenge';
          this.phaseTimer = 0.95;
        }
        this.emit('onUiDirty');
      }

      step(rawDt) {
        if (this.paused) return;
        const dt = Math.min(rawDt, 0.05) * this.speed;

        // Decay arena feedback values
        this.netRipple = Math.max(0, this.netRipple - dt * 1.8);
        this.crowdExcitement = Math.max(0.14, this.crowdExcitement - dt * 0.25);
        this.bouncePulse = Math.max(0, this.bouncePulse - dt * 1.4);
        this.squeakPulse = Math.max(0, this.squeakPulse - dt * 1.3);
        this.bounceGauge = clamp(this.floor.bounce * 0.72 + this.bouncePulse * 0.42, 0.1, 1.0);
        this.squeakGauge = clamp(this.floor.squeak * 0.72 + this.squeakPulse * 0.44, 0.1, 1.0);

        if (this.lastServeDisplay && this.lastServeDisplay.timer > 0) {
          this.lastServeDisplay.timer -= dt;
        }
        if (this.officials.refTimer > 0) {
          this.officials.refTimer -= dt;
          if (this.officials.refTimer <= 0) {
            this.officials.refSignal = 'idle';
            this.officials.lineJudgeFlag = [0, 0, 0, 0];
          }
        }

        // Update player motion & jump kinematics
        this.updateActors(dt);

        // Phase state machine
        if (this.phase === 'ceremony') {
          this.phaseTimer -= dt;
          if (this.phaseTimer < 3.5) {
            // Walk onto court line positions
            for (let t = 0; t < 2; t++) {
              const dir = t === 0 ? 1 : -1;
              for (let s = 0; s < 6; s++) {
                const home = rotWorldPos(t, s, t === this.servingTeam);
                this.actors[t][s].tx = this.phaseTimer > 1.7 ? -dir * 3.0 : home.x;
                this.actors[t][s].tz = this.phaseTimer > 1.7 ? -3.0 + s * 1.2 : home.z;
              }
            }
          }
          if (this.phaseTimer <= 0) {
            this.positionForServe();
            this.phase = 'preServe';
            this.phaseTimer = 0.8;
            this.emit('onCaption', { main: 'SET 1', sub: `${this.teams[this.servingTeam].code} TO SERVE` });
            this.emit('onUiDirty');
          }
          return;
        }

        if (this.phase === 'preServe') {
          this.phaseTimer -= dt;
          const srvActor = this.actors[this.servingTeam][0];
          const dir = this.servingTeam === 0 ? 1 : -1;
          this.ball.x = srvActor.x + dir * 0.36;
          this.ball.y = 1.12 + Math.abs(Math.sin(this.phaseTimer * 7)) * 0.18;
          this.ball.z = srvActor.z;
          if (this.phaseTimer <= 0) {
            this.startServeToss();
          }
          return;
        }

        if (this.phase === 'serveToss') {
          this.stepBallSub(dt, false);
          this.phaseTimer -= dt;
          if (this.phaseTimer <= 0) {
            this.executeServeStrike();
          }
          return;
        }

        if (this.phase === 'rally') {
          this.stepBallSub(dt, true);
          return;
        }

        if (this.phase === 'pointEnd') {
          if (this.ball.inAir) this.stepBallSub(dt, false);
          if (this.closeCall) {
            this.closeCall.timeLeft = Math.max(0, this.closeCall.timeLeft - dt);
            if (this.closeCall.timeLeft <= 0) this.closeCall = null;
          }
          this.phaseTimer -= dt;
          if (this.phaseTimer <= 0) {
            this.closeCall = null;
            this.finishSetOrAdvance();
          }
          return;
        }

        if (this.phase === 'timeout') {
          this.phaseTimer -= dt;
          if (this.phaseTimer <= 0) {
            this.timeoutInfo = null;
            this.positionForServe();
            this.phase = 'preServe';
            this.phaseTimer = 0.85;
            this.emit('onUiDirty');
          }
          return;
        }

        if (this.phase === 'challenge') {
          if (this.videoCheck) {
            this.videoCheck.progress = Math.min(1, this.videoCheck.progress + dt / 2.15);
            if (!this.videoCheck.resolved && this.videoCheck.progress >= 1) {
              this.resolveVideoCheck();
            }
          }
          this.phaseTimer -= dt;
          if (this.phaseTimer <= 0) {
            this.videoCheck = null;
            this.emit('onVideoCheck', null);
            this.finishSetOrAdvance();
          }
          return;
        }

        if (this.phase === 'setBreak') {
          this.phaseTimer -= dt;
          if (this.phaseTimer <= 0) {
            this.beginNextSet();
          }
          return;
        }

        if (this.phase === 'matchOver') {
          if (this.autoNext) {
            this.autoNextTimer -= dt;
            if (this.autoNextTimer <= 0) {
              const count = this.league.teams.length;
              const next0 = (this.teamIdx[0] + 1) % count;
              const next1 = (this.teamIdx[1] + 2) % count;
              this.startNewMatch(this.leagueIdx, next0, next1 === next0 ? (next0 + 1) % count : next1, this.formatKey, this.userTeam, false);
            }
          }
        }
      }

      updateActors(dt) {
        const floorSpeed = this.floor.speedMod;
        for (let t = 0; t < 2; t++) {
          const dir = t === 0 ? 1 : -1;
          for (let s = 0; s < 6; s++) {
            const a = this.actors[t][s];
            // Vertical jump physics
            if (a.y > 0 || a.vy > 0) {
              a.vy -= GRAVITY * 1.35 * dt;
              a.y += a.vy * dt;
              if (a.y <= 0) { a.y = 0; a.vy = 0; }
            }

            // Horizontal sprinting (extra burst when actively chasing assigned contact)
            const dx = a.tx - a.x;
            const dz = a.tz - a.z;
            const dist = Math.hypot(dx, dz);
            const isTarget = this.phase === 'rally' && this.rally.targetPlayer === a;
            const maxSpd = (5.5 + (a.player.ratings.defence - 75) * 0.04) * (isTarget ? 1.32 : 1.0) * floorSpeed * (0.86 + a.player.stamina * 0.0014);
            if (dist > 0.05) {
              const stepD = Math.min(dist, maxSpd * dt);
              a.x += (dx / dist) * stepD;
              a.z += (dz / dist) * stepD;
              if (a.poseTimer <= 0) a.pose = 'run';
              if (dist > 1.8 && this.rng() < dt * 1.2 && this.phase === 'rally') {
                this.triggerSqueak(0.42);
              }
            } else if (a.poseTimer <= 0 && a.pose === 'run') {
              a.pose = 'ready';
            }

            // Facing smoothly toward net or ball
            const targetAngle = (this.phase === 'rally')
              ? Math.atan2(-(this.ball.z - a.z), this.ball.x - a.x)
              : (dir > 0 ? 0 : Math.PI);
            let diff = targetAngle - a.facing;
            while (diff > Math.PI) diff -= Math.PI * 2;
            while (diff < -Math.PI) diff += Math.PI * 2;
            a.facing += diff * Math.min(1, dt * 10);

            if (a.poseTimer > 0) {
              a.poseTimer -= dt;
              if (a.poseTimer <= 0 && this.phase === 'rally') {
                a.pose = 'ready';
              }
            }
          }
        }
      }

      stepBallSub(dt, activeRally) {
        const steps = Math.max(1, Math.ceil(dt / 0.01));
        const sdt = dt / steps;
        for (let i = 0; i < steps; i++) {
          if (!this.ball.inAir) break;
          const prevX = this.ball.x;
          const gEff = GRAVITY + this.ball.extraG;

          this.ball.vy -= gEff * sdt;
          if (this.ball.flutter > 0) {
            this.ball.flutterPhase += sdt * 16;
            this.ball.vz += Math.sin(this.ball.flutterPhase) * this.ball.flutter * sdt * 6.0;
          }
          this.ball.x += this.ball.vx * sdt;
          this.ball.y += this.ball.vy * sdt;
          this.ball.z += this.ball.vz * sdt;
          this.ball.rotX += this.ball.vz * sdt * 4.2;
          this.ball.rotZ -= this.ball.vx * sdt * 4.2;

          if (activeRally && i === 0) {
            this.rally.trail.push({ x: this.ball.x, y: this.ball.y, z: this.ball.z });
            if (this.rally.trail.length > 26) this.rally.trail.shift();
          }

          // Net crossing collision
          if ((prevX < 0 && this.ball.x >= 0) || (prevX > 0 && this.ball.x <= 0)) {
            const netH = this.league.netHeight;
            if (Math.abs(this.ball.z) <= COURT_HALF_Z + 0.15) {
              if (this.ball.y < netH - 0.05) {
                this.ball.x = prevX;
                this.ball.vx *= -0.22;
                this.ball.vy = Math.min(this.ball.vy * 0.25, 0.5);
                this.ball.vz *= 0.45;
                this.ball.hitNet = true;
                this.netRipple = 1.0;
                this.emit('onSound', { type: 'bounce', intensity: 0.65, bounce: 0.4 });
                if (activeRally) {
                  this.rally.targetPlayer = null;
                }
              } else if (this.ball.y < netH + 0.06) {
                // Clips top tape and dribbles over!
                this.ball.vx *= 0.84;
                this.netRipple = 0.55;
              }
            }
          }

          if (activeRally && this.phase === 'rally') {
            this.rally.stageTime = (this.rally.stageTime || 0) + sdt;
            // Check blocker interception near net
            this.checkBlockerIntercept();

            // Check assigned target player contact
            const tp = this.rally.targetPlayer;
            if (tp && !this.ball.hitNet) {
              const distXZ = Math.hypot(tp.x - this.ball.x, tp.z - this.ball.z);
              if (this.rally.stage === 'receive' || this.rally.stage === 'dig' || this.rally.stage === 'blockRebound') {
                if (this.ball.vy < 0 && this.ball.y <= 1.32 && this.ball.y >= 0.24 && distXZ <= 2.25) {
                  const isServe = this.rally.stage === 'receive';
                  this.handleReceiveOrDig(tp, isServe);
                  break;
                }
              } else if (this.rally.stage === 'set') {
                if (this.rally.stageTime > 0.28 && this.ball.vy < 0 && this.ball.y <= 2.55 && this.ball.y >= 0.95 && distXZ <= 2.45) {
                  this.handleSet(tp);
                  break;
                }
              } else if (this.rally.stage === 'attack') {
                const strikeH = this.rally.targetPos.y;
                if (this.rally.stageTime > 0.20 && this.ball.y <= strikeH + 0.22 && this.ball.y >= 1.75 && this.ball.vy < 1.3 && distXZ <= 2.35) {
                  this.handleAttack(tp);
                  break;
                }
              }
            }
          }

          // Floor bounce!
          if (this.ball.y <= BALL_RADIUS) {
            const impactSpeed = Math.abs(this.ball.vy);
            this.ball.y = BALL_RADIUS;
            this.ball.vy = impactSpeed * this.floor.bounce;
            this.ball.vx *= 0.78;
            this.ball.vz *= 0.78;
            this.ball.bounces++;
            this.bouncePulse = Math.min(1, this.bouncePulse + clamp(impactSpeed / 12, 0.25, 1.0) * this.floor.bounce);
            this.emit('onSound', { type: 'bounce', intensity: clamp(impactSpeed / 11, 0.2, 1.0), bounce: this.floor.bounce });

            if (activeRally && this.phase === 'rally') {
              this.resolveFloorPoint(this.ball.x, this.ball.z, this.ball.hitNet ? 'net' : null);
              break;
            }
            if (this.ball.vy < 0.6) {
              this.ball.vy = 0;
              this.ball.vx *= 0.6;
              this.ball.vz *= 0.6;
              if (Math.hypot(this.ball.vx, this.ball.vz) < 0.2) this.ball.inAir = false;
            }
          }
        }
      }
    }

