# INTEGRATION

Needs `makeRng`/`hashSeed`, `clamp` (see the dither pack, section 1). The engine emits events (onCaption etc.) the original UI listens to; names and commentary in this extract are the original English text. A Korean version of the same game with translated strings is at https://github.com/sigco3111/lighthouse-cup-ko.
