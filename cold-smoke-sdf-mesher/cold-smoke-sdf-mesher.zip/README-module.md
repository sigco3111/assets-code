# 06_sdfmesh.js — SDF → 삼각형 메쉬

Cold Smoke에서 스키어·나무·동물 같은 입체를 코드로 모델링해 메쉬화하는 모듈입니다. 외부 의존·게임 전역 참조가 없는 순수 수학 코드입니다.

## 정의하는 전역 (스크립트 스코프)
- `sd` — 부호거리함수(SDF) 라이브러리: sphere, ellipsoid, capsule(테이퍼), rbox, smin, smax 등. 비교문 기반 고속 구현.
- `meshSDF(f, bmin, bmax, cell, opt)` — 내로우밴드 서피스넷 메셔. SDF 함수 f와 경계상자·셀 크기를 받아 표면 메쉬를 만듭니다.
- `meshBuilder()` — 파라메트릭 지오메트리(스키·폴처럼 얇아 그리드에 안 맞는 것)를 붙이는 빌더: vert/quad/tri/sweep/merge/done.

## 반환 형식
`meshSDF`는 `{ verts, idx, nv, ni }`를 반환합니다. verts는 정점당 float 10개(위치 3 + 법선 3 + 속성 4), idx는 Uint32 삼각형 인덱스입니다.

## 사용 예 (Node)
원본 파일은 bare 전역을 정의하므로 단독 스크립트로 쓸 때는 자체 스코프로 감싸거나 번들에 연결하세요.

    // 예: 눈사람 = 구 3개 스무스 블렌드 + 캡슐 모자
    const f = (x,y,z) => {
      let d = sd.sphere(x,y,z, 0,0.28,0, 0.28);
      d = sd.smin(d, sd.sphere(x,y,z, 0,0.68,0, 0.20), 0.08);
      d = sd.smin(d, sd.sphere(x,y,z, 0,0.98,0, 0.14), 0.06);
      return Math.min(d, sd.capsule(x,y,z, 0,1.08,0, 0,1.30,0, 0.12,0.02));
    };
    const m = meshSDF(f, [-0.45,0,-0.45], [0.45,1.4,0.45], 0.012);
