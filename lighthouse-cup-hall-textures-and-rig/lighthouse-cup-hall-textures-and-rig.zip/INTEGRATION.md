# INTEGRATION

Needs THREE r128 (global), a `makeRng`/`hashSeed` PRNG (see the dither pack, section 1) and a `clamp` helper. Textures are canvas-generated (THREE.CanvasTexture). `createRiggedPerson(opts)` returns a rig object; `poseRig(rig,pose,time)` animates it.
