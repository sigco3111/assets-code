// Extracted from Lighthouse Cup index.html (original English build, commit d147523)
// https://github.com/itsLucas02/lighthouse-cup
// MIT License, Copyright (c) 2026 Aizzul Luqman. See LICENSE.txt.
// Excerpt from a single-file game: reference or light adaptation, not a drop-in package.
// court surfaces
    // --- Court Surface Definitions ---
    const FLOOR_TYPES = {
      maple: {
        key: 'maple', label: 'Maple',
        bounce: 0.80, squeak: 0.78, speedMod: 1.00,
        courtBase: '#DAA973', courtAlt: '#C9955E', freeZone: '#185D78', lineColor: '#FCF9F2', attackColor: '#E85A1B',
        style: 'planks'
      },
      taraflex: {
        key: 'taraflex', label: 'Taraflex',
        bounce: 0.72, squeak: 0.92, speedMod: 0.97,
        courtBase: '#E87A3C', courtAlt: '#DF7034', freeZone: '#1B4E84', lineColor: '#FCF9F2', attackColor: '#FCF9F2',
        style: 'matte'
      },
      parquet: {
        key: 'parquet', label: 'Parquet',
        bounce: 0.86, squeak: 0.68, speedMod: 1.03,
        courtBase: '#C4915E', courtAlt: '#A87648', freeZone: '#236644', lineColor: '#FCF9F2', attackColor: '#E85A1B',
        style: 'parquet'
      },
      rubber: {
        key: 'rubber', label: 'Rubber',
        bounce: 0.66, squeak: 0.44, speedMod: 0.94,
        courtBase: '#2F7D6C', courtAlt: '#297061', freeZone: '#1B3052', lineColor: '#F3EAD9', attackColor: '#F5D24E',
        style: 'speckle'
      }
    };
    const FLOOR_ORDER = ['maple', 'taraflex', 'parquet', 'rubber'];

// light presets
    const LIGHT_PRESETS = {
      day: {
        skyTop:     [0.29, 0.54, 0.84],
        skyMid:     [0.64, 0.80, 0.94],
        skyBot:     [0.95, 0.89, 0.78],
        sunDir:     [0.55, 0.65, -0.52],
        sunIntensity: 1.15,
        sunColor:   [1.00, 0.96, 0.88],
        hemiSky:    [0.82, 0.90, 1.00],
        hemiGnd:    [0.64, 0.52, 0.38],
        hemiInt:    0.76,
        columnsOn:  0.0,
        spotInt:    0.0,
        beamOp:     0.0,
        stars:      0.0
      },
      evening: {
        skyTop:     [0.10, 0.14, 0.28],
        skyMid:     [0.48, 0.33, 0.45],
        skyBot:     [0.91, 0.56, 0.42],
        sunDir:     [-0.62, 0.26, -0.74],
        sunIntensity: 0.42,
        sunColor:   [1.00, 0.65, 0.45],
        hemiSky:    [0.42, 0.46, 0.68],
        hemiGnd:    [0.24, 0.20, 0.24],
        hemiInt:    0.42,
        columnsOn:  1.0,
        spotInt:    1.15,
        beamOp:     0.09,
        stars:      0.35
      },
      show: {
        skyTop:     [0.03, 0.05, 0.11],
        skyMid:     [0.08, 0.12, 0.24],
        skyBot:     [0.18, 0.15, 0.32],
        sunDir:     [0.20, 0.88, 0.40],
        sunIntensity: 0.22,
        sunColor:   [0.62, 0.76, 1.00],
        hemiSky:    [0.22, 0.28, 0.48],
        hemiGnd:    [0.12, 0.10, 0.18],
        hemiInt:    0.32,
        columnsOn:  1.0,
        spotInt:    1.72,
        beamOp:     0.17,
        stars:      0.95
      }
    };


// canvas textures, rigged person + pose animation
    function makeFloorTexture(floorCfg) {
      const c = document.createElement('canvas');
      c.width = 1024;
      c.height = 640;
      const g = c.getContext('2d');

      // Free zone background (24m x 15m mapped across 1024 x 640)
      const pxPerM_X = c.width / 24;
      const pxPerM_Z = c.height / 15;
      const wx = (m) => (m + 12) * pxPerM_X;
      const wz = (m) => (m + 7.5) * pxPerM_Z;

      g.fillStyle = floorCfg.freeZone;
      g.fillRect(0, 0, c.width, c.height);

      // Subtle free-zone border framing
      g.strokeStyle = 'rgba(255,255,255,0.14)';
      g.lineWidth = 3;
      g.strokeRect(10, 10, c.width - 20, c.height - 20);

      // Playing Court 18 x 9m (x: -9..9, z: -4.5..4.5)
      const cx0 = wx(-9), cz0 = wz(-4.5), cw = 18 * pxPerM_X, ch = 9 * pxPerM_Z;
      g.save();
      g.beginPath();
      g.rect(cx0, cz0, cw, ch);
      g.clip();

      g.fillStyle = floorCfg.courtBase;
      g.fillRect(cx0, cz0, cw, ch);

      const rng = makeRng('FLOOR_' + floorCfg.key);
      if (floorCfg.style === 'planks') {
        const rows = 32;
        const rh = ch / rows;
        for (let r = 0; r < rows; r++) {
          let x = cx0 - rng() * 60;
          while (x < cx0 + cw) {
            const pw = 55 + rng() * 95;
            g.fillStyle = rng() < 0.46 ? floorCfg.courtAlt : floorCfg.courtBase;
            g.fillRect(x, cz0 + r * rh, pw - 1, rh - 1);
            x += pw;
          }
        }
      } else if (floorCfg.style === 'parquet') {
        const tile = 24;
        for (let y = cz0; y < cz0 + ch; y += tile) {
          for (let x = cx0; x < cx0 + cw; x += tile) {
            const alt = ((Math.floor((x - cx0) / tile) + Math.floor((y - cz0) / tile)) % 2) === 0;
            g.fillStyle = alt ? floorCfg.courtBase : floorCfg.courtAlt;
            g.fillRect(x, y, tile - 1, tile - 1);
          }
        }
      } else if (floorCfg.style === 'speckle') {
        for (let i = 0; i < 1600; i++) {
          g.fillStyle = rng() < 0.5 ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.12)';
          g.fillRect(cx0 + rng() * cw, cz0 + rng() * ch, 3, 3);
        }
      } else {
        // Taraflex subtle matte front-zone tint
        g.fillStyle = floorCfg.courtAlt;
        g.fillRect(wx(-3), cz0, 6 * pxPerM_X, ch);
      }
      g.restore();

      // Court Lines (5cm official lines)
      g.strokeStyle = floorCfg.lineColor;
      g.lineWidth = 4.5;
      g.strokeRect(cx0, cz0, cw, ch);

      // Centre line under net
      g.beginPath();
      g.moveTo(wx(0), cz0);
      g.lineTo(wx(0), cz0 + ch);
      g.stroke();

      // Attack lines at x = ±3m
      g.strokeStyle = floorCfg.attackColor;
      g.lineWidth = 4.5;
      for (const ax of [-3, 3]) {
        g.beginPath();
        g.moveTo(wx(ax), cz0);
        g.lineTo(wx(ax), cz0 + ch);
        g.stroke();
        // Dashed 1.75m attack-line extensions outside court
        g.save();
        g.setLineDash([7, 7]);
        g.lineWidth = 3.5;
        g.beginPath();
        g.moveTo(wx(ax), wz(-4.5)); g.lineTo(wx(ax), wz(-6.2));
        g.moveTo(wx(ax), wz(4.5));  g.lineTo(wx(ax), wz(6.2));
        g.stroke();
        g.restore();
      }

      // Service zone ticks
      g.strokeStyle = floorCfg.lineColor;
      g.lineWidth = 3.5;
      for (const sx of [-9.35, 9.35]) {
        for (const sz of [-4.5, 4.5]) {
          g.beginPath();
          g.moveTo(wx(sx), wz(sz));
          g.lineTo(wx(sx + (sx < 0 ? -0.3 : 0.3)), wz(sz));
          g.stroke();
        }
      }

      // Apron text
      g.fillStyle = 'rgba(250, 245, 235, 0.72)';
      g.font = '800 22px "Barlow Condensed", sans-serif';
      g.textAlign = 'center';
      g.fillText('LIGHTHOUSE CUP  ·  MARLOWE ARENA', wx(0), wz(6.15));
      g.fillText('GRAND FINAL', wx(0), wz(-5.75));

      const tex = new THREE.CanvasTexture(c);
      tex.minFilter = THREE.NearestFilter;
      tex.magFilter = THREE.NearestFilter;
      tex.needsUpdate = true;
      return tex;
    }

    function makeNetTexture() {
      const c = document.createElement('canvas');
      c.width = 512;
      c.height = 128;
      const g = c.getContext('2d');
      g.clearRect(0, 0, 512, 128);
      // Mesh grid
      g.strokeStyle = 'rgba(20, 30, 48, 0.88)';
      g.lineWidth = 2.5;
      for (let x = 0; x <= 512; x += 12) {
        g.beginPath(); g.moveTo(x, 12); g.lineTo(x, 118); g.stroke();
      }
      for (let y = 12; y <= 118; y += 12) {
        g.beginPath(); g.moveTo(0, y); g.lineTo(512, y); g.stroke();
      }
      // Top white tape + orange accent stripe
      g.fillStyle = '#FCF9F2';
      g.fillRect(0, 0, 512, 13);
      g.fillStyle = '#E85A1B';
      g.fillRect(0, 11, 512, 3);
      // Bottom tape
      g.fillStyle = '#FCF9F2';
      g.fillRect(0, 118, 512, 10);

      const tex = new THREE.CanvasTexture(c);
      tex.minFilter = THREE.NearestFilter;
      tex.magFilter = THREE.NearestFilter;
      return tex;
    }

    function makeSponsorTexture(sp) {
      const c = document.createElement('canvas');
      c.width = 256;
      c.height = 64;
      const g = c.getContext('2d');
      g.fillStyle = sp.bg;
      g.fillRect(0, 0, 256, 64);
      g.fillStyle = sp.accent;
      g.fillRect(0, 0, 12, 64);
      g.fillRect(244, 0, 12, 64);
      g.fillRect(12, 56, 232, 8);
      g.fillStyle = sp.fg;
      g.font = '800 26px "Barlow Condensed", sans-serif';
      g.textAlign = 'center';
      g.textBaseline = 'middle';
      g.fillText(sp.name, 128, 30);
      const tex = new THREE.CanvasTexture(c);
      tex.minFilter = THREE.NearestFilter;
      tex.magFilter = THREE.NearestFilter;
      return tex;
    }

    function makeVolleyballTexture() {
      const c = document.createElement('canvas');
      c.width = 128;
      c.height = 64;
      const g = c.getContext('2d');
      g.fillStyle = '#F5D24E';
      g.fillRect(0, 0, 128, 64);
      // Iconic blue & orange/cream panels
      g.fillStyle = '#185D78';
      g.fillRect(0, 0, 44, 32);
      g.fillRect(64, 32, 44, 32);
      g.fillStyle = '#E85A1B';
      g.fillRect(44, 0, 20, 64);
      g.fillRect(108, 0, 20, 64);
      g.strokeStyle = '#13223A';
      g.lineWidth = 3;
      g.beginPath();
      g.moveTo(0, 32); g.lineTo(128, 32);
      g.moveTo(44, 0); g.lineTo(44, 64);
      g.moveTo(64, 0); g.lineTo(64, 64);
      g.moveTo(108, 0); g.lineTo(108, 64);
      g.stroke();
      const tex = new THREE.CanvasTexture(c);
      tex.minFilter = THREE.NearestFilter;
      tex.magFilter = THREE.NearestFilter;
      return tex;
    }

    // Build blocky rigged 3D character (players, officials, coaches)
    function createRiggedPerson(opts) {
      const root = new THREE.Group();
      const bodyPivot = new THREE.Group();
      root.add(bodyPivot);

      const matJersey = new THREE.MeshLambertMaterial({ color: opts.jersey || '#13223A' });
      const matTrim   = new THREE.MeshLambertMaterial({ color: opts.trim   || '#E85A1B' });
      const matShorts = new THREE.MeshLambertMaterial({ color: opts.shorts || '#0B1324' });
      const matSkin   = new THREE.MeshLambertMaterial({ color: opts.skin   || '#E8BE9D' });
      const matHair   = new THREE.MeshLambertMaterial({ color: opts.hair   || '#211915' });
      const matShoe   = new THREE.MeshLambertMaterial({ color: '#FCF9F2' });

      // Hips / Shorts
      const hips = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.24, 0.42), matShorts);
      hips.position.y = 0.88;
      hips.castShadow = true;
      bodyPivot.add(hips);

      // Torso
      const torsoGroup = new THREE.Group();
      torsoGroup.position.set(0, 0.98, 0);
      bodyPivot.add(torsoGroup);

      const torso = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.54, 0.44), matJersey);
      torso.position.y = 0.27;
      torso.castShadow = true;
      torsoGroup.add(torso);

      // Jersey stripe / trim
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.355, 0.11, 0.455), matTrim);
      stripe.position.y = 0.36;
      torsoGroup.add(stripe);

      // Head + Hair
      const headGroup = new THREE.Group();
      headGroup.position.set(0, 0.58, 0);
      torsoGroup.add(headGroup);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.29, 0.30, 0.29), matSkin);
      head.position.y = 0.16;
      head.castShadow = true;
      headGroup.add(head);

      const hair = new THREE.Mesh(new THREE.BoxGeometry(0.31, 0.13, 0.31), matHair);
      hair.position.set(-0.02, 0.28, 0);
      headGroup.add(hair);

      // Left & Right Arms (hanging along -Y from shoulders at z = ±0.28)
      const makeArm = (zSign) => {
        const pivot = new THREE.Group();
        pivot.position.set(0, 0.49, zSign * 0.29);
        const sleeve = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.18, 0.14), matJersey);
        sleeve.position.y = -0.09;
        pivot.add(sleeve);
        const arm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.46, 0.12), matSkin);
        arm.position.y = -0.36;
        arm.castShadow = true;
        pivot.add(arm);
        torsoGroup.add(pivot);
        return pivot;
      };
      const leftArm = makeArm(-1);
      const rightArm = makeArm(1);

      // Left & Right Legs
      const makeLeg = (zSign) => {
        const pivot = new THREE.Group();
        pivot.position.set(0, 0.80, zSign * 0.12);
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.68, 0.15), matSkin);
        leg.position.y = -0.34;
        leg.castShadow = true;
        pivot.add(leg);
        const pad = new THREE.Mesh(new THREE.BoxGeometry(0.165, 0.14, 0.165), matShorts);
        pad.position.y = -0.36;
        pivot.add(pad);
        const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.13, 0.16), matShoe);
        shoe.position.set(0.04, -0.73, 0);
        shoe.castShadow = true;
        pivot.add(shoe);
        bodyPivot.add(pivot);
        return pivot;
      };
      const leftLeg = makeLeg(-1);
      const rightLeg = makeLeg(1);

      // Optional held flag (for line judges) or clipboard (for coaches)
      let prop = null;
      if (opts.hasFlag) {
        prop = new THREE.Group();
        const stick = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.55, 0.03), new THREE.MeshLambertMaterial({ color: '#FCF9F2' }));
        stick.position.y = -0.25;
        const cloth = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.24, 0.03), new THREE.MeshLambertMaterial({ color: '#E85A1B' }));
        cloth.position.set(0.14, -0.42, 0);
        prop.add(stick, cloth);
        prop.position.set(0.04, -0.56, 0);
        rightArm.add(prop);
      } else if (opts.hasClipboard) {
        prop = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.03, 0.20), new THREE.MeshLambertMaterial({ color: '#DAA973' }));
        prop.position.set(0.14, -0.45, 0);
        leftArm.add(prop);
      }

      return {
        root, bodyPivot, torsoGroup, headGroup, leftArm, rightArm, leftLeg, rightLeg,
        mats: { jersey: matJersey, trim: matTrim, shorts: matShorts, skin: matSkin, hair: matHair },
        prop
      };
    }

    function poseRig(rig, pose, time, seedOffset = 0) {
      const bp = rig.bodyPivot;
      const tg = rig.torsoGroup;
      const la = rig.leftArm;
      const ra = rig.rightArm;
      const ll = rig.leftLeg;
      const rl = rig.rightLeg;

      // Reset transforms (character faces +X, arms/legs swing around Z axis!)
      bp.position.set(0, 0, 0);
      bp.rotation.set(0, 0, 0);
      tg.rotation.set(0, 0, 0);
      rig.headGroup.rotation.set(0, 0, 0);
      la.rotation.set(0, 0, 0);
      ra.rotation.set(0, 0, 0);
      ll.rotation.set(0, 0, 0);
      rl.rotation.set(0, 0, 0);

      const t = time + seedOffset;

      switch (pose) {
        case 'ready': {
          const bob = Math.sin(t * 4.5) * 0.03;
          bp.position.y = -0.08 + bob;
          tg.rotation.z = -0.26;
          la.rotation.z = 0.72; la.rotation.x = 0.25;
          ra.rotation.z = 0.72; ra.rotation.x = -0.25;
          ll.rotation.z = 0.24; rl.rotation.z = -0.24;
          break;
        }
        case 'run': {
          const sw = Math.sin(t * 14);
          bp.position.y = Math.abs(sw) * 0.07;
          tg.rotation.z = -0.22;
          ll.rotation.z = sw * 0.65;
          rl.rotation.z = -sw * 0.65;
          la.rotation.z = -sw * 0.7;
          ra.rotation.z = sw * 0.7;
          break;
        }
        case 'jumpServe': {
          tg.rotation.z = 0.20;
          la.rotation.z = 2.2;
          ra.rotation.z = 2.85 + Math.sin(t * 18) * 0.35;
          ll.rotation.z = -0.38; rl.rotation.z = 0.28;
          break;
        }
        case 'floatServe': {
          tg.rotation.z = -0.10;
          la.rotation.z = 1.25;
          ra.rotation.z = 2.45;
          ll.rotation.z = 0.32; rl.rotation.z = -0.28;
          break;
        }
        case 'spike': {
          tg.rotation.z = -0.18;
          tg.rotation.y = 0.25;
          la.rotation.z = 0.75;
          ra.rotation.z = 2.75;
          ll.rotation.z = -0.45; rl.rotation.z = -0.25;
          break;
        }
        case 'block': {
          tg.rotation.z = -0.06;
          la.rotation.z = 3.02; la.rotation.x = 0.08;
          ra.rotation.z = 3.02; ra.rotation.x = -0.08;
          ll.rotation.z = 0.05; rl.rotation.z = -0.05;
          break;
        }
        case 'dig': {
          bp.position.y = -0.24;
          tg.rotation.z = -0.56;
          la.rotation.z = 1.38; la.rotation.x = 0.38;
          ra.rotation.z = 1.38; ra.rotation.x = -0.38;
          ll.rotation.z = 0.48; rl.rotation.z = -0.45;
          break;
        }
        case 'set': {
          bp.position.y = -0.06;
          tg.rotation.z = 0.08;
          la.rotation.z = 2.55; la.rotation.x = 0.35;
          ra.rotation.z = 2.55; ra.rotation.x = -0.35;
          break;
        }
        case 'dive': {
          bp.position.y = -0.46;
          bp.rotation.z = -1.24;
          la.rotation.z = 2.95;
          ra.rotation.z = 2.95;
          ll.rotation.z = -0.18; rl.rotation.z = 0.14;
          break;
        }
        case 'celebrate': {
          const hop = Math.abs(Math.sin(t * 9.5)) * 0.26;
          bp.position.y = hop;
          la.rotation.z = 2.85; la.rotation.x = -0.35;
          ra.rotation.z = 2.85; ra.rotation.x = 0.35;
          break;
        }
        case 'dejected': {
          bp.position.y = -0.10;
          tg.rotation.z = -0.38;
          rig.headGroup.rotation.z = -0.35;
          la.rotation.z = 0.22; ra.rotation.z = 0.22;
          break;
        }
        case 'seated': {
          bp.position.y = -0.30;
          ll.rotation.z = 1.45; rl.rotation.z = 1.45;
          la.rotation.z = 0.35; ra.rotation.z = 0.35;
          break;
        }
        default:
          break;
      }
    }

