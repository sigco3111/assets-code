# kervan-asset-forge

Kervan의 절차적 3D 모델 생성 파이프라인(assets/src)입니다. headless Blender로 도시 랜드마크 7종, 시장,
카라반사라이, 낙타, 라이더 GLB를 코드로 만듭니다.

- `_kv.py`: 공통 키트(재질·파츠·익스포트 유틸). 나머지 `<모델명>.py`가 모델별 빌더입니다.
- `slim_glb.py`: 생성된 GLB 용량 최적화.
- `build.ps1`, `textures.ps1`: Windows PowerShell 빌드 드라이버(전체 빌드, 텍스처 합성).
- 실행 예: `blender --background --python src/camel.py` (Blender 4.x, 별도 의존성 없음).

라이선스: MIT (Copyright (c) 2026 Furkiozknn) — LICENSE.txt 참조.
