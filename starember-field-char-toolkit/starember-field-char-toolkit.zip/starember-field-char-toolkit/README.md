# Starember Field Procedural Character Toolkit (별잿빛 들판 절차적 캐릭터 도구)

Generic procedural anime-style character building machinery extracted from
gamedemo_by_Fable5.2 (星烬原野), MIT. Code-only; no images, no company logos,
no specific character designs.

- src/char/geo.ts: geometry primitives (lathe parts, strands, tubes, skirts, heads, bows, loft/skinning)
- src/char/parts.ts: body part library (hair, limbs, clothing pieces, proportions P0)
- src/char/rig.ts: joints + spring bones
- src/char/builder.ts: model assembly (decals via caller-supplied draw callbacks, materials, outlines)
- src/char/anim.ts: procedural animation poses/clips
- src/char/face.ts: canvas-drawn expression face textures
- src/render/toon.ts, src/render/geoutil.ts, src/core/math.ts: required helpers

Deps: three ^0.187 + three/addons (RoundedBoxGeometry). TypeScript.

Excluded on purpose (rights): src/char/roster.ts (the 8 specific AI-company
character assemblies, modeled after ZipZipPipe's design sheets) and
src/char/logos.ts (company emblems). Build your own characters with the parts
library instead of reproducing those designs.
