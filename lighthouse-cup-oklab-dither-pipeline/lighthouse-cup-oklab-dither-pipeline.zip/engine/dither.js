// Extracted from Lighthouse Cup index.html (original English build, commit d147523)
// https://github.com/itsLucas02/lighthouse-cup
// MIT License, Copyright (c) 2026 Aizzul Luqman. See LICENSE.txt.
// Excerpt from a single-file game: reference or light adaptation, not a drop-in package.
// 1) seeded PRNG + fixed 90-colour palette + sRGB->OKLab
    function hashSeed(str) {
      let h = 2166136261 >>> 0;
      for (let i = 0; i < str.length; i++) {
        h ^= str.charCodeAt(i);
        h = Math.imul(h, 16777619);
      }
      return h >>> 0;
    }

    function makeRng(seed) {
      let a = (typeof seed === 'string' ? hashSeed(seed) : seed) >>> 0;
      return function rng() {
        a |= 0;
        a = (a + 0x6D2B79F5) | 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };
    }

    const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
    const lerp = (a, b, t) => a + (b - a) * t;

    // --- Fixed 90-Colour Sports-Hall Palette (strictly 90 entries) ---
    const PALETTE_HEX = [
      // Deep navy & dark shadow ramp (10)
      '#060A14','#0B1324','#13223A','#1B3052','#26426E','#35588A','#4B72A6','#6B92C2','#97B6DB','#CBDCEF',
      // Warm maple, paper & cream ramp (10)
      '#4A311D','#66452A','#845B38','#A47449','#C4915E','#DAA973','#E8C28E','#F0D7AC','#F3EAD9','#FCF9F2',
      // Signal orange, terracotta & amber (10)
      '#5E1E09','#872D0D','#B33E12','#D84D16','#E85A1B','#F77532','#FF9452','#FFB67A','#D4881F','#F2BD4B',
      // Taraflex / court blues & teals (9)
      '#0B2A38','#104154','#185D78','#227DA0','#359DC2','#5EBCE0','#124F49','#1F7A6F','#45A899',
      // Forest, emerald & turf greens (8)
      '#102C1E','#194730','#236644','#2F885A','#49AA74','#75C794','#A6DCAC','#D2EED0',
      // Crimson, coral & burgundy kits (8)
      '#421017','#691923','#942430','#BD313E','#DE4953','#EF7278','#F6A4A8','#6B274C',
      // Gold, ochre & volleyball yellow (7)
      '#5C430E','#8A6614','#BA8D1D','#DFB22C','#F5D24E','#FAE78C','#8E6F2D',
      // Violet, plum & arena show spotlights (6)
      '#24143D','#3D2266','#5C3894','#8059BD','#A884DE','#D4B9F5',
      // Concrete, architectural neutral grays & rafters (8)
      '#1B1F26','#2E343E','#464F5C','#636E7D','#848F9E','#A7B0BD','#C9D0D9','#E5E9EF',
      // Skin & hair tones (10)
      '#3B2418','#593622','#784B31','#9A6444','#BA815C','#D49F7A','#E8BE9D','#F4D6BC','#211915','#6B4B2E',
      // Evening & dusk sky tints (4)
      '#E89578','#C96A72','#7A568C','#495E91'
    ];

    // sRGB [0..1] -> OKLab [L, a, b]
    function srgbToLinear(c) {
      return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }

    function hexToRgb01(hex) {
      const n = parseInt(hex.slice(1), 16);
      return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
    }

    function rgb01ToOklab(r, g, b) {
      const lr = srgbToLinear(r), lg = srgbToLinear(g), lb = srgbToLinear(b);
      const l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb);
      const m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb);
      const s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb);
      return [
        0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
        1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
        0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s
      ];
    }

    const PALETTE_RGB = PALETTE_HEX.map(hexToRgb01);
    const PALETTE_OKLAB = PALETTE_RGB.map(([r, g, b]) => rgb01ToOklab(r, g, b));

// 2) palette / Bayer matrix data textures
    function createPaletteTextures() {
      const rgbData = new Uint8Array(90 * 4);
      const labData = new Uint8Array(90 * 4);
      for (let i = 0; i < 90; i++) {
        const [r, g, b] = PALETTE_RGB[i];
        rgbData[i * 4 + 0] = Math.round(r * 255);
        rgbData[i * 4 + 1] = Math.round(g * 255);
        rgbData[i * 4 + 2] = Math.round(b * 255);
        rgbData[i * 4 + 3] = 255;

        const [L, a, lb] = PALETTE_OKLAB[i];
        labData[i * 4 + 0] = clamp(Math.round(L * 255), 0, 255);
        labData[i * 4 + 1] = clamp(Math.round(((a / 0.8) + 0.5) * 255), 0, 255);
        labData[i * 4 + 2] = clamp(Math.round(((lb / 0.8) + 0.5) * 255), 0, 255);
        labData[i * 4 + 3] = 255;
      }
      const mk = (arr, w, h, wrap) => {
        const tex = new THREE.DataTexture(arr, w, h, THREE.RGBAFormat);
        tex.minFilter = THREE.NearestFilter;
        tex.magFilter = THREE.NearestFilter;
        tex.wrapS = wrap;
        tex.wrapT = wrap;
        tex.needsUpdate = true;
        return tex;
      };
      // 4x4 Bayer ordered dither matrix
      const bayerVals = [
         0,  8,  2, 10,
        12,  4, 14,  6,
         3, 11,  1,  9,
        15,  7, 13,  5
      ];
      const bData = new Uint8Array(16 * 4);
      for (let i = 0; i < 16; i++) {
        const v = Math.round(((bayerVals[i] + 0.5) / 16) * 255);
        bData[i * 4 + 0] = v;
        bData[i * 4 + 1] = v;
        bData[i * 4 + 2] = v;
        bData[i * 4 + 3] = 255;
      }
      return {
        rgbTex: mk(rgbData, 90, 1, THREE.ClampToEdgeWrapping),
        labTex: mk(labData, 90, 1, THREE.ClampToEdgeWrapping),
        bayerTex: mk(bData, 4, 4, THREE.RepeatWrapping)
      };
    }

    // Build dynamic Court + Free Zone CanvasTexture

// 3) procedural sky shader + low-res render target + OKLab nearest-palette post pass (methods buildSkyAndPostProcess and createLowResTarget of ArenaRenderer, wrapped in a stub class)
class ArenaRendererPostProcess {
      buildSkyAndPostProcess() {
        // Procedural Sky Scene rendered behind the floating island diorama
        this.skyScene = new THREE.Scene();
        this.skyCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        this.skyUniforms = {
          uTop:   { value: new THREE.Vector3(...LIGHT_PRESETS.day.skyTop) },
          uMid:   { value: new THREE.Vector3(...LIGHT_PRESETS.day.skyMid) },
          uBot:   { value: new THREE.Vector3(...LIGHT_PRESETS.day.skyBot) },
          uStars: { value: 0.0 },
          uTime:  { value: 0.0 },
          uYaw:   { value: 0.58 }
        };
        const skyMat = new THREE.ShaderMaterial({
          depthWrite: false,
          depthTest: false,
          uniforms: this.skyUniforms,
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = vec4(position.xy, 0.0, 1.0);
            }
          `,
          fragmentShader: `
            precision highp float;
            varying vec2 vUv;
            uniform vec3 uTop;
            uniform vec3 uMid;
            uniform vec3 uBot;
            uniform float uStars;
            uniform float uTime;
            uniform float uYaw;

            float hash21(vec2 p) {
              p = fract(p * vec2(123.34, 456.21));
              p += dot(p, p + 45.32);
              return fract(p.x * p.y);
            }

            void main() {
              float h = clamp(vUv.y, 0.0, 1.0);
              vec3 col = mix(uBot, uMid, smoothstep(0.0, 0.48, h));
              col = mix(col, uTop, smoothstep(0.45, 0.96, h));

              // Soft scrolling horizon cloud bands visible through hall windows
              float cx = vUv.x * 5.0 + uYaw * 0.6 + uTime * 0.015;
              float band = sin(cx * 2.1) * 0.5 + sin(cx * 4.7 + 1.3) * 0.25;
              float cloudMask = smoothstep(0.28, 0.42, h) * (1.0 - smoothstep(0.56, 0.78, h));
              float cloud = smoothstep(0.18, 0.65, band + 0.35) * cloudMask * (1.0 - uStars * 0.75);
              col = mix(col, vec3(0.97, 0.94, 0.89), cloud * 0.28);

              // Subtle coastal stars in Evening & Show modes
              if (uStars > 0.02 && h > 0.32) {
                vec2 cell = floor((vUv + vec2(uYaw * 0.08, 0.0)) * vec2(140.0, 80.0));
                float rnd = hash21(cell);
                if (rnd > 0.986) {
                  float tw = 0.65 + 0.35 * sin(uTime * 3.0 + rnd * 60.0);
                  col += vec3(0.95, 0.92, 0.82) * uStars * tw * smoothstep(0.32, 0.6, h);
                }
              }

              // Distant Marlowe Lighthouse sweep beam in Show/Evening sky
              if (uStars > 0.15) {
                float sweep = fract(uTime * 0.08);
                float bx = abs(vUv.x - sweep);
                float beam = smoothstep(0.14, 0.0, bx) * smoothstep(0.18, 0.55, h) * (1.0 - smoothstep(0.58, 0.92, h));
                col += vec3(0.96, 0.78, 0.48) * beam * uStars * 0.12;
              }

              gl_FragColor = vec4(col, 1.0);
            }
          `
        });
        this.skyScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), skyMat));

        // Low-res RenderTarget + DepthTexture + 90-Colour OKLab Post-Process Pass
        const palTex = createPaletteTextures();
        this.postScene = new THREE.Scene();
        this.postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        this.hasDepthTex = Boolean(
          this.renderer.capabilities.isWebGL2 ||
          this.renderer.extensions.get('WEBGL_depth_texture')
        );

        this.postUniforms = {
          tColor:     { value: null },
          tDepth:     { value: null },
          uPalRgbTex: { value: palTex.rgbTex },
          uPalLabTex: { value: palTex.labTex },
          uBayerTex:  { value: palTex.bayerTex },
          uRes:       { value: new THREE.Vector2(320, 200) },
          uOutlines:  { value: 1.0 },
          uDither:    { value: 1.0 },
          uHasDepth:  { value: this.hasDepthTex ? 1.0 : 0.0 }
        };

        const postMat = new THREE.ShaderMaterial({
          depthWrite: false,
          depthTest: false,
          uniforms: this.postUniforms,
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = vec4(position.xy, 0.0, 1.0);
            }
          `,
          fragmentShader: `
            precision highp float;
            varying vec2 vUv;
            uniform sampler2D tColor;
            uniform sampler2D tDepth;
            uniform sampler2D uPalRgbTex;
            uniform sampler2D uPalLabTex;
            uniform sampler2D uBayerTex;
            uniform vec2 uRes;
            uniform float uOutlines;
            uniform float uDither;
            uniform float uHasDepth;

            vec3 srgbToLin(vec3 c) {
              vec3 lo = c / 12.92;
              vec3 hi = pow(max((c + 0.055) / 1.055, vec3(0.0)), vec3(2.4));
              return mix(lo, hi, step(vec3(0.04045), c));
            }

            vec3 rgbToOklab(vec3 c) {
              vec3 lin = srgbToLin(clamp(c, 0.0, 1.0));
              float l = pow(max(0.4122214708 * lin.r + 0.5363325363 * lin.g + 0.0514459929 * lin.b, 0.0), 0.33333333);
              float m = pow(max(0.2119034982 * lin.r + 0.6806995451 * lin.g + 0.1073969566 * lin.b, 0.0), 0.33333333);
              float s = pow(max(0.0883024619 * lin.r + 0.2817188376 * lin.g + 0.6299787005 * lin.b, 0.0), 0.33333333);
              return vec3(
                0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
                1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
                0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s
              );
            }

            void main() {
              vec2 px = floor(vUv * uRes);
              vec2 uv = (px + 0.5) / uRes;
              vec2 texel = 1.0 / uRes;

              vec3 col = texture2D(tColor, uv).rgb;

              // Orthographic depth-based outlines (deep navy ink)
              if (uOutlines > 0.5 && uHasDepth > 0.5) {
                float dC = texture2D(tDepth, uv).r;
                float dL = texture2D(tDepth, uv + vec2(-texel.x, 0.0)).r;
                float dR = texture2D(tDepth, uv + vec2( texel.x, 0.0)).r;
                float dU = texture2D(tDepth, uv + vec2(0.0,  texel.y)).r;
                float dD = texture2D(tDepth, uv + vec2(0.0, -texel.y)).r;
                // Only outline foreground silhouette / sharp convex jumps
                float jump = max(max(dL - dC, dR - dC), max(dU - dC, dD - dC));
                float edge = step(0.0095, jump) * step(dC, 0.999);
                col = mix(col, vec3(0.055, 0.095, 0.175), edge * 0.84);
              }

              // Convert to OKLab and apply 4x4 Bayer ordered dithering
              vec3 lab = rgbToOklab(col);
              if (uDither > 0.5) {
                float bayer = texture2D(uBayerTex, (px + 0.5) / 4.0).r - 0.5;
                lab.x += bayer * 0.048;
                lab.yz += bayer * 0.016;
              }

              // Snap to nearest of fixed 90-colour palette in OKLab space
              vec3 bestRgb = vec3(0.0);
              float bestDist = 1e9;
              for (int i = 0; i < 90; i++) {
                float u = (float(i) + 0.5) / 90.0;
                vec3 enc = texture2D(uPalLabTex, vec2(u, 0.5)).rgb;
                vec3 pLab = vec3(enc.r, (enc.g - 0.5) * 0.8, (enc.b - 0.5) * 0.8);
                vec3 diff = lab - pLab;
                float d2 = diff.x * diff.x * 1.15 + diff.y * diff.y + diff.z * diff.z;
                if (d2 < bestDist) {
                  bestDist = d2;
                  bestRgb = texture2D(uPalRgbTex, vec2(u, 0.5)).rgb;
                }
              }

              gl_FragColor = vec4(bestRgb, 1.0);
            }
          `
        });
        this.postScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), postMat));
      }

      createLowResTarget(w, h) {
        if (this.rt) {
          if (this.rt.depthTexture) this.rt.depthTexture.dispose();
          this.rt.dispose();
        }
        const opts = {
          minFilter: THREE.NearestFilter,
          magFilter: THREE.NearestFilter,
          format: THREE.RGBAFormat,
          type: THREE.UnsignedByteType,
          depthBuffer: true,
          stencilBuffer: false
        };
        if (this.hasDepthTex) {
          opts.depthTexture = new THREE.DepthTexture(w, h);
          opts.depthTexture.format = THREE.DepthFormat;
          opts.depthTexture.type = THREE.UnsignedShortType;
        }
        this.rt = new THREE.WebGLRenderTarget(w, h, opts);
        this.postUniforms.tColor.value = this.rt.texture;
        this.postUniforms.tDepth.value = this.hasDepthTex ? this.rt.depthTexture : null;
        this.postUniforms.uRes.value.set(w, h);
      }
}
