# INTEGRATION

Needs: THREE r128 (global), a `clamp(v,a,b)` helper, and the ArenaRenderer fields referenced in the excerpt (this.renderer, this.canvas, this.pixelSize, this.enableOutlines, this.enableDither, this.postUniforms). The palette (PALETTE_HEX, 90 entries) can be swapped. `createPaletteTextures()` returns {rgbTex, labTex, bayerTex}.
