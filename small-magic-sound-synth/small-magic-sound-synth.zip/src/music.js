// The title's music: one piece, played round and round while the title is up, faded out as a game is gone into and
// in again on coming back. It is a plain <audio>, not the game's own sound: a piece is minutes long, and is better
// played as it arrives than held whole in memory. A page may make no sound until a key or a click: until then it
// waits (`wake`).
// The pieces are by Kevin MacLeod (incompetech.com), CC BY 4.0, from Patch's library; see CREDITS.md.
//   level   how loud each is played, so that they are about as loud as one another
export const PIECES = [
  { id: 'achaidh', name: 'Achaidh Cheide', file: 'achaidh-cheide.ogg', level: 0.5 },
  { id: 'valley', name: 'Enchanted Valley', file: 'enchanted-valley.ogg', level: 0.58 },
  { id: 'evening', name: 'Evening Fall', file: 'evening-fall.ogg', level: 0.75 },
];

export function createMusic({ base = 'music/' } = {}) {
  const a = new Audio();
  a.loop = true; a.preload = 'none'; a.volume = 0;
  let piece = PIECES[0], want = false, off = false, quiet = false, hidden = false, waiting = false, last = performance.now();
  const should = () => want && !off && !quiet && !hidden;
  const begin = () => { waiting = false; a.play().catch(() => { waiting = true; }); };
  // (in and out over a second or two, never cut; stopped once it is silent)
  setInterval(() => {
    const now = performance.now(), dt = Math.min(0.2, (now - last) / 1000); last = now;
    const to = should() ? piece.level : 0, v = a.volume;
    if (to > v) { if (a.paused && !waiting) begin(); a.volume = Math.min(to, v + dt / 1.6 * piece.level); }
    else if (to < v) a.volume = Math.max(to, v - dt / 1.1 * piece.level);
    else if (to === 0 && !a.paused) a.pause();
  }, 40);
  const load = () => { a.src = base + piece.file; a.currentTime = 0; };
  load();
  return {
    pieces: PIECES,
    get piece() { return piece.id; },
    /** Which piece: it begins again from its beginning. */
    set piece(id) { const p = PIECES.find((x) => x.id === id) ?? PIECES[0]; if (p === piece) return; piece = p; a.pause(); a.volume = 0; load(); },
    /** Whether it should be playing (the title is up). */
    get on() { return want; }, set on(v) { want = Boolean(v); },
    /** Turned off in the settings; and silenced with all other sound. */
    set off(v) { off = Boolean(v); }, set quiet(v) { quiet = Boolean(v); },
    set hidden(v) { hidden = Boolean(v); },
    /** A key or a click has been made: a page may now make sound. */
    wake() { if (waiting && should()) begin(); },
    get playing() { return !a.paused; },
    /** For the checks: what is playing, how far in, and how loud. */
    get state() { return { file: a.src.split('/').pop(), at: a.currentTime, volume: a.volume, paused: a.paused }; },
  };
}
